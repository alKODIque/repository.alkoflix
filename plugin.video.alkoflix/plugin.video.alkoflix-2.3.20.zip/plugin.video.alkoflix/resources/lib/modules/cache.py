# -*- coding: utf-8 -*-
# plugin.video.alkoflix
# resources/lib/modules/cache.py

from modules import kodi_utils
from modules.maintenance_log import start as maintenance_start, record as maintenance_record
# logger = kodi_utils.logger

ls = kodi_utils.local_string
navigator_db = kodi_utils.navigator_db
watched_db = kodi_utils.watched_db
favourites_db = kodi_utils.favourites_db
views_db = kodi_utils.views_db
trakt_db = kodi_utils.trakt_db
mdbl_db = kodi_utils.mdbl_db
maincache_db = kodi_utils.maincache_db
metacache_db = kodi_utils.metacache_db
debridcache_db = kodi_utils.debridcache_db
external_db = kodi_utils.external_db
current_dbs = kodi_utils.current_dbs
databases_path = kodi_utils.databases_path
packages_path = kodi_utils.packages_path
database_connect = kodi_utils.database_connect

# Création et validation des bases SQLite utilisées par alkoFlix.
def check_databases():
	# Crée le dossier des bases de données si celui-ci n'existe pas encore.
	if not kodi_utils.path_exists(databases_path): kodi_utils.make_directory(databases_path)
	dbcon = database_connect(navigator_db) # Navigateur
	dbcon.execute("""CREATE TABLE IF NOT EXISTS navigator
					(list_name text, list_type text, list_contents text, unique(list_name, list_type))""")
	dbcon.close()
	dbcon = database_connect(watched_db) # Statut de visionnement
	dbcon.execute("""CREATE TABLE IF NOT EXISTS watched_status
					(db_type text, media_id text, season integer, episode integer, last_played text, title text, unique(db_type, media_id, season, episode))""")
	dbcon.execute("""CREATE TABLE IF NOT EXISTS progress
					(db_type text, media_id text, season integer, episode integer, resume_point text, curr_time text,
					last_played text, resume_id integer, title text, unique(db_type, media_id, season, episode))""")
	# Séries abandonnées du fournisseur local alkoFlix. Cette table reste dans
	# watched.db afin qu'elle suive naturellement les sauvegardes/restaurations
	# du suivi local, sans dépendre d'un cache temporaire.
	dbcon.execute("""CREATE TABLE IF NOT EXISTS dropped_status
					(media_id text primary key, title text, dropped_at text)""")
	dbcon.close()
	dbcon = database_connect(favourites_db) # Favoris
	dbcon.execute("""CREATE TABLE IF NOT EXISTS favourites (db_type text, tmdb_id text, title text, added_at text, unique (db_type, tmdb_id))""")
	dbcon.execute("""CREATE TABLE IF NOT EXISTS favourite_tombstones (db_type text, tmdb_id text, title text, deleted_at text, PRIMARY KEY (db_type, tmdb_id))""")
	try:
		columns = [i[1] for i in dbcon.execute("""PRAGMA table_info(favourites)""").fetchall()]
		if 'added_at' not in columns:
			dbcon.execute("""ALTER TABLE favourites ADD COLUMN added_at text""")
			dbcon.execute("""UPDATE favourites SET added_at = datetime('now', 'localtime') WHERE added_at IS NULL OR added_at = ''""")
	except: pass
	dbcon.close()
	dbcon = database_connect(views_db) # Vues
	dbcon.execute("""CREATE TABLE IF NOT EXISTS views (view_type text, view_id text, unique (view_type))""")
	dbcon.close()
	dbcon = database_connect(maincache_db) # Cache principal
	dbcon.execute("""CREATE TABLE IF NOT EXISTS maincache (id text unique, data text, expires integer)""")
	dbcon.close()
	dbcon = database_connect(metacache_db) # Cache des métadonnées
	dbcon.execute("""CREATE TABLE IF NOT EXISTS metadata
					(db_type text not null, tmdb_id text not null, imdb_id text, tvdb_id text, meta text, expires integer, unique (db_type, tmdb_id))""")
	dbcon.execute("""CREATE TABLE IF NOT EXISTS season_metadata (tmdb_id text not null unique, meta text, expires integer)""")
	dbcon.execute("""CREATE TABLE IF NOT EXISTS function_cache (string_id text not null, data text, expires integer)""")
	dbcon.execute("""CREATE INDEX IF NOT EXISTS alkoflix_select_id_media ON metadata (tmdb_id, db_type)""")
	dbcon.close()
	dbcon = database_connect(debridcache_db) # Cache Debrid
	dbcon.execute("""CREATE TABLE IF NOT EXISTS debrid_data (hash text not null, debrid text not null, cached text, expires integer, unique (hash, debrid))""")
	dbcon.close()
	dbcon = database_connect(external_db) # Cache des providers externes
	dbcon.execute("""CREATE TABLE IF NOT EXISTS results_data
					(provider text, db_type text, tmdb_id text, title text, year integer, season text, episode text, results text,
					expires integer, unique (provider, db_type, tmdb_id, title, year, season, episode))""")
	dbcon.execute("""CREATE TABLE IF NOT EXISTS provider_hashes
					(provider text not null, hash text not null, result text, expires integer, last_seen integer,
					unique(provider, hash))""")
	dbcon.execute("""CREATE TABLE IF NOT EXISTS provider_hash_map
					(provider text not null, db_type text not null, media_id text, title text, year text, season text,
					episode text, hash text not null, expires integer,
					unique(provider, db_type, media_id, title, year, season, episode, hash))""")
	dbcon.execute("""CREATE INDEX IF NOT EXISTS alkoflix_provider_hash_map_media ON provider_hash_map (provider, db_type, media_id, season, episode)""")
	dbcon.execute("""CREATE INDEX IF NOT EXISTS alkoflix_provider_hash_map_title ON provider_hash_map (provider, db_type, title, year, season, episode)""")
	dbcon.execute("""CREATE INDEX IF NOT EXISTS alkoflix_provider_hashes_expire ON provider_hashes (expires)""")
	dbcon.execute("""CREATE INDEX IF NOT EXISTS alkoflix_provider_hash_map_expire ON provider_hash_map (expires)""")
	dbcon.close()
	dbcon = database_connect(trakt_db) # Données Trakt
	dbcon.execute("""CREATE TABLE IF NOT EXISTS trakt_data (id text unique, data text)""")
	dbcon.execute("""CREATE TABLE IF NOT EXISTS watched_status
					(db_type text, media_id text, season integer, episode integer, last_played text, title text, unique(db_type, media_id, season, episode))""")
	dbcon.execute("""CREATE TABLE IF NOT EXISTS progress
					(db_type text, media_id text, season integer, episode integer, resume_point text, curr_time text,
					last_played text, resume_id integer, title text, unique(db_type, media_id, season, episode))""")
	dbcon.close()
	dbcon = database_connect(mdbl_db) # Données MDBList
	dbcon.execute("""CREATE TABLE IF NOT EXISTS mdbl_data (id text unique, data text)""")
	dbcon.execute("""CREATE TABLE IF NOT EXISTS watched_status
					(db_type text, media_id text, season integer, episode integer, last_played text, title text, unique(db_type, media_id, season, episode))""")
	dbcon.execute("""CREATE TABLE IF NOT EXISTS progress
					(db_type text, media_id text, season integer, episode integer, resume_point text, curr_time text,
					last_played text, resume_id integer, title text, unique(db_type, media_id, season, episode))""")
	dbcon.close()

# Supprime uniquement les anciennes bases dont le nom a été validé comme obsolète.
# Le profil contient aussi des fichiers utilisateur, des files de synchronisation,
# des journaux SQLite et des téléchargements en cours : tout fichier inconnu doit
# être conservé, même s'il n'apparaît pas dans current_dbs.
def remove_old_databases():
	# A05 (stabilisation) : aucune ancienne base n'est confirmée comme supprimable
	# automatiquement dans la v2.3.7. Ajouter exclusivement des noms complets de
	# bases .db après vérification de leur migration et de leur non-utilisation.
	obsolete_databases = ()
	if not obsolete_databases: return
	files = kodi_utils.list_dirs(databases_path)[1]
	for item in files:
		if item not in obsolete_databases or item in current_dbs or not item.endswith('.db'):
			continue
		try: kodi_utils.delete_file(databases_path + item)
		except: pass

# Supprime les fichiers SQLite associés à une base donnée, incluant les journaux temporaires.
def _delete_database_files(db_file):
	removed = 0
	for suffix in ('', '-journal', '-wal', '-shm', '.download', '.tmp', '.old'):
		try:
			path = db_file + suffix
			if kodi_utils.path_exists(path):
				kodi_utils.delete_file(path)
				removed += 1
		except: pass
	return removed

# Retire automatiquement les grosses bases locales ALKO quand les fonctions sont désactivées.
def cleanup_disabled_optional_databases():
	removed = 0
	try:
		alko_source_enabled = (str(kodi_utils.get_setting('provider.alkopaste', 'false')).strip().lower() == 'true' or str(kodi_utils.get_setting('results.alkopaste_fallback', 'false')).strip().lower() == 'true')
		if not alko_source_enabled:
			try:
				from magneto.alkopaste import _delete_alkopaste_database_files
				removed += int(_delete_alkopaste_database_files() or 0)
			except:
				removed += _delete_database_files('special://profile/addon_data/plugin.video.alkoflix/alkopaste.db')
	except: pass
	# v2.1.77 : ne jamais supprimer automatiquement la base Catalogue alkoPaste.
	# Le catalogue est désormais natif et doit rester installé pour tous les profils.
	return removed

# Nettoie les anciens paquets ZIP alkoFlix laissés dans le dossier packages de Kodi.
def remove_old_packages():
	files = kodi_utils.list_dirs(packages_path)[1]
	removed = 0
	for item in files:
		if '.alkoflix' in item and item.endswith('zip'):
			try:
				if kodi_utils.delete_file(packages_path + item) is not False: removed += 1
			except: pass
	return removed

# A10 : nettoyage regroupe par base, transactionnel et sans VACUUM systematique.
# Un VACUUM peut durer longtemps et perturber Kodi sur Android, meme quand il
# n'y a aucune ligne expiree. Les pages liberees restent reutilisables par SQLite.
def clean_databases(current_time=None, database_check=True, silent=False):
    started = maintenance_start()
    if not silent and not kodi_utils.confirm_dialog(text=
            'Nettoyer les caches expirés et les anciens ZIP alkoFlix ?[CR][CR]'
            'La taille du cache des métadonnées est aussi limitée si nécessaire. '
            'La base de liens ALKO est retirée seulement si cette source est désactivée. '
            'Vos favoris, menus personnalisés et suivi local sont conservés.', top_space=True):
        maintenance_record('Nettoyer les caches expires', 'annule', started)
        return False
    started = maintenance_start()
    try:
        removed_packages = remove_old_packages()
        remove_old_databases()
        if database_check: check_databases()
        cleanup_disabled_optional_databases()
    except Exception as exc:
        if not silent:
            maintenance_record('Nettoyer les caches expires', 'echec', started, erreur=type(exc).__name__)
            kodi_utils.notification(32574, 1500)
        return False
    current_time = current_time or get_current_time()
    cleanup = (
        (external_db, 'results_data', 'expires'),
        (external_db, 'provider_hashes', 'expires'),
        (external_db, 'provider_hash_map', 'expires'),
        (debridcache_db, 'debrid_data', 'expires'),
        (maincache_db, 'maincache', 'expires'),
        (metacache_db, 'metadata', 'expires'),
        (metacache_db, 'function_cache', 'expires'),
        (metacache_db, 'season_metadata', 'expires'),
    )
    grouped = {}
    for db, table, expires_col in cleanup:
        grouped.setdefault(db, []).append((table, expires_col))
    success, expired_count, processed_dbs = True, 0, 0
    for db, tables in grouped.items():
        dbcon = None
        db_removed = 0
        try:
            dbcon = database_connect(db, timeout=1.5)
            cur = dbcon.cursor()
            for table, expires_col in tables:
                if db == maincache_db and table == 'maincache':
                    from caches.cache_policy import is_persistent_maincache_key
                    rows = cur.execute('SELECT id FROM maincache WHERE CAST(expires AS INT) <= ?', (current_time,)).fetchall()
                    expired = [(row[0], current_time) for row in rows if not is_persistent_maincache_key(row[0])]
                    cur.executemany('DELETE FROM maincache WHERE id = ? AND CAST(expires AS INT) <= ?', expired)
                else:
                    cur.execute('DELETE FROM %s WHERE CAST(%s AS INT) <= ?' %
                                (table, expires_col), (current_time,))
                db_removed += max(0, cur.rowcount)
            dbcon.commit()
            expired_count += db_removed
            processed_dbs += 1
        except Exception as exc:
            if dbcon:
                try: dbcon.rollback()
                except Exception: pass
            success = False
            kodi_utils.logger('alkoFlix cache maintenance skipped', '%s | %s' % (db, exc))
        finally:
            if dbcon:
                try: dbcon.close()
                except Exception: pass
    limit_metacache_database()
    if not silent: kodi_utils.notification(32576 if success else 32574, 1500)
    if not silent:
        maintenance_record('Nettoyer les caches expires', 'termine' if success else 'partiel', started,
                           lignes_expirees_supprimees=expired_count, zip_supprimes=removed_packages,
                           bases_nettoyees=processed_dbs, bases_prevues=len(grouped))
    return success


def limit_metacache_database(max_size=50):
    try:
        with kodi_utils.open_file(metacache_db) as f:
            fsize = f.size()
        if float(fsize) / 1048576 < max_size: return
    except Exception as exc:
        kodi_utils.logger('alkoFlix metacache size unavailable', str(exc))
        return
    dbcon = None
    try:
        dbcon = database_connect(metacache_db, timeout=1.5)
        dbcur = dbcon.cursor()
        dbcur.execute('''DELETE FROM metadata WHERE ROWID IN
                         (SELECT ROWID FROM metadata ORDER BY ROWID DESC LIMIT -1 OFFSET 4000)''')
        dbcur.execute('''DELETE FROM function_cache WHERE ROWID IN
                         (SELECT ROWID FROM function_cache ORDER BY ROWID DESC LIMIT -1 OFFSET 100)''')
        dbcur.execute('''DELETE FROM season_metadata WHERE ROWID IN
                         (SELECT ROWID FROM season_metadata ORDER BY ROWID DESC LIMIT -1 OFFSET 100)''')
        dbcon.commit()
    except Exception as exc:
        if dbcon:
            try: dbcon.rollback()
            except Exception: pass
        kodi_utils.logger('alkoFlix metacache maintenance skipped', str(exc))
    finally:
        if dbcon:
            try: dbcon.close()
            except Exception: pass

# Retourne l'heure courante en timestamp local pour comparer les expirations de cache.
def get_current_time():
	import time, datetime
	return int(time.mktime(datetime.datetime.now().timetuple()))

# Supprime les entrées du cache principal qui correspondent à un préfixe précis.
def _clear_maincache_like(pattern):
	dbcon = None
	try:
		if not kodi_utils.path_exists(maincache_db): return True
		dbcon = database_connect(maincache_db)
		dbcur = dbcon.cursor()
		dbcur.execute("""SELECT id FROM maincache WHERE id LIKE ?""", (pattern,))
		from caches.cache_policy import is_persistent_maincache_key
		remove_list = [str(i[0]) for i in dbcur.fetchall() if not is_persistent_maincache_key(i[0])]
		if remove_list:
			dbcur.executemany("""DELETE FROM maincache WHERE id = ?""", [(key,) for key in remove_list])
			dbcon.commit()
			for item in remove_list: kodi_utils.clear_property(item)
		return True
	except Exception as exc:
		if dbcon is not None: dbcon.rollback()
		kodi_utils.logger('alkoFlix cache clear failed', '%s | %s' % (pattern, exc))
		return False
	finally:
		if dbcon is not None: dbcon.close()

# Nettoie les fichiers temporaires créés par le service de sous-titres Wyzie.
def _clear_wyzie_temp_subtitles():
	try:
		subtitle_path = 'special://temp/'
		for item in kodi_utils.list_dirs(subtitle_path)[1]:
			item_lower = item.lower()
			if item.startswith('alkoFlixSubs_') and item_lower.endswith('.srt'):
				kodi_utils.delete_file('%s%s' % (subtitle_path, item))
		return True
	except: return False

def _format_removed_count(count):
	try: count = int(count or 0)
	except: count = 0
	return count

# Supprime une base locale complète demandée depuis l'onglet Maintenance.
def delete_local_database(database_type, silent=False):
	started = maintenance_start()
	database_type = str(database_type or '').strip().lower()
	if database_type == 'watched_status' and kodi_utils.player.isPlaying():
		if not silent: kodi_utils.notification('Arrêtez la lecture avant de réinitialiser le suivi local.', 2500)
		if not silent: maintenance_record('Reinitialiser le suivi local', 'bloque', started, raison='lecture_en_cours')
		return False
	labels = {
		'alkopaste_catalogue': 'Catalogue alkoPaste',
		'alkopaste_source': 'source ALKO',
		'watched_status': 'statut de visionnage local'
	}
	label = labels.get(database_type, database_type or 'base locale')
	action = 'Reinitialiser le suivi local' if database_type == 'watched_status' else 'Supprimer la base %s' % labels.get(database_type, 'inconnue')
	if not silent:
		text = 'Supprimer la base locale « %s » ?[CR][CR]Elle sera recréée ou retéléchargée seulement si la fonction correspondante est utilisée.' % label
		if database_type == 'watched_status':
			text = 'Effacer tout le suivi personnel local ?[CR][CR]Cela supprime les éléments vus, les positions de reprise et les séries abandonnées stockés localement dans alkoFlix. Les favoris et les données des comptes Trakt/MDBList sont conservés.'
		if not kodi_utils.confirm_dialog(text=text, top_space=True):
			maintenance_record(action, 'annule', started)
			return False
	started = maintenance_start()
	removed = 0
	success = True
	try:
		if database_type == 'alkopaste_catalogue':
			try:
				from magneto.alkopaste import _delete_alkopaste_catalogue_database_files, _clear_alkopaste_catalogue_runtime_cache
				removed = _format_removed_count(_delete_alkopaste_catalogue_database_files())
				try: _clear_alkopaste_catalogue_runtime_cache()
				except: pass
				try:
					from catalogue.catalogs import clear_catalogue_cache
					clear_catalogue_cache()
				except: pass
			except:
				removed = _delete_database_files('special://profile/addon_data/plugin.video.alkoflix/alkopaste_catalogue.db')
		elif database_type == 'alkopaste_source':
			try:
				from magneto.alkopaste import _delete_alkopaste_database_files
				removed = _format_removed_count(_delete_alkopaste_database_files())
			except:
				removed = _delete_database_files('special://profile/addon_data/plugin.video.alkoflix/alkopaste.db')
		elif database_type == 'watched_status':
			# This is personal data, not a disposable SQLite file. Keep the file,
			# journals, local watchlist and any other tables; reset only what the
			# confirmation names, in one transaction.
			check_databases()
			con = database_connect(watched_db)
			try:
				with con:
					for table in ('watched_status', 'progress', 'dropped_status'):
						removed += con.execute('DELETE FROM %s' % table).rowcount
			finally:
				con.close()
			try:
				if 'alkoflix' in kodi_utils.get_infolabel('Container.PluginName').lower(): kodi_utils.container_refresh()
			except: pass
		else:
			success = False
	except:
		success = False
	if not silent:
		if success:
			if database_type == 'watched_status': kodi_utils.notification('Suivi local réinitialisé : %s éléments effacés.' % removed, 2500)
			elif removed: kodi_utils.notification('Base %s supprimée.' % label, 2500)
			else: kodi_utils.notification('Aucune base %s à supprimer.' % label, 2500)
		else: kodi_utils.notification(32574, 1500)
		counts = {'elements_effaces': removed} if database_type == 'watched_status' else {'fichiers_supprimes': removed}
		maintenance_record(action, 'termine' if success else 'echec', started, **counts)
	return success

# Caches temporaires uniquement : les données personnelles restent dans leurs bases dédiées.
CACHE_SCOPES = {
	'meta': 'les métadonnées des films, séries et épisodes',
	'internal_scrapers': 'les résultats des clouds',
	'external_scrapers': 'les résultats des sources et la disponibilité des liens chez les débrideurs',
	'easynews': 'les résultats de recherche Easynews',
	'wyzie': 'les recherches Wyzie et les fichiers de sous-titres temporaires alkoFlix',
	'trakt': 'les données Trakt en cache, qui seront resynchronisées depuis votre compte',
	'mdblist': 'les données MDBList en cache, qui seront resynchronisées depuis votre compte',
	'tmdblist': 'les listes du compte TMDb en cache',
	'tmdb_negative': 'la mémorisation des recherches TMDb sans résultat, pour autoriser une nouvelle tentative',
	'imdb': 'les images et informations publiques IMDb en cache (aucun compte IMDb)',
	'ad_cloud': 'les données AllDebrid en cache : cloud, liens résolus et disponibilité',
	'rd_cloud': 'les données Real-Debrid en cache : cloud, liens résolus et disponibilité',
	'tb_cloud': 'les données TorBox en cache : cloud, liens résolus et disponibilité',
	'navigator': 'les menus générés, en conservant vos menus modifiés et dossiers personnalisés',
	'list': 'les réponses API et listes temporaires, en conservant vos recherches enregistrées et historiques',
}

def clear_cache(cache_type, silent=False):
	started = maintenance_start()
	cache_type = {'menus': 'navigator', 'lists': 'list'}.get(cache_type, cache_type)
	scope = CACHE_SCOPES.get(cache_type)
	if scope is None:
		kodi_utils.logger('alkoFlix cache clear skipped', 'unknown cache type: %s' % cache_type)
		return False
	if not silent:
		text = ('Vider %s ?[CR][CR]Ces données seront récupérées à la prochaine utilisation. '
			'Vos favoris, comptes et suivi personnel local sont conservés.') % scope
		if not kodi_utils.confirm_dialog(text=text, top_space=True):
			maintenance_record('Vider un cache', 'annule', started, categorie=cache_type)
			return False
	started = maintenance_start()
	try:
		success = bool(_clear_cache_data(cache_type, silent=silent))
	except Exception as exc:
		kodi_utils.logger('alkoFlix cache clear failed', '%s | %s: %s' % (cache_type, type(exc).__name__, exc))
		success = False
	kodi_utils.logger('alkoFlix cache clear', '%s | success=%s' % (cache_type, success))
	if not silent: kodi_utils.notification(32576 if success else 32574, 1500)
	if not silent: maintenance_record('Vider un cache', 'termine' if success else 'echec', started, categorie=cache_type)
	return success


def _clear_cache_data(cache_type, silent=False):
	success = True
	if cache_type == 'meta':
		from caches.meta_cache import MetaCache
		success = MetaCache().delete_all()
	elif cache_type == 'internal_scrapers':
		items = 'ad_cloud', 'rd_cloud', 'tb_cloud'
		results = [clear_cache(item, silent=True) for item in items]
		success = all(results)
	elif cache_type == 'external_scrapers':
		from caches.providers_cache import ExternalProvidersCache
		from caches.debrid_cache import DebridCache
		data = ExternalProvidersCache().delete_cache()
		debrid_cache = DebridCache().clear_database()
		success = (data, debrid_cache) == ('success', 'success')
	elif cache_type == 'easynews':
		from debrids.easynews_api import clear_media_results_database
		success = clear_media_results_database() == 'success'
	elif cache_type == 'wyzie':
		cache_success = _clear_maincache_like('subtitles_wyzie_%')
		temp_success = _clear_wyzie_temp_subtitles()
		success = cache_success and temp_success
	elif cache_type == 'trakt':
		from caches.trakt_cache import clear_all_trakt_cache_data
		success = clear_all_trakt_cache_data(reason='manual_cache_clear')
		try:
			if not silent and 'alkoflix' in kodi_utils.get_infolabel('Container.PluginName').lower(): kodi_utils.container_refresh()
		except: pass
	elif cache_type == 'mdblist':
		from indexers.mdblist_api import clear_mdbl_cache
		from caches.mdbl_cache import clear_all_mdbl_cache_data
		public_success = clear_mdbl_cache()
		account_success = clear_all_mdbl_cache_data()
		success = public_success and account_success
	elif cache_type == 'tmdblist':
		from indexers.tmdb_api import clear_tmdbl_cache
		success = clear_tmdbl_cache()
	elif cache_type == 'tmdb_negative':
		from indexers.tmdb_api import clear_tmdb_negative_cache
		success = clear_tmdb_negative_cache()
	elif cache_type == 'imdb':
		from indexers.imdb_api import clear_imdb_cache
		success = clear_imdb_cache()
	elif cache_type == 'ad_cloud':
		from debrids.alldebrid_api import AllDebridAPI
		success = AllDebridAPI().clear_cache()
	elif cache_type == 'rd_cloud':
		from debrids.real_debrid_api import RealDebridAPI
		success = RealDebridAPI().clear_cache()
	elif cache_type == 'tb_cloud':
		from debrids.torbox_api import TorBoxAPI
		success = TorBoxAPI().clear_cache()
	elif cache_type in ('navigator', 'menus'):
		from caches.navigator_cache import navigator_cache
		stats = navigator_cache.clear_menu_cache()
		success = bool(stats and stats.get('success', False))
		try:
			if not silent and 'alkoflix' in kodi_utils.get_infolabel('Container.PluginName').lower(): kodi_utils.container_refresh()
		except: pass
	elif cache_type in ('list', 'lists'):
		from caches.main_cache import MainCache
		success = MainCache().delete_all_lists()
	else:
		success = False
		try: kodi_utils.logger('clear cache skipped', 'unknown cache type: %s' % cache_type)
		except: pass
	return success

# Liste les caches propres au fonctionnement interne de l'addon.
def _internal_cache_items():
	return [
		('meta', 'Métadonnées'),
		('imdb', 'Informations publiques IMDb'),
		('navigator', 'Menus générés'),
		('list', '%s %s' % (ls(32815), ls(32524))),
		# Seul le cache des menus générés est vidé; la base navigator.db est conservée.
		('external_scrapers', 'Résultats des sources'),
		('tmdb_negative', 'Recherches TMDb sans résultat')
	]

# Liste les caches liés aux services connectés ou externes configurés par l'utilisateur.
def _service_cache_items():
	from modules.debrid import debrid_enabled
	enabled_debrids = debrid_enabled()
	caches = []
	if kodi_utils.get_setting('trakt_user') not in ('', None):
		caches.append(('trakt', ls(32087)))
	if kodi_utils.get_setting('mdblist.access_token') not in ('', None) or kodi_utils.get_setting('mdblist.token') not in ('', None):
		caches.append(('mdblist', 'MDBList'))
	if kodi_utils.get_setting('tmdb.token') not in ('', None) or kodi_utils.get_setting('tmdb.session_id') not in ('', None):
		caches.append(('tmdblist', 'TMDbLists'))
	if kodi_utils.get_setting('subtitles.apikey') not in ('', None):
		caches.append(('wyzie', 'Wyzie'))
	if 'alldebrid' in enabled_debrids:
		caches.append(('ad_cloud', ls(32063)))
	if 'real-debrid' in enabled_debrids:
		caches.append(('rd_cloud', ls(32054)))
	if 'torbox' in enabled_debrids:
		caches.append(('tb_cloud', 'TorBox'))
	return caches

# Une confirmation et un résultat pour chaque lot, avec annulation entre deux caches.
def _clear_cache_batch(caches, action='Vider les caches'):
	started = maintenance_start()
	if not caches:
		kodi_utils.notification('Aucun service connecté à nettoyer.', 2000)
		maintenance_record(action, 'termine', started, caches_traites=0)
		return True
	labels = ', '.join(label for _, label in caches)
	text = ('Vider les caches suivants ?[CR]%s[CR][CR]'
		'Les données seront récupérées à la prochaine utilisation. '
		'Vos favoris, comptes et suivi personnel local sont conservés.') % labels
	if not kodi_utils.confirm_dialog(text=text, top_space=True):
		maintenance_record(action, 'annule', started, caches_traites=0)
		return False
	started = maintenance_start()
	completed, failed = True, []
	processed = []
	kodi_utils.progressDialog.create('alkoFlix', '')
	try:
		for count, (cache_type, cache_label) in enumerate(caches, 1):
			if kodi_utils.progressDialog.iscanceled():
				completed = False
				break
			kodi_utils.progressDialog.update(int(count / len(caches) * 100), cache_label)
			if not clear_cache(cache_type, silent=True): failed.append(cache_type)
			processed.append(cache_type)
	except Exception as exc:
		failed.append('execution')
		kodi_utils.logger('alkoFlix cache batch failed', type(exc).__name__)
	finally:
		kodi_utils.progressDialog.close()
	kodi_utils.logger('alkoFlix cache batch', 'completed=%s | failed=%s' % (completed, ','.join(failed) or 'none'))
	if not completed: kodi_utils.notification('Nettoyage interrompu.', 2000)
	elif failed: kodi_utils.notification('Certains caches n’ont pas pu être vidés. Voir le journal Kodi.', 3000)
	else: kodi_utils.notification(32576, 1500)
	outcome = 'partiel' if failed else ('termine' if completed else 'annule')
	maintenance_record(action, outcome, started, caches_traites=len(processed), caches_prevus=len(caches),
		categories=','.join(processed) or 'aucune', echecs=','.join(failed) or 'aucun')
	try:
		if 'alkoflix' in kodi_utils.get_infolabel('Container.PluginName').lower(): kodi_utils.container_refresh()
	except Exception: pass
	return completed and not failed


def clear_internal_cache():
	return _clear_cache_batch(_internal_cache_items(), 'Vider les caches de navigation et de recherche')


def clear_services_cache():
	return _clear_cache_batch(_service_cache_items(), 'Vider les caches des services connectes')


def clear_all_cache():
	return _clear_cache_batch(_internal_cache_items() + _service_cache_items(), 'Vider tous les caches temporaires')
