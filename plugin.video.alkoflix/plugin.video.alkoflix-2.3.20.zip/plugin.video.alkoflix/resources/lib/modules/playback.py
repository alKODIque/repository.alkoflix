# -*- coding: utf-8 -*-
"""Invocation-local Kodi playback contract (Omega 21 / Piers 22).

Native playable plugin calls must answer their own handle exactly once.
RunPlugin/service/thread calls have no resolver handle: Player.play is the
supported command API. A fallback after an answered handle is a new playback
command, never a second answer to that old handle. No global handle is retained.
"""
from contextlib import contextmanager
from threading import local
from urllib.parse import parse_qsl, urlencode, urlsplit

from modules import kodi_utils as ku

_STATE = local()
_CLOUD_MODES = frozenset(('alldebrid.resolve_ad', 'real_debrid.resolve_rd',
                          'torbox.resolve_tb', 'easynews.resolve_easynews'))


def is_playback(params):
    mode = params.get('mode')
    return (mode in ('play_media', 'tmdbh_play', 'tmdbh_select', 'media_play')
            or (mode in _CLOUD_MODES and params.get('play') == 'true'))


def mark_item(url, item, is_folder):
    """Mark only playable alkoFlix routes, never actions/info/folders/other add-ons."""
    if is_folder or not isinstance(url, str) or not url.startswith('plugin://plugin.video.alkoflix'):
        return url
    parsed = urlsplit(url)
    if parsed.scheme != 'plugin' or parsed.netloc != 'plugin.video.alkoflix':
        return url
    params = dict(parse_qsl(parsed.query, keep_blank_values=True))
    if not is_playback(params):
        return url
    item.setProperty('IsPlayable', 'true')
    item.setProperty('ForceResolvePlugin', 'true')
    item.setProperty('OverrideInfotag', 'true')
    # Native Play/Resume has already been chosen by Kodi for these items.
    if params.get('mode') == 'play_media':
        params['_kodi_resume'] = 'true'
        url = 'plugin://plugin.video.alkoflix/?' + urlencode(params)
    return url


class Request:
    def __init__(self, handle, params, resume=False):
        self.handle = handle
        self.params = params
        self.resume = resume
        self.completed = False

    def resolve(self, item, success=True):
        if self.completed:
            raise RuntimeError('plugin handle already answered')
        self.completed = True
        ku.xbmcplugin.setResolvedUrl(self.handle, success, item)
        ku.logger('Résolution Kodi', 'handle=%s | %s' % (
            self.handle, 'URL remise à Kodi' if success else 'Demande terminée sans lecture'), level='info')


@contextmanager
def plugin_request(argv):
    previous = getattr(_STATE, 'request', None)
    request = None
    try:
        handle = int(argv[1])
        params = dict(parse_qsl(argv[2].lstrip('?'), keep_blank_values=True))
        if handle >= 0 and is_playback(params):
            request = Request(handle, params, len(argv) > 3 and argv[3] == 'resume:true')
    except (IndexError, TypeError, ValueError):
        pass
    _STATE.request = request
    try:
        yield request
    finally:
        try:
            if request is not None and not request.completed:
                request.resolve(ku.make_listitem(), False)
        finally:
            _STATE.request = previous


def current_request():
    return getattr(_STATE, 'request', None)


def native_resume_choice():
    request = current_request()
    if request is not None and not request.completed:
        if request.resume or request.params.get('_kodi_resume') == 'true':
            return request.resume
    return None


def start(url, item, player=None):
    """Use the resolver callback when one is expected, otherwise a playback command."""
    if not isinstance(url, str) or not url.strip():
        raise ValueError('empty playback URL')
    item.setPath(url)
    item.setProperty('IsPlayable', 'true')
    request = current_request()
    if request is not None and not request.completed:
        request.resolve(item)
        return 'resolved'
    (player if player is not None else ku.player).play(url, item)
    reason = 'handle déjà répondu : lien de secours ou épisode suivant' if request is not None else 'service ou commande sans handle'
    ku.logger('Résolution Kodi', 'Player.play | %s' % reason, level='info')
    return 'command'


def play_url(url):
    """Cloud/direct files have no invented movie/episode scrobbling."""
    if not url:
        ku.logger('Résolution Kodi', 'URL absente : lecture non lancée', level='warning')
        return False
    start(url, ku.make_listitem())
    return True
