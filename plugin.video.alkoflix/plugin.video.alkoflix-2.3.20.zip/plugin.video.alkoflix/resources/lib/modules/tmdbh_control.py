# -*- coding: utf-8 -*-
# plugin.video.alkoflix
# resources/lib/modules/tmdbh_control.py
# © Les alKODIques

from pathlib import Path
import xbmcvfs
from modules import kodi_utils

TMDBH_ADDON_ID = 'plugin.video.themoviedb.helper'


def _confirm_tmdbh_action(enabled):
	if enabled:
		text = (
			'Cette action va réactiver [B]TMDb Helper[/B].[CR][CR]'
			'Certains skins et widgets l’utilisent pour leurs propres contenus, informations et images.[CR][CR]'
			'Voulez-vous continuer ?'
		)
	else:
		text = (
			'Cette action va désactiver [B]TMDb Helper[/B].[CR][CR]'
			'Attention : TMDb Helper est une extension externe souvent utilisée par les skins, '
			'les widgets et certains raccourcis. Si vous la désactivez, certains widgets du skin '
			'peuvent se vider ou perdre leurs images.[CR][CR]'
			'alkoFlix ne dépend pas directement de son service pour sa navigation interne, '
			'mais cette option doit rester un choix volontaire.[CR][CR]'
			'Voulez-vous continuer ?'
		)
	return kodi_utils.confirm_dialog(text=text, ok_label='Oui', cancel_label='Non', top_space=True)



def _tmdbh_clean_value(value):
	"""Nettoie les placeholders TMDb Helper absents (ex. ``_``)."""
	try:
		text = str(value if value is not None else '').strip()
	except Exception:
		return ''
	if text.lower() in ('', '_', 'none', 'null', 'undefined'):
		return ''
	return text


def _tmdbh_positive_int(value):
	try:
		text = _tmdbh_clean_value(value)
		if not text: return None
		number = int(float(text))
		return number if number > 0 else None
	except Exception:
		return None


def _tmdbh_season(value):
	# Kodi/TMDb use season 0 for specials. Episodes must still be positive.
	try:
		text = _tmdbh_clean_value(value)
		if not text: return None
		number = int(text)
		return number if number >= 0 else None
	except (TypeError, ValueError):
		return None


def _tmdbh_first_label(*labels):
	"""Retourne le premier InfoLabel Kodi non vide encore disponible.

	Lors d'un clic sur une liste aplatie TMDb Helper (calendrier, épisodes
	récents, etc.), les numéros S/E existent sur le ListItem Kodi mais peuvent
	ne pas être propagés jusque dans les placeholders du player JSON.
	"""
	for label in labels:
		try:
			value = _tmdbh_clean_value(kodi_utils.get_infolabel(label))
			if value: return value
		except Exception:
			pass
	return ''


def _tmdbh_gui_location():
	"""Diagnostic IDs only; never log source URLs or a saved GUI selection."""
	try:
		gui = kodi_utils.xbmcgui
		return 'fenêtre=%s | dialogue=%s' % (
			int(gui.getCurrentWindowId()), int(gui.getCurrentWindowDialogId()))
	except Exception:
		return 'fenêtre=? | dialogue=?'


def _tmdbh_uncover_calendar():
	"""Read the calendar behind Kodi's busy overlay, without changing focus.

	In a custom skin hub, Kodi's default InfoLabel context can select the
	modal busy dialog instead of the focused widget (GUIInfoHelper.cpp).
	TMDb Helper closes this overlay in PlayerResolver.execute(), but that is
	after its directory steps. Close only these two busy dialogs here, waiting
	for the GUI command to complete before reading ListItem. Other dialogs,
	widgets and the parent resolution handle are left to their owner.
	"""
	before = _tmdbh_gui_location()
	closed = []
	for name in ('busydialognocancel', 'busydialog'):
		try:
			if not kodi_utils.get_visibility('Window.IsVisible(%s)' % name):
				continue
			# The second argument waits for execution, while `true` forces the
			# dialog to close without its animation. Neither cancels the script.
			kodi_utils.xbmc.executebuiltin('Dialog.Close(%s,true)' % name, True)
			closed.append(name)
		except Exception:
			pass
	kodi_utils.logger('TMDb Helper', 'Récupération calendrier | %s | attentes fermées=%s | après %s' % (
		before, ','.join(closed) or 'aucune', _tmdbh_gui_location()), level='info')


def _tmdbh_recover_episode_context(params):
	"""Répare les paramètres d'un player TMDbH lancé depuis une liste d'épisodes.

	TMDb Helper peut ouvrir son player avec ``{season}`` / ``{episode}`` vides
	quand les épisodes proviennent d'une liste aplatie (par ex. calendrier) au
	lieu de l'arborescence Série > Saison > Épisode. Le ListItem Kodi affiché
	conserve néanmoins ces InfoLabels. On les relit donc avant de lancer le
	pipeline alkoFlix.
	"""
	play_params = dict(params or {})
	media_type = _tmdbh_clean_value(play_params.get('media_type')).lower()
	if media_type in ('episodes', 'episode', 'tvshow', 'tv'):
		play_params['media_type'] = 'episode'
	else:
		return play_params

	season = _tmdbh_season(play_params.get('season'))
	episode = _tmdbh_positive_int(play_params.get('episode'))
	needs_context = season is None or episode is None
	if needs_context:
		_tmdbh_uncover_calendar()
		# Prefer the parent show's ID. A bare UniqueId(tmdb) on an episode
		# identifies the episode, so it must not be compared with the show ID.
		target_id = _tmdbh_positive_int(play_params.get('tmdb_id'))
		selected_id = _tmdbh_positive_int(_tmdbh_first_label(
			'ListItem.Property(tvshow.tmdb_id)', 'ListItem.UniqueId(tvshow.tmdb)',
			'ListItem.Property(item.tmdb_id)'))
		if target_id and selected_id and target_id != selected_id:
			kodi_utils.logger('TMDb Helper',
				'Contexte calendrier refusé : autre série sélectionnée | cible=%s | sélection=%s' % (
					target_id, selected_id), level='warning')
			return play_params

	# Les placeholders manquants de TMDb Helper sont souvent remplacés par "_".
	# On les enlève pour éviter un int('_') plus loin dans SourceSelect.
	if season is None: play_params.pop('season', None)
	if not episode: play_params.pop('episode', None)

	if season is None:
		season = _tmdbh_season(_tmdbh_first_label(
			'ListItem.Season', 'ListItem.Property(season)', 'ListItem.Property(season_number)',
			'Container.ListItem.Season'))
	if not episode:
		episode = _tmdbh_positive_int(_tmdbh_first_label(
			'ListItem.Episode', 'ListItem.Property(episode)', 'ListItem.Property(episode_number)',
			'Container.ListItem.Episode'))

	# Dernier repli : certains skins affichent SxxExx dans le label même si les
	# champs numériques n'ont pas été recopiés dans l'URL du player.
	if season is None or not episode:
		try:
			import re
			text = ' '.join(filter(None, (
				_tmdbh_first_label('ListItem.Label', 'ListItem.Label2'),
				_tmdbh_clean_value(play_params.get('ep_name')),
				_tmdbh_clean_value(play_params.get('query')),
			)))
			match = re.search(r'(?i)\bS\s*0*(\d{1,3})\s*E\s*0*(\d{1,4})\b', text)
			if not match:
				match = re.search(r'(?i)\b0*(\d{1,3})\s*[xX]\s*0*(\d{1,4})\b', text)
			if match:
				season = season if season is not None else _tmdbh_season(match.group(1))
				episode = episode or _tmdbh_positive_int(match.group(2))
		except Exception:
			pass

	if season is not None: play_params['season'] = str(season)
	if episode: play_params['episode'] = str(episode)
	if needs_context:
		kodi_utils.logger('TMDb Helper', 'Contexte calendrier lu | tmdb=%s | S%sE%s | %s' % (
			_tmdbh_positive_int(play_params.get('tmdb_id')) or '?',
			season if season is not None else '?', episode or '?', _tmdbh_gui_location()), level='info')

	# Complète aussi les métadonnées utiles à alkoFlix quand le JSON n'a reçu
	# que le contexte de la série.
	fallbacks = {
		'query': ('ListItem.TVShowTitle', 'ListItem.ShowTitle'),
		'ep_name': ('ListItem.Title', 'ListItem.Label'),
		'premiered': ('ListItem.Premiered', 'ListItem.Date'),
		'year': ('ListItem.Year',),
	}
	for key, labels in fallbacks.items():
		if not _tmdbh_clean_value(play_params.get(key)):
			value = _tmdbh_first_label(*labels)
			if value: play_params[key] = value

	if not _tmdbh_clean_value(play_params.get('tmdb_id')):
		tmdb_id = _tmdbh_first_label(
			'ListItem.Property(tmdb_id)',
			'ListItem.UniqueId(tmdb)',
			'ListItem.UniqueId(tvshow.tmdb)',
			'ListItem.Property(tvshow.tmdb)')
		if tmdb_id: play_params['tmdb_id'] = tmdb_id

	try:
		kodi_utils.logger('TMDb Helper episode context',
			'recovered=%s | tmdb_id=%s | S%sE%s | show=%s | episode=%s' % (
				bool(season is not None and episode), play_params.get('tmdb_id', ''),
				play_params.get('season', ''), play_params.get('episode', ''),
				play_params.get('query', ''), play_params.get('ep_name', '')
			))
	except Exception:
		pass
	return play_params


def prepare_tmdbh_params(params):
	"""Normalise les paramètres reçus des player JSON TMDb Helper."""
	play_params = dict(params or {})
	media_type = _tmdbh_clean_value(play_params.get('media_type')).lower()
	if media_type in ('movies', 'movie'):
		play_params['media_type'] = 'movie'
	elif media_type in ('episodes', 'episode', 'tvshow', 'tv'):
		play_params['media_type'] = 'episode'
		# Le nouveau player a capturé le contexte AVANT le relais setResolvedUrl.
		# Ne jamais le remplacer par le ListItem du lecteur ou d'un autre widget.
		if play_params.get('_tmdbh_prepared') != 'true':
			play_params = _tmdbh_recover_episode_context(play_params)
	return play_params


def prepare_tmdbh_episode(params, handle):
	"""Return one playable URL with fixed S/E before TMDb Helper hands off playback.

	This is a directory endpoint for a TMDb Helper player step, not a resolver.
	No playback, source search, persistent context or cached directory is used.
	"""
	if handle < 0:
		kodi_utils.logger('TMDb Helper', 'Préparation ignorée : appel sans handle de dossier', level='warning')
		return
	succeeded = False
	try:
		play_params = prepare_tmdbh_params(dict(params, media_type='episode'))
		season = _tmdbh_season(play_params.get('season'))
		episode = _tmdbh_positive_int(play_params.get('episode'))
		tmdb_id = _tmdbh_positive_int(play_params.get('tmdb_id'))
		if season is None or episode is None or tmdb_id is None:
			kodi_utils.logger('TMDb Helper', 'Préparation impossible : identité ou saison/épisode absent avant le relais', level='warning')
			kodi_utils.notification('TMDb Helper : saison/épisode absent dans cet élément.', 4000)
			return
		play_params.pop('context_request', None)
		play_params.update({
			'mode': 'tmdbh_play' if play_params.get('autoplay') == 'true' else 'tmdbh_select',
			'media_type': 'episode', 'tmdb_id': str(tmdb_id),
			'season': str(season), 'episode': str(episode), '_tmdbh_prepared': 'true'
		})
		item = kodi_utils.make_listitem()
		item.setLabel('alkoFlix S%02dE%02d' % (season, episode))
		info = item.getVideoInfoTag()
		info.setMediaType('episode')
		info.setSeason(season)
		info.setEpisode(episode)
		kodi_utils.add_item(handle, kodi_utils.build_url(play_params), item, False)
		succeeded = True
		kodi_utils.logger('TMDb Helper', 'Contexte préparé avant relais | tmdb=%s | S%sE%s' % (
			tmdb_id, season, episode), level='info')
		return play_params
	except Exception as exc:
		kodi_utils.logger('TMDb Helper', 'Échec de préparation du contexte | %s' % type(exc).__name__, level='error')
	finally:
		# The same calendar URL can designate a different episode on the next click.
		kodi_utils.xbmcplugin.endOfDirectory(handle, succeeded=succeeded, cacheToDisc=False)


def play_from_tmdbh(params, autoplay=True):
	"""Point d'entrée dédié aux players JSON TMDb Helper.

	Le player « Play » doit lancer une vraie lecture directe, sans dépendre du
	réglage global Lecture auto d'alkoFlix. Le player « Select » force au contraire
	l'ouverture du sélecteur. Dans les deux cas, on redirige ensuite vers
	SourceSelect afin de conserver exactement le même pipeline de lecture, Trakt,
	bookmarks et Up Next que depuis l'addon.

	Depuis la v2.1.31, un épisode lancé depuis une liste TMDb Helper aplatie
	(calendrier, épisodes diffusés aujourd'hui, etc.) récupère aussi SxxExx depuis
	le ListItem Kodi si les placeholders du player JSON sont absents.
	"""
	try:
		play_params = prepare_tmdbh_params(params)
		play_params['mode'] = 'play_media'
		play_params['tmdbh_player'] = 'true'
		play_params['autoplay'] = 'true' if autoplay else 'false'
		# Valeur explicite pour éviter tout vieux paramètre False/True mal interprété
		# venant d'un JSON installé manuellement dans TMDb Helper.
		if autoplay:
			play_params['force_play'] = 'true'
		else:
			play_params['force_select'] = 'true'

		if play_params.get('media_type') == 'episode':
			season = _tmdbh_season(play_params.get('season'))
			episode = _tmdbh_positive_int(play_params.get('episode'))
			if season is None or not episode:
				kodi_utils.logger('TMDb Helper', 'Épisode incomplet | saison/épisode introuvable', level='warning')
				return kodi_utils.notification(
					'TMDb Helper : saison/épisode introuvable pour cet élément.', 4000)

		kodi_utils.logger('TMDb Helper', 'Demande | mode=%s | média=%s | tmdb=%s | S%sE%s' % (
			'Play' if autoplay else 'Select',
			play_params.get('media_type'), play_params.get('tmdb_id'),
			play_params.get('season', ''), play_params.get('episode', '')
		), level='info')
		from modules.sources import SourceSelect
		return SourceSelect.factory(play_params)
	except Exception as e:
		try: kodi_utils.logger('TMDb Helper', 'Échec de démarrage | %s' % type(e).__name__, level='error')
		except: pass
		try: kodi_utils.notification('TMDb Helper : lecture alkoFlix impossible.', 4000)
		except: pass


def options_from_tmdbh(params):
	"""Ouvre le menu Options avec la même récupération S/E que les players Play/Select."""
	try:
		play_params = prepare_tmdbh_params(params)
		if play_params.get('media_type') == 'episode':
			season = _tmdbh_season(play_params.get('season'))
			episode = _tmdbh_positive_int(play_params.get('episode'))
			if season is None or not episode:
				return kodi_utils.notification(
					'TMDb Helper : saison/épisode introuvable pour cet élément.', 4000)
			play_params['content'] = 'episode'
		elif play_params.get('media_type') == 'movie':
			play_params['content'] = 'movie'
		from modules import dialogs
		return dialogs.options_menu(play_params)
	except Exception as e:
		try: kodi_utils.logger('TMDb Helper', 'Échec du menu Options | %s' % type(e).__name__, level='error')
		except: pass
		try: kodi_utils.notification('TMDb Helper : options alkoFlix impossibles.', 4000)
		except: pass


def set_tmdbh_enabled(enabled=False):
	if not kodi_utils.addon_installed(TMDBH_ADDON_ID):
		return kodi_utils.notification('TMDb Helper n’est pas installé.', 4000)
	if not _confirm_tmdbh_action(enabled):
		return
	ok = kodi_utils.set_addon_enabled(TMDBH_ADDON_ID, bool(enabled))
	if not ok:
		return kodi_utils.notification('Impossible de modifier TMDb Helper.', 4000)
	state = 'réactivé' if enabled else 'désactivé'
	text = 'TMDb Helper a été %s.[CR][CR]Un redémarrage de Kodi est recommandé pour que le changement soit totalement propre.[CR][CR]Voulez-vous redémarrer Kodi maintenant ?' % state
	restart = kodi_utils.dialog.yesno('alkoFlix', text, 'Plus tard', 'Redémarrer')
	if restart: kodi_utils.execute_builtin('RestartApp')
	else: kodi_utils.notification('TMDb Helper %s. Redémarrez Kodi plus tard.' % state, 4000)


def _delete_path(path):
	files_deleted, dirs_deleted = 0, 0
	try:
		if not path.exists(): return files_deleted, dirs_deleted
		if path.is_dir():
			for child in path.iterdir():
				f, d = _delete_path(child)
				files_deleted += f
				dirs_deleted += d
			try:
				path.rmdir()
				dirs_deleted += 1
			except Exception as e:
				kodi_utils.logger('TMDb Helper cache rmdir skipped', '%s | %s' % (path, e))
		else:
			try:
				path.unlink(missing_ok=True)
				files_deleted += 1
			except Exception as e:
				kodi_utils.logger('TMDb Helper cache file skipped', '%s | %s' % (path, e))
	except Exception as e:
		kodi_utils.logger('TMDb Helper cache path skipped', '%s | %s' % (path, e))
	return files_deleted, dirs_deleted


def clear_tmdbh_cache():
	if not kodi_utils.addon_installed(TMDBH_ADDON_ID):
		return kodi_utils.notification('TMDb Helper n’est pas installé.', 4000)
	text = (
		'Cette action va vider les bases/cache de [B]TMDb Helper[/B].[CR][CR]'
		'Cela ne touche pas aux caches internes d’alkoFlix. Kodi/TMDb Helper reconstruira ses données au besoin.[CR][CR]'
		'Voulez-vous continuer ?'
	)
	if not kodi_utils.confirm_dialog(text=text, ok_label='Oui', cancel_label='Non', top_space=True):
		return
	progress = kodi_utils.progressDialog
	files_deleted, dirs_deleted = 0, 0
	try:
		progress.create('alkoFlix', 'Vidage du cache TMDb Helper...')
		progress.update(25, 'Recherche des dossiers TMDb Helper...')
	except: pass
	paths = []
	try:
		base = Path(xbmcvfs.translatePath('special://profile/addon_data/%s' % TMDBH_ADDON_ID))
		for name in ('database', 'database_07', 'cache'):
			p = base / name
			if p.exists(): paths.append(p)
	except Exception as e:
		kodi_utils.logger('TMDb Helper cache path error', e)
	try: progress.update(55, 'Suppression du cache TMDb Helper...')
	except: pass
	for p in paths:
		f, d = _delete_path(p)
		files_deleted += f
		dirs_deleted += d
	try:
		progress.update(100, 'Cache TMDb Helper vidé.')
		kodi_utils.sleep(700)
		progress.close()
	except: pass
	kodi_utils.logger('TMDb Helper cache clear done', 'files_deleted=%s | dirs_deleted=%s' % (files_deleted, dirs_deleted))
	text = 'Cache TMDb Helper vidé : %s fichiers et %s dossiers supprimés quand Kodi le permet.[CR][CR]Un redémarrage de Kodi est recommandé.[CR][CR]Voulez-vous redémarrer Kodi maintenant ?' % (files_deleted, dirs_deleted)
	restart = kodi_utils.dialog.yesno('alkoFlix', text, 'Plus tard', 'Redémarrer')
	if restart: kodi_utils.execute_builtin('RestartApp')
	else: kodi_utils.notification('Cache TMDb Helper vidé. Redémarrez Kodi plus tard.', 4000)
