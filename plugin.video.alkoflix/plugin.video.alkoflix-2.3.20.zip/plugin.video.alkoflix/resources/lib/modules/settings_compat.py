"""Compatibility rules shared by settings imports and retired native sources."""

RETIRED_NATIVE_PROVIDERS = frozenset((
    'mediafusion', 'piratebay', 'hydracker', 'ygg', 'torr9', 'movix',
    'zone_telechargement',
))

RETIRED_SETTING_IDS = frozenset((
    'provider.zone_telechargement', 'results.zone_telechargement_fallback',
    'hoster.zone_telechargement.url',
    'auto_resume_movie', 'auto_resume_episode',
))


def is_retired_setting(setting_id):
    value = str(setting_id or '')
    return value in RETIRED_SETTING_IDS or value.startswith('hoster.zone_telechargement.')


def active_setting_ids():
	return frozenset(active_settings_defaults())


def active_settings_defaults():
    """Fail closed when the installed schema is unavailable during an import."""
    import xml.etree.ElementTree as ET
    from modules import kodi_utils
    path = 'special://home/addons/plugin.video.alkoflix/resources/settings.xml'
    reader = kodi_utils.open_file(path, 'r')
    try:
        content = reader.read()
    finally:
        reader.close()
    root = ET.fromstring(content)
    result = {item.get('id'): str(item.get('default') or '')
              for item in root.iter('setting') if item.get('id')}
    if not result:
        raise ValueError('Le schéma des réglages alkoFlix est vide.')
    return result
