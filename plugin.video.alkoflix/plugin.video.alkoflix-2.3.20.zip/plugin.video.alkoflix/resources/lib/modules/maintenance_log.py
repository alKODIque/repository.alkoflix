"""Compact summaries of explicit maintenance actions, independent of debug mode."""
from time import monotonic
from modules import kodi_utils


def start(action=None):
    started = monotonic()
    if action: record(action, 'debut')
    return started


def record(action, outcome='termine', started=None, **details):
    # Callers provide only category names, counts and fixed reasons: no file
    # paths, source URLs, account identifiers or settings values are logged.
    try:
        parts = [str(action), 'resultat=%s' % outcome]
        if started is not None: parts.append('duree=%.2fs' % max(0, monotonic() - started))
        for key, value in details.items():
            if value is not None: parts.append('%s=%s' % (key, str(value).replace('\n', ' ')[:160]))
        level = 'error' if outcome == 'echec' else ('warning' if outcome == 'partiel' else 'info')
        kodi_utils.logger('Maintenance', ' | '.join(parts), level=level)
    except Exception:
        # Logging must never interrupt maintenance or mask its original error.
        pass


def download(action, function):
    started = start(action)
    try:
        result = function()
    except Exception as exc:
        record(action, 'echec', started, erreur=type(exc).__name__)
        raise
    result_info = result if isinstance(result, dict) else {}
    outcome = 'termine' if result_info.get('ok') else 'echec'
    if result_info.get('reason') == 'disabled': outcome = 'bloque'
    record(action, outcome, started, liens=result_info.get('links'), medias=result_info.get('catalogue'))
    return result
