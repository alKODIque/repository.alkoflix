"""Persistent records sharing maincache.db must survive ordinary cache cleanup."""

SAVED_SEARCH_KEYS = frozenset((
    'alkoflix_tmdb_discover_230_saved',
    'alkoflix_trakt_discover_saved',
))


def is_persistent_maincache_key(key):
    key = str(key or '')
    return (key in SAVED_SEARCH_KEYS or key.endswith('_queries')
            or key.startswith(('alkoflix_discover_', 'migration:')))
