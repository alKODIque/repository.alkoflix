import json
from urllib.parse import parse_qsl
from caches.navigator_cache import navigator_cache
from modules import kodi_utils, menu_lists as default_menus
# from modules.kodi_utils import logger

ls, media_path = kodi_utils.local_string, kodi_utils.media_path
main_list_name_dict = {
	'RootList': ls(32457), 'MovieList': ls(32028), 'TVShowList': ls(32029),
	'DocumentaryList': 'Docus & Télé', 'FamilyList': 'Famille',
	'AnimeList': 'Animés japonais', 'AnimationList': 'Dessins animés',
	'PeopleList': 'Personnes', 'AlkoPasteCatalogueList': 'Catalogue alkoPaste'
}

def _list_name(active_list):
	try:
		return main_list_name_dict[active_list]
	except Exception:
		try:
			item = default_menus.main_menu_items.get(active_list, {})
			name = item.get('name', active_list)
			return ls(name).replace('[B]', '').replace('[/B]', '')
		except Exception:
			return str(active_list or '')

pos_str, top_pos_str, top_str = ls(32707), ls(32708), ls(32709)
folder_icon_default = 'myfolder.png'
menu_icons_base_path = 'special://home/addons/plugin.video.alkoflix/resources/skins/Default/Icones de menu/'
media_icon_extensions = ('.png', '.jpg', '.jpeg', '.webp')

def menu_icons_path(*args):
	return '%s%s' % (menu_icons_base_path, '/'.join(args)) if args else menu_icons_base_path

def _icon_filename(icon):
	icon = str(icon or '').strip()
	if not icon: return ''
	return icon.replace('\\', '/').rstrip('/').split('/')[-1]

class MenuEditor:
	def __init__(self, params):
		self.params = params
		if 'menu_item' in params: self.menu_item = json.loads(params.get('menu_item'))
		else: self.menu_item = dict(parse_qsl(kodi_utils.get_infolabel("ListItem.FileNameAndPath").replace('plugin://plugin.video.alkoflix/?','')))
		self.params_get, self.menu_item_get = self.params.get, self.menu_item.get
		if not self.menu_item: self._make_menu_item()

	def edit_menu(self):
		active_list, position = self.params_get('active_list'), int(self.params_get('position', '0'))
		menu_name = self.menu_item_get('name')
		menu_name_translated = ls(menu_name)
		menu_name_translated_display = menu_name_translated.replace('[B]', '').replace('[/B]', '')
		external_list_item, shortcut_folder = self.menu_item_get('external_list_item', 'False') == 'True', self.menu_item_get('shortcut_folder', 'False') == 'True'
		list_name =  _list_name(active_list)
		listing = []
		if len(active_list) != 1:
			listing.append((ls(32716) % menu_name_translated_display, self.move))
			listing.append((ls(32717) % menu_name_translated_display, self.remove))
		if shortcut_folder:
			listing.append(('Renommer ce dossier', self.shortcut_folder_rename))
			listing.append(('Choisir une icône pour ce dossier', self.shortcut_folder_choose_icon))
			listing.append(('Réinitialiser l’icône de ce dossier', self.shortcut_folder_reset_icon))
		else:
			listing.append((ls(32718) % menu_name_translated_display, self.add_original_external))
			listing.append((ls(32719) % menu_name_translated_display, self.shortcut_folder_add_item))
		listing.append((ls(32721) % list_name, self.add_original))
		listing.append((ls(32725) % list_name, self.shortcut_folder_add_to_main_menu))
		listing.append((ls(32720) % list_name, self.add_trakt))
		listing.append((ls(32722) % list_name, self.restore))
		listing.append((ls(32723) % list_name, self.check_update_list))
		if not external_list_item: listing.append((ls(32724) % menu_name_translated_display, self.reload_menu_item))
		list_items = [{'line1': i[0]} for i in listing]
		kwargs = {'items': json.dumps(list_items), 'heading': 'alkoFlix', 'enumerate': 'false', 'multi_choice': 'false', 'multi_line': 'false'}
		function = kodi_utils.select_dialog([i[1] for i in listing], **kwargs)
		if function is None: return
		self.params = {'active_list': active_list, 'list_name': list_name, 'menu_name': menu_name, 'menu_name_translated': menu_name_translated, 'position': position}
		self.params_get = self.params.get
		return function()

	def edit_menu_shortcut_folder(self):
		listing = [
			('Renommer cette entrée', 'rename_item'),
			('Choisir une icône pour cette entrée', 'choose_icon_item')
		]
		if self.menu_item_get('original_name'):
			listing.append(('Réinitialiser le nom de cette entrée', 'reset_name_item'))
		if self.menu_item_get('original_iconImage'):
			listing.append(('Réinitialiser l’icône de cette entrée', 'reset_icon_item'))
		if self.menu_item_get('mode') == 'navigator.build_shortcut_folder_list':
			listing.extend([
				('Renommer le dossier source', 'rename_folder'),
				('Choisir une icône pour le dossier source', 'choose_icon_folder'),
				('Réinitialiser l’icône du dossier source', 'reset_icon_folder')
			])
		listing.extend([(ls(32712), 'move'), (ls(32713), 'remove'), ('%s %s' % (ls(32671), ls(32129)), 'clear_all')])
		list_items = [{'line1': i[0]} for i in listing]
		kwargs = {'items': json.dumps(list_items), 'heading': 'alkoFlix', 'enumerate': 'false', 'multi_choice': 'false', 'multi_line': 'false'}
		self.action = kodi_utils.select_dialog([i[1] for i in listing], **kwargs)
		if self.action is None: return
		return self.shortcut_folder_contents_adjust()

	def browse(self):
		active_list = self.params_get('active_list')
		list_name =  _list_name(active_list)
		try: choice_items = self._get_removed_items(active_list)
		except: return kodi_utils.notification(32760, 1500)
		browse_item = self._menu_select(choice_items, list_name)
		if browse_item is None: return
		browse_item = choice_items[browse_item]
		if browse_item.get('mode') == 'build_popular_people': kodi_utils.execute_builtin('RunPlugin(%s)' % kodi_utils.build_url(browse_item))
		else: kodi_utils.execute_builtin('Container.Update(%s)' % kodi_utils.build_url(browse_item))

	def move(self):
		active_list = self.params_get('active_list')
		list_items = navigator_cache.currently_used_list(active_list)
		if len(list_items) == 1: return kodi_utils.notification(32736, 1500)
		choice_items = [i for i in list_items if str(i['name']) != str(self.params_get('menu_name'))]
		current_position = self.params_get('position')
		new_position = self._menu_select(choice_items, self.params_get('menu_name_translated'), multi_line='true', position_list=True)
		if new_position is None or new_position == current_position: return
		list_items.insert(new_position, list_items.pop(current_position))
		self._db_execute('set', active_list, list_items)

	def remove(self):
		if not kodi_utils.confirm_dialog(): return kodi_utils.notification(32736, 1500)
		active_list = self.params_get('active_list')
		list_items = navigator_cache.currently_used_list(active_list)
		if len(list_items) == 1: return kodi_utils.notification(32736, 1500)
		try: current_position = int(self.params_get('position', '0'))
		except: current_position = -1
		removed_items = []
		if current_position >= 0 and current_position < len(list_items):
			removed_items = [dict(list_items[current_position])]
		else:
			removed_items = [dict(i) for i in list_items if str(i.get('name')) == str(self.params_get('menu_name'))]
		if removed_items: navigator_cache.mark_removed_items(active_list, removed_items)
		list_items = [i for i in list_items if str(i['name']) != str(self.params_get('menu_name'))]
		self._db_execute('set', active_list, list_items)

	def add_original(self):
		active_list = self.params_get('active_list')
		try: choice_items = self._get_removed_items(active_list)
		except: return kodi_utils.notification(32760, 1500)
		menu_name_translated = self.params_get('menu_name_translated')
		choice = self._menu_select(choice_items, menu_name_translated)
		if choice is None: return kodi_utils.notification(32736, 1500)
		choice_list = choice_items[choice]
		list_items = navigator_cache.currently_used_list(active_list)
		position = self._menu_select(list_items, menu_name_translated, multi_line='true', position_list=True)
		if position is None: return kodi_utils.notification(32736, 1500)
		list_items.insert(position, choice_list)
		navigator_cache.mark_restored_items(active_list, [choice_list])
		self._db_execute('set', active_list, list_items)

	def _choice_target_list_key(self, choice_name, choice_list):
		try:
			return choice_list.get('action') or choice_name
		except Exception:
			return choice_name

	def add_original_external(self):
		active_list = self.params_get('active_list')
		choice_items = self._get_main_menu_items(active_list)
		choice = self._menu_select([i[1] for i in choice_items], '')
		if choice is None: return kodi_utils.notification(32736, 1500)
		choice_name, choice_list = choice_items[choice]
		target_list = self._choice_target_list_key(choice_name, choice_list)
		list_items = navigator_cache.currently_used_list(target_list)
		menu_name_translated = self.params_get('menu_name_translated')
		position = self._menu_select(list_items, menu_name_translated, multi_line='true', position_list=True)
		if position is None: return kodi_utils.notification(32736, 1500)
		menu_name = self._get_external_name_input(menu_name_translated)
		list_items.insert(position, self._add_external_info_to_item(self.menu_item, menu_name, False))
		self._db_execute('set', choice_name, list_items, refresh=False)

	def add_trakt(self):
		from indexers.trakt_api import get_trakt_list_selection
		trakt_selection = get_trakt_list_selection(list_choice='nav_edit')
		if trakt_selection is None: return kodi_utils.notification(32736, 1500)
		active_list = self.params_get('active_list')
		list_items = navigator_cache.currently_used_list(active_list)
		menu_name = trakt_selection['name']
		position = self._menu_select(list_items, menu_name, multi_line='true', position_list=True)
		if position is None: return kodi_utils.notification(32736, 1500)
		menu_name = self._get_external_name_input(menu_name)
		trakt_selection.update({'mode': 'build_trakt_list', 'iconImage': 'trakt.png'})
		list_items.insert(position, self._add_external_info_to_item(trakt_selection, menu_name, False))
		self._db_execute('set', active_list, list_items)

	def restore(self):
		if not kodi_utils.confirm_dialog(): return kodi_utils.notification(32736, 1500)
		active_list = self.params_get('active_list')
		navigator_cache.clear_removed_items(active_list)
		self._db_execute('delete', active_list, list_type='edited', refresh=False)
		try: self._db_execute('set', active_list, default_menus.main_menus[active_list], 'default')
		except Exception: return kodi_utils.notification(32983, 1500)

	def reload_menu_item(self):
		active_list = self.params_get('active_list')
		default, edited = navigator_cache.get_main_lists(active_list)
		list_type = 'edited' if edited else 'default'
		current_list = edited or default
		menu_name = self.params_get('menu_name')
		try: new_item = [i for i in default if str(i['name']) == str(menu_name)][0]
		except: return kodi_utils.notification(32760, 1500)
		list_items = [i for i in current_list if str(i['name']) != str(menu_name)]
		list_items.insert(self.params_get('position', 0), new_item)
		navigator_cache.mark_restored_items(active_list, [new_item])
		self._db_execute('set', active_list, list_items, list_type)

	def check_update_list(self):
		active_list = self.params_get('active_list')
		try: new_contents = default_menus.main_menus[active_list]
		except Exception: return kodi_utils.notification(32983, 1500)
		default, edited = navigator_cache.get_main_lists(active_list)
		list_type = 'edited' if edited else'default'
		current_list = edited or default
		if default == new_contents: return kodi_utils.notification(32983, 1500)
		new_entry = [i for i in new_contents if not i in default][0]
		new_entry_translated_name = ls(new_entry.get('name'))
		if not kodi_utils.confirm_dialog(text='%s[CR]%s' % (ls(32727) % new_entry_translated_name, ls(32728))): return kodi_utils.notification(32736, 1500)
		item_position = self._menu_select(current_list, new_entry_translated_name, position_list=True)
		if item_position is None: return kodi_utils.notification(32736, 1500)
		current_list.insert(item_position, new_entry)
		navigator_cache.mark_restored_items(active_list, [new_entry])
		self._db_execute('set', active_list, current_list, list_type)
		if list_type == 'edited': self._db_execute('set', active_list, new_contents, 'default')

	def add_external(self):
		choice_items = self._get_main_menu_items([])
		choice = self._menu_select([i[1] for i in choice_items], '')
		if choice is None: return kodi_utils.notification(32736, 1500)
		choice_name, choice_list = choice_items[choice]
		target_list = self._choice_target_list_key(choice_name, choice_list)
		list_items = navigator_cache.currently_used_list(target_list)
		menu_name = self.params_get('name')
		position = self._menu_select(list_items, menu_name, multi_line='true', position_list=True)
		if position is None: return kodi_utils.notification(32736, 1500)
		menu_name = self._get_external_name_input(menu_name)
		list_items.insert(position, self._add_external_info_to_item(self.menu_item, menu_name))
		self._db_execute('set', choice_name, list_items, refresh=False)


	def _shortcut_folder_name(self):
		return (self.params_get('shortcut_folder_name') or self.params_get('menu_name') or
			self.params_get('list_name') or self.menu_item_get('shortcut_folder_name') or self.menu_item_get('name'))

	def _shortcut_folder_item_target_name(self, item=None):
		item = item or self.menu_item
		try:
			return str(item.get('shortcut_folder_name') or item.get('folder_name') or item.get('list_name') or item.get('name') or '').strip()
		except Exception:
			return ''

	def _shortcut_folder_item_by_position(self):
		active_list = self.params_get('active_list')
		try: position = int(self.params_get('position', '0'))
		except: position = -1
		list_items = navigator_cache.get_shortcut_folder_contents(active_list)
		if position < 0 or position >= len(list_items): return active_list, list_items, None, position
		return active_list, list_items, dict(list_items[position]), position

	def _set_shortcut_folder_item(self, item):
		active_list, list_items, old_item, position = self._shortcut_folder_item_by_position()
		if old_item is None: return kodi_utils.notification(32736, 1500)
		list_items[position] = item
		self._db_execute('set', active_list, list_items, 'shortcut_folder', True)

	def shortcut_folder_item_rename(self):
		active_list, list_items, item, position = self._shortcut_folder_item_by_position()
		if item is None: return kodi_utils.notification(32736, 1500)
		old_name = str(item.get('name') or '').strip()
		new_name = kodi_utils.dialog.input('alkoFlix', defaultt=old_name)
		new_name = str(new_name or '').strip()
		if not new_name or new_name == old_name: return kodi_utils.notification(32736, 1500)
		if item.get('mode') == 'navigator.build_shortcut_folder_list':
			item['shortcut_folder_name'] = self._shortcut_folder_item_target_name(item)
		if not item.get('original_name'):
			item['original_name'] = old_name
		item['name'] = new_name
		item['custom_alias'] = 'True'
		self._set_shortcut_folder_item(item)

	def shortcut_folder_item_reset_name(self):
		active_list, list_items, item, position = self._shortcut_folder_item_by_position()
		if item is None: return kodi_utils.notification(32736, 1500)
		original_name = item.get('original_name')
		if not original_name: return kodi_utils.notification(32736, 1500)
		item['name'] = original_name
		item.pop('original_name', None)
		item.pop('custom_alias', None)
		self._set_shortcut_folder_item(item)

	def shortcut_folder_item_choose_icon(self):
		active_list, list_items, item, position = self._shortcut_folder_item_by_position()
		if item is None: return kodi_utils.notification(32736, 1500)
		current_icon = item.get('iconImage') or folder_icon_default
		icon = self._select_menu_icon(current_icon)
		if not icon: return kodi_utils.notification(32736, 1500)
		if item.get('mode') == 'navigator.build_shortcut_folder_list':
			item['shortcut_folder_name'] = self._shortcut_folder_item_target_name(item)
		if not item.get('original_iconImage'):
			item['original_iconImage'] = current_icon
		item['iconImage'] = icon
		item['custom_icon'] = 'True'
		self._set_shortcut_folder_item(item)

	def shortcut_folder_item_reset_icon(self):
		active_list, list_items, item, position = self._shortcut_folder_item_by_position()
		if item is None: return kodi_utils.notification(32736, 1500)
		original_icon = item.get('original_iconImage')
		if not original_icon: return kodi_utils.notification(32736, 1500)
		item['iconImage'] = original_icon
		item.pop('original_iconImage', None)
		item.pop('custom_icon', None)
		self._set_shortcut_folder_item(item)

	def _valid_media_icon(self, icon):
		icon = str(icon or '').strip()
		if not icon or '/' in icon or '\\' in icon: return False
		return icon.lower().endswith(media_icon_extensions)

	def _get_menu_icons(self):
		try: folders, files = kodi_utils.list_dirs(menu_icons_path())
		except: files = []
		return sorted([str(i) for i in files if self._valid_media_icon(i)], key=lambda s: s.lower())

	def _menu_icon_label(self, icon):
		icon = _icon_filename(icon).rsplit('.', 1)[0]
		return icon.replace('-', ' ').strip().capitalize()

	def _select_menu_icon(self, current_icon=folder_icon_default):
		icons = self._get_menu_icons()
		if not icons: return kodi_utils.notification('Aucune icône de menu trouvée', 1500)
		current_name = _icon_filename(current_icon)
		items = []
		for icon in icons:
			icon_path = menu_icons_path(icon)
			line2 = 'Icône actuelle' if icon == current_name else ''
			items.append({'line1': self._menu_icon_label(icon), 'line2': line2, 'icon': icon_path})
		try: preselect = [icons.index(current_name)] if current_name in icons else []
		except: preselect = []
		kwargs = {'items': json.dumps(items), 'heading': 'Choisir une icône de menu', 'enumerate': 'false', 'multi_choice': 'false', 'multi_line': 'false', 'preselect': preselect, 'use_details': 'true'}
		choice = kodi_utils.select_dialog(icons, **kwargs)
		return menu_icons_path(choice) if choice else choice

	def _sync_shortcut_folder_refs(self, old_name=None, new_name=None, icon=None):
		old_name = str(old_name or new_name or '').strip()
		new_name = str(new_name or old_name or '').strip()
		if not old_name or not new_name: return
		for folder_name, folder_contents in navigator_cache.get_shortcut_folders():
			try:
				list_items = eval(folder_contents)
				if not list_items: continue
				updated = False
				new_items = []
				for item in list_items:
					item = dict(item)
					if item.get('mode') == 'navigator.build_shortcut_folder_list':
						target_name = str(item.get('shortcut_folder_name') or item.get('name'))
						if target_name == str(old_name):
							item['shortcut_folder_name'] = new_name
							if not item.get('custom_alias') or str(item.get('name')) == str(old_name): item['name'] = new_name
							if icon is not None and not item.get('custom_icon'): item['iconImage'] = icon or folder_icon_default
							updated = True
					new_items.append(item)
				if updated: navigator_cache.set_list(folder_name, 'shortcut_folder', new_items)
			except: pass

	def _sync_shortcut_folder_icon(self, folder_name, icon):
		if not folder_name: return
		for main_list_name in default_menus.main_menus:
			try:
				list_items = navigator_cache.currently_used_list(main_list_name)
				if not list_items: continue
				updated = False
				new_items = []
				for item in list_items:
					item = dict(item)
					if item.get('mode') == 'navigator.build_shortcut_folder_list':
						target_name = str(item.get('shortcut_folder_name') or item.get('name'))
						if target_name == str(folder_name) and not item.get('custom_icon'):
							item['iconImage'] = icon or folder_icon_default
							updated = True
					new_items.append(item)
				if updated: navigator_cache.set_list(main_list_name, 'edited', new_items)
			except: pass
		self._sync_shortcut_folder_refs(folder_name, folder_name, icon or folder_icon_default)

	def _sync_shortcut_folder_rename(self, old_name, new_name, icon):
		if not old_name or not new_name: return
		for main_list_name in default_menus.main_menus:
			try:
				list_items = navigator_cache.currently_used_list(main_list_name)
				if not list_items: continue
				updated = False
				new_items = []
				for item in list_items:
					item = dict(item)
					if item.get('mode') == 'navigator.build_shortcut_folder_list':
						target_name = str(item.get('shortcut_folder_name') or item.get('name'))
						if target_name == str(old_name):
							item['shortcut_folder_name'] = new_name
							if not item.get('custom_alias') or str(item.get('name')) == str(old_name): item['name'] = new_name
							if not item.get('custom_icon'): item['iconImage'] = icon or folder_icon_default
							updated = True
					new_items.append(item)
				if updated: navigator_cache.set_list(main_list_name, 'edited', new_items)
			except: pass
		self._sync_shortcut_folder_refs(old_name, new_name, icon or folder_icon_default)

	def shortcut_folder_rename(self):
		old_name = self._shortcut_folder_name()
		if not old_name: return kodi_utils.notification(32736, 1500)
		new_name = kodi_utils.dialog.input('alkoFlix', defaultt=old_name)
		new_name = str(new_name or '').strip()
		if not new_name or new_name == old_name: return kodi_utils.notification(32736, 1500)
		try:
			existing_names = [i[0] for i in navigator_cache.get_shortcut_folders()]
			if new_name in existing_names: return kodi_utils.notification('Ce dossier existe déjà', 1500)
		except: pass
		contents = navigator_cache.get_shortcut_folder_contents(old_name)
		icon = navigator_cache.get_shortcut_folder_icon(old_name)
		navigator_cache.set_list(new_name, 'shortcut_folder', contents)
		if icon and icon != folder_icon_default: navigator_cache.set_shortcut_folder_icon(new_name, icon)
		else: navigator_cache.delete_shortcut_folder_icon(new_name)
		try: navigator_cache.delete_list(old_name, 'shortcut_folder')
		except: pass
		try: navigator_cache.delete_shortcut_folder_icon(old_name)
		except: pass
		self._sync_shortcut_folder_rename(old_name, new_name, icon)
		kodi_utils.notification(32576, 1500)
		kodi_utils.sleep(200)
		kodi_utils.container_refresh()

	def shortcut_folder_choose_icon(self):
		folder_name = self._shortcut_folder_name()
		if not folder_name: return kodi_utils.notification(32736, 1500)
		current_icon = navigator_cache.get_shortcut_folder_icon(folder_name)
		icon = self._select_menu_icon(current_icon)
		if not icon: return kodi_utils.notification(32736, 1500)
		navigator_cache.set_shortcut_folder_icon(folder_name, icon)
		self._sync_shortcut_folder_icon(folder_name, icon)
		self._db_execute('set', folder_name, navigator_cache.get_shortcut_folder_contents(folder_name), 'shortcut_folder', True)

	def shortcut_folder_reset_icon(self):
		folder_name = self._shortcut_folder_name()
		if not folder_name: return kodi_utils.notification(32736, 1500)
		navigator_cache.delete_shortcut_folder_icon(folder_name)
		self._sync_shortcut_folder_icon(folder_name, folder_icon_default)
		self._db_execute('set', folder_name, navigator_cache.get_shortcut_folder_contents(folder_name), 'shortcut_folder', True)

	def _menu_select(self, choice_items, menu_name, heading='alkoFlix', multi_line='false', position_list=False):
		def _builder():
			for item in choice_items:
				item_get = item.get
				line1 = ls(item_get('name', '')).replace('[B]', '').replace('[/B]', '')
				line2 = pos_str % (menu_name, line1 or ls(item_get('list_name')) if position_list else '')
				if item_get('iconImage') in ('', 'None', None, folder_icon_default): icon = media_path(folder_icon_default)
				elif item_get('iconImage') == 'alkoflix.png': icon = kodi_utils.get_addoninfo('icon')
				elif item_get('network_id') or '://' in str(item_get('iconImage', '')): icon = item_get('iconImage', 'discover.png')
				else: icon = '%s%s' % (icon_path, item_get('iconImage', 'discover.png'))
				yield {'line1': line1, 'line2': line2, 'icon': icon}
		menu_name, icon_path = menu_name.replace('[B]', '').replace('[/B]', ''), media_path()
		list_items = list(_builder())
		if position_list: list_items.insert(0, {'line1': top_str, 'line2': top_pos_str % menu_name, 'icon': media_path('top.png')})
		index_list = [list_items.index(i) for i in list_items]
		kwargs = {'items': json.dumps(list_items), 'heading': heading, 'enumerate': 'false', 'multi_choice': 'false', 'multi_line': multi_line}
		return kodi_utils.select_dialog(index_list, **kwargs)

	def _get_removed_items(self, active_list):
		default_list_items, list_items = navigator_cache.get_main_lists(active_list)
		return [i for i in default_list_items if not i in list_items]

	def _clean_display_name(self, value):
		try:
			name = ls(value)
		except Exception:
			name = value
		try:
			return str(name or '').replace('[B]', '').replace('[/B]', '').strip()
		except Exception:
			return str(value or '').strip()

	def _get_external_name_input(self, current_name):
		current_name = self._clean_display_name(current_name)
		new_name = kodi_utils.dialog.input('alkoFlix', defaultt=current_name)
		if new_name == current_name: return None
		return new_name

	def _add_external_info_to_item(self, menu_item, menu_name=None, add_all_params=True):
		if add_all_params:
			self.params.pop('mode', None)
			self.params.pop('menu_item', None)
			menu_item.update(self.params)
		if menu_name:
			menu_item['name'] = menu_name
		else:
			# Les entrées récupérées depuis l’URL Kodi arrivent parfois avec un ID de
			# libellé sous forme de texte (ex. "32453"). Les menus natifs savent souvent
			# le retraduire, mais le Catalogue alkoPaste affiche des chaînes prêtes à
			# l’emploi. On stocke donc le libellé lisible pour les raccourcis copiés.
			menu_item['name'] = self._clean_display_name(menu_item.get('name'))
		menu_item['external_list_item'] = 'True'
		return menu_item

	def _alkopaste_catalogue_enabled(self):
		try: return str(kodi_utils.get_setting('catalogue.alkopaste.enabled', 'false')).strip().lower() == 'true'
		except: return False

	def _get_main_menu_items(self, active_list):
		choice_list = []
		for i in default_menus.default_menu_items:
			if i == active_list: continue
			if i == 'AlkoPasteCatalogueList' and not self._alkopaste_catalogue_enabled(): continue
			if i not in default_menus.main_menu_items: continue
			item = dict(default_menus.main_menu_items[i])
			# Certaines entrées de menu racine, comme le Catalogue alkoPaste,
			# sont des routes directes et n'ont pas forcément d'action. Pour l'éditeur,
			# la clé de destination reste le nom interne de la liste.
			item.setdefault('action', i)
			choice_list.append((i, item))
		return choice_list

	def _make_menu_item(self):
		if self.params_get('action') in ('tmdb_movies_keyword', 'tmdb_tv_keyword'):
			self.menu_item = {
				'mode': self.params_get('mode'), 'action': self.params_get('action'),
				'keyword_id': self.params_get('keyword_id'), 'name': self.params_get('name'), 'iconImage': 'tmdb.png'
			}

	def _remove_active_shortcut_folder(self, main_menu_items_list, folder_name):
		for x in main_menu_items_list:
			try:
				match = [i for i in x[1] if str(i['name']) == str(folder_name)][0]
				new_list = [i for i in x[1] if i != match]
				self._db_execute('set', x[0], new_list, refresh=False)
			except: pass

	def _db_execute(self, db_action, list_name, list_contents=[], list_type='edited', refresh=True):
		if db_action == 'set': navigator_cache.set_list(list_name, list_type, list_contents)
		elif db_action == 'delete': navigator_cache.delete_list(list_name, list_type)
		elif db_action == 'make_new_folder': navigator_cache.set_list(list_name, 'shortcut_folder', list_contents)
		kodi_utils.notification(32576, 1500)
		kodi_utils.sleep(200)
		if refresh: kodi_utils.container_refresh()

	def shortcut_folder_contents_adjust(self):
		active_list = self.params_get('active_list')
		if self.action == 'rename_item': return self.shortcut_folder_item_rename()
		if self.action == 'choose_icon_item': return self.shortcut_folder_item_choose_icon()
		if self.action == 'reset_name_item': return self.shortcut_folder_item_reset_name()
		if self.action == 'reset_icon_item': return self.shortcut_folder_item_reset_icon()
		if self.action == 'rename_folder': return self.shortcut_folder_rename()
		if self.action == 'choose_icon_folder': return self.shortcut_folder_choose_icon()
		if self.action == 'reset_icon_folder': return self.shortcut_folder_reset_icon()
		if self.action == 'clear_all':
			if not kodi_utils.confirm_dialog(): return kodi_utils.notification(32736, 1500)
			list_items = []
		else:
			list_items = navigator_cache.get_shortcut_folder_contents(active_list)
			try: current_position = int(self.params_get('position', '0'))
			except: current_position = -1
			if current_position < 0 or current_position >= len(list_items): return kodi_utils.notification(32736, 1500)
			list_name = self.menu_item_get('name')
			if self.action == 'remove':
				if not kodi_utils.confirm_dialog(): return kodi_utils.notification(32736, 1500)
				list_items.pop(current_position)
			else:
				if len(list_items) == 1: return kodi_utils.notification(32736, 1500)
				choice_items = [dict(i) for pos, i in enumerate(list_items) if pos != current_position]
				new_position = self._menu_select(choice_items, list_name, multi_line='true', position_list=True)
				if new_position is None or new_position == current_position: return
				list_items.insert(new_position, list_items.pop(current_position))
		self._db_execute('set', active_list, list_items, 'shortcut_folder', True)

	def shortcut_folder_make(self):
		list_name = kodi_utils.dialog.input('alkoFlix')
		if not list_name: return
		self._db_execute('make_new_folder', list_name, list_type='shortcut_folder')

	def shortcut_folder_add_item(self):
		shortcut_folders = navigator_cache.get_shortcut_folders()
		if len(shortcut_folders) == 1: choice_name, choice_list = shortcut_folders[0]
		elif shortcut_folders:
			choice = self._menu_select([{'name': i[0], 'iconImage': navigator_cache.get_shortcut_folder_icon(i[0])} for i in shortcut_folders], '')
			if choice is None: return kodi_utils.notification(32736, 1500)
			shortcut_folders[choice]
			choice_name, choice_list = shortcut_folders[choice]
		else:
			if not kodi_utils.confirm_dialog(text=32702, top_space=True, default_control=10): return kodi_utils.notification(32736, 1500)
			self.shortcut_folder_make()
			try: choice_name, choice_list = navigator_cache.get_shortcut_folders()[0]
			except: return kodi_utils.notification(32736, 1500)
		list_items = eval(choice_list)
		name = self.params_get('name') or self.params_get('menu_name_translated')
		menu_name = self._get_external_name_input(name) or name
		if self.menu_item_get('mode') == 'navigator.build_shortcut_folder_list':
			self.menu_item['shortcut_folder_name'] = self._shortcut_folder_item_target_name(self.menu_item) or name
			if menu_name != self.menu_item['shortcut_folder_name']:
				self.menu_item['original_name'] = self.menu_item['shortcut_folder_name']
				self.menu_item['custom_alias'] = 'True'
		self.menu_item.update({'name': menu_name, 'iconImage': self.params_get('iconImage') or self.menu_item_get('iconImage')})
		position = self._menu_select(list_items, menu_name, multi_line='true', position_list=True) if list_items else 0
		if position is None: return kodi_utils.notification(32736, 1500)
		list_items.insert(position, self.menu_item)
		self._db_execute('set', choice_name, list_items, 'shortcut_folder', False)

	def shortcut_folder_add_to_main_menu(self):
		shortcut_folders = navigator_cache.get_shortcut_folders()
		if len(shortcut_folders) == 1: name = shortcut_folders[0][0]
		elif shortcut_folders:
			choice = self._menu_select([{'name': i[0], 'iconImage': navigator_cache.get_shortcut_folder_icon(i[0])} for i in shortcut_folders], '')
			if choice is None: return kodi_utils.notification(32736, 1500)
			shortcut_folders[choice]
			name = shortcut_folders[choice][0]
		else:
			if not kodi_utils.confirm_dialog(text=32702, top_space=True, default_control=10): return kodi_utils.notification(32736, 1500)
			self.shortcut_folder_make()
			try: name = navigator_cache.get_shortcut_folders()[0][0]
			except: return kodi_utils.notification(32736, 1500)
		chosen_folder = {'mode': 'navigator.build_shortcut_folder_list', 'name': name, 'iconImage': navigator_cache.get_shortcut_folder_icon(name), 'shortcut_folder': 'True', 'external_list_item': 'True'}
		active_list = self.params_get('active_list')
		list_items = navigator_cache.currently_used_list(active_list)
		position = self._menu_select(list_items, name, multi_line='true', position_list=True)
		if position is None: return kodi_utils.notification(32736, 1500)
		list_items.insert(position, chosen_folder)
		self._db_execute('set', active_list, list_items)

	def shortcut_folder_delete(self):
		if not kodi_utils.confirm_dialog(): return kodi_utils.notification(32736, 1500)
		main_menu_items_list = [(i, navigator_cache.currently_used_list(i)) for i in default_menus.main_menus]
		folder_name = self.params_get('list_name') or self.menu_item_get('name')
		navigator_cache.delete_shortcut_folder_icon(folder_name)
		self._db_execute('delete', folder_name, list_type='shortcut_folder')
		self._remove_active_shortcut_folder(main_menu_items_list, folder_name)

