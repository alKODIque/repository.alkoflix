# -*- coding: utf-8 -*-
# plugin.video.alkoflix
# resources/lib/alko/control.py

from json import dumps as jsdumps, loads as jsloads
import os.path
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs
import xml.etree.ElementTree as ET

addon = xbmcaddon.Addon

def _addon():
	return addon('plugin.video.alkoflix')

def addonInfo(info):
	return _addon().getAddonInfo(info)

def getLangString(language_id):
	return _addon().getLocalizedString(language_id)

class _KodiProxy:
	def __init__(self, factory, cached=False):
		self._factory = factory
		self._cached = cached
		self._instance = None

	def _get(self):
		if self._cached:
			if self._instance is None: self._instance = self._factory()
			return self._instance
		return self._factory()

	def __getattr__(self, name):
		obj = self._get()
		attr = getattr(obj, name)
		if not callable(attr):
			if not self._cached:
				try: del obj
				except: pass
			return attr
		def _method(*args, **kwargs):
			instance = self._get()
			try: return getattr(instance, name)(*args, **kwargs)
			finally:
				if not self._cached:
					try: del instance
					except: pass
		return _method

	def reset(self):
		self._instance = None

condVisibility = xbmc.getCondVisibility
execute = xbmc.executebuiltin
jsonrpc = xbmc.executeJSONRPC
monitor_class = xbmc.Monitor
monitor = _KodiProxy(lambda: xbmc.Monitor(), cached=True)
dialog = _KodiProxy(lambda: xbmcgui.Dialog())
homeWindow = _KodiProxy(lambda: xbmcgui.Window(10000))

existsPath = xbmcvfs.exists
openFile = xbmcvfs.File
makeFile = xbmcvfs.mkdir
makeDirs = xbmcvfs.mkdirs
transPath = xbmcvfs.translatePath
joinPath = os.path.join

SETTINGS_PATH = transPath(joinPath(addonInfo('path'), 'resources', 'settings.xml'))
try: dataPath = transPath(addonInfo('profile')).decode('utf-8')
except: dataPath = transPath(addonInfo('profile'))
settingsFile = joinPath(dataPath, 'settings.xml')


def setting(id, fallback=None):
#	try: settings_dict = jsloads(homeWindow.getProperty('alkoscrapers_settings'))
	try: settings_dict = jsloads(homeWindow.getProperty('alkoflix_settings'))
	except: settings_dict = make_settings_dict()
	if settings_dict is None: settings_dict = settings_fallback(id)
	value = settings_dict.get(id, '')
	if fallback is None: return value
	if value == '': return fallback
	return value

def settings_fallback(id):
	return {id: _addon().getSetting(id)}

def setSetting(id, value):
	result = _addon().setSetting(id, value)
	homeWindow.clearProperty('alkoflix_settings')
	return result

def make_settings_dict(): # service runs upon a setting change
	try:
		root = ET.parse(settingsFile).getroot()
		settings_dict = {}
		for item in root:
			dict_item = {}
			setting_id = item.get('id')
			setting_value = item.text
			if setting_value is None: setting_value = ''
			dict_item = {setting_id: setting_value}
			settings_dict.update(dict_item)
#		homeWindow.setProperty('alkoscrapers_settings', jsdumps(settings_dict))
		homeWindow.setProperty('alkoflix_settings', jsdumps(settings_dict))
		return settings_dict
	except:
		return None

def refresh_debugReversed(): # called from service "onSettingsChanged" to clear log if setting to reverse has been changed
	if homeWindow.getProperty('alkoflix.debug.reversed') != setting('debug.reversed'):
		homeWindow.setProperty('alkoflix.debug.reversed', setting('debug.reversed'))

def lang(language_id):
	return getLangString(language_id)

def sleep(time):  # Modified `sleep` command that honors a user exit request
	while time > 0 and not monitor.abortRequested():
		xbmc.sleep(min(100, time))
		time = time - 100



def addonId():
	return addonInfo('id')

def addonName():
	return addonInfo('name')

def addonVersion():
	return addonInfo('version')

def addonIcon():
	return addonInfo('icon')

def addonPath():
	try: return transPath(addonInfo('path').decode('utf-8'))
	except: return transPath(addonInfo('path'))

def openSettings(query=None, id=None):
	try:
		if id is None: id = addonInfo('id')
		idle()
		execute('Addon.OpenSettings(%s)' % id)
		if not query: return
		c, f = query.split('.')
		execute('SetFocus(%i)' % (int(c) - 100))
		execute('SetFocus(%i)' % (int(f) - 80))
	except:
		return

def getSettingDefault(id):
	import re
	try:
		settings = open(SETTINGS_PATH, 'r')
		value = ' '.join(settings.readlines())
		value.strip('\n')
		settings.close()
		value = re.findall(r'id=\"%s\".*?default=\"(.*?)\"' % (id), value)[0]
		return value
	except:
		return None

def idle():
	if int(xbmc.getInfoLabel("System.BuildVersion")[:2]) >= 18 and condVisibility('Window.IsActive(busydialognocancel)'):
		return execute('Dialog.Close(busydialognocancel)')
	else:
		return execute('Dialog.Close(busydialog)')

def yesnoDialog(line, heading=None, nolabel='', yeslabel=''):
	if heading is None: heading = addonInfo('name')
	return dialog.yesno(heading, line, nolabel, yeslabel)

def selectDialog(list, heading=None):
	if heading is None: heading = addonInfo('name')
	return dialog.select(heading, list)

def multiselectDialog(list, preselect=[], heading=None):
	if heading is None: heading = addonInfo('name')
	return dialog.multiselect(heading, list, preselect=preselect)

def notification(title=None, message=None, icon=None, time=3000, sound=False):
	if title == 'default' or title is None: title = addonName()
	if isinstance(title, int): heading = lang(title)
	else: heading = str(title)
	if isinstance(message, int): body = lang(message)
	else: body = str(message)
	if icon is None or icon == '' or icon == 'default': icon = addonIcon()
	elif icon == 'INFO': icon = xbmcgui.NOTIFICATION_INFO
	elif icon == 'WARNING': icon = xbmcgui.NOTIFICATION_WARNING
	elif icon == 'ERROR': icon = xbmcgui.NOTIFICATION_ERROR
	dialog.notification(heading, body, icon, time, sound=sound)

