# -*- coding: utf-8 -*-
# plugin.video.alkoflix
# resources/lib/modules/thumbnails.py

import sqlite3 as database
from pathlib import Path
from datetime import datetime, timedelta
import xbmc, xbmcaddon, xbmcgui, xbmcvfs
from modules import kodi_utils


def ls(string):
	try: return xbmcaddon.Addon().getLocalizedString(int(string))
	except: return str(string)


def logger(heading, function):
	try:
		if xbmcaddon.Addon().getSetting('debug.enabled') != 'true': return
		xbmc.log('>> %s <<: %s' % (heading, function), xbmc.LOGDEBUG)
	except: pass


def notification(line1, time=3000, sound=False):
	addon_info = xbmcaddon.Addon().getAddonInfo
	xbmcgui.Dialog().notification(addon_info('name'), line1, addon_info('icon'), time, sound)


def _delete_path(path):
	files_deleted, dirs_deleted = 0, 0
	try:
		if not path.exists(): return files_deleted, dirs_deleted
		if path.is_dir():
			for child in path.iterdir():
				child_files, child_dirs = _delete_path(child)
				files_deleted += child_files
				dirs_deleted += child_dirs
			try:
				path.rmdir()
				dirs_deleted += 1
			except Exception as e:
				logger('clear kodi thumbnails rmdir skipped', '%s | %s' % (path, e))
		else:
			try:
				path.unlink(missing_ok=True)
				files_deleted += 1
			except Exception as e:
				logger('clear kodi thumbnails file skipped', '%s | %s' % (path, e))
	except Exception as e:
		logger('clear kodi thumbnails path skipped', '%s | %s' % (path, e))
	return files_deleted, dirs_deleted


def _delete_folder_contents(folder):
	files_deleted, dirs_deleted = 0, 0
	try:
		if not folder.exists(): return files_deleted, dirs_deleted
		for child in folder.iterdir():
			child_files, child_dirs = _delete_path(child)
			files_deleted += child_files
			dirs_deleted += child_dirs
	except Exception as e:
		logger('clear kodi thumbnails folder skipped', '%s | %s' % (folder, e))
	return files_deleted, dirs_deleted


def _clear_textures_database(dbfile):
	dbcon = None
	try:
		if not dbfile.exists(): return False
		dbcon = database.connect(str(dbfile), isolation_level=None)
		dbcur = dbcon.cursor()
		dbcur.execute('''PRAGMA synchronous = OFF''')
		dbcur.execute('''PRAGMA journal_mode = OFF''')
		dbcur.execute("SELECT name FROM sqlite_master WHERE type = 'table'")
		tables = {item[0] for item in dbcur.fetchall()}
		for table in ('sizes', 'texture', 'path'):
			if table in tables: dbcur.execute('DELETE FROM %s' % table)
		dbcon.commit()
		try: dbcur.execute('VACUUM')
		except Exception as e: logger('clear kodi thumbnails vacuum skipped', e)
		return True
	except Exception as e:
		logger('clear kodi thumbnails database failed', e)
		return False
	finally:
		try:
			if dbcon: dbcon.close()
		except: pass


def _delete_textures_database_files(dbfile):
	deleted = 0
	for suffix in ('', '-wal', '-shm', '-journal'):
		path = Path('%s%s' % (dbfile, suffix))
		try:
			if path.exists():
				path.unlink(missing_ok=True)
				deleted += 1
		except Exception as e:
			logger('clear kodi thumbnails db file skipped', '%s | %s' % (path, e))
	return deleted


def _textures_database_candidates():
	# Utilise la base de textures de la version Kodi réellement exécutée.
	# On conserve les deux chemins historiques car, selon la plateforme,
	# special://database et special://profile/Database peuvent être des alias.
	try:
		resolved = kodi_utils.get_texture_database_path()
		db_name = str(resolved).replace('\\', '/').rsplit('/', 1)[-1]
	except:
		db_name = 'Textures14.db' if _kodi_major_version() >= 22 else 'Textures13.db'
	candidates, seen = [], set()
	for special_path in ('special://database', 'special://profile/Database'):
		try:
			path = Path(xbmcvfs.translatePath(special_path), db_name)
			key = str(path).lower()
			if key not in seen:
				seen.add(key)
				candidates.append(path)
		except Exception as e:
			logger('clear kodi thumbnails db candidate skipped', '%s | %s' % (special_path, e))
	return candidates


def _kodi_major_version():
	try: return int(str(xbmc.getInfoLabel('System.BuildVersion'))[:2])
	except: return 21


def _textures_database_label(dbfiles=None):
	try:
		if dbfiles:
			for dbfile in dbfiles:
				if dbfile: return Path(dbfile).name
		return str(kodi_utils.get_texture_database_path()).replace('\\', '/').rsplit('/', 1)[-1]
	except:
		return 'Textures14.db' if _kodi_major_version() >= 22 else 'Textures13.db'


# Vide complètement le cache des vignettes Kodi et propose un redémarrage.
def clear_kodi_thumbnail_cache():
	progress_dialog = xbmcgui.DialogProgress()
	thumbs_folder = Path(xbmcvfs.translatePath('special://thumbnails'))
	dbfiles = _textures_database_candidates()
	db_label = _textures_database_label(dbfiles)
	try:
		progress_dialog.create('alkoFlix', 'Vidage du cache des vignettes Kodi...')
		progress_dialog.update(10, 'Nettoyage de %s...' % db_label)
	except: pass
	database_cleared, db_files_deleted = False, 0
	for dbfile in dbfiles:
		if _clear_textures_database(dbfile): database_cleared = True
	try: progress_dialog.update(35, 'Suppression de %s...' % db_label)
	except: pass
	for dbfile in dbfiles:
		db_files_deleted += _delete_textures_database_files(dbfile)
	try: progress_dialog.update(60, 'Suppression du dossier Thumbnails...')
	except: pass
	files_deleted, dirs_deleted = _delete_folder_contents(thumbs_folder)
	try:
		progress_dialog.update(100, 'Cache des vignettes Kodi vidé.')
		xbmc.sleep(700)
		progress_dialog.close()
	except: pass
	logger('clear kodi thumbnails done', 'database_cleared=%s | db_files_deleted=%s | files_deleted=%s | dirs_deleted=%s' % (database_cleared, db_files_deleted, files_deleted, dirs_deleted))
	text = 'Le cache des vignettes Kodi a été vidé : dossier Thumbnails nettoyé et %s vidé/supprimé quand Kodi le permet.[CR][CR]Un redémarrage de Kodi est nécessaire pour reconstruire correctement les nouvelles images.[CR][CR]Voulez-vous redémarrer Kodi maintenant ?' % db_label
	restart = xbmcgui.Dialog().yesno('alkoFlix', text, 'Plus tard', 'Redémarrer')
	if restart: xbmc.executebuiltin('RestartApp')
	else: notification('Cache des vignettes vidé. Redémarrez Kodi plus tard.', 4000)


# Vide le contenu du dossier temporaire Kodi et propose un redémarrage.
def clear_kodi_temp_cache():
	progress_dialog = xbmcgui.DialogProgress()
	temp_folder = Path(xbmcvfs.translatePath('special://temp'))
	try:
		progress_dialog.create('alkoFlix', 'Vidage du cache temporaire Kodi...')
		progress_dialog.update(25, 'Suppression du contenu du dossier temp...')
	except: pass
	files_deleted, dirs_deleted = _delete_folder_contents(temp_folder)
	try:
		progress_dialog.update(100, 'Cache temporaire Kodi vidé.')
		xbmc.sleep(700)
		progress_dialog.close()
	except: pass
	logger('clear kodi temp done', 'folder=%s | files_deleted=%s | dirs_deleted=%s' % (temp_folder, files_deleted, dirs_deleted))
	text = 'Le cache temporaire Kodi a été vidé : fichiers et sous-dossiers du dossier temp supprimés quand Kodi le permet.[CR][CR]Un redémarrage de Kodi est nécessaire pour finaliser correctement le nettoyage.[CR][CR]Voulez-vous redémarrer Kodi maintenant ?'
	restart = xbmcgui.Dialog().yesno('alkoFlix', text, 'Plus tard', 'Redémarrer')
	if restart: xbmc.executebuiltin('RestartApp')
	else: notification('Cache Kodi vidé. Redémarrez Kodi plus tard.', 4000)


def _obsolete_thumbnail_days(days):
	try: days = int(str(days or '').strip())
	except: days = 15
	return days if days > 0 else 15


def _obsolete_thumbnail_cutoff(days):
	current_date = datetime.date(datetime.utcnow())
	return (current_date - timedelta(days=_obsolete_thumbnail_days(days))).strftime('%Y-%m-%d %H:%M:%S')


def _texture_db_for_obsolete_cleanup():
	for dbfile in _textures_database_candidates():
		try:
			if dbfile.exists(): return dbfile
		except: pass
	try: return Path(xbmcvfs.translatePath(kodi_utils.get_texture_database_path()))
	except: return Path(xbmcvfs.translatePath('special://database'), 'Textures14.db' if _kodi_major_version() >= 22 else 'Textures13.db')


def clean_obsolete_thumbnails(days=15, silent=True, progress=False):
	days = _obsolete_thumbnail_days(days)
	thumbs_folder = Path(xbmcvfs.translatePath('special://thumbnails'))
	dbfile = _texture_db_for_obsolete_cleanup()
	if not dbfile.exists():
		if not silent: notification(ls(32575))
		return 0
	item_list, result_length, progress_dialog = [], 0, None
	dbcon = None
	try:
		back_date = _obsolete_thumbnail_cutoff(days)
		dbcon = database.connect(str(dbfile), isolation_level=None)
		dbcur = dbcon.cursor()
		dbcur.execute('''PRAGMA synchronous = OFF''')
		dbcur.execute('''PRAGMA journal_mode = OFF''')
		dbcur.execute("SELECT idtexture FROM sizes WHERE lastusetime < ?", (str(back_date), ))
		result = dbcur.fetchall()
		result_length = len(result)
		if not result_length > 0:
			if not silent: notification(ls(33190))
			logger('obsolete thumbnails cleanup', 'nothing to clean | days=%s' % days)
			return 0
		if progress:
			progress_dialog = xbmcgui.DialogProgress()
			progress_dialog.create(ls(33191), '')
			progress_dialog.update(0, ls(33192))
		for count, item in enumerate(result):
			if progress_dialog and progress_dialog.iscanceled(): break
			_id = item[0]
			dbcur.execute("SELECT cachedurl FROM texture WHERE id = ?", (_id, ))
			row = dbcur.fetchone()
			if not row: continue
			path = thumbs_folder.joinpath(row[0])
			try: path.unlink(missing_ok=True)
			except Exception as e: logger('obsolete thumbnails file skipped', '%s | %s' % (path, e))
			item_list.append((_id,))
			if progress_dialog:
				percent = int(count / result_length * 100)
				line = '[B]%s:[/B] %s[CR][B]%s:[/B] %02d - %s[CR][B]%s:[/B] %s'
				line = line % (ls(33197), result_length, ls(33198), count, str(path.name), ls(33199), str(path.parent))
				progress_dialog.update(max(1, percent), line)
		if not item_list:
			if not silent: notification(ls(33190))
			logger('obsolete thumbnails cleanup', 'no database entries removed | days=%s | scanned=%s' % (days, result_length))
			return 0
		if progress_dialog:
			line = '%s %s[CR]%s[CR]%%s' % (ls(33193), len(item_list), ls(32577).replace('[B]', '').replace('[/B]', ''))
			progress_dialog.update(33, line % ls(33194))
		dbcur.executemany("DELETE FROM sizes WHERE idtexture = ?", item_list)
		if progress_dialog: progress_dialog.update(66, line % ls(33196))
		dbcur.executemany("DELETE FROM texture WHERE id = ?", item_list)
		if progress_dialog: progress_dialog.update(99, line % ls(33195))
		dbcon.commit()
		try: dbcur.execute("VACUUM")
		except Exception as e: logger('obsolete thumbnails vacuum skipped', e)
		logger('obsolete thumbnails cleanup done', 'days=%s | deleted=%s | db=%s' % (days, len(item_list), dbfile))
		if progress: xbmc.sleep(1500)
		if not silent: notification(ls(33200))
		return len(item_list)
	except Exception as e:
		logger('obsolete thumbnails cleanup failed', e)
		if not silent: notification('Nettoyage des miniatures impossible pour le moment.', 4000)
		return 0
	finally:
		try:
			if progress_dialog: progress_dialog.close()
		except: pass
		try:
			if dbcon: dbcon.close()
		except: pass


def thumb_cleaner():
	minimum_uses = 30
	days = xbmcgui.Dialog().numeric(0 , ls(33188), defaultt=str(minimum_uses))
	if not days: return notification(ls(33189))
	return clean_obsolete_thumbnails(days=days, silent=False, progress=True)
