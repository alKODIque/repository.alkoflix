# -*- coding: utf-8 -*-
# alkoFlix - mapping saisons/épisodes anime

import re
import unicodedata

TRUE_VALUES = ('true', '1', 'yes', 'on', 'anime')
ANIME_HINT_KEYS = (
	'anime_context', 'is_anime', 'anime', 'native_type', 'fav_type', 'parent_fav_type', 'series_fav_type',
	'tv_fav_type', 'catalogue_section', 'catalogue_category', 'category', 'section', 'menu', 'path', 'folder',
	'action', 'mode', 'content_type', 'collection_type'
)
ANIME_WORDS = ('anime', 'animé', 'animes', 'animés', 'japonais', 'japanese animation')
JP_WORDS = ('ja', 'jp', 'jpn', 'japon', 'japan', 'japanese', '日本')
ANIMATION_WORDS = ('anime', 'animé', 'animation', 'animations')


def _safe_int(value, default=0):
	try:
		if value in ('', None): return default
		return int(float(str(value).strip()))
	except:
		return default


def _text(value):
	try:
		if value is None: return ''
		if isinstance(value, bytes): value = value.decode('utf-8', 'ignore')
		return str(value)
	except:
		return ''


def _flatten(value):
	if value is None: return []
	if isinstance(value, dict):
		items = []
		for key, item in value.items():
			items.extend(_flatten(key)); items.extend(_flatten(item))
		return items
	if isinstance(value, (list, tuple, set)):
		items = []
		for item in value: items.extend(_flatten(item))
		return items
	return [_text(value)]


def _norm(value):
	value = _text(value).lower()
	try:
		value = ''.join(c for c in unicodedata.normalize('NFKD', value) if not unicodedata.combining(c))
	except:
		pass
	return value


def _has_any(value, words):
	value = _norm(value)
	return any(_norm(word) in value for word in words)


def is_anime_context(meta=None, params=None, data=None):
	try:
		for source in (params or {}, data or {}, meta or {}):
			if not isinstance(source, dict): continue
			for key in ANIME_HINT_KEYS:
				if key not in source: continue
				value = source.get(key)
				if isinstance(value, bool) and value: return True
				value_text = _norm(value)
				if value_text in TRUE_VALUES: return True
				if _has_any(value_text, ANIME_WORDS): return True
		# Détection de secours : Animation + Japon/JA. On reste volontairement prudent.
		texts = []
		for source in (params or {}, data or {}, meta or {}):
			if not isinstance(source, dict): continue
			for key in ('genres', 'genre', 'genre_names', 'genre_list', 'genre_ids', 'country_codes', 'countries', 'origin_country', 'original_language', 'language'):
				texts.extend(_flatten(source.get(key)))
		joined = ' '.join(_norm(i) for i in texts)
		has_animation = any(word in joined for word in ('anime', 'anime', 'animation', '16'))
		has_japan = any(word in joined for word in JP_WORDS)
		return bool(has_animation and has_japan)
	except:
		return False


def _season_rows(meta):
	try:
		rows = meta.get('season_data') or []
		if not isinstance(rows, (list, tuple)): return []
		output = []
		for row in rows:
			try:
				season = _safe_int(row.get('season_number'))
				count = _safe_int(row.get('episode_count'))
				if season < 0: continue
				output.append({'season_number': season, 'episode_count': count})
			except:
				continue
		return sorted(output, key=lambda i: i['season_number'])
	except:
		return []


def _absolute_from_meta(meta, season, episode):
	try:
		season, episode = _safe_int(season), _safe_int(episode)
		if season <= 1: return episode
		total = 0
		for row in _season_rows(meta):
			row_season = _safe_int(row.get('season_number'))
			if row_season == 0: continue
			if row_season < season: total += _safe_int(row.get('episode_count'))
		return total + episode if total else episode
	except:
		return _safe_int(episode)


def _ordinal_en(number):
	number = _safe_int(number)
	if number % 100 in (11, 12, 13): suffix = 'th'
	else: suffix = {1: 'st', 2: 'nd', 3: 'rd'}.get(number % 10, 'th')
	return '%d%s' % (number, suffix)


def _add_candidate(candidates, season, episode, kind, absolute_episode=0, cour_size=0, extra=None):
	season, episode = _safe_int(season), _safe_int(episode)
	if season <= 0 or episode <= 0: return
	key = (season, episode)
	if key in [(i['season'], i['episode']) for i in candidates]: return
	item = {
		'season': season,
		'episode': episode,
		'kind': kind,
		'absolute_episode': _safe_int(absolute_episode),
		'cour_size': _safe_int(cour_size)
	}
	if isinstance(extra, dict):
		for key, value in extra.items():
			if value not in ('', None): item[key] = value
	candidates.append(item)


def _clean_group_name(value):
	try:
		value = _text(value).strip()
		if not value: return ''
		value = re.sub(r'\s+', ' ', value)
		# Les noms génériques ajoutent du bruit; les vrais sous-titres de saison restent utiles.
		if _norm(value) in ('season 1', 'season 2', 'season 3', 'saison 1', 'saison 2', 'saison 3', 'tv', 'absolute', 'dvd', 'digital'):
			return ''
		return value
	except:
		return ''


def _tmdb_group_sort_key(item):
	try:
		type_name = _text(item.get('type'))
		priority = {
			'TV': 0,
			'Story arc': 1,
			'Absolute': 2,
			'Digital': 3,
			'DVD': 4,
			'Original air date': 5,
			'Production': 6
		}.get(type_name, 9)
		# Les groupes avec plusieurs groupes/saisons sont généralement ceux qu'on veut pour les animes.
		group_count = _safe_int(item.get('group_count'))
		return (priority, 0 if group_count > 1 else 1, -_safe_int(item.get('episode_count')))
	except:
		return (9, 9, 0)


def _tmdb_episode_group_candidates(meta, params, data, season, episode, absolute_episode=0):
	"""Retourne les candidats issus des groupes d'épisodes TMDb.

	TMDb garde parfois une saison longue en affichage principal, mais propose un
	groupe alternatif qui correspond au découpage utilisé dans les releases
	anime (Season 2 / Cour 2 / arc de saison). On lit uniquement ces groupes
	explicites; aucune conversion automatique 12/13 épisodes n'est devinée.
	"""
	try:
		tmdb_id = _safe_int((meta or {}).get('tmdb_id') or (params or {}).get('tmdb_id') or (data or {}).get('tmdb_id') or (data or {}).get('tmdb'))
		if tmdb_id <= 0: return []
		from indexers.tmdb_api import episode_groups, episode_group_details
		groups = episode_groups(tmdb_id) or []
		if not groups: return []
		output, seen = [], set()
		# Garde-fou : les détails sont en cache TMDb, mais au premier passage on évite d'appeler 15 groupes.
		for group_info in sorted(groups, key=_tmdb_group_sort_key)[:8]:
			group_id = group_info.get('id')
			if not group_id: continue
			try: details = episode_group_details(group_id) or []
			except: details = []
			if not details: continue
			for group_index, group in enumerate(details):
				group_order = _safe_int(group.get('order')) or (group_index + 1)
				if group_order <= 0: continue
				group_name = _clean_group_name(group.get('name') or group_info.get('name'))
				episodes = group.get('episodes') or []
				for ep_index, ep in enumerate(episodes):
					try:
						if _safe_int(ep.get('season_number')) != _safe_int(season): continue
						if _safe_int(ep.get('episode_number')) != _safe_int(episode): continue
						alt_episode = _safe_int(ep.get('order')) + 1 if ep.get('order') not in ('', None) else (ep_index + 1)
						if alt_episode <= 0: continue
						key = (group_order, alt_episode)
						if key in seen: continue
						seen.add(key)
						output.append({
							'season': group_order,
							'episode': alt_episode,
							'kind': 'tmdb_group:%s' % group_id,
							'tmdb_group_id': group_id,
							'tmdb_group_type': group_info.get('type') or '',
							'tmdb_group_name': group_info.get('name') or '',
							'group_name': group_name,
							'absolute_episode': _safe_int(absolute_episode)
						})
					except:
						continue
		return output
	except:
		return []


def build_episode_map(meta=None, params=None, data=None):
	try:
		meta = meta or {}
		params = params or {}
		data = data or {}
		media_type = meta.get('media_type') or params.get('media_type') or data.get('media_type') or 'episode'
		season = _safe_int(meta.get('season') or params.get('season') or data.get('season'))
		episode = _safe_int(meta.get('episode') or params.get('episode') or data.get('episode'))
		if media_type != 'episode' or season <= 0 or episode <= 0: return {}
		if not is_anime_context(meta, params, data): return {}
		absolute_episode = _safe_int(params.get('absolute_episode') or data.get('absolute_episode')) or _absolute_from_meta(meta, season, episode)
		candidates = []
		_add_candidate(candidates, season, episode, 'tmdb', absolute_episode)
		# Recherche par défaut : on reste sur le découpage TMDb affiché à l'écran.
		# Les groupes TMDb alternatifs ne doivent plus être interrogés d'emblée,
		# sinon tous les groupements apparaissent dans le sélecteur. Ils sont
		# proposés seulement via le popup « Scraper depuis le groupe d'épisodes »
		# quand le groupement par défaut ne retourne aucun résultat.
		include_groups = str(
			params.get('anime_include_episode_groups')
			or data.get('anime_include_episode_groups')
			or meta.get('anime_include_episode_groups')
			or ''
		).lower() in TRUE_VALUES
		if include_groups:
			for tmdb_candidate in _tmdb_episode_group_candidates(meta, params, data, season, episode, absolute_episode):
				_add_candidate(
					candidates, tmdb_candidate.get('season'), tmdb_candidate.get('episode'),
					tmdb_candidate.get('kind') or 'tmdb_group', absolute_episode, 0, tmdb_candidate
				)
		# Aucun plan B 12/13 épisodes : les animes longs peuvent avoir des découpages
		# très variables. On reste sur TMDb + groupes TMDb + découpage custom explicite.
		# Si une source catalogue a déjà fourni un découpage alternatif, on le garde.
		custom_season = _safe_int(meta.get('custom_season') or params.get('custom_season') or data.get('custom_season'))
		custom_episode = _safe_int(meta.get('custom_episode') or params.get('custom_episode') or data.get('custom_episode'))
		if custom_season and custom_episode:
			_add_candidate(candidates, custom_season, custom_episode, 'custom', absolute_episode)
		if len(candidates) <= 1 and not absolute_episode: return {}
		return {
			'enabled': True,
			'canonical_season': season,
			'canonical_episode': episode,
			'absolute_episode': absolute_episode,
			'candidates': candidates
		}
	except:
		return {}


def ensure_meta(meta, params=None):
	try:
		if not isinstance(meta, dict): return meta
		params = params or {}
		if is_anime_context(meta, params): meta['anime_context'] = True
		mapping = build_episode_map(meta, params)
		if mapping:
			meta['anime_context'] = True
			meta['anime_episode_map'] = mapping
	except:
		pass
	return meta


def _map_from(data_or_meta):
	try:
		mapping = (data_or_meta or {}).get('anime_episode_map') or {}
		if mapping.get('enabled'): return mapping
		mapping = build_episode_map(data_or_meta or {}, data_or_meta or {}, data_or_meta or {})
		return mapping if mapping.get('enabled') else {}
	except:
		return {}


def episode_candidates(data_or_meta):
	mapping = _map_from(data_or_meta)
	if mapping: return list(mapping.get('candidates') or [])
	season, episode = _safe_int((data_or_meta or {}).get('season')), _safe_int((data_or_meta or {}).get('episode'))
	return [{'season': season, 'episode': episode, 'kind': 'tmdb', 'absolute_episode': _safe_int((data_or_meta or {}).get('absolute_episode'))}] if season and episode else []


def explicit_episode_candidates(data_or_meta):
	"""Candidats utilisables pour matcher un SxxEyy écrit noir sur blanc.

	Les groupes TMDb peuvent parfois fournir une numérotation locale au sein d'un
	groupe qui reste en saison 1 (ex.: S01E11) alors que l'épisode canonique est
	S01E23 et l'alternative utile est S02E11. Pour les releases qui annoncent un
	SxxEyy explicite, on garde donc seulement :
	- l'épisode canonique TMDb;
	- les vrais remappings vers une autre saison;
	- les découpages custom explicites.
	Les candidats même saison / autre épisode restent disponibles via le nom du
	groupe, mais ne valident plus un S01E11 parasite.
	"""
	try:
		mapping = _map_from(data_or_meta or {})
		canonical = (_safe_int(mapping.get('canonical_season') or (data_or_meta or {}).get('season')), _safe_int(mapping.get('canonical_episode') or (data_or_meta or {}).get('episode')))
		items, seen = [], set()
		for cand in episode_candidates(data_or_meta or {}):
			season, episode = _safe_int(cand.get('season')), _safe_int(cand.get('episode'))
			if not season or not episode: continue
			pair = (season, episode)
			kind = _text(cand.get('kind'))
			if pair == canonical or season != canonical[0] or kind == 'custom':
				if pair not in seen:
					seen.add(pair)
					items.append(cand)
		return items
	except:
		return episode_candidates(data_or_meta or {})


def search_episode_candidates(data_or_meta):
	"""Candidats utilisés pour interroger une API externe par saison/épisode.

	Même règle stricte que pour les SxxEyy explicites : on n'envoie pas de
	requête S01E11 inventée par un groupe TMDb si l'épisode demandé est S01E23.
	"""
	return explicit_episode_candidates(data_or_meta)


def season_candidates(data_or_meta):
	seasons = []
	for item in episode_candidates(data_or_meta):
		season = _safe_int(item.get('season'))
		if season and season not in seasons: seasons.append(season)
	return seasons


def episode_numbers_for_season(data_or_meta, season, explicit_only=False):
	season = _safe_int(season)
	numbers = []
	items = explicit_episode_candidates(data_or_meta) if explicit_only else episode_candidates(data_or_meta)
	for item in items:
		if _safe_int(item.get('season')) == season:
			episode = _safe_int(item.get('episode'))
			if episode and episode not in numbers: numbers.append(episode)
	return numbers


def explicit_episode_numbers_for_season(data_or_meta, season):
	"""Numéros acceptés quand une source indexe ses épisodes par saison explicite.

	Ex.: si l'épisode canonique est S01E23 et le groupe TMDb utile donne S02E11,
	on accepte S01E23 et S02E11, mais pas un S01E11 parasite issu d'un
	groupe alternatif. C'est utilisé par ALKO/source locale et autres index
	structurés qui stockent saison + numéro d'épisode.
	"""
	return episode_numbers_for_season(data_or_meta, season, explicit_only=True)


def hdlrs(data_or_meta):
	items = []
	mapping = _map_from(data_or_meta)
	absolute = _safe_int(mapping.get('absolute_episode') or (data_or_meta or {}).get('absolute_episode'))
	for cand in explicit_episode_candidates(data_or_meta):
		season, episode = _safe_int(cand.get('season')), _safe_int(cand.get('episode'))
		for value in ('S%02dE%02d' % (season, episode), 'S%dE%02d' % (season, episode), '%dx%02d' % (season, episode)):
			if value not in items: items.append(value)
	if absolute:
		for value in ('E%02d' % absolute, 'E%d' % absolute, 'EP%02d' % absolute, 'Episode %02d' % absolute, str(absolute), '%02d' % absolute):
			if value not in items: items.append(value)
	return items


def search_suffixes(data_or_meta):
	items = []
	mapping = _map_from(data_or_meta)
	absolute = _safe_int(mapping.get('absolute_episode') or (data_or_meta or {}).get('absolute_episode'))
	canonical = (_safe_int(mapping.get('canonical_season')), _safe_int(mapping.get('canonical_episode')))
	for cand in explicit_episode_candidates(data_or_meta):
		season, episode = _safe_int(cand.get('season')), _safe_int(cand.get('episode'))
		for value in ('S%02dE%02d' % (season, episode), 'S%02d E%02d' % (season, episode), 'S%dE%02d' % (season, episode), '%dx%02d' % (season, episode)):
			if value not in items: items.append(value)
		group_name = _clean_group_name(cand.get('group_name') or cand.get('tmdb_group_name'))
		if group_name and (season, episode) != canonical:
			for value in ('%s %02d' % (group_name, episode), '%s %d' % (group_name, episode), '%s Episode %02d' % (group_name, episode)):
				if value not in items: items.append(value)
		if (season, episode) != canonical:
			for value in (
				'Season %d Episode %02d' % (season, episode), 'Season %d %02d' % (season, episode),
				'Saison %d Episode %02d' % (season, episode), 'Saison %d %02d' % (season, episode),
				'Cour %d %02d' % (season, episode), 'Part %d %02d' % (season, episode),
				'%s Season %02d' % (_ordinal_en(season), episode), '%s Season %d' % (_ordinal_en(season), episode)
			):
				if value not in items: items.append(value)
	if absolute:
		for value in ('E%02d' % absolute, 'E%d' % absolute, 'EP%02d' % absolute, 'Episode %02d' % absolute, 'Episode %d' % absolute, '%02d' % absolute, str(absolute)):
			if value not in items: items.append(value)
	return items


def episode_data_variants(data):
	try:
		variants, seen = [], set()
		base = dict(data or {})
		for cand in search_episode_candidates(base):
			season, episode = _safe_int(cand.get('season')), _safe_int(cand.get('episode'))
			key = (season, episode)
			if not season or not episode or key in seen: continue
			seen.add(key)
			item = dict(base)
			item.update({
				'season': str(season), 'episode': str(episode), 'anime_variant': True,
				'anime_match_season': season, 'anime_match_episode': episode,
				'anime_canonical_season': _safe_int(base.get('season')), 'anime_canonical_episode': _safe_int(base.get('episode'))
			})
			variants.append(item)
		return variants or [base]
	except:
		return [data]


def season_data_variants(data):
	try:
		variants, seen = [], set()
		base = dict(data or {})
		for season in season_candidates(base):
			if season in seen: continue
			seen.add(season)
			item = dict(base)
			item.update({'season': str(season), 'anime_variant': True, 'anime_match_season': season})
			variants.append(item)
		return variants or [base]
	except:
		return [data]


def _release_text(value):
	value = _norm(value)
	value = re.sub(r'[^a-z0-9]+', ' ', value)
	return ' %s ' % re.sub(r'\s+', ' ', value).strip()



def explicit_episode_pairs(release_title):
	"""Détecte uniquement les marqueurs épisode explicites (SxxEyy / 2x07 / Season 2 Episode 7).

	On ne traite pas les numéros seuls ici : trop dangereux pour les animés.
	"""
	pairs = []
	try:
		text = _release_text(release_title)
		patterns = (
			r'\bs\s*0*(\d{1,3})\s*e\s*0*(\d{1,3})\b',
			r'\bseason\s*0*(\d{1,3})\s*(?:e|ep|episode)\s*0*(\d{1,3})\b',
			r'\bsaison\s*0*(\d{1,3})\s*(?:e|ep|episode|episode)\s*0*(\d{1,3})\b',
			r'\b0*(\d{1,3})\s*x\s*0*(\d{1,3})\b'
		)
		for pattern in patterns:
			for found_season, found_episode in re.findall(pattern, text):
				pair = (_safe_int(found_season), _safe_int(found_episode))
				if pair[0] and pair[1] and pair not in pairs: pairs.append(pair)
	except:
		pass
	return pairs


def explicit_episode_mismatch(release_title, data_or_meta=None):
	"""Retourne True quand une release annonce clairement un autre SxxEyy.

	Important pour NYAA/TorrentsDB : certains manifests répondent large et peuvent
	renvoyer S01E07 même si on cherche le découpage TMDb alternatif S02E07.
	Dans ce cas on refuse la release au lieu de se fier au simple numéro 07.
	"""
	try:
		found_pairs = explicit_episode_pairs(release_title)
		if not found_pairs: return False
		valid_pairs = []
		for cand in explicit_episode_candidates(data_or_meta or {}):
			pair = (_safe_int(cand.get('season')), _safe_int(cand.get('episode')))
			if pair[0] and pair[1] and pair not in valid_pairs: valid_pairs.append(pair)
		if not valid_pairs: return False
		return not any(pair in valid_pairs for pair in found_pairs)
	except:
		return False

def release_matches_episode(release_title, season, episode, data_or_meta=None):
	try:
		text = _release_text(release_title)
		pairs = [(_safe_int(i.get('season')), _safe_int(i.get('episode'))) for i in explicit_episode_candidates(data_or_meta or {'season': season, 'episode': episode})]
		for found_season, found_episode in re.findall(r'\bs\s*0*(\d{1,2})\s*e\s*0*(\d{1,3})\b', text):
			found = (_safe_int(found_season), _safe_int(found_episode))
			return found in pairs
		for found_season, found_episode in re.findall(r'\b0*(\d{1,2})\s*x\s*0*(\d{1,3})\b', text):
			found = (_safe_int(found_season), _safe_int(found_episode))
			return found in pairs
		for cand in episode_candidates(data_or_meta or {}):
			group_name = _clean_group_name(cand.get('group_name') or cand.get('tmdb_group_name'))
			local_episode = _safe_int(cand.get('episode'))
			if group_name and local_episode:
				group_text = _release_text(group_name).strip()
				if group_text and group_text in text:
					patterns = (
						r'\be\s*0*%d\b' % local_episode,
						r'\bep\s*0*%d\b' % local_episode,
						r'\bepisode\s*0*%d\b' % local_episode,
						r'(?<!\d)0*%d(?!\d)' % local_episode
					)
					if any(re.search(pattern, text) for pattern in patterns): return True
		absolute = _safe_int((_map_from(data_or_meta or {}) or {}).get('absolute_episode'))
		if absolute:
			patterns = (
				r'\be\s*0*%d\b' % absolute,
				r'\bep\s*0*%d\b' % absolute,
				r'\bepisode\s*0*%d\b' % absolute,
				r'(?<!\d)0*%d(?!\d)' % absolute
			)
			return any(re.search(pattern, text) for pattern in patterns)
		return False
	except:
		return False


def file_matches_episode(filename, season, episode, data_or_meta=None):
	return release_matches_episode(filename, season, episode, data_or_meta)


def pack_contains_episode(item, data_or_meta, season, episode):
	try:
		if not isinstance(item, dict): return False
		if not ('episode_start' in item and 'episode_end' in item): return True
		start, end = _safe_int(item.get('episode_start')), _safe_int(item.get('episode_end'))
		if start <= 0 or end <= 0: return True
		candidate_numbers = []
		item_season = _safe_int(item.get('anime_match_season') or item.get('search_season') or item.get('season'))
		if item_season: candidate_numbers.extend(episode_numbers_for_season(data_or_meta, item_season))
		candidate_numbers.append(_safe_int(episode))
		for cand in episode_candidates(data_or_meta): candidate_numbers.append(_safe_int(cand.get('episode')))
		for number in sorted(set(i for i in candidate_numbers if i)):
			if start <= number <= end: return True
		return False
	except:
		return True


def candidate_for_release(release_title, data_or_meta=None):
	try:
		text = _release_text(release_title)
		for found_season, found_episode in re.findall(r'\bs\s*0*(\d{1,2})\s*e\s*0*(\d{1,3})\b', text):
			found = (_safe_int(found_season), _safe_int(found_episode))
			for cand in explicit_episode_candidates(data_or_meta or {}):
				if (_safe_int(cand.get('season')), _safe_int(cand.get('episode'))) == found: return dict(cand)
		for found_season, found_episode in re.findall(r'\b0*(\d{1,2})\s*x\s*0*(\d{1,3})\b', text):
			found = (_safe_int(found_season), _safe_int(found_episode))
			for cand in explicit_episode_candidates(data_or_meta or {}):
				if (_safe_int(cand.get('season')), _safe_int(cand.get('episode'))) == found: return dict(cand)
		for cand in episode_candidates(data_or_meta or {}):
			group_name = _clean_group_name(cand.get('group_name') or cand.get('tmdb_group_name'))
			local_episode = _safe_int(cand.get('episode'))
			if not group_name or not local_episode: continue
			group_text = _release_text(group_name).strip()
			if group_text and group_text in text:
				patterns = (
					r'\be\s*0*%d\b' % local_episode,
					r'\bep\s*0*%d\b' % local_episode,
					r'\bepisode\s*0*%d\b' % local_episode,
					r'(?<!\d)0*%d(?!\d)' % local_episode
				)
				if any(re.search(pattern, text) for pattern in patterns): return dict(cand)
	except:
		pass
	return {}


def with_preferred_cour(data_or_meta, cour_size=0, match_kind=''):
	try:
		cour_size = _safe_int(cour_size)
		match_kind = _text(match_kind)
		if not cour_size and not match_kind: return data_or_meta
		item = dict(data_or_meta or {})
		mapping = dict(item.get('anime_episode_map') or _map_from(item) or {})
		candidates = list(mapping.get('candidates') or [])
		if not candidates: return item
		canonical = (_safe_int(mapping.get('canonical_season')), _safe_int(mapping.get('canonical_episode')))
		filtered = []
		for cand in candidates:
			pair = (_safe_int(cand.get('season')), _safe_int(cand.get('episode')))
			if (
				pair == canonical
				or (cour_size and _safe_int(cand.get('cour_size')) == cour_size)
				or (match_kind and _text(cand.get('kind')) == match_kind)
				or cand.get('kind') == 'custom'
			):
				filtered.append(cand)
		if filtered:
			mapping['candidates'] = filtered
			item['anime_episode_map'] = mapping
		return item
	except:
		return data_or_meta
