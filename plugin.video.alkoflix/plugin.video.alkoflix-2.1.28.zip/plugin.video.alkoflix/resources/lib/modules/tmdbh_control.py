# -*- coding: utf-8 -*-
# plugin.video.alkoflix
# resources/lib/modules/tmdbh_control.py
# © Les alKODIques

from pathlib import Path
import xbmcvfs
from modules import kodi_utils

TMDBH_ADDON_ID = 'plugin.video.themoviedb.helper'


def _confirm_tmdbh_action(enabled):
	if enabled:
		text = (
			'Cette action va réactiver [B]TMDb Helper[/B].[CR][CR]'
			'Certains skins et widgets l’utilisent pour leurs propres contenus, informations et images.[CR][CR]'
			'Voulez-vous continuer ?'
		)
	else:
		text = (
			'Cette action va désactiver [B]TMDb Helper[/B].[CR][CR]'
			'Attention : TMDb Helper est une extension externe souvent utilisée par les skins, '
			'les widgets et certains raccourcis. Si vous la désactivez, certains widgets du skin '
			'peuvent se vider ou perdre leurs images.[CR][CR]'
			'alkoFlix ne dépend pas directement de son service pour sa navigation interne, '
			'mais cette option doit rester un choix volontaire.[CR][CR]'
			'Voulez-vous continuer ?'
		)
	return kodi_utils.confirm_dialog(text=text, ok_label='Oui', cancel_label='Non', top_space=True)



def play_from_tmdbh(params, autoplay=True):
	"""Point d'entrée dédié aux players JSON TMDb Helper.

	Le player « Play » doit lancer une vraie lecture directe, sans dépendre du
	réglage global Lecture auto d'alkoFlix. Le player « Select » force au contraire
	l'ouverture du sélecteur. Dans les deux cas, on redirige ensuite vers
	SourceSelect afin de conserver exactement le même pipeline de lecture, Trakt,
	bookmarks et Up Next que depuis l'addon.
	"""
	try:
		play_params = dict(params or {})
		play_params['mode'] = 'play_media'
		play_params['tmdbh_player'] = 'true'
		play_params['autoplay'] = 'true' if autoplay else 'false'
		# Valeur explicite pour éviter tout vieux paramètre False/True mal interprété
		# venant d'un JSON installé manuellement dans TMDb Helper.
		if autoplay:
			play_params['force_play'] = 'true'
		else:
			play_params['force_select'] = 'true'
		try:
			media_type = str(play_params.get('media_type') or '').lower()
			if media_type in ('movies', 'movie'):
				play_params['media_type'] = 'movie'
			elif media_type in ('episodes', 'episode', 'tvshow', 'tv'):
				play_params['media_type'] = 'episode'
		except: pass
		kodi_utils.logger('TMDb Helper player', '%s -> media_type=%s | tmdb_id=%s | S%sE%s' % (
			'Play' if autoplay else 'Select',
			play_params.get('media_type'), play_params.get('tmdb_id'),
			play_params.get('season', ''), play_params.get('episode', '')
		))
		from modules.sources import SourceSelect
		return SourceSelect.factory(play_params)
	except Exception as e:
		try: kodi_utils.logger('TMDb Helper player', 'Erreur -> %s: %s' % (type(e).__name__, e))
		except: pass
		try: kodi_utils.notification('TMDb Helper : lecture alkoFlix impossible.', 4000)
		except: pass


def set_tmdbh_enabled(enabled=False):
	if not kodi_utils.addon_installed(TMDBH_ADDON_ID):
		return kodi_utils.notification('TMDb Helper n’est pas installé.', 4000)
	if not _confirm_tmdbh_action(enabled):
		return
	ok = kodi_utils.set_addon_enabled(TMDBH_ADDON_ID, bool(enabled))
	if not ok:
		return kodi_utils.notification('Impossible de modifier TMDb Helper.', 4000)
	state = 'réactivé' if enabled else 'désactivé'
	text = 'TMDb Helper a été %s.[CR][CR]Un redémarrage de Kodi est recommandé pour que le changement soit totalement propre.[CR][CR]Voulez-vous redémarrer Kodi maintenant ?' % state
	restart = kodi_utils.dialog.yesno('alkoFlix', text, 'Plus tard', 'Redémarrer')
	if restart: kodi_utils.execute_builtin('RestartApp')
	else: kodi_utils.notification('TMDb Helper %s. Redémarrez Kodi plus tard.' % state, 4000)


def _delete_path(path):
	files_deleted, dirs_deleted = 0, 0
	try:
		if not path.exists(): return files_deleted, dirs_deleted
		if path.is_dir():
			for child in path.iterdir():
				f, d = _delete_path(child)
				files_deleted += f
				dirs_deleted += d
			try:
				path.rmdir()
				dirs_deleted += 1
			except Exception as e:
				kodi_utils.logger('TMDb Helper cache rmdir skipped', '%s | %s' % (path, e))
		else:
			try:
				path.unlink(missing_ok=True)
				files_deleted += 1
			except Exception as e:
				kodi_utils.logger('TMDb Helper cache file skipped', '%s | %s' % (path, e))
	except Exception as e:
		kodi_utils.logger('TMDb Helper cache path skipped', '%s | %s' % (path, e))
	return files_deleted, dirs_deleted


def clear_tmdbh_cache():
	if not kodi_utils.addon_installed(TMDBH_ADDON_ID):
		return kodi_utils.notification('TMDb Helper n’est pas installé.', 4000)
	text = (
		'Cette action va vider les bases/cache de [B]TMDb Helper[/B].[CR][CR]'
		'Cela ne touche pas aux caches internes d’alkoFlix. Kodi/TMDb Helper reconstruira ses données au besoin.[CR][CR]'
		'Voulez-vous continuer ?'
	)
	if not kodi_utils.confirm_dialog(text=text, ok_label='Oui', cancel_label='Non', top_space=True):
		return
	progress = kodi_utils.progressDialog
	files_deleted, dirs_deleted = 0, 0
	try:
		progress.create('alkoFlix', 'Vidage du cache TMDb Helper...')
		progress.update(25, 'Recherche des dossiers TMDb Helper...')
	except: pass
	paths = []
	try:
		base = Path(xbmcvfs.translatePath('special://profile/addon_data/%s' % TMDBH_ADDON_ID))
		for name in ('database', 'database_07', 'cache'):
			p = base / name
			if p.exists(): paths.append(p)
	except Exception as e:
		kodi_utils.logger('TMDb Helper cache path error', e)
	try: progress.update(55, 'Suppression du cache TMDb Helper...')
	except: pass
	for p in paths:
		f, d = _delete_path(p)
		files_deleted += f
		dirs_deleted += d
	try:
		progress.update(100, 'Cache TMDb Helper vidé.')
		kodi_utils.sleep(700)
		progress.close()
	except: pass
	kodi_utils.logger('TMDb Helper cache clear done', 'files_deleted=%s | dirs_deleted=%s' % (files_deleted, dirs_deleted))
	text = 'Cache TMDb Helper vidé : %s fichiers et %s dossiers supprimés quand Kodi le permet.[CR][CR]Un redémarrage de Kodi est recommandé.[CR][CR]Voulez-vous redémarrer Kodi maintenant ?' % (files_deleted, dirs_deleted)
	restart = kodi_utils.dialog.yesno('alkoFlix', text, 'Plus tard', 'Redémarrer')
	if restart: kodi_utils.execute_builtin('RestartApp')
	else: kodi_utils.notification('Cache TMDb Helper vidé. Redémarrez Kodi plus tard.', 4000)
