# created  for alkoscrapers
"""
	alkoscrapers Project
"""

import re, base64
from json import loads as jsloads
from urllib.parse import quote, urlparse, unquote_plus, parse_qsl

from alko import client
from alko import source_utils
from alko.control import setting as getSetting


class source:
	timeout = 7
	priority = 1
	pack_capable = False # packs parsed in sources function
	hasMovies = True
	hasEpisodes = True
	def _base_from_manifest(self, manifest_url):
		if not manifest_url: return None
		try:
			if '://' not in manifest_url:
				manifest_url = 'https://%s' % manifest_url
			parsed = urlparse(manifest_url)
			if not parsed.scheme or not parsed.netloc: return None
			path = parsed.path or ''
			for suffix in ('/manifest.json', '/manifest'):
				if path.endswith(suffix):
					path = path[:-len(suffix)]
					break
			base_url = '%s://%s%s' % (parsed.scheme, parsed.netloc, path)
			return base_url.rstrip('/')
		except:
			return None
	def _normalize_base_link_for_catalogue_match(self, value):
		try:
			value = str(value or '').strip()
			if not value: return ''
			base = self._base_from_manifest(value) or value.rstrip('/')
			return base.lower().rstrip('/')
		except:
			return ''

	def _catalogue_id_belongs_to_this_manifest(self, catalogue_id='', catalogue_base_url='', catalogue_video_id=False):
		# Un ID interne de catalogue ne doit être envoyé à un scraper custom que si
		# le scraper custom pointe vers le même manifest que le catalogue d'origine.
		# Sinon un ID French Stream (fs:...) envoyé à Baguettio, par exemple, ne peut
		# pas retourner de liens. Dans ce cas, on revient aux IDs standards IMDb/TMDb.
		catalogue_id = str(catalogue_id or '').strip()
		if not catalogue_id: return False
		catalogue_base = self._normalize_base_link_for_catalogue_match(catalogue_base_url)
		provider_base = self._normalize_base_link_for_catalogue_match(self.base_link)
		if catalogue_base and provider_base:
			return catalogue_base == provider_base
		# Garde-fou spécifique : fs: est propre à French Stream. On ne l'envoie pas
		# à un autre manifest custom si la base d'origine n'est pas connue.
		if catalogue_id.lower().startswith('fs:'):
			return provider_base and ('french-stream' in provider_base or 'frenchstream' in provider_base)
		# Sans base connue, on conserve l'ancien comportement pour les autres IDs.
		return True

	def _standard_request_id(self, imdb='', tmdb=''):
		imdb = str(imdb or '').strip()
		tmdb = str(tmdb or '').strip()
		if imdb: return imdb
		if tmdb:
			return tmdb if tmdb.lower().startswith('tmdb:') else 'tmdb:%s' % tmdb
		return ''

	def _release_title_from_stream(self, stream, meta=None, behavior=None):
		meta = meta or stream.get('meta') or {}
		behavior = behavior or stream.get('behaviorHints') or {}
		release_title = meta.get('originalTitle') or meta.get('title') or meta.get('name') or ''
		if not release_title:
			release_title = behavior.get('filename') or ''
		if not release_title:
			for key in ('title', 'description'):
				text = stream.get(key) or ''
				if not text: continue
				text = text.replace('\u2508\u27a4', '\n')
				match = re.search(r'([A-Za-z0-9].*?\.(?:mkv|mp4|avi|m2ts|m4v|ts))', text, re.IGNORECASE)
				if match:
					return match.group(1).strip()
				line = text.split('\n')[0].strip()
				if line:
					release_title = line
					break
		if not release_title:
			release_title = stream.get('name') or ''
		return release_title
	def _size_from_stream(self, stream, meta=None, behavior=None):
		meta = meta or stream.get('meta') or {}
		behavior = behavior or stream.get('behaviorHints') or {}
		# Les addons Stremio ne placent pas tous la taille au même endroit.
		# Baguettio, selon le mode utilisé, peut fournir la taille directement dans "size"
		# ou seulement dans les textes affichés (description, filename, folderName, title).
		for value in (
			meta.get('size'), behavior.get('videoSize'), behavior.get('size'),
			stream.get('size'), stream.get('videoSize'), stream.get('sizeBytes'),
			stream.get('filesize'), stream.get('fileSize')
		):
			try:
				if value in ('', None): continue
				if isinstance(value, str):
					value = value.strip()
					if re.search(r'\b(?:gb|gib|mb|mib)\b', value, re.I):
						return value
				value = float(value)
				if value > 0:
					return f"{value / 1073741824:.2f} GB"
			except:
				pass
		for text in (
			behavior.get('filename'), stream.get('folderName'), stream.get('filename'),
			stream.get('title'), stream.get('name'), stream.get('description')
		):
			try:
				if not text: continue
				match = re.search(r'(?<![A-Za-z0-9])([0-9]+(?:[\.,][0-9]+)?)\s*(GB|GiB|MB|MiB)\b', str(text), re.I)
				if match:
					return '%s %s' % (match.group(1).replace(',', '.'), match.group(2).upper().replace('GIB', 'GB').replace('MIB', 'MB'))
			except:
				pass
		return ''

	def _iter_stream_values(self, value, depth=0):
		# Lumio peut placer le hash dans stream, meta, behaviorHints,
		# ou dans un objet imbriqué. On balaye large, mais avec une profondeur bornée.
		if depth > 5: return
		try:
			if isinstance(value, dict):
				for key, item in value.items():
					yield key
					for nested in self._iter_stream_values(item, depth + 1):
						yield nested
			elif isinstance(value, (list, tuple, set)):
				for item in value:
					for nested in self._iter_stream_values(item, depth + 1):
						yield nested
			else:
				yield value
		except:
			return

	def _hash_blob_to_hex(self, value):
		try:
			if value in ('', None): return None
			if isinstance(value, bytes):
				raw = value
				return raw.hex().lower() if len(raw) == 20 else None
			text = str(value or '').strip().strip('"\' ,;|()[]{}')
			if not text: return None
			if re.match(r'^[A-Fa-f0-9]{40}$', text): return text.lower()
			# BTIH peut être fourni en base32 (forme acceptée dans les magnets).
			if re.match(r'^[A-Z2-7a-z]{32}$', text):
				try:
					raw = base64.b32decode(text.upper())
					if len(raw) == 20: return raw.hex().lower()
				except:
					pass
			# Certains manifests exposent mHash en base64/base64url (20 octets).
			compact = re.sub(r'\s+', '', text)
			if 24 <= len(compact) <= 64 and re.match(r'^[A-Za-z0-9_\-+/=]+$', compact):
				for candidate in (compact, compact.replace('-', '+').replace('_', '/')):
					try:
						candidate += '=' * ((4 - len(candidate) % 4) % 4)
						raw = base64.b64decode(candidate, validate=False)
						if len(raw) == 20: return raw.hex().lower()
					except:
						pass
		except:
			pass
		return None

	def _hash_from_text(self, value):
		try:
			if value in ('', None): return None
			if isinstance(value, bytes):
				try: value = value.decode('utf-8', 'ignore')
				except: value = repr(value)
			text = unquote_plus(str(value or '')).strip()
			if not text: return None
			direct = self._hash_blob_to_hex(text)
			if direct: return direct
			# Magnets et champs hash nommés.
			for pattern in (
				r'btih[:=]([A-Fa-f0-9]{40}|[A-Z2-7a-z]{32}|[A-Za-z0-9_\-+/=]{24,64})',
				r'(?:infohash|info_hash|torrenthash|torrent_hash|torrentinfohash|torrent_info_hash|mhash|m_hash|magnethash|magnet_hash|magnetinfohash|magnet_info_hash|hash|btih)["\\\'\s:=/?&#]+([A-Fa-f0-9]{40}|[A-Z2-7a-z]{32}|[A-Za-z0-9_\-+/=]{24,64})'
			):
				match = re.search(pattern, text, re.I)
				if match:
					normalized = self._hash_blob_to_hex(match.group(1))
					if normalized: return normalized
			match = re.search(r'\b([A-Fa-f0-9]{40})\b', text)
			if match: return match.group(1).lower()
			# On décode les tokens base32/base64 seulement si le texte parle clairement de hash/magnet,
			# pour éviter de prendre un morceau de nom de fichier pour un vrai hash.
			if re.search(r'btih|hash|mhash|magnet', text, re.I):
				for token in re.split(r'[^A-Za-z0-9_\-+/=]+', text):
					if 24 <= len(token) <= 64:
						normalized = self._hash_blob_to_hex(token)
						if normalized: return normalized
		except:
			pass
		return None


	def _hash_from_decoded_lumio_payload(self, value, depth=0):
		# Les URLs /playback de Lumio contiennent un petit JSON encodé en base64url.
		# Exemple observé dans les logs : {"c":[{"t":"t","h":"<mHash>","ad":1}], ...}
		# On récupère surtout la clé courte "h", sans transformer n'importe quel lien direct
		# en faux torrent.
		if depth > 6: return None
		try:
			if isinstance(value, dict):
				for key, item in value.items():
					key_norm = re.sub(r'[^a-z0-9]+', '', str(key or '').lower())
					if key_norm in ('h', 'hash', 'infohash', 'mhash', 'btih', 'torrenthash', 'magnethash'):
						normalized = self._hash_from_text(item) or self._hash_blob_to_hex(item)
						if normalized: return normalized
					nested = self._hash_from_decoded_lumio_payload(item, depth + 1)
					if nested: return nested
			if isinstance(value, (list, tuple, set)):
				for item in value:
					nested = self._hash_from_decoded_lumio_payload(item, depth + 1)
					if nested: return nested
		except:
			pass
		return None

	def _hash_from_lumio_playback_token(self, value):
		try:
			if value in ('', None): return None
			text = unquote_plus(str(value or '').strip().strip('/'))
			if not text: return None
			# Les URLs Lumio signent le payload : <base64url_json>.<signature>.
			# Le hash est dans le JSON, pas directement dans le segment de chemin.
			parts = [text]
			if '.' in text:
				parts.insert(0, text.split('.', 1)[0])
			for part in parts:
				part = part.strip().strip('/').strip('"\'')
				if not part or len(part) < 24 or len(part) > 2048: continue
				if not re.match(r'^[A-Za-z0-9_\-+/=]+$', part): continue
				for candidate in (part, part.replace('-', '+').replace('_', '/')):
					try:
						padded = candidate + ('=' * ((4 - len(candidate) % 4) % 4))
						raw = base64.urlsafe_b64decode(padded.encode('utf-8'))
						decoded = raw.decode('utf-8', 'ignore').strip()
						if not decoded: continue
						# Filet rapide si le JSON est lisible mais un peu sale.
						match = re.search(r'["\'](?:h|hash|infoHash|infohash|mHash|mhash|btih|torrentHash|magnetHash)["\']\s*:\s*["\']([A-Fa-f0-9]{40})["\']', decoded)
						if match: return match.group(1).lower()
						if not decoded.startswith(('{', '[')): continue
						payload = jsloads(decoded)
						normalized = self._hash_from_decoded_lumio_payload(payload)
						if normalized: return normalized
					except:
						pass
		except:
			pass
		return None


	def _hash_from_url_tokens(self, value):
		# Lumio peut retourner une URL de lecture Lumio/AD qui contient le mHash
		# sous forme de paramètre court ou de segment encodé, sans champ infoHash séparé.
		try:
			if value in ('', None): return None
			text = unquote_plus(str(value or '').strip())
			if not text: return None
			parsed = urlparse(text)
			candidates = []
			# Paramètres explicites et variantes courtes observées dans certains proxys.
			for key, val in parse_qsl(parsed.query or '', keep_blank_values=False):
				key_norm = re.sub(r'[^a-z0-9]+', '', str(key or '').lower())
				if key_norm in ('hash', 'infohash', 'ih', 'btih', 'mhash', 'mh', 'magnet', 'magneturl', 'magnethash', 'torrenthash', 'th', 'h', 'm'):
					candidates.append(val)
				# Certains liens placent le magnet entier dans un paramètre url/link/stream.
				if key_norm in ('url', 'link', 'stream', 'src', 'u'):
					candidates.append(val)
			# Segments de chemin : seulement pour les URLs Lumio/stream/torrent/magnet,
			# afin d'éviter de décoder n'importe quel nom de fichier en faux hash.
			netloc_path = '%s %s' % (parsed.netloc or '', parsed.path or '')
			is_lumio_playback = bool(re.search(r'lumio|mylumio', parsed.netloc or '', re.I) and re.search(r'/playback/', parsed.path or '', re.I))
			if re.search(r'lumio|mylumio|torrent|magnet|stream|resolve|play', netloc_path, re.I):
				path_tokens = [token for token in (parsed.path or '').split('/') if token]
				for token in path_tokens:
					if is_lumio_playback:
						normalized = self._hash_from_lumio_playback_token(token)
						if normalized: return normalized
					for part in re.split(r'[^A-Za-z0-9_\-+/=]+', token):
						if 24 <= len(part) <= 2048:
							candidates.append(part)
			for candidate in candidates:
				if is_lumio_playback:
					normalized = self._hash_from_lumio_playback_token(candidate)
					if normalized: return normalized
				normalized = self._hash_from_text(candidate) or self._hash_blob_to_hex(candidate)
				if normalized: return normalized
		except:
			pass
		return None

	def _hash_from_stream(self, stream, meta=None, behavior=None, direct_url=None):
		meta = meta or stream.get('meta') or {}
		behavior = behavior or stream.get('behaviorHints') or {}
		hash_keys = (
			'infoHash', 'infohash', 'infohash', 'hash', 'btih',
			'mHash', 'mhash', 'mhash',
			'magnetHash', 'magnethash', 'magnetInfoHash', 'magnet_info_hash',
			'torrentHash', 'torrenthash', 'torrentInfoHash', 'torrent_info_hash',
			'torrent', 'magnet', 'magnetUrl', 'magnet_url'
		)
		for source in (stream, meta, behavior):
			try:
				if not isinstance(source, dict): continue
				for key in hash_keys:
					normalized = self._hash_from_text(source.get(key))
					if normalized: return normalized
			except:
				pass
		for text in (
			direct_url, stream.get('url'), stream.get('externalUrl'), stream.get('external_url'),
			stream.get('magnet'), stream.get('magnetUrl'), stream.get('magnet_url'),
			behavior.get('filename'), behavior.get('folderName'), behavior.get('magnet'), behavior.get('magnetUrl'), behavior.get('magnet_url'),
			stream.get('folderName'), stream.get('filename'),
			stream.get('title'), stream.get('name'), stream.get('description')
		):
			normalized = self._hash_from_text(text) or self._hash_from_url_tokens(text)
			if normalized: return normalized
		# Dernier filet : Lumio peut encapsuler les champs dans des objets imbriqués.
		for value in self._iter_stream_values(stream):
			normalized = self._hash_from_text(value)
			if normalized: return normalized
		return None
	def _indexer_from_description(self, description):
		if not description: return None
		text = str(description).replace('\u2508\u27a4', '\n')
		match = re.search(r'[\U0001F50D\U0001F50E]\s*([^\n\r]+)', text)
		if not match: return None
		value = match.group(1).strip()
		return value or None

	def _known_tracker_label(self, text):
		try:
			if not text: return None
			value = str(text).lower()
			for old, repl in (('é', 'e'), ('è', 'e'), ('ê', 'e'), ('ë', 'e'), ('à', 'a'), ('â', 'a'), ('î', 'i'), ('ï', 'i'), ('ô', 'o'), ('ù', 'u'), ('û', 'u'), ('ç', 'c')):
				value = value.replace(old, repl)
			compact = re.sub(r'[^a-z0-9]+', ' ', value).strip()
			if re.search(r'\bfree\s*telecharg', compact): return 'Free-Telecharger'
			if re.search(r'\bwawa\s*city\b|\bwawacity\b', compact): return 'Wawacity'
			if re.search(r'\bdarki\s*api\b|\bdarkiapi\b|\bdarki\b', compact): return 'Darki'
			if re.search(r'\bwa\s*source\b|\bwasource\b', compact): return 'WASource'
			if re.search(r'\bsharewood\b|\bshare\s*wood\b', compact): return 'Sharewood'
			if re.search(r'\btirexo\b', compact): return 'Tirexo'
			if re.search(r'\bfrench\s*stream\b|\bfrenchstream\b', compact): return 'FrenchStream'
			if re.search(r'\bzone\s*telecharg(?:ement)?\b|\bzonetelecharg(?:ement)?\b|\bzone\s*annuaire\b|\bzoneannuaire\b|\bzt\b', compact): return 'ZoneTelechargement'
			if re.search(r'\b(?:0x|ox)\s*torrent\b|\b(?:0x|ox)torrent\b', compact): return 'OxTorrent'
			if re.search(r'\bmovix\b', compact): return 'Movix'
			if re.search(r'\bc\s*411\b|\bc411\b', compact): return 'C411'
			if re.search(r'\btorr(?:ent)?\s*[89]\b|\btorr[89]\b|\btorrent[89]\b', compact): return 'Torr9'
			if re.search(r'\bygg(?:torrent)?\b', compact): return 'YGG'
			if re.search(r'\bthe\s*old\s*school\b|\bold\s*school\b|\btos\b', compact): return 'The Old School'
			if re.search(r'\bla\s*cale\b|\blacale\b', compact): return 'La Cale'
			if re.search(r'\bgeneration\s*free\b|\bgenerationfree\b|\bgen\s*free\b|\bg\s*free\b', compact): return 'Generation-Free'
			if re.search(r'\btr4ker(?:\s*net)?\b', compact): return 'TR4KER'
			if re.search(r'\bv3x(?:\s*club)?\b', compact): return 'V3X'
			if re.search(r'\bg3\s*mini\s*(?:track3r|tracker)?\b|\bg3mini\s*(?:track3r|tracker)?\b|\bgemini\b', compact): return 'G3MINI TRACK3R'
			if re.search(r'\bnostradamus\b', compact): return 'Nostradamus'
		except:
			pass
		return None

	def _clean_tracker_label(self, value):
		try:
			if value in ('', None): return None
			value = str(value).replace('\u2508\u27a4', ' ')
			for symbol in ('🔍', '🔎', '☁', '📦', '🌎', '📁', '🎥', '🎞', '🏷'):
				value = value.replace(symbol, ' ')
			value = re.sub(r'\s+', ' ', value).strip(' -|,;')
			known = self._known_tracker_label(value)
			if known: return known
			# Ne jamais utiliser le nom du manifest custom comme tracker/site.
			manifest = str(getattr(self, 'display_name', '') or '').strip().lower()
			if manifest and value.strip().lower() == manifest:
				return None
			return value or None
		except:
			return None

	def _tracker_from_stream(self, stream, meta=None, behavior=None):
		meta = meta or stream.get('meta') or {}
		behavior = behavior or stream.get('behaviorHints') or {}
		# Même logique que AIOStreams : certains manifests placent le vrai
		# tracker/site dans la description visible, d'autres dans meta/indexer.
		for text in (
			stream.get('description'), stream.get('title'), stream.get('name'),
			behavior.get('filename'), stream.get('folderName'), stream.get('filename'),
			meta.get('indexer'), meta.get('tracker'), meta.get('site'), meta.get('source')
		):
			known = self._known_tracker_label(text)
			if known: return known
		for text in (stream.get('description'), stream.get('title'), stream.get('name'), behavior.get('filename')):
			tracker = self._clean_tracker_label(self._indexer_from_description(text or ''))
			if tracker: return tracker
		for value in (
			meta.get('indexer'), meta.get('tracker'), meta.get('site'), meta.get('source'),
			stream.get('indexer'), stream.get('tracker'), stream.get('site'), stream.get('source'),
			behavior.get('indexer'), behavior.get('tracker'), behavior.get('site'), behavior.get('source'),
			stream.get('addon'), stream.get('name')
		):
			tracker = self._clean_tracker_label(value)
			if tracker: return tracker
		return ''


	def _is_lumio_torrent_tracker(self, tracker):
		try:
			known = self._known_tracker_label(tracker) or tracker or ''
			value = str(known or '').strip().lower()
			return value in ('ygg', 'sharewood', 'c411', 'torr9', 'tr4ker', 'v3x')
		except:
			return False


	def _direct_url_from_stream(self, stream, meta=None, behavior=None):
		meta = meta or stream.get('meta') or {}
		behavior = behavior or stream.get('behaviorHints') or {}
		# Certains manifests Stremio retournent un lien jouable dans externalUrl
		# plutôt que dans url. alkoFlix doit donc l'accepter comme lien direct
		# lorsqu'aucun hash/magnet exploitable n'est fourni.
		for value in (
			stream.get('url'), stream.get('externalUrl'), stream.get('external_url'),
			stream.get('magnet'), stream.get('magnetUrl'), stream.get('magnet_url'),
			meta.get('url'), meta.get('externalUrl'), meta.get('external_url'),
			meta.get('magnet'), meta.get('magnetUrl'), meta.get('magnet_url'),
			behavior.get('url'), behavior.get('externalUrl'), behavior.get('external_url'),
			behavior.get('magnet'), behavior.get('magnetUrl'), behavior.get('magnet_url')
		):
			try:
				if value in ('', None): continue
				value = str(value).strip()
				if value: return value
			except:
				pass
		return ''

	def _is_lumio_manifest(self):
		return True

	def _debrid_from_direct_url(self, direct_url):
		try:
			url = str(direct_url or '').lower()
			if 'alldebrid' in url: return 'alldebrid'
			if 'real-debrid' in url or 'realdebrid' in url: return 'real-debrid'
			if 'premiumize' in url: return 'premiumize.me'
			if 'torbox' in url: return 'torbox'
		except:
			pass
		return 'alldebrid'

	def __init__(self):
		self.language = ['en', 'fr']
		self.display_name = 'LUMIO'
		manifest_url = getSetting('lumio.manifest_url', '').strip()
		self.base_link = self._base_from_manifest(manifest_url) if manifest_url else None
		self.movieSearch_link = '/stream/movie/%s.json'
		self.tvSearch_link = '/stream/series/%s:%s:%s.json'
		self.min_seeders = 0

	def sources(self, data, hostDict):
		sources = []
		if not data or not self.base_link: return sources
		sources_append = sources.append
		try:
			title = data['tvshowtitle'] if 'tvshowtitle' in data else data['title']
			title = title.replace('&', 'and').replace('Special Victims Unit', 'SVU').replace('/', ' ').replace(':', ' ')
			title = re.sub(r'\s+', ' ', title).strip()
			aliases = data['aliases']
			episode_title = data['title'] if 'tvshowtitle' in data else None
			total_seasons = data['total_seasons'] if 'tvshowtitle' in data else None
			year = data['year']
			imdb = data.get('imdb')
			catalogue_id = data.get('catalogue_id')
			catalogue_base_url = data.get('catalogue_base_url') or ''
			catalogue_video_id = data.get('catalogue_video_id') is True
			if catalogue_id is not None:
				catalogue_id = str(catalogue_id).strip()
				if catalogue_id.lower() in ('', 'none', 'null', 'false', '0'):
					catalogue_id = ''
			else:
				catalogue_id = ''
			if imdb is not None:
				imdb = str(imdb).strip()
				if imdb.lower() in ('', 'none', 'null', 'false', '0'):
					imdb = ''
			else:
				imdb = ''
			tmdb = data.get('tmdb')
			if tmdb is not None:
				tmdb = str(tmdb).strip()
				if tmdb.lower() in ('', 'none', 'null', 'false', '0'):
					tmdb = ''
			else:
				tmdb = ''
			use_catalogue_id = self._catalogue_id_belongs_to_this_manifest(catalogue_id, catalogue_base_url, catalogue_video_id)
			if 'tvshowtitle' in data:
				season = data['season']
				episode = data['episode']
				hdlr = 'S%02dE%02d' % (int(season), int(episode))
				# Les catalogues Stremio peuvent utiliser leur propre identifiant interne
				# pour les épisodes. Si cet identifiant est présent, il doit être
				# transmis au manifest avant l'IMDb, comme le fait Stremio.
				# L'identifiant doit être encodé entièrement, car certains IDs internes
				# contiennent des ':'; sinon le manifest reçoit un ID tronqué.
				request_id = catalogue_id if use_catalogue_id else self._standard_request_id(imdb, tmdb)
				if not request_id: return sources
				if catalogue_video_id and use_catalogue_id:
					url = '%s/stream/series/%s.json' % (self.base_link, quote(str(request_id), safe=''))
				else:
					url = '%s%s' % (self.base_link, self.tvSearch_link % (quote(str(request_id), safe=''), season, episode))
			else:
				hdlr = year
				request_id = catalogue_id if use_catalogue_id else self._standard_request_id(imdb, tmdb)
				if not request_id: return sources
				url = '%s%s' % (self.base_link, self.movieSearch_link % quote(str(request_id), safe=''))
			# log_utils.log('url = %s' % url)
			if 'timeout' in data: self.timeout = int(data['timeout'])
			results = client.request(url, timeout=self.timeout)
			files = jsloads(results).get('streams') or [] if results else []
			# Les résultats LUMIO doivent respecter la configuration du manifest.
			# Aucun filtre de langue alkoFlix n'est appliqué ici.
		except:
			source_utils.scraper_error('LUMIO')
			return sources

		for file in files:
			try:
				package, episode_start = None, 0
				meta = file.get('meta') or {}
				behavior = file.get('behaviorHints') or {}
				direct_url = self._direct_url_from_stream(file, meta, behavior)
				tracker = self._tracker_from_stream(file, meta, behavior)
				info_hash = self._hash_from_stream(file, meta, behavior, direct_url)
				raw_info_hash = info_hash
				source_type = (meta.get('type') or file.get('type') or '').lower()
				if source_type == 'nzb': source_type = 'usenet'
				if source_type == 'http': source_type = 'direct'
				is_magnet_url = bool(direct_url) and str(direct_url).lower().startswith('magnet:')
				if is_magnet_url:
					source_type = 'torrent'
				if info_hash and self._is_lumio_torrent_tracker(tracker):
					source_type = 'torrent'
				if not source_type:
					source_type = 'torrent' if info_hash else 'direct'
				# Plusieurs manifests Stremio fournissent une URL technique en plus du hash.
				# Si un hash existe, le résultat reste un magnet/torrent pour le sélecteur
				# et le débrideur. Les vrais liens directs restent directs.
				use_direct = bool(direct_url) and not is_magnet_url and not info_hash
				if not info_hash and not use_direct and direct_url:
					info_hash = self._hash_from_stream(file, meta, behavior, direct_url)
				info_hash = None if use_direct else info_hash

				release_title = self._release_title_from_stream(file, meta, behavior)
				display_title = source_utils.clean_display_name(release_title)
				name = source_utils.clean_name(release_title)
				if not name: continue

				if total_seasons is not None:
					valid, last_season = source_utils.filter_show_pack(title, aliases, imdb, year, season, name, total_seasons)
					if valid:
						package = 'show'
					else:
						valid, episode_start, episode_end = source_utils.filter_season_pack(title, aliases, year, season, name)
						if valid: package = 'season'
				name_info = source_utils.info_from_name(name, title, year, hdlr, episode_title)
				name_info = re.sub(r'\b4khdhub(?:\.com)?\b', '', name_info, flags=re.I)
				name_info = re.sub(r'\.{2,}', '.', name_info)
				language = source_utils.release_language(name_info)

				if use_direct:
					if not direct_url: continue
					url = direct_url
				else:
					if not info_hash: continue
					url = 'magnet:?xt=urn:btih:%s&dn=%s' % (info_hash, name)

				seeders = 0
				is_lumio_manifest = self._is_lumio_manifest()

				quality, info = source_utils.get_release_quality(name_info, url)
				dsize = 0
				try:
					size = self._size_from_stream(file, meta, behavior)
					if size:
						dsize, isize = source_utils._size(size)
						if isize: info.insert(0, isize)
				except:
					dsize = 0
				info = ' | '.join(info)

				if use_direct:
					item = {
						'source': self.display_name or source_type or 'direct', 'language': language, 'direct': True, 'debridonly': False,
						'provider': 'lumio', 'url': url, 'name': name, 'display_title': display_title, 'name_info': name_info,
						'quality': quality, 'info': info, 'size': dsize, 'seeders': seeders,
						'lumio_direct': True, 'debrid': self._debrid_from_direct_url(url), 'provider_name': self.display_name, 'source_site': self.display_name,
						'bypass_filter': True, 'true_size': True
					}
				else:
					item = {
						'source': 'torrent', 'language': language, 'direct': False, 'debridonly': True,
						'provider': 'lumio', 'hash': info_hash, 'mHash': info_hash, 'infoHash': info_hash, 'url': url, 'name': name, 'display_title': display_title, 'name_info': name_info,
						'quality': quality, 'info': info, 'size': dsize, 'seeders': seeders, 'provider_name': self.display_name, 'source_site': self.display_name,
						'bypass_filter': True, 'true_size': True
					}
				if is_lumio_manifest:
					item['lumio_direct'] = bool(use_direct)
					item['custom_manifest'] = item.get('custom_manifest') or 'LUMIO'
					item['manifest_label'] = item.get('manifest_label') or 'LUMIO'
					if not item.get('provider_name') or str(item.get('provider_name')).lower().startswith('custom'):
						item['provider_name'] = 'LUMIO'

				if source_type == 'usenet' and not tracker: tracker = 'usenet'
				if tracker and str(tracker).strip().lower() not in ('n/a', 'na'):
					item['tracker'] = tracker
					item['source_site'] = tracker
				if package: item['package'] = package
				if package == 'show': item.update({'last_season': last_season})
				if episode_start: item.update({'episode_start': episode_start, 'episode_end': episode_end}) # for partial season packs
				sources_append(item)
			except:
				source_utils.scraper_error('LUMIO')
		return sources
