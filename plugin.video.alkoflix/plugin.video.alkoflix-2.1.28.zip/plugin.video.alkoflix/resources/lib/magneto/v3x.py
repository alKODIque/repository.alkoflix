# -*- coding: utf-8 -*-
# plugin.video.alkoflix
# resources/lib/magneto/v3x.py

import re

from modules.private_torznab import PrivateTorznabSource
from modules import anime_episode_map


class source(PrivateTorznabSource):
    provider_key = 'v3x'
    provider_name = 'V3X'
    api_setting = 'private.v3x.api_key'
    base_url = 'https://api.v3x.club/torznab'
    response_mode = 'xml'

    # V3X expose un indexer Torznab natif pour Jackett/Prowlarr. La clé personnelle
    # est envoyée uniquement comme paramètre Torznab `apikey`.
    auth_mode = 'query_apikey'
    auth_modes = ('query_apikey',)
    try_next_auth_on_empty = False

    # Catégories indiquées par la documentation V3X pour les clients Torznab directs.
    movie_categories = '2000'
    episode_categories = '5000'
    season_categories = '5000'
    show_categories = '5000'

    # Tracker privé : les résultats restent filtrés localement. alkoFlix ne transmet
    # jamais le .torrent personnalisé (et donc jamais la passkey) au débrideur :
    # seul l'infohash/magnet propre exposé par Torznab est utilisé.
    trust_api_results = False
    allow_loose_private_match = False
    max_requests_per_minute = 60
    timeout = 8
    priority = 4

    def _request_attempts(self, params, api_key):
        request_params = dict(params or {})
        # Demande les attributs Torznab étendus quand l'indexer les propose
        # (infohash, magneturl, seeders, taille, etc.).
        request_params.setdefault('extended', '1')
        request_params['apikey'] = api_key
        return [(self.base_url, request_params, {}, 'query_apikey')]

    def _clean_tmdb_id(self, data):
        try:
            value = str((data or {}).get('tmdb') or (data or {}).get('tmdb_id') or '').strip()
            if not value:
                return ''
            match = re.search(r'(\d+)', value)
            return match.group(1) if match else ''
        except:
            return ''

    def _clean_imdb_id(self, data):
        try:
            value = str((data or {}).get('imdb') or (data or {}).get('imdb_id') or '').strip()
            if not value or value.lower() in ('none', 'null', 'false', '0'):
                return ''
            match = re.search(r'tt\d+', value, re.I)
            if match:
                return match.group(0).lower()
            match = re.search(r'\d+', value)
            return 'tt%s' % match.group(0) if match else ''
        except:
            return ''

    def _query_text(self, *parts):
        try:
            text = ' '.join(str(i or '').strip() for i in parts if str(i or '').strip())
            return re.sub(r'\s+', ' ', text).strip()
        except:
            return ''

    def _id_params_chain(self, data, search_type, include_episode=False, season_only=False):
        params_list = []
        try:
            base = {'t': search_type}
            if include_episode or season_only:
                season = (data or {}).get('season')
                if season not in ('', None):
                    base['season'] = str(season)
            if include_episode:
                episode = (data or {}).get('episode')
                if episode not in ('', None):
                    base['ep'] = str(episode)

            # TMDb d'abord : identifiant principal d'alkoFlix.
            tmdb = self._clean_tmdb_id(data)
            if tmdb:
                params = dict(base)
                params['tmdbid'] = tmdb
                self._append_unique_params(params_list, params)

            imdb = self._clean_imdb_id(data)
            if imdb:
                params = dict(base)
                params['imdbid'] = imdb
                self._append_unique_params(params_list, params)
        except:
            pass
        return params_list

    def _movie_params(self, data):
        params_list = self._id_params_chain(data, 'movie')
        try:
            query = self._query_text(data.get('title'), data.get('year'))
            if query:
                self._append_unique_params(params_list, {'t': 'search', 'q': query})
            title_only = self._query_text(data.get('title'))
            if title_only and title_only != query:
                self._append_unique_params(params_list, {'t': 'search', 'q': title_only})
        except:
            pass
        return params_list

    def _episode_params(self, data):
        params_list = []
        variants = anime_episode_map.episode_data_variants(data) if data.get('anime_context') else [data]
        try:
            show = self._query_text(data.get('tvshowtitle'))
            for variant in variants:
                for params in self._id_params_chain(variant, 'tvsearch', include_episode=True):
                    self._append_unique_params(params_list, params)
                season = int(variant.get('season') or 0)
                episode = int(variant.get('episode') or 0)
                if show and season and episode:
                    self._append_unique_params(params_list, {'t': 'tvsearch', 'q': show, 'season': str(season), 'ep': str(episode)})
            for suffix in (anime_episode_map.search_suffixes(data)[:8] if data.get('anime_context') else []):
                self._append_unique_params(params_list, {'t': 'search', 'q': '%s %s' % (show, suffix)})
            if show and not data.get('anime_context'):
                season = int(data.get('season') or 0)
                episode = int(data.get('episode') or 0)
                if season and episode:
                    self._append_unique_params(params_list, {'t': 'search', 'q': '%s S%02dE%02d' % (show, season, episode)})
                    self._append_unique_params(params_list, {'t': 'search', 'q': '%s %dx%02d' % (show, season, episode)})
        except:
            pass
        return params_list

    def _season_params(self, data):
        params_list = []
        variants = anime_episode_map.season_data_variants(data) if data.get('anime_context') else [data]
        try:
            show = self._query_text(data.get('tvshowtitle'))
            for variant in variants:
                for params in self._id_params_chain(variant, 'tvsearch', season_only=True):
                    self._append_unique_params(params_list, params)
                season = int(variant.get('season') or 0)
                if show and season:
                    self._append_unique_params(params_list, {'t': 'tvsearch', 'q': show, 'season': str(season)})
                    self._append_unique_params(params_list, {'t': 'search', 'q': '%s S%02d' % (show, season)})
        except:
            pass
        return params_list

    def _show_params(self, data):
        params_list = self._id_params_chain(data, 'tvsearch')
        try:
            show = self._query_text(data.get('tvshowtitle'))
            if show:
                self._append_unique_params(params_list, {'t': 'tvsearch', 'q': show})
                self._append_unique_params(params_list, {'t': 'search', 'q': show})
        except:
            pass
        return params_list
