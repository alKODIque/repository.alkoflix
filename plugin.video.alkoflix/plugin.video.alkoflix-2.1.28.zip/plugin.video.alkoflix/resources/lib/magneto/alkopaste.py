# alkoFlix v1.5.42 catalogue ordering/filter fixes
# -*- coding: utf-8 -*-
# plugin.video.alkoflix
# resources/lib/magneto/alkopaste.py

import ast
import gzip
import hashlib
import json
import os
import re
import sqlite3
import time
import unicodedata
from datetime import timedelta
import requests

from caches.main_cache import MainCache
from magneto.hosters.common import BaseHosterSource, clean_text, normalize_quality, language_code, hoster_key, parse_size_gb
from modules import kodi_utils, anime_episode_map


# ---------------------------------------------------------------------------
# Configuration interne alkoPaste
# ---------------------------------------------------------------------------
# alkoPaste lit maintenant uniquement une configuration racine distante.
#
# Ce code pointe vers un raw de configuration public. Le raw de configuration
# pointe ensuite vers l’index maître côté alkoPaste. Les codes enfants/index
# doivent donc être gérés côté site, pas dans l’addon.
ALKOPASTE_BASE_URL = 'https://paste.lesalkodiques.com/raw/%s'
ALKOPASTE_CATALOGUE_REMOTE_MANIFEST = 'https://paste.lesalkodiques.com/catalogue/manifest.json'
ALKOPASTE_SOURCE_REMOTE_MANIFEST = 'https://paste.lesalkodiques.com/source/manifest.json'

# Seul code visible dans l’addon : la configuration racine officielle.
ALKOPASTE_REMOTE_CONFIG_CODES = ('K4AUmGqJ',)

# Aucun code enfant statique, aucun fallback hardcodé.
ALKOPASTE_FILM_CODES = ()
ALKOPASTE_SERIES_CODES = ()
ALKOPASTE_INDEX_CODES = {}
ALKOPASTE_ALL_INDEX_CATEGORIES = ()
ALKOPASTE_MOVIE_INDEX_CATEGORIES = ()
ALKOPASTE_SERIES_INDEX_CATEGORIES = ()
ALKOPASTE_EXTRA_CODES = ()

ALLDEBRID_DEFAULT_BASE_URL = 'https://alldebrid.com/f/'
PASTE_CACHE_HOURS = 6
INDEX_CACHE_HOURS = 24
DB_SYNC_INTERVAL_HOURS = 24
INDEX_MAX_DEPTH = 8
# Version des clés de cache : à incrémenter quand la logique de parsing change.
# Cela force un nouveau chargement des raws sans demander aux utilisateurs de vider les caches.
ALKOPASTE_CACHE_VERSION = 'v13'
ALKOPASTE_DB_VERSION = 9
ALKOPASTE_CATALOGUE_DB_VERSION = 3
ALKOPASTE_DB = 'special://profile/addon_data/plugin.video.alkoflix/alkopaste.db'
ALKOPASTE_CATALOGUE_DB = 'special://profile/addon_data/plugin.video.alkoflix/alkopaste_catalogue.db'

COL_CAT = 0
COL_TMDB = 1
COL_TITLE = 2
COL_SAISON = 3
COL_GROUPES = 4
COL_NETWORK = 7
COL_YEAR = 8
COL_GENRES = 9
COL_RES = 10
COL_SIZE = 11
COL_URLS = 12
LEGACY_COL_URLS = 11

SERIES_URL_PATTERN = re.compile(r"(\d+)\s*:\s*(?:([\'\"])(.*?)\2|([^,\]\}]+))")
CODE_LINE_PATTERN = re.compile(r'^[A-Za-z0-9]{4,32}$')
INLINE_CODE_PATTERN = re.compile(r'(?<![A-Za-z0-9])(?=[A-Za-z0-9]{0,7}\d)([A-Za-z0-9]{8})(?![A-Za-z0-9])')
RAW_URL_PATTERN = re.compile(r'https?://[^\s#;]+/raw/[A-Za-z0-9]{4,32}', re.I)

SERIES_CAT_KEYS = (
	'serie', 'series', 'tvshow', 'tvshows', 'episode', 'episodes',
	'anime', 'animes', 'animejaponais', 'animesjaponais',
	'daserie', 'daseries', 'dessinsanimeserie', 'dessinsanimesserie',
	'dessinsanimeseries', 'animationserie', 'animationseries'
)
MOVIE_CAT_KEYS = (
	'film', 'films', 'movie', 'movies', 'docu', 'docus', 'documentaire',
	'documentaires', 'documentary', 'replay', 'quebec', 'concert', 'concerts',
	'spectacle', 'spectacles', 'dafilm', 'dafilms', 'dessinsanimesfilm',
	'dessinsanimesfilms', 'animationfilm', 'animationfilms'
)


def _cat_key(value):
	try:
		text = unicodedata.normalize('NFKD', str(value or '').lower())
		text = ''.join(ch for ch in text if not unicodedata.combining(ch))
		return re.sub(r'[^a-z0-9]+', '', text)
	except:
		return ''


def _normalize_cat(value):
	key = _cat_key(value)
	if key in SERIES_CAT_KEYS: return 'serie'
	if key in MOVIE_CAT_KEYS: return 'film'
	# Les codes alkoPaste peuvent utiliser des variantes plus parlantes :
	# "Films d'animation", "Séries QC", "Documentaires", etc.
	# Pour l'index catalogue, on doit donc reconnaître les familles par contenu,
	# et non seulement par clés exactes.
	if any(token in key for token in ('serie', 'series', 'tvshow', 'tvshows', 'episode', 'episodes')):
		return 'serie'
	if any(token in key for token in ('film', 'films', 'movie', 'movies', 'concert', 'spectacle', 'replay')):
		return 'film'
	if any(token in key for token in ('docu', 'documentaire', 'documentary', 'quebec', 'contenuqc', 'qc')):
		return 'film'
	if any(token in key for token in ('anime', 'animes', 'animejaponais', 'animesjaponais', 'japanime', 'manga')):
		# Si le libellé ne précise pas série/film, on garde le comportement historique anime=série.
		return 'serie'
	if 'dessin' in key or key.startswith('da') or 'animation' in key:
		# "Dessins animés" seul est ambigu : sans précision série, on le traite comme film.
		return 'film'
	return key


def _safe_int(value, default=None):
	try:
		if value in ('', None): return default
		return int(str(value).strip())
	except:
		return default



def _dedupe_append(target, value):
	try:
		value = str(value or '').strip()
		if value and value not in target: target.append(value)
	except:
		pass


def _is_blank_size(value):
	try:
		return str(value or '').strip().lower() in ('', 'none', 'null', 'false', '0', '0.0', '0,0')
	except:
		return True


def _size_gb(value):
	try:
		if _is_blank_size(value): return 0.0
		if isinstance(value, (int, float)): return round(float(value), 2)
		text = clean_text(value).replace(',', '.').strip()
		# Dans les pastes ALKO, la colonne SIZE est en Go. Une valeur brute "0.68"
		# doit donc être traitée comme 0.68 Go, pas ignorée faute d'unité.
		if re.match(r'^[0-9]+(?:\.[0-9]+)?$', text): return round(float(text), 2)
		return parse_size_gb(text)
	except:
		return 0.0


def _size_at_index(size_raw, index):
	try:
		values = _literal_list(size_raw)
		if isinstance(values, list) and values:
			return _size_gb(values[index]) if index < len(values) else 0.0
		if index == 0: return _size_gb(size_raw)
	except:
		pass
	return 0.0


def _series_size_map(size_raw):
	items = {}
	try:
		for ep_num, value in _series_urls(size_raw):
			items[int(ep_num)] = _size_gb(value)
	except:
		pass
	return items


def _row_urls_raw(parts):
	try:
		if len(parts) > COL_URLS: return parts[COL_URLS].strip()
		if len(parts) > LEGACY_COL_URLS: return parts[LEGACY_COL_URLS].strip()
	except:
		pass
	return ''


def _row_size_raw(parts):
	try:
		# Ancien format : CAT;TMDB;TITLE;SAISON;GROUPES;CAST;DIRECTOR;NETWORK;YEAR;GENRES;RES;URLS
		# Nouveau format : CAT;TMDB;TITLE;SAISON;GROUPES;CAST;DIRECTOR;NETWORK;YEAR;GENRES;RES;SIZE;URLS
		if len(parts) > COL_URLS: return parts[COL_SIZE].strip()
	except:
		pass
	return ''


def _header_has_urls(parts):
	try:
		for idx in (COL_URLS, LEGACY_COL_URLS):
			if len(parts) > idx and str(parts[idx] or '').strip().upper().startswith('URLS'):
				return True
		return any(str(part or '').strip().upper().startswith('URLS=') for part in parts)
	except:
		return False


def _target_tmdb_ids(data):
	ids = []
	try:
		for key in ('tmdb', 'tmdb_id', 'tmdbid'):
			value = str((data or {}).get(key) or '').strip()
			if value and value not in ('0', 'None', 'none', 'null') and value not in ids:
				ids.append(value)
	except:
		pass
	return ids

def _wanted_episodes_for_row(data, row_season, target_episode):
	try:
		if data.get('anime_context') and row_season is not None:
			# Source ALKO indexe déjà par saison + épisode. En contexte anime, on
			# doit donc accepter seulement les paires explicites valides (TMDb
			# canonique + vrais remappings de groupes TMDb), pas les candidats
			# same-season parasites comme S01E11 quand la cible utile est S02E11.
			numbers = anime_episode_map.explicit_episode_numbers_for_season(data, row_season)
			if numbers: return numbers
	except:
		pass
	return [target_episode] if target_episode is not None else []

def _series_query_seasons(data, target_season):
	try:
		if data.get('anime_context'):
			seasons = anime_episode_map.season_candidates(data)
			if seasons: return seasons
	except:
		pass
	return [target_season] if target_season is not None else []

def _display_data_for_episode(data, row_season, ep_num):
	try:
		item = dict(data or {})
		if row_season is not None: item['season'] = row_season
		item['episode'] = ep_num
		return item
	except:
		return data

def _code_url(code):
	code = str(code or '').strip()
	if not code: return ''
	if code.startswith('http://') or code.startswith('https://'): return code
	return ALKOPASTE_BASE_URL % code


def _content_cache_key(url):
	try:
		return 'alkoflix_alkopaste_%s_raw_%s' % (ALKOPASTE_CACHE_VERSION, hashlib.md5(url.encode('utf-8'), usedforsecurity=False).hexdigest())
	except TypeError:
		return 'alkoflix_alkopaste_%s_raw_%s' % (ALKOPASTE_CACHE_VERSION, hashlib.md5(url.encode('utf-8')).hexdigest())


def _index_cache_key(code):
	try:
		return 'alkoflix_alkopaste_%s_index_%s' % (ALKOPASTE_CACHE_VERSION, hashlib.md5(str(code).encode('utf-8'), usedforsecurity=False).hexdigest())
	except TypeError:
		return 'alkoflix_alkopaste_%s_index_%s' % (ALKOPASTE_CACHE_VERSION, hashlib.md5(str(code).encode('utf-8')).hexdigest())


def _fetch_text(url):
	if not url: return ''
	cache_key = _content_cache_key(url)
	cache = MainCache()
	cached = cache.get(cache_key)
	if cached: return cached
	try:
		response = requests.get(url, timeout=12)
		if response.status_code != 200: return ''
		text = response.text or ''
		if text:
			cache.set(cache_key, text, expiration=timedelta(hours=PASTE_CACHE_HOURS))
		return text
	except Exception as e:
		try: kodi_utils.logger('alkoPaste', 'Lecture raw impossible | url=%s | erreur=%s' % (url, type(e).__name__))
		except: pass
		return ''


def _base_url_from_header(header):
	try:
		parts = str(header or '').split(';')
		# Nouveau format : URLS=... en colonne 12. Ancien format : URLS=... en colonne 11.
		for idx in (COL_URLS, LEGACY_COL_URLS):
			if len(parts) <= idx: continue
			value = parts[idx].strip()
			if value.upper().startswith('URLS') and '=' in value:
				base = value.split('=', 1)[1].strip()
				if base: return base
		# Défense bonus : si l'entête est déplacée un jour, on cherche la cellule URLS=...
		for value in parts:
			value = str(value or '').strip()
			if value.upper().startswith('URLS') and '=' in value:
				base = value.split('=', 1)[1].strip()
				if base: return base
	except:
		pass
	return ALLDEBRID_DEFAULT_BASE_URL

def _full_url(base_url, suffix):
	try:
		suffix = str(suffix or '').strip()
		if not suffix: return ''
		if suffix.startswith('http://') or suffix.startswith('https://') or suffix.startswith('magnet:'):
			return suffix
		base_url = str(base_url or ALLDEBRID_DEFAULT_BASE_URL).strip()
		# Les pastes historiques stockent les suffixes AllDebrid à concaténer directement.
		return '%s%s' % (base_url, suffix)
	except:
		return ''



def _literal_list(value):
	try:
		result = ast.literal_eval(value or '[]')
		return result if isinstance(result, list) else []
	except:
		return []




def _clean_list_value(value):
	try:
		text = clean_text(value)
		text = re.sub(r'\s+', ' ', text).strip()
		# Les pastes peuvent contenir des cellules vides sous forme de texte
		# (ex. [] ou Sans genre). On les ignore complètement dans le catalogue.
		if not text: return ''
		compact = re.sub(r'\s+', '', text).strip().lower()
		if compact in ('[]', '[ ]', '{}', 'none', 'null', 'n/a', 'na', '-', '--'):
			return ''
		if compact in ('sansgenre', 'sansgenres', 'sans_genre', 'sangenre', 'indetermine', 'indéterminé', 'nonclasse', 'nonclassé'):
			return ''
		return text
	except:
		return ''


def _cell_values(value):
	values = []
	try:
		literal = _literal_list(value)
		if isinstance(literal, list) and literal:
			for item in literal:
				text = _clean_list_value(item)
				if text and text not in values: values.append(text)
			return values
	except:
		pass
	try:
		text = str(value or '').strip()
		if not text: return []
		for part in re.split(r'\s*[,|]\s*', text):
			part = _clean_list_value(part)
			if part and part not in values: values.append(part)
	except:
		pass
	return values


def _row_value(parts, index):
	try:
		return parts[index].strip() if len(parts) > index else ''
	except:
		return ''


def _catalogue_media_type_from_key(raw_key, normalized):
	try:
		key = _cat_key(raw_key)
		if normalized == 'serie' or 'serie' in key or 'series' in key or 'tvshow' in key or 'episode' in key:
			return 'serie'
		return 'film'
	except:
		return 'film'


def _catalogue_section(raw_cat, media_type):
	key = _cat_key(raw_cat)
	is_series = media_type == 'serie'
	if any(token in key for token in ('animejaponais', 'animesjaponais', 'japanime', 'manga')) or key in ('anime', 'animes'):
		return 'anime_series' if is_series else 'anime_movie'
	if 'dessin' in key or key.startswith('da') or 'animation' in key:
		return 'animation_series' if is_series else 'animation_movie'
	if 'docu' in key or 'documentaire' in key or 'documentary' in key:
		return 'documentary_series' if is_series else 'documentary_movie'
	if 'quebec' in key or key in ('qc', 'contenuqc') or key.startswith('qc'):
		return 'qc_series' if is_series else 'qc_movie'
	if 'concert' in key:
		return 'concerts'
	if 'spectacle' in key or 'showhumour' in key or 'humour' in key:
		return 'spectacles'
	return 'series' if is_series else 'films'


def _catalogue_row_hash(media_type, tmdb_id, section, paste_code, source_order):
	try:
		payload = '|'.join((str(media_type or ''), str(tmdb_id or ''), str(section or ''), str(paste_code or ''), str(source_order or '')))
		try:
			return hashlib.sha1(payload.encode('utf-8'), usedforsecurity=False).hexdigest()
		except TypeError:
			return hashlib.sha1(payload.encode('utf-8')).hexdigest()
	except:
		return str(int(time.time() * 1000))


def _catalogue_term_hash(section, media_type, tmdb_id, term_type, root, value, source_order):
	try:
		payload = '|'.join((str(section or ''), str(media_type or ''), str(tmdb_id or ''), str(term_type or ''), str(root or ''), str(value or ''), str(source_order or '')))
		try:
			return hashlib.sha1(payload.encode('utf-8'), usedforsecurity=False).hexdigest()
		except TypeError:
			return hashlib.sha1(payload.encode('utf-8')).hexdigest()
	except:
		return str(int(time.time() * 1000))


def _term_insert(dbcur, section, media_type, tmdb_id, term_type, value, label='', root='', source_order=0):
	try:
		value = _clean_list_value(value)
		if not value: return 0
		label = _clean_list_value(label) or value
		root = _clean_list_value(root)
		row_hash = _catalogue_term_hash(section, media_type, tmdb_id, term_type, root, value, source_order)
		dbcur.execute("""INSERT OR IGNORE INTO alko_catalogue_terms
			(section, media_type, tmdb_id, term_type, root, value, label, source_order, row_hash, updated_at)
			VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
			(str(section or '').strip(), str(media_type or '').strip(), str(tmdb_id or '').strip(),
			str(term_type or '').strip(), root, value, label, int(source_order or 0), row_hash, int(time.time())))
		return dbcur.rowcount or 0
	except Exception:
		return 0


NETWORK_LABEL_ALIASES = {
	'staez': 'Starz',
	'starz': 'Starz'
}


def _network_alias_key(value):
	try:
		text = _clean_list_value(value).lower()
		text = unicodedata.normalize('NFKD', text)
		text = ''.join(ch for ch in text if not unicodedata.combining(ch))
		return re.sub(r'[^a-z0-9]+', '', text)
	except:
		return ''


def _canonical_network_label(label):
	label = _clean_list_value(label)
	if not label: return ''
	return NETWORK_LABEL_ALIASES.get(_network_alias_key(label), label)


def _network_id_from_value(value):
	text = _clean_list_value(value)
	if not text: return ''
	if ':' in text:
		return _clean_list_value(text.split(':', 1)[0])
	return text if text.isdigit() else ''


def _network_filter_aliases(filter_value):
	text = _clean_list_value(filter_value)
	if not text: return [], ''
	network_id = _network_id_from_value(text)
	label = text.split(':', 1)[1] if ':' in text else text
	canonical = _canonical_network_label(label) or label
	labels = set([_clean_list_value(label), _clean_list_value(canonical)])
	alias_key = _network_alias_key(canonical)
	for raw_key, raw_label in NETWORK_LABEL_ALIASES.items():
		if _network_alias_key(raw_label) == alias_key:
			labels.add(raw_label)
			labels.add(raw_key.upper())
	values = set(labels)
	if network_id:
		values.add(network_id)
		for item in list(labels):
			if item:
				values.add('%s:%s' % (network_id, item))
	return [v for v in values if v], network_id


def _network_value_label(value):
	text = _clean_list_value(value)
	if not text: return '', ''
	if ':' in text:
		network_id, network_name = text.split(':', 1)
		network_id = _clean_list_value(network_id)
		label = _canonical_network_label(network_name)
		value = '%s:%s' % (network_id, label) if network_id and label else (network_id or label)
		return value, label or value
	label = _canonical_network_label(text)
	return label, label


def _title_alpha_value(title):
	try:
		text = clean_text(title)
		if not text: return ''
		first = unicodedata.normalize('NFKD', text[0].upper())
		first = ''.join(ch for ch in first if not unicodedata.combining(ch))[:1]
		if first and first.isdigit(): return '0-9'
		if first and 'A' <= first <= 'Z': return first
	except:
		pass
	return '#'


def _insert_catalogue_terms(dbcur, media_type, tmdb_id, title, year, section, groups_raw, network_raw, genres_raw, source_order):
	added = 0
	try:
		for raw_genre in _cell_values(genres_raw):
			label = _catalogue_genre_label(raw_genre, media_type)
			added += _term_insert(dbcur, section, media_type, tmdb_id, 'genre', raw_genre, label, '', source_order)
		# Les diffuseurs sont utiles seulement côté séries dans le Catalogue alkoPaste.
		# On évite d'indexer des valeurs film inutiles qui alourdissent les menus.
		if str(media_type or '') == 'serie':
			for raw_network in _cell_values(network_raw):
				value, label = _network_value_label(raw_network)
				if label.lower() in ('tous', 'tout', 'all') or value.lower() in ('tous', 'tout', 'all'):
					continue
				added += _term_insert(dbcur, section, media_type, tmdb_id, 'network', value, label, '', source_order)
		for raw_group in _cell_values(groups_raw):
			root, child = _theme_parts(raw_group)
			if root:
				added += _term_insert(dbcur, section, media_type, tmdb_id, 'group_root', root, root, '', source_order)
			if root and child:
				added += _term_insert(dbcur, section, media_type, tmdb_id, 'group_child', child, child, root, source_order)
		if year:
			added += _term_insert(dbcur, section, media_type, tmdb_id, 'year', str(year), str(year), '', source_order)
		alpha = _title_alpha_value(title)
		if alpha:
			added += _term_insert(dbcur, section, media_type, tmdb_id, 'alpha', alpha, alpha, '', source_order)
	except Exception:
		pass
	return added


def _insert_catalogue_row(dbcur, media_type, tmdb_id, title, year, raw_cat, groups_raw, network_raw, genres_raw, paste_code, source_order):
	try:
		tmdb_id = str(tmdb_id or '').strip()
		if not tmdb_id or tmdb_id in ('0', 'None', 'none', 'null'): return 0
		media_type = 'serie' if media_type == 'serie' else 'film'
		section = _catalogue_section(raw_cat, media_type)
		groups = json.dumps(_cell_values(groups_raw), ensure_ascii=False)
		networks = json.dumps(_cell_values(network_raw), ensure_ascii=False)
		genres = json.dumps(_cell_values(genres_raw), ensure_ascii=False)
		row_hash = _catalogue_row_hash(media_type, tmdb_id, section, paste_code, source_order)
		dbcur.execute("""INSERT OR IGNORE INTO alko_catalogue
			(media_type, tmdb_id, title, year, raw_cat, section, groups_json, networks_json, genres_json, paste_code, source_order, row_hash, updated_at)
			VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
			(media_type, tmdb_id, clean_text(title), year, clean_text(raw_cat), section, groups, networks, genres,
			str(paste_code or '').strip(), int(source_order or 0), row_hash, int(time.time())))
		row_added = dbcur.rowcount or 0
		# Index secondaire inspiré de la logique vStream : les menus ne relisent plus toutes
		# les lignes média pour extraire genres/listes/diffuseurs. Les valeurs sont
		# normalisées une fois pendant la reconstruction, puis servies par requêtes SQL.
		_insert_catalogue_terms(dbcur, media_type, tmdb_id, title, year, section, groups_raw, network_raw, genres_raw, source_order)
		return row_added
	except Exception:
		return 0

def _series_urls(urls_raw):
	try:
		items = []
		for match in SERIES_URL_PATTERN.findall(urls_raw or ''):
			# match = (episode, quote, quoted_suffix, unquoted_suffix)
			suffix = match[2] or match[3] or ''
			suffix = str(suffix).strip().strip('\"\'')
			if suffix:
				items.append((int(match[0]), suffix))
		return items
	except:
		return []


def _looks_like_content_paste(content):
	try:
		lines = [line.strip() for line in (content or '').splitlines() if line.strip()]
		if not lines: return False
		header_parts = lines[0].split(';')
		header_text = ';'.join(header_parts).upper()
		if _header_has_urls(header_parts): return True
		# Le Catalogue alkoPaste peut utiliser les mêmes colonnes média sans forcément
		# exposer de liens. On reconnaît donc aussi les raws structurés CAT/TMDB/TITLE.
		if 'CAT' in header_text and 'TMDB' in header_text and 'TITLE' in header_text: return True
		# Fallback pour un raw sans header mais contenant des lignes structurées.
		for line in lines[:8]:
			parts = line.split(';')
			if len(parts) > COL_TMDB and _normalize_cat(parts[COL_CAT].strip()) in ('film', 'serie') and str(parts[COL_TMDB]).strip():
				return True
	except:
		pass
	return False

def _extract_index_codes(content):
	codes = []
	seen = set()
	try:
		for raw_line in (content or '').splitlines():
			line = (raw_line or '').strip().lstrip('\ufeff')
			if not line: continue

			# Accepte les URLs raw complètes, qu'elles soient seules ou intégrées dans une ligne.
			for url in RAW_URL_PATTERN.findall(line):
				if url not in seen:
					seen.add(url)
					codes.append(url)

			# Ancien format : une ligne contient seulement un code, parfois suivi d'un commentaire.
			plain = line.split('#', 1)[0].strip()
			if plain and CODE_LINE_PATTERN.match(plain):
				if plain not in seen:
					seen.add(plain)
					codes.append(plain)
				continue

			# Nouveau format accepté : "# Films: codeIndex # Séries: autreCode ..."
			# On cible seulement les codes 8 caractères pour ne pas confondre les libellés avec des codes.
			for code in INLINE_CODE_PATTERN.findall(line):
				if code not in seen:
					seen.add(code)
					codes.append(code)
	except:
		pass
	return codes

def _remote_config_index_codes():
	codes = []
	try:
		for config_code in ALKOPASTE_REMOTE_CONFIG_CODES:
			content = _fetch_text(_code_url(config_code))
			if not content: continue
			try:
				payload = json.loads(content.strip())
			except:
				payload = {}
			index_refs = []
			if isinstance(payload, dict):
				for key in ('pasteMasterIndexUrl', 'paste_master_index_url', 'masterIndexUrl', 'indexUrl', 'url'):
					value = str(payload.get(key) or '').strip()
					if value and value not in index_refs: index_refs.append(value)
				for key in ('pasteMasterIndexCode', 'paste_master_index_code', 'masterIndexCode', 'indexCode', 'code'):
					value = str(payload.get(key) or '').strip()
					if value and value not in index_refs: index_refs.append(value)
			else:
				index_refs.extend(_extract_index_codes(content))
			if not index_refs:
				index_refs.extend(_extract_index_codes(content))

			for ref in index_refs:
				index_content = _fetch_text(_code_url(ref))
				for code in _extract_index_codes(index_content):
					_dedupe_append(codes, code)
	except Exception as e:
		try: kodi_utils.logger('alkoPaste', 'Configuration distante ignorée | erreur=%s' % type(e).__name__)
		except: pass
	return codes


def _resolve_index_code(code, depth=0, visited=None):
	visited = visited or set()
	code = str(code or '').strip()
	if not code or code in visited or depth > INDEX_MAX_DEPTH: return []
	visited.add(code)
	cache = MainCache()
	cache_key = _index_cache_key('%s:%s' % (code, depth))
	cached = cache.get(cache_key)
	if cached:
		try:
			return list(cached)
		except:
			pass

	url = _code_url(code)
	content = _fetch_text(url)
	if not content: return []

	if _looks_like_content_paste(content):
		resolved = [code]
	else:
		resolved = []
		for child_code in _extract_index_codes(content):
			for leaf_code in _resolve_index_code(child_code, depth + 1, visited):
				if leaf_code not in resolved:
					resolved.append(leaf_code)

	try:
		cache.set(cache_key, resolved, expiration=timedelta(hours=INDEX_CACHE_HOURS))
	except:
		pass
	return resolved


def _codes_from_categories(categories):
	codes = []
	for category in categories:
		for code in ALKOPASTE_INDEX_CODES.get(category, ()): 
			if code not in codes: codes.append(code)
	return codes


def _code_entries_for_media(media_type):
	root_codes = []
	wanted = 'serie' if media_type == 'episode' else 'film'
	# Source unique : configuration distante. Aucun code enfant/fallback n’est hardcodé.
	for code in _remote_config_index_codes():
		if code not in root_codes: root_codes.append(code)

	content_codes = []
	for code in root_codes:
		for leaf_code in _resolve_index_code(code):
			if leaf_code not in content_codes:
				content_codes.append(leaf_code)
	return content_codes, wanted

def _release_language(value):
	try:
		text = str(value or '')
		if re.search(r'(?i)(?:^|[ ._\-])(?:vostfr|subfrench)(?:$|[ ._\-])', text): return 'fr'
		if re.search(r'(?i)(?:^|[ ._\-])(?:multi|french|truefrench|true[ ._\-]?french|vfq|vff|vf2|vfi|vf|fr|fre|fra)(?:$|[ ._\-])', text): return 'fr'
	except:
		pass
	return language_code(value)



def _alkopaste_db_related_files():
	# Fichiers locaux de la source ALKO, journaux SQLite et téléchargements interrompus inclus.
	return (
		ALKOPASTE_DB,
		ALKOPASTE_DB + '-journal',
		ALKOPASTE_DB + '-wal',
		ALKOPASTE_DB + '-shm',
		ALKOPASTE_DB + '.download',
		ALKOPASTE_DB + '.tmp',
		ALKOPASTE_DB + '.old'
	)


def _delete_alkopaste_database_files():
	# La source ALKO est un index local jetable : aucune migration lourde, aucun journal SQLite
	# à conserver. Lors d'une mise à jour, on supprime tout et on reconstruit une base propre.
	removed = 0
	for db_file in _alkopaste_db_related_files():
		try:
			if kodi_utils.path_exists(db_file):
				kodi_utils.delete_file(db_file)
				removed += 1
		except:
			pass
	return removed


def _db_connect():
	try:
		profile_path = 'special://profile/addon_data/plugin.video.alkoflix/'
		if not kodi_utils.path_exists(profile_path): kodi_utils.make_directorys(profile_path)
	except:
		pass
	dbcon = kodi_utils.database_connect(ALKOPASTE_DB, timeout=30)
	dbcon.row_factory = sqlite3.Row
	try:
		dbcon.execute("""PRAGMA synchronous = OFF""")
		dbcon.execute("""PRAGMA journal_mode = OFF""")
		dbcon.execute("""PRAGMA temp_store = MEMORY""")
		dbcon.execute("""PRAGMA mmap_size = 268435456""")
	except:
		pass
	return dbcon


def _db_init(dbcon=None):
	own = dbcon is None
	if own: dbcon = _db_connect()
	try:
		dbcon.execute("""CREATE TABLE IF NOT EXISTS alko_meta (id TEXT PRIMARY KEY, value TEXT)""")
		try:
			version = _db_meta_get(dbcon, 'schema_version')
			if version != str(ALKOPASTE_DB_VERSION):
				dbcon.execute("""DROP TABLE IF EXISTS alko_links""")
				dbcon.execute("""DROP TABLE IF EXISTS alko_catalogue""")
				dbcon.execute("""DROP TABLE IF EXISTS alko_catalogue_terms""")
				# Important : après une migration de schéma, l'ancien last_sync ne doit pas
				# empêcher la reconstruction. Sinon la table catalogue reste vide jusqu'au
				# prochain cycle 24 h ou une mise à jour manuelle.
				_db_meta_set(dbcon, 'last_sync', '0')
				_db_meta_set(dbcon, 'last_count', '0')
				_db_meta_set(dbcon, 'last_catalogue_count', '0')
		except:
			pass
		dbcon.execute("""CREATE TABLE IF NOT EXISTS alko_links (
			id INTEGER PRIMARY KEY AUTOINCREMENT,
			media_type TEXT NOT NULL,
			tmdb_id TEXT NOT NULL,
			title TEXT,
			year INTEGER,
			season INTEGER,
			quality_text TEXT,
			size_text TEXT,
			urls_raw TEXT NOT NULL,
			base_url TEXT,
			paste_code TEXT,
			row_hash TEXT NOT NULL,
			updated_at INTEGER
		)""")
		dbcon.execute("""CREATE INDEX IF NOT EXISTS idx_alko_links_movie ON alko_links(media_type, tmdb_id)""")
		dbcon.execute("""CREATE INDEX IF NOT EXISTS idx_alko_links_series ON alko_links(media_type, tmdb_id, season)""")
		dbcon.execute("""CREATE UNIQUE INDEX IF NOT EXISTS idx_alko_links_unique ON alko_links(row_hash)""")
		_db_meta_set(dbcon, 'schema_version', str(ALKOPASTE_DB_VERSION))
		dbcon.commit()
	finally:
		if own:
			try: dbcon.close()
			except: pass

def _db_meta_get(dbcon, key, default=''):
	try:
		row = dbcon.execute("""SELECT value FROM alko_meta WHERE id=?""", (key,)).fetchone()
		return row['value'] if row else default
	except:
		return default


def _db_meta_set(dbcon, key, value):
	try:
		dbcon.execute("""INSERT OR REPLACE INTO alko_meta(id, value) VALUES(?, ?)""", (key, str(value)))
	except:
		pass


def _all_content_codes():
	codes = []
	root_codes = []
	try:
		# Source unique : configuration distante. Aucun code enfant/fallback n’est hardcodé.
		for code in _remote_config_index_codes():
			if code not in root_codes: root_codes.append(code)
		for code in root_codes:
			for leaf_code in _resolve_index_code(code):
				if leaf_code not in codes: codes.append(leaf_code)
	except Exception as e:
		try: kodi_utils.logger('alkoPaste DB', 'Résolution index impossible | erreur=%s' % type(e).__name__)
		except: pass
	return codes

def _row_hash(media_type, tmdb_id, season, quality_text, size_text, urls_raw, paste_code):
	try:
		# Le code paste n'entre pas dans l'unicité : si le même média/liste de liens
		# apparaît dans deux index, on garde une seule ligne locale.
		payload = '|'.join((
			str(media_type or '').strip(),
			str(tmdb_id or '').strip(),
			str(season if season is not None else '').strip(),
			clean_text(quality_text),
			str(size_text or '').strip(),
			str(urls_raw or '').strip()
		))
		try:
			return hashlib.sha1(payload.encode('utf-8'), usedforsecurity=False).hexdigest()
		except TypeError:
			return hashlib.sha1(payload.encode('utf-8')).hexdigest()
	except:
		return str(int(time.time() * 1000))

def _insert_db_row(dbcur, media_type, tmdb_id, title, year, season, quality_text, size_text, urls_raw, base_url, paste_code):
	try:
		# Règle volontairement stricte : la DB alkoPaste s'indexe uniquement par TMDb ID.
		# Le titre reste seulement une info d'affichage, jamais une clé de recherche.
		tmdb_id = str(tmdb_id or '').strip()
		if not tmdb_id or tmdb_id in ('0', 'None', 'none', 'null'): return 0
		urls_raw = str(urls_raw or '').strip()
		if not urls_raw: return 0
		media_type = str(media_type or '').strip()
		quality_text = clean_text(quality_text)
		size_text = str(size_text or '').strip()
		title = clean_text(title)
		row_hash = _row_hash(media_type, tmdb_id, season, quality_text, size_text, urls_raw, paste_code)
		dbcur.execute("""INSERT OR IGNORE INTO alko_links
			(media_type, tmdb_id, title, year, season, quality_text, size_text, urls_raw, base_url, paste_code, row_hash, updated_at)
			VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
			(media_type, tmdb_id, title, year, season, quality_text, size_text, urls_raw,
			str(base_url or ALLDEBRID_DEFAULT_BASE_URL).strip(), str(paste_code or '').strip(),
			row_hash, int(time.time())))
		return dbcur.rowcount or 0
	except Exception:
		return 0

def _import_content_code(dbcur, code, clear_existing=True, order_start=0, include_links=True, include_catalogue=True):
	links_added, catalogue_added, source_order = 0, 0, int(order_start or 0)
	try:
		url = _code_url(code)
		content = _fetch_text(url)
		if not content or not _looks_like_content_paste(content): return 0, 0, source_order
		lines = content.splitlines()
		if not lines: return 0, 0, source_order
		first_parts = lines[0].split(';')
		first_header_text = ';'.join(first_parts).upper()
		first_header = _header_has_urls(first_parts) or ('CAT' in first_header_text and 'TMDB' in first_header_text and 'TITLE' in first_header_text)
		base_url = _base_url_from_header(lines[0]) if first_header else ALLDEBRID_DEFAULT_BASE_URL
		data_lines = lines[1:] if first_header else lines
		if clear_existing:
			paste_key = str(code or '').strip()
			if include_catalogue:
				dbcur.execute("""DELETE FROM alko_catalogue_terms WHERE source_order IN (SELECT source_order FROM alko_catalogue WHERE paste_code=?)""", (paste_key,))
				dbcur.execute("""DELETE FROM alko_catalogue WHERE paste_code=?""", (paste_key,))
			if include_links:
				dbcur.execute("""DELETE FROM alko_links WHERE paste_code=?""", (paste_key,))
		for line in data_lines:
			line = (line or '').strip()
			if not line: continue
			parts = line.split(';')
			if len(parts) <= COL_TMDB: continue
			raw_cat = _row_value(parts, COL_CAT)
			normalized_cat = _normalize_cat(raw_cat)
			if normalized_cat not in ('film', 'serie'): continue
			tmdb_id = _row_value(parts, COL_TMDB)
			# Aucun fallback titre : sans TMDb ID, la ligne est ignorée.
			if not tmdb_id or tmdb_id in ('0', 'None', 'none', 'null'): continue
			source_order += 1
			media_type = _catalogue_media_type_from_key(raw_cat, normalized_cat)
			title = _row_value(parts, COL_TITLE)
			year = _safe_int(_row_value(parts, COL_YEAR), None)
			if include_catalogue:
				catalogue_added += _insert_catalogue_row(dbcur, media_type, tmdb_id, title, year, raw_cat,
					_row_value(parts, COL_GROUPES), _row_value(parts, COL_NETWORK), _row_value(parts, COL_GENRES), code, source_order)
			if not include_links:
				continue
			urls_raw = _row_urls_raw(parts)
			if not urls_raw: continue
			if media_type == 'serie':
				season = _safe_int(_row_value(parts, COL_SAISON), None)
				links_added += _insert_db_row(dbcur, 'serie', tmdb_id, title, year, season,
					_row_value(parts, COL_RES), _row_size_raw(parts), urls_raw, base_url, code)
			else:
				links_added += _insert_db_row(dbcur, 'film', tmdb_id, title, year, None,
					_row_value(parts, COL_RES), _row_size_raw(parts), urls_raw, base_url, code)
	except Exception as e:
		try: kodi_utils.logger('alkoPaste DB', 'Import paste impossible | code=%s | erreur=%s' % (code, type(e).__name__))
		except: pass
	return links_added, catalogue_added, source_order

def _db_sync_due(dbcon):
	try:
		last_sync = _safe_int(_db_meta_get(dbcon, 'last_sync', '0'), 0) or 0
		if not last_sync: return True
		return int(time.time()) - last_sync >= int(DB_SYNC_INTERVAL_HOURS * 3600)
	except:
		return True


def alkopaste_database_status():
	status = {'ready': False, 'total': 0, 'catalogue_total': 0, 'last_sync': 0, 'last_count': 0}
	dbcon = None
	try:
		dbcon = _db_connect()
		_db_init(dbcon)
		status['total'] = int(dbcon.execute("""SELECT COUNT(*) AS total FROM alko_links""").fetchone()['total'] or 0)
		status['catalogue_total'] = 0
		status['last_sync'] = _safe_int(_db_meta_get(dbcon, 'last_sync', '0'), 0) or 0
		status['last_count'] = _safe_int(_db_meta_get(dbcon, 'last_count', '0'), 0) or 0
		status['ready'] = status['total'] > 0
	except Exception:
		pass
	finally:
		if dbcon:
			try: dbcon.close()
			except: pass
	return status


def _db_clear_links(dbcon):
	try:
		dbcon.execute("""DELETE FROM alko_links""")
		dbcon.commit()
	except:
		pass


def _build_fresh_database(codes):
	_delete_alkopaste_database_files()
	dbcon = _db_connect()
	try:
		_db_init(dbcon)
		added, catalogue_added, source_order = 0, 0, 0
		dbcur = dbcon.cursor()
		dbcur.execute("""BEGIN""")
		for code in codes:
			links_count, catalogue_count, source_order = _import_content_code(dbcur, code, clear_existing=False, order_start=source_order, include_links=True, include_catalogue=False)
			added += links_count
			catalogue_added += catalogue_count
		_db_meta_set(dbcon, 'schema_version', str(ALKOPASTE_DB_VERSION))
		_db_meta_set(dbcon, 'last_sync', int(time.time()))
		_db_meta_set(dbcon, 'last_count', added)
		_db_meta_set(dbcon, 'last_catalogue_count', catalogue_added)
		dbcon.commit()
		try:
			for db_file in _alkopaste_db_related_files()[1:]:
				if kodi_utils.path_exists(db_file): kodi_utils.delete_file(db_file)
		except:
			pass
		return added, catalogue_added
	except:
		try: dbcon.rollback()
		except: pass
		raise
	finally:
		try: dbcon.close()
		except: pass


# ---------------------------------------------------------------------------
# Source ALKO distante préconstruite
# ---------------------------------------------------------------------------
# Le gros parsing des liens alkoPaste est fait côté serveur. alkoFlix télécharge
# alkopaste_links.db.gz puis cherche localement par TMDb ID dans alko_links.

def _alkopaste_remote_cache_bust_url(url):
	url = str(url or '').strip()
	if not url:
		return ''
	sep = '&' if '?' in url else '?'
	try:
		return '%s%s_alkoflix_ts=%s' % (url, sep, int(time.time()))
	except:
		return url


def _alkopaste_remote_no_cache_headers():
	return {
		'Cache-Control': 'no-cache, no-store, must-revalidate',
		'Pragma': 'no-cache',
		'Expires': '0',
	}



def _alkopaste_clear_maincache_like(pattern):
	# Les listes du Catalogue alkoPaste sont mises en cache dans maincache.
	# Après une nouvelle DB, garder ces entrées revient à afficher l'ancien catalogue
	# même si le téléchargement a réussi. On supprime donc DB + propriétés mémoire.
	try:
		db_path = kodi_utils.maincache_db
		if not kodi_utils.path_exists(db_path): return 0
		dbcon = kodi_utils.database_connect(db_path)
		dbcur = dbcon.cursor()
		dbcur.execute("""SELECT id FROM maincache WHERE id LIKE ?""", (pattern,))
		ids = [str(i[0]) for i in dbcur.fetchall() or []]
		if ids:
			dbcur.execute("""DELETE FROM maincache WHERE id LIKE ?""", (pattern,))
			dbcon.commit()
			try: dbcur.execute("""VACUUM""")
			except: pass
		for cache_id in ids:
			try: kodi_utils.clear_property(cache_id)
			except: pass
		try: dbcon.close()
		except: pass
		return len(ids)
	except Exception as e:
		try: kodi_utils.logger('Catalogue alkoPaste cache', 'Nettoyage maincache impossible | erreur=%s' % type(e).__name__)
		except: pass
		return 0


def _clear_alkopaste_catalogue_runtime_cache():
	# Préfixe utilisé par _catalogue_cache_key(), ancien mode lazy inclus.
	return _alkopaste_clear_maincache_like('alkoflix_alkopaste_catalogue_%')


def _source_manifest_base_url(manifest_url=''):
	manifest_url = str(manifest_url or ALKOPASTE_SOURCE_REMOTE_MANIFEST).strip().split('?', 1)[0]
	return manifest_url.rsplit('/', 1)[0].rstrip('/')


def _source_abs_url(url, manifest_url=''):
	url = str(url or '').strip()
	if not url: return ''
	if url.startswith('http://') or url.startswith('https://'): return url
	return '%s/%s' % (_source_manifest_base_url(manifest_url), url.lstrip('/'))


def _source_bytes_sha256(data):
	try: return hashlib.sha256(data or b'').hexdigest()
	except: return ''


def _source_local_db_path():
	return kodi_utils.translate_path(ALKOPASTE_DB)


def _source_table_exists(dbcon, table):
	try:
		row = dbcon.execute("""SELECT name FROM sqlite_master WHERE type='table' AND name=?""", (table,)).fetchone()
		return bool(row)
	except:
		return False


def _source_is_remote_schema(dbcon):
	return _source_table_exists(dbcon, 'alko_links') and _source_table_exists(dbcon, 'alko_meta')


def _source_remote_validate(db_path):
	dbcon = None
	try:
		dbcon = sqlite3.connect(db_path)
		dbcon.row_factory = sqlite3.Row
		if not _source_is_remote_schema(dbcon): return 0
		row = dbcon.execute("""SELECT COUNT(*) AS total FROM alko_links""").fetchone()
		return int(row['total'] or 0)
	except:
		return 0
	finally:
		try:
			if dbcon: dbcon.close()
		except: pass


def _source_remote_ready():
	try:
		path = _source_local_db_path()
		if not os.path.exists(path): return False
		return _source_remote_validate(path) > 0
	except:
		return False


def _source_remote_count():
	try:
		path = _source_local_db_path()
		if not os.path.exists(path): return 0
		return _source_remote_validate(path)
	except:
		return 0


def _source_remote_meta(key, default=''):
	dbcon = None
	try:
		path = _source_local_db_path()
		if not os.path.exists(path): return default
		dbcon = sqlite3.connect(path)
		dbcon.row_factory = sqlite3.Row
		if not _source_table_exists(dbcon, 'alko_meta'): return default
		row = dbcon.execute("""SELECT value FROM alko_meta WHERE id=?""", (key,)).fetchone()
		return row['value'] if row else default
	except:
		return default
	finally:
		try:
			if dbcon: dbcon.close()
		except: pass


def _source_remote_sync_due():
	try:
		last_sync = _safe_int(_source_remote_meta('last_sync', '0'), 0) or 0
		if not last_sync: return True
		return int(time.time()) - last_sync >= int(DB_SYNC_INTERVAL_HOURS * 3600)
	except:
		return True


def _source_remote_set_meta(db_path, values):
	try:
		dbcon = sqlite3.connect(db_path)
		dbcon.execute("""CREATE TABLE IF NOT EXISTS alko_meta (id TEXT PRIMARY KEY, value TEXT)""")
		for key, value in (values or {}).items():
			dbcon.execute("""INSERT OR REPLACE INTO alko_meta(id, value) VALUES(?, ?)""", (str(key), str(value)))
		dbcon.commit()
		dbcon.close()
	except:
		pass


def _download_remote_source_database(force=False):
	# En automatique, on respecte le même intervalle local que le catalogue.
	# Le service peut se réveiller plus souvent, mais la source de liens ne
	# revérifie pas le manifest ni la base avant 24 h, sauf demande manuelle.
	if not force and _source_remote_ready() and not _source_remote_sync_due():
		return {'ok': True, 'skipped': True, 'reason': 'not_due', 'pastes': 0, 'links': _source_remote_count(), 'catalogue': 0}
	manifest_url = ALKOPASTE_SOURCE_REMOTE_MANIFEST
	request_manifest_url = _alkopaste_remote_cache_bust_url(manifest_url) if force else manifest_url
	try:
		response = requests.get(request_manifest_url, timeout=20, headers=_alkopaste_remote_no_cache_headers())
		response.raise_for_status()
		manifest = response.json() or {}
	except Exception:
		if not force and _source_remote_ready():
			return {'ok': True, 'skipped': True, 'reason': 'manifest_unavailable_using_local', 'pastes': 0, 'links': _source_remote_count(), 'catalogue': 0}
		return {'ok': False, 'skipped': False, 'reason': 'source_manifest_unavailable', 'pastes': 0, 'links': 0, 'catalogue': 0}

	version = str(manifest.get('version') or '')
	compressed = manifest.get('compressed') or {}
	db_info = manifest.get('db') or {}
	remote_marker = version or str(compressed.get('sha256') or db_info.get('sha256') or '')
	local_marker = _source_remote_meta('remote_marker', '')
	if not force and remote_marker and local_marker == remote_marker and _source_remote_ready():
		return {'ok': True, 'skipped': True, 'reason': 'not_changed', 'pastes': 0, 'links': _source_remote_count(), 'catalogue': 0}

	gz_url = _source_abs_url(compressed.get('url') or db_info.get('url') or 'alkopaste_links.db.gz', manifest_url)
	if force and gz_url:
		gz_url = _alkopaste_remote_cache_bust_url(gz_url)
	if not gz_url:
		return {'ok': False, 'skipped': False, 'reason': 'missing_source_db_url', 'pastes': 0, 'links': 0, 'catalogue': 0}

	try:
		response = requests.get(gz_url, timeout=180, headers=_alkopaste_remote_no_cache_headers())
		response.raise_for_status()
		payload = response.content or b''
	except:
		if not force and _source_remote_ready():
			return {'ok': True, 'skipped': True, 'reason': 'download_failed_using_local', 'pastes': 0, 'links': _source_remote_count(), 'catalogue': 0}
		return {'ok': False, 'skipped': False, 'reason': 'source_download_failed', 'pastes': 0, 'links': 0, 'catalogue': 0}

	expected_gz_sha = str(compressed.get('sha256') or '').strip().lower()
	expected_db_sha = str(db_info.get('sha256') or '').strip().lower()
	payload_sha = _source_bytes_sha256(payload).lower()

	# v1.5.41 :
	# Certains hébergeurs/proxys peuvent transformer le fichier .gz, modifier
	# l'encodage HTTP ou servir une version légèrement différente pendant que
	# le manifest est déjà mis à jour. On ne bloque donc plus sur le SHA du .gz.
	# La seule chose vraiment essentielle côté Kodi : obtenir une base SQLite
	# lisible et valide.
	try:
		if payload.startswith(b'SQLite format 3'):
			db_bytes = payload
		else:
			db_bytes = gzip.decompress(payload)
	except:
		db_bytes = payload

	try:
		final_sha = _source_bytes_sha256(db_bytes).lower()
		if expected_gz_sha and payload_sha != expected_gz_sha:
			kodi_utils.logger('Source ALKO distante', 'SHA .gz différent du manifest, validation SQLite utilisée.')
		if expected_db_sha and final_sha != expected_db_sha:
			kodi_utils.logger('Source ALKO distante', 'SHA DB différent du manifest, validation SQLite utilisée.')
	except:
		pass

	tmp_path = ''
	try:
		profile_path = kodi_utils.translate_path('special://profile/addon_data/plugin.video.alkoflix/')
		if not os.path.exists(profile_path): os.makedirs(profile_path)
		db_path = _source_local_db_path()
		# Temp d'installation volontairement hors liste de nettoyage :
		# la v1.9.9 pouvait supprimer *.download juste avant os.replace().
		tmp_path = db_path + '.installing'
		try:
			if os.path.exists(tmp_path): os.remove(tmp_path)
		except:
			pass
		with open(tmp_path, 'wb') as f:
			f.write(db_bytes)
		count = _source_remote_validate(tmp_path)
		if count <= 0:
			try: os.remove(tmp_path)
			except: pass
			return {'ok': False, 'skipped': False, 'reason': 'invalid_source_sqlite', 'pastes': 0, 'links': 0, 'catalogue': 0}
		_source_remote_set_meta(tmp_path, {
			'schema_version': str(ALKOPASTE_DB_VERSION),
			'remote_manifest': manifest_url,
			'remote_marker': remote_marker,
			'remote_version': version,
			'last_sync': int(time.time()),
			'last_count': count,
			'generated_at': manifest.get('generated_at') or '',
			'source': 'remote'
		})
		_delete_alkopaste_database_files()
		os.replace(tmp_path, db_path)
		return {'ok': True, 'skipped': False, 'reason': 'downloaded', 'pastes': 0, 'links': count, 'catalogue': 0, 'generated_at': manifest.get('generated_at') or '', 'remote_marker': remote_marker}
	except Exception as e:
		try:
			if tmp_path and os.path.exists(tmp_path): os.remove(tmp_path)
		except: pass
		try:
			kodi_utils.logger('Source ALKO distante', 'Installation DB impossible | erreur=%s | detail=%s' % (type(e).__name__, str(e)))
		except: pass
		return {'ok': False, 'skipped': False, 'reason': type(e).__name__, 'pastes': 0, 'links': 0, 'catalogue': 0}

def _alkopaste_source_enabled():
	"""Retourne True uniquement si la source de liens ALKO est activée.

	Le Catalogue alkoPaste possède sa propre base et ne doit jamais autoriser
	le téléchargement ou l'utilisation de la base de liens ALKO.
	"""
	try:
		return str(kodi_utils.get_setting('provider.alkopaste', 'false')).strip().lower() == 'true'
	except:
		return False


def _sync_alkopaste_source_database(force=False, rebuild=False):
	"""Télécharge la base distante de la source ALKO.
	Aucune reconstruction lourde des pastes n'est faite côté Kodi.
	"""
	# Garde-fou absolu : même un appel direct, un test global ou une action
	# contextuelle ne peut télécharger la base si la source ALKO est désactivée.
	if not _alkopaste_source_enabled():
		return {'ok': True, 'skipped': True, 'reason': 'disabled', 'pastes': 0, 'links': 0, 'catalogue': 0}
	lock_prop = 'alkoflix.alkopaste.source.remote.sync.running'
	try:
		if kodi_utils.get_property(lock_prop) == 'true':
			return {'ok': False, 'skipped': True, 'reason': 'running', 'pastes': 0, 'links': _source_remote_count(), 'catalogue': 0}
		kodi_utils.set_property(lock_prop, 'true')
	except:
		pass
	try:
		return _download_remote_source_database(force=bool(force or rebuild))
	finally:
		try: kodi_utils.clear_property(lock_prop)
		except: pass


# ---------------------------------------------------------------------------
# Catalogue alkoPaste : base séparée de la source de liens ALKO
# ---------------------------------------------------------------------------

def _alkopaste_catalogue_db_related_files():
	# Fichiers locaux du catalogue dans userdata.
	# On inclut aussi les temporaires pour ne pas laisser de vieux restes sur les box
	# avec peu d'espace disque après un changement de schéma ou un téléchargement interrompu.
	return (
		ALKOPASTE_CATALOGUE_DB,
		ALKOPASTE_CATALOGUE_DB + '-journal',
		ALKOPASTE_CATALOGUE_DB + '-wal',
		ALKOPASTE_CATALOGUE_DB + '-shm',
		ALKOPASTE_CATALOGUE_DB + '.download',
		ALKOPASTE_CATALOGUE_DB + '.tmp',
		ALKOPASTE_CATALOGUE_DB + '.old'
	)


def _delete_alkopaste_catalogue_database_files():
	removed = 0
	for db_file in _alkopaste_catalogue_db_related_files():
		try:
			if kodi_utils.path_exists(db_file):
				kodi_utils.delete_file(db_file)
				removed += 1
		except:
			pass
	return removed


def _cleanup_alkopaste_catalogue_when_disabled():
	# Si le catalogue alkoPaste est désactivé, on ne garde pas une grosse base locale
	# inutile dans userdata. Elle sera retéléchargée si l'utilisateur réactive le catalogue.
	try:
		removed = _delete_alkopaste_catalogue_database_files()
		if removed:
			try: _clear_alkopaste_catalogue_runtime_cache()
			except: pass
			try: kodi_utils.logger('Catalogue alkoPaste', 'Base locale supprimée car le catalogue est désactivé.')
			except: pass
		return removed
	except:
		return 0


def _catalogue_db_connect():
	try:
		profile_path = 'special://profile/addon_data/plugin.video.alkoflix/'
		if not kodi_utils.path_exists(profile_path): kodi_utils.make_directorys(profile_path)
	except:
		pass
	dbcon = kodi_utils.database_connect(ALKOPASTE_CATALOGUE_DB, timeout=30)
	dbcon.row_factory = sqlite3.Row
	try:
		dbcon.execute("""PRAGMA synchronous = OFF""")
		dbcon.execute("""PRAGMA journal_mode = OFF""")
		dbcon.execute("""PRAGMA temp_store = MEMORY""")
		dbcon.execute("""PRAGMA mmap_size = 268435456""")
	except:
		pass
	return dbcon


def _cat_meta_get(dbcon, key, default=''):
	try:
		row = dbcon.execute("""SELECT value FROM alko_catalogue_meta WHERE id=?""", (key,)).fetchone()
		return row['value'] if row else default
	except:
		return default


def _cat_meta_set(dbcon, key, value):
	try:
		dbcon.execute("""INSERT OR REPLACE INTO alko_catalogue_meta(id, value) VALUES(?, ?)""", (key, str(value)))
	except:
		pass


def _catalogue_db_init(dbcon=None):
	own = dbcon is None
	if own: dbcon = _catalogue_db_connect()
	try:
		dbcon.execute("""CREATE TABLE IF NOT EXISTS alko_catalogue_meta (id TEXT PRIMARY KEY, value TEXT)""")
		try:
			version = _cat_meta_get(dbcon, 'schema_version')
			if version != str(ALKOPASTE_CATALOGUE_DB_VERSION):
				dbcon.execute("""DROP TABLE IF EXISTS alko_catalogue""")
				dbcon.execute("""DROP TABLE IF EXISTS alko_catalogue_terms""")
				_cat_meta_set(dbcon, 'last_sync', '0')
				_cat_meta_set(dbcon, 'last_catalogue_count', '0')
		except:
			pass
		dbcon.execute("""CREATE TABLE IF NOT EXISTS alko_catalogue (
			id INTEGER PRIMARY KEY AUTOINCREMENT,
			media_type TEXT NOT NULL,
			tmdb_id TEXT NOT NULL,
			title TEXT,
			year INTEGER,
			raw_cat TEXT,
			section TEXT NOT NULL,
			groups_json TEXT,
			networks_json TEXT,
			genres_json TEXT,
			paste_code TEXT,
			source_order INTEGER,
			row_hash TEXT NOT NULL,
			updated_at INTEGER
		)""")
		dbcon.execute("""CREATE INDEX IF NOT EXISTS idx_alko_catalogue_section ON alko_catalogue(section, media_type, source_order)""")
		dbcon.execute("""CREATE INDEX IF NOT EXISTS idx_alko_catalogue_tmdb ON alko_catalogue(media_type, tmdb_id)""")
		dbcon.execute("""CREATE INDEX IF NOT EXISTS idx_alko_catalogue_section_tmdb_order ON alko_catalogue(section, media_type, tmdb_id, source_order)""")
		dbcon.execute("""CREATE INDEX IF NOT EXISTS idx_alko_catalogue_media_order ON alko_catalogue(media_type, source_order)""")
		dbcon.execute("""CREATE UNIQUE INDEX IF NOT EXISTS idx_alko_catalogue_unique ON alko_catalogue(row_hash)""")
		dbcon.execute("""CREATE TABLE IF NOT EXISTS alko_catalogue_terms (
			id INTEGER PRIMARY KEY AUTOINCREMENT,
			section TEXT NOT NULL,
			media_type TEXT NOT NULL,
			tmdb_id TEXT NOT NULL,
			term_type TEXT NOT NULL,
			root TEXT,
			value TEXT NOT NULL,
			label TEXT,
			source_order INTEGER,
			row_hash TEXT NOT NULL,
			updated_at INTEGER
		)""")
		dbcon.execute("""CREATE INDEX IF NOT EXISTS idx_alko_catalogue_terms_lookup ON alko_catalogue_terms(section, media_type, term_type, value)""")
		dbcon.execute("""CREATE INDEX IF NOT EXISTS idx_alko_catalogue_terms_root ON alko_catalogue_terms(section, media_type, term_type, root, value)""")
		dbcon.execute("""CREATE INDEX IF NOT EXISTS idx_alko_catalogue_terms_tmdb ON alko_catalogue_terms(section, media_type, tmdb_id, source_order)""")
		dbcon.execute("""CREATE UNIQUE INDEX IF NOT EXISTS idx_alko_catalogue_terms_unique ON alko_catalogue_terms(row_hash)""")
		_cat_meta_set(dbcon, 'schema_version', str(ALKOPASTE_CATALOGUE_DB_VERSION))
		dbcon.commit()
	finally:
		if own:
			try: dbcon.close()
			except: pass


def _catalogue_db_sync_due(dbcon):
	try:
		last_sync = _safe_int(_cat_meta_get(dbcon, 'last_sync', '0'), 0) or 0
		if not last_sync: return True
		return int(time.time()) - last_sync >= int(DB_SYNC_INTERVAL_HOURS * 3600)
	except:
		return True


def alkopaste_catalogue_database_status():
	status = {'ready': False, 'catalogue_total': 0, 'last_sync': 0}
	dbcon = None
	try:
		dbcon = _catalogue_db_connect()
		_catalogue_db_init(dbcon)
		status['catalogue_total'] = int(dbcon.execute("""SELECT COUNT(*) AS total FROM alko_catalogue""").fetchone()['total'] or 0)
		status['last_sync'] = _safe_int(_cat_meta_get(dbcon, 'last_sync', '0'), 0) or 0
		status['ready'] = status['catalogue_total'] > 0
	except Exception:
		pass
	finally:
		if dbcon:
			try: dbcon.close()
			except: pass
	return status


def _build_fresh_catalogue_database(codes):
	_delete_alkopaste_catalogue_database_files()
	dbcon = _catalogue_db_connect()
	try:
		_catalogue_db_init(dbcon)
		catalogue_added, source_order = 0, 0
		dbcur = dbcon.cursor()
		dbcur.execute("""BEGIN""")
		for code in codes:
			links_count, catalogue_count, source_order = _import_content_code(dbcur, code, clear_existing=False, order_start=source_order, include_links=False, include_catalogue=True)
			catalogue_added += catalogue_count
		_cat_meta_set(dbcon, 'schema_version', str(ALKOPASTE_CATALOGUE_DB_VERSION))
		_cat_meta_set(dbcon, 'last_sync', int(time.time()))
		_cat_meta_set(dbcon, 'last_catalogue_count', catalogue_added)
		dbcon.commit()
		try:
			for db_file in _alkopaste_catalogue_db_related_files()[1:]:
				if kodi_utils.path_exists(db_file): kodi_utils.delete_file(db_file)
		except:
			pass
		return catalogue_added
	except:
		try: dbcon.rollback()
		except: pass
		raise
	finally:
		try: dbcon.close()
		except: pass


def sync_alkopaste_catalogue_database(force=False, rebuild=False):
	"""Télécharge la base distante du Catalogue alkoPaste.

	Aucune reconstruction lourde côté Kodi.
	Le bouton Maintenance doit remplacer la base locale par celle du serveur,
	sans redémarrage de Kodi.
	"""
	lock_prop = 'alkoflix.alkopaste.catalogue.remote.sync.running'
	try:
		if kodi_utils.get_property(lock_prop) == 'true':
			return {'ok': False, 'skipped': True, 'reason': 'running', 'pastes': 0, 'links': 0, 'catalogue': _catalogue_remote_count()}
		kodi_utils.set_property(lock_prop, 'true')
	except:
		pass
	try:
		return _download_remote_catalogue_database(force=bool(force or rebuild))
	finally:
		try: kodi_utils.clear_property(lock_prop)
		except: pass


def sync_alkopaste_database(force=False, rebuild=False):
	"""Wrapper : source ALKO et Catalogue alkoPaste sont synchronisés séparément."""
	source_enabled = False
	catalogue_enabled = False
	try: source_enabled = str(kodi_utils.get_setting('provider.alkopaste', 'false')).strip().lower() == 'true'
	except: pass
	try: catalogue_enabled = str(kodi_utils.get_setting('catalogue.alkopaste.enabled', 'false')).strip().lower() == 'true'
	except: pass
	results = []
	if source_enabled:
		results.append(_sync_alkopaste_source_database(force=force, rebuild=rebuild))
	if catalogue_enabled:
		results.append(sync_alkopaste_catalogue_database(force=force, rebuild=rebuild))
	else:
		# Aucun intérêt de conserver l'ancienne base catalogue si cette fonction est désactivée.
		_cleanup_alkopaste_catalogue_when_disabled()
	if not results:
		return {'ok': True, 'skipped': True, 'reason': 'disabled', 'pastes': 0, 'links': 0, 'catalogue': 0}
	ok = all(bool(r.get('ok')) or bool(r.get('skipped')) for r in results if isinstance(r, dict))
	skipped = all(bool(r.get('skipped')) for r in results if isinstance(r, dict))
	return {
		'ok': ok,
		'skipped': skipped,
		'reason': ','.join([str(r.get('reason') or '') for r in results if isinstance(r, dict) and r.get('reason')]) or '',
		'pastes': sum(int(r.get('pastes', 0) or 0) for r in results if isinstance(r, dict)),
		'links': sum(int(r.get('links', 0) or 0) for r in results if isinstance(r, dict)),
		'catalogue': sum(int(r.get('catalogue', 0) or 0) for r in results if isinstance(r, dict))
	}


def sync_alkopaste_catalogue_database_manual():
	try:
		kodi_utils.notification('Téléchargement du Catalogue alkoPaste...')
	except:
		pass
	result = sync_alkopaste_catalogue_database(force=True, rebuild=True)
	try:
		if result.get('ok'):
			count = result.get('catalogue', 0) or _catalogue_remote_count()
			generated = result.get('generated_at') or _catalogue_remote_meta('generated_at', '')
			if result.get('skipped'):
				message = 'Catalogue alkoPaste déjà disponible : %s médias.' % count
			else:
				message = 'Catalogue alkoPaste retéléchargé depuis le serveur : %s médias.' % count
			if generated:
				message += '\\nGénéré : %s' % generated
			message += '\\nAucun redémarrage nécessaire.'
			kodi_utils.ok_dialog(heading='alkoFlix', text=message, top_space=True)
			try:
				kodi_utils.container_refresh()
			except:
				pass
		else:
			kodi_utils.ok_dialog(heading='alkoFlix', text='Le Catalogue alkoPaste n’a pas pu être téléchargé depuis le serveur. Raison : %s' % (result.get('reason') or 'erreur inconnue'), top_space=True)
	except:
		pass
	return result

def sync_alkopaste_database_manual():
	try:
		kodi_utils.notification('Téléchargement de la source ALKO...')
	except:
		pass
	# Bouton Maintenance séparé : ici on met à jour seulement la base de liens ALKO.
	# Aucun raw n'est parcouru côté Kodi : on télécharge la base /source/ du serveur.
	result = _sync_alkopaste_source_database(force=True, rebuild=True)
	try:
		if result.get('reason') == 'disabled':
			kodi_utils.ok_dialog(heading='alkoFlix', text='La source ALKO est désactivée dans les paramètres. Aucune base de liens n’a été téléchargée.', top_space=True)
		elif result.get('ok'):
			count = result.get('links', 0) or _source_remote_count()
			generated = result.get('generated_at') or _source_remote_meta('generated_at', '')
			if result.get('skipped'):
				message = 'Source ALKO déjà disponible : %s liens.' % count
			else:
				message = 'Source ALKO retéléchargée depuis le serveur : %s liens.' % count
			if generated:
				message += '\\nGénérée : %s' % generated
			message += '\\nAucun redémarrage nécessaire.'
			kodi_utils.ok_dialog(heading='alkoFlix', text=message, top_space=True)
			try:
				kodi_utils.container_refresh()
			except:
				pass
		else:
			kodi_utils.ok_dialog(heading='alkoFlix', text='La source ALKO n’a pas pu être téléchargée depuis le serveur. Raison : %s' % (result.get('reason') or 'erreur inconnue'), top_space=True)
	except:
		pass
	return result


def _db_ready():
	dbcon = None
	try:
		dbcon = _db_connect()
		_db_init(dbcon)
		count = dbcon.execute("""SELECT COUNT(*) AS total FROM alko_links""").fetchone()['total']
		return count > 0
	except:
		return False
	finally:
		if dbcon:
			try: dbcon.close()
			except: pass


def _query_database(data, wanted):
	results = []
	seen = set()
	dbcon = None
	try:
		dbcon = _db_connect()
		_db_init(dbcon)
		target_tmdb_ids = _target_tmdb_ids(data)
		# Règle stricte : alkoPaste cherche uniquement par TMDb ID.
		# Aucun matching par titre, même en fallback.
		if not target_tmdb_ids: return []
		target_season = _safe_int(data.get('season'), None)
		target_episode = _safe_int(data.get('episode'), None)
		media_type = 'serie' if wanted == 'serie' else 'film'
		placeholders = ','.join('?' for _ in target_tmdb_ids)
		params = [media_type] + list(target_tmdb_ids)
		if media_type == 'serie':
			query = """SELECT * FROM alko_links WHERE media_type=? AND tmdb_id IN (%s)""" % placeholders
			season_values = [i for i in _series_query_seasons(data, target_season) if i is not None]
			if season_values:
				query += """ AND (season IS NULL OR season IN (%s))""" % ','.join('?' for _ in season_values)
				params.extend(season_values)
		else:
			query = """SELECT * FROM alko_links WHERE media_type=? AND tmdb_id IN (%s)""" % placeholders
		rows = dbcon.execute(query, params).fetchall()
		for row in rows:
			if media_type == 'serie':
				series_items = _series_urls(row['urls_raw'])
				size_map = _series_size_map(row['size_text'])
				row_season = _safe_int(row['season'], target_season)
				wanted_eps = _wanted_episodes_for_row(data, row_season, target_episode)
				for idx, (ep_num, suffix) in enumerate(series_items):
					if target_episode is not None and int(ep_num) not in wanted_eps: continue
					url = _full_url(row['base_url'] or ALLDEBRID_DEFAULT_BASE_URL, suffix)
					if not url or url in seen: continue
					seen.add(url)
					size = size_map.get(int(ep_num), _size_at_index(row['size_text'], idx))
					results.append(_build_db_result(_display_data_for_episode(data, row_season, int(ep_num)), row, url, row['quality_text'], size))
			else:
				res_list = _literal_list(row['quality_text'])
				urls_list = _literal_list(row['urls_raw'])
				if not res_list or not urls_list: continue
				for idx, (res_name, suffix) in enumerate(zip(res_list, urls_list)):
					url = _full_url(row['base_url'] or ALLDEBRID_DEFAULT_BASE_URL, suffix)
					if not url or url in seen: continue
					seen.add(url)
					size = _size_at_index(row['size_text'], idx)
					results.append(_build_db_result(data, row, url, res_name, size))
	except Exception as e:
		try: kodi_utils.logger('alkoPaste DB', 'Recherche impossible | erreur=%s' % type(e).__name__)
		except: pass
	finally:
		if dbcon:
			try: dbcon.close()
			except: pass
	return results

def _build_db_result(data, row, url, quality_text, size=0):
	quality_text = clean_text(quality_text)
	return {
		'link': url,
		'hoster': 'alldebrid' if hoster_key('', url) == 'alldebrid' else hoster_key('', url),
		'quality': normalize_quality(quality_text),
		'language': _release_language(quality_text),
		'raw_language': quality_text,
		'display_name': _build_db_display_name(data, row, quality_text),
		'size': _size_gb(size),
		# Les résultats ALKO issus de la base SQLite locale sont bien des lectures cache.
		# Champ visuel uniquement : permet au sélecteur d'afficher ALKO en vert comme les autres hits cache.
		'local_cache': True,
		'local_cache_label': 'CACHE'
	}

def _build_db_display_name(data, row, quality_text=''):
	try:
		title = clean_text(row['title']) or clean_text(data.get('tvshowtitle') or data.get('title'))
		res_name = clean_text(quality_text)
		if row['media_type'] == 'serie':
			season = _safe_int(row['season'], _safe_int(data.get('season'), 0)) or 0
			episode = _safe_int(data.get('episode'), 0) or 0
			return clean_text('%s S%02dE%02d %s' % (title, season, episode, res_name))
		return clean_text('%s %s %s' % (title, row['year'] or data.get('year') or '', res_name))
	except:
		return clean_text(quality_text or '')


# ---------------------------------------------------------------------------
# Catalogue alkoPaste (menus de médias, sans récupération de liens)
# ---------------------------------------------------------------------------
# Mode v1.5.32 : le catalogue se comporte comme des endpoints légers.
# On ne construit plus une énorme table média pendant la mise à jour.
# Les codes racines ci-dessous sont les seules portes d'entrée officielles.

ALKOPASTE_CATALOGUE_PAGE_SIZE = 20
ALKOPASTE_CATALOGUE_INDEX_CACHE_VERSION = 'root_v15_catalogue_halloween_icons'

ALKOPASTE_CATALOGUE_SECTION_ROOTS = {
	'films': '4Fwo3co2',
	'series': '5bdDy9db',
	'documentary_movie': 'gSwGJc25',
	'documentary_series': 'gSwGJc25',
	'replay': '4fcd74af',
	'qc_movie': 'VrghLNhG',
	'qc_series': 'VrghLNhG',
	'concerts': '017cea8a',
	'spectacles': '8545d720',
	'animation_movie': 'fff5fe57',
	'animation_series': 'fff5fe57',
	'anime_movie': 'e227f398',
	'anime_series': 'e227f398'
}

_ALKO_MOVIE_GENRE_LABELS = {
	'28': 'Action', '12': 'Aventure', '16': 'Animation', '35': 'Comédie', '80': 'Crime',
	'99': 'Documentaire', '18': 'Drame', '10751': 'Famille', '14': 'Fantastique', '36': 'Histoire',
	'27': 'Horreur', '10402': 'Musique', '9648': 'Mystère', '10749': 'Romance', '878': 'Science-fiction',
	'10770': 'Téléfilm', '53': 'Thriller', '10752': 'Guerre', '37': 'Western'
}
_ALKO_SERIES_GENRE_LABELS = {
	'10759': 'Action et aventure', '16': 'Animation', '35': 'Comédie', '80': 'Crime',
	'18': 'Drame', '10751': 'Famille', '10762': 'Jeunesse', '9648': 'Mystère',
	'10765': 'Science-fiction et fantastique', '10766': 'Soap', '10768': 'Guerre et politique', '37': 'Western',
	'99': 'Documentaire', '10763': 'Actualités', '10764': 'Téléréalité', '10767': 'Talk-show',
	# Certains catalogues alkoPaste peuvent mélanger les genres films/séries.
	# 10749 est le genre Romance côté films, on le garde lisible au lieu d'afficher le numéro brut.
	'10749': 'Romance'
}

_ALKO_GENRE_ICONS = {
	'28': 'genre_action.png', 'Action': 'genre_action.png',
	'12': 'genre_adventure.png', 'Aventure': 'genre_adventure.png',
	'10759': 'genre_action.png', 'Action et aventure': 'genre_action.png',
	'16': 'genre_animation.png', 'Animation': 'genre_animation.png',
	'35': 'genre_comedy.png', 'Comédie': 'genre_comedy.png',
	'80': 'genre_crime.png', 'Crime': 'genre_crime.png',
	'99': 'genre_documentary.png', 'Documentaire': 'genre_documentary.png',
	'18': 'genre_drama.png', 'Drame': 'genre_drama.png',
	'10751': 'genre_family.png', 'Famille': 'genre_family.png',
	'14': 'genre_fantasy.png', 'Fantastique': 'genre_fantasy.png',
	'36': 'genre_history.png', 'Histoire': 'genre_history.png',
	'27': 'genre_horror.png', 'Horreur': 'genre_horror.png',
	'10762': 'genre_kids.png', 'Jeunesse': 'genre_kids.png',
	'10402': 'genre_music.png', 'Musique': 'genre_music.png',
	'9648': 'genre_mystery.png', 'Mystère': 'genre_mystery.png',
	'10763': 'genre_news.png', 'Actualités': 'genre_news.png',
	'10764': 'genre_reality.png', 'Téléréalité': 'genre_reality.png',
	'10749': 'genre_romance.png', 'Romance': 'genre_romance.png',
	'878': 'genre_scifi.png', 'Science-fiction': 'genre_scifi.png',
	'10765': 'genre_scifi.png', 'Science-fiction et fantastique': 'genre_scifi.png',
	'10766': 'genre_soap.png', 'Soap': 'genre_soap.png',
	'10767': 'genre_talk.png', 'Talk-show': 'genre_talk.png',
	'10770': 'genre_tv.png', 'Téléfilm': 'genre_tv.png',
	'53': 'genre_thriller.png', 'Thriller': 'genre_thriller.png',
	'10752': 'genre_war.png', 'Guerre': 'genre_war.png',
	'10768': 'genre_war.png', 'Guerre et politique': 'genre_war.png',
	'37': 'genre_western.png', 'Western': 'genre_western.png'
}


def _catalogue_genre_label(value, media_type=''):
	value = _clean_list_value(value)
	if not value: return ''
	primary = _ALKO_SERIES_GENRE_LABELS if str(media_type or '') == 'serie' else _ALKO_MOVIE_GENRE_LABELS
	fallback = _ALKO_MOVIE_GENRE_LABELS if primary is _ALKO_SERIES_GENRE_LABELS else _ALKO_SERIES_GENRE_LABELS
	label = primary.get(value) or fallback.get(value)
	if label: return label
	# Un identifiant TMDb inconnu ne doit pas s'afficher tel quel dans le menu.
	# Mieux vaut ne pas créer l'entrée que d'avoir un genre nommé "10749" ou équivalent.
	if re.match(r'^\d+$', value): return ''
	return value


def _catalogue_genre_icon(value, label=''):
	value = _clean_list_value(value)
	label = _clean_list_value(label)
	return _ALKO_GENRE_ICONS.get(value) or _ALKO_GENRE_ICONS.get(label) or 'genres.png'


def _catalogue_media_type_for_section(section):
	return 'serie' if str(section or '') in ('series', 'animation_series', 'documentary_series', 'qc_series', 'anime_series') else 'film'


ALKOPASTE_CATALOGUE_SECTION_ROOT_FALLBACKS = {
	'documentary_movie': 'documentary',
	'documentary_series': 'documentary',
	'animation_movie': 'animation',
	'animation_series': 'animation',
	'qc_movie': 'qc',
	'qc_series': 'qc',
	'anime_movie': 'anime',
	'anime_series': 'anime',
}


def _remote_item_section_where(section, media_type, alias='i'):
	section = str(section or '').strip()
	media_type = str(media_type or _catalogue_media_type_for_section(section)).strip()
	root_key = ALKOPASTE_CATALOGUE_SECTION_ROOT_FALLBACKS.get(section, '')
	prefix = (str(alias or '').strip() + '.') if alias else ''
	if root_key:
		return "((%ssection=? AND %smedia_type=?) OR (%sroot_key=? AND %smedia_type=?))" % (prefix, prefix, prefix, prefix), [section, media_type, root_key, media_type]
	return "(%ssection=? AND %smedia_type=?)" % (prefix, prefix), [section, media_type]


def _remote_facet_section_where(section, media_type, alias=''):
	section = str(section or '').strip()
	media_type = str(media_type or _catalogue_media_type_for_section(section)).strip()
	root_key = ALKOPASTE_CATALOGUE_SECTION_ROOT_FALLBACKS.get(section, '')
	prefix = (str(alias or '').strip() + '.') if alias else ''
	if root_key:
		return "((%ssection=? AND %smedia_type=?) OR (%sroot_key=? AND %smedia_type=?))" % (prefix, prefix, prefix, prefix), [section, media_type, root_key, media_type]
	return "(%ssection=? AND %smedia_type=?)" % (prefix, prefix), [section, media_type]


def _catalogue_cache_key(kind, *parts):
	payload = '|'.join([ALKOPASTE_CATALOGUE_INDEX_CACHE_VERSION, str(kind)] + [str(i or '') for i in parts])
	try:
		digest = hashlib.md5(payload.encode('utf-8'), usedforsecurity=False).hexdigest()
	except TypeError:
		digest = hashlib.md5(payload.encode('utf-8')).hexdigest()
	return 'alkoflix_alkopaste_catalogue_%s_%s' % (kind, digest)


def _catalogue_section_root_code(section):
	return ALKOPASTE_CATALOGUE_SECTION_ROOTS.get(str(section or '').strip(), '')


def _catalogue_section_source_codes(section, refresh=False):
	"""Retourne les codes enfants d'une section sans valider chaque paste.
	C'est volontaire : valider chaque enfant obligeait à ouvrir tous les pastes,
	ce qui transformait la mise à jour en reconstruction interminable.
	"""
	section = str(section or '').strip()
	root_code = _catalogue_section_root_code(section)
	if not root_code: return []
	cache = MainCache()
	cache_key = _catalogue_cache_key('sources', section, root_code)
	if refresh:
		try: cache.delete(cache_key)
		except: pass
	cached = cache.get(cache_key)
	if cached: return list(cached)
	content = _fetch_text(_code_url(root_code))
	codes = []
	if content:
		if _looks_like_content_paste(content):
			codes = [root_code]
		else:
			codes = _extract_index_codes(content)
	if not codes:
		codes = [root_code]
	try: cache.set(cache_key, codes, expiration=timedelta(hours=INDEX_CACHE_HOURS))
	except: pass
	return codes


def _catalogue_line_to_row(parts, section, wanted_media_type, paste_code, source_order):
	try:
		if len(parts) <= COL_TMDB: return None
		raw_cat = _row_value(parts, COL_CAT)
		normalized = _normalize_cat(raw_cat)
		if normalized not in ('film', 'serie'): return None
		media_type = _catalogue_media_type_from_key(raw_cat, normalized)
		if media_type != wanted_media_type: return None
		tmdb_id = str(_row_value(parts, COL_TMDB) or '').strip()
		if not tmdb_id or tmdb_id in ('0', 'None', 'none', 'null'): return None
		title = clean_text(_row_value(parts, COL_TITLE))
		year = _safe_int(_row_value(parts, COL_YEAR), None)
		groups = _cell_values(_row_value(parts, COL_GROUPES))
		networks = _cell_values(_row_value(parts, COL_NETWORK)) if media_type == 'serie' else []
		genres = _cell_values(_row_value(parts, COL_GENRES))
		return {
			'section': section, 'media_type': media_type, 'tmdb_id': tmdb_id, 'title': title,
			'year': year, 'groups': groups, 'networks': networks, 'genres': genres,
			'paste_code': paste_code, 'source_order': source_order,
			'alpha': _title_alpha_value(title)
		}
	except:
		return None


def _catalogue_iter_media_rows(section, media_type='', stop_after=0):
	section = str(section or '').strip()
	media_type = str(media_type or _catalogue_media_type_for_section(section)).strip()
	queue = list(_catalogue_section_source_codes(section))
	visited = set()
	source_order = 0
	while queue:
		code = str(queue.pop(0) or '').strip()
		if not code or code in visited: continue
		visited.add(code)
		content = _fetch_text(_code_url(code))
		if not content: continue
		if not _looks_like_content_paste(content):
			for child in _extract_index_codes(content):
				if child not in visited: queue.append(child)
			continue
		lines = content.splitlines()
		if not lines: continue
		first_parts = lines[0].split(';')
		first_header_text = ';'.join(first_parts).upper()
		first_header = _header_has_urls(first_parts) or ('CAT' in first_header_text and 'TMDB' in first_header_text and 'TITLE' in first_header_text)
		data_lines = lines[1:] if first_header else lines
		for line in data_lines:
			line = (line or '').strip()
			if not line: continue
			parts = line.split(';')
			source_order += 1
			row = _catalogue_line_to_row(parts, section, media_type, code, source_order)
			if not row: continue
			yield row
			if stop_after and source_order >= stop_after:
				return


def _theme_parts(value):
	text = _clean_list_value(value)
	if not text: return '', ''
	if ':' not in text: return text, ''
	root, child = text.split(':', 1)
	return _clean_list_value(root), _clean_list_value(child)


def _row_matches_theme_lazy(row, group1='', group2=None):
	group1 = _clean_list_value(group1)
	if not group1: return True
	wanted_child = None if group2 is None else _clean_list_value(group2)
	for raw_group in row.get('groups') or []:
		root, child = _theme_parts(raw_group)
		if root != group1: continue
		if wanted_child is None: return True
		if child == wanted_child: return True
	return False


def _row_matches_filter_lazy(row, filter_type='', filter_value=''):
	filter_type = str(filter_type or '').strip()
	filter_value = _clean_list_value(filter_value)
	if not filter_type or not filter_value: return True
	filter_type = _catalogue_resolve_filter_type(filter_type)
	if filter_type == 'genre':
		values = _catalogue_filter_values(filter_value)
		if len(values) > 1: return all(value in (row.get('genres') or []) for value in values)
		return filter_value in (row.get('genres') or [])
	if filter_type == 'network': return filter_value in (row.get('networks') or [])
	if filter_type == 'year': return str(row.get('year') or '') == filter_value
	if filter_type == 'alpha': return str(row.get('alpha') or '') == filter_value
	return True


def _row_matches_catalogue_lazy(row, filter_type='', filter_value='', group1='', group2=None):
	return _row_matches_filter_lazy(row, filter_type, filter_value) and _row_matches_theme_lazy(row, group1, group2)


def _fresh_random_seed_value():
	# Garde une vraie granularité sous la seconde. Le mode Aléatoire du catalogue
	# peut être rouvert très vite depuis un skin; time.time() tronqué donnait alors
	# le même tirage et l'impression que rien ne changeait.
	try: return str(time.time_ns())
	except:
		try: return '%.6f' % time.time()
		except: return str(time.time())


def _stable_random_seed(value=''):
	try:
		value = str(value or '').strip()
		# Important : ne pas convertir les valeurs time.time() en int(float(...)).
		# Ça supprimait les décimales et plusieurs ouvertures rapides partageaient
		# exactement le même seed. On hashe donc la chaîne complète.
		payload = value or _fresh_random_seed_value()
		try:
			return int(hashlib.sha1(payload.encode('utf-8'), usedforsecurity=False).hexdigest()[:8], 16) % 2147483647
		except TypeError:
			return int(hashlib.sha1(payload.encode('utf-8')).hexdigest()[:8], 16) % 2147483647
	except:
		try: return int(time.time_ns() % 2147483647)
		except: return int(time.time() * 1000) % 2147483647


def _catalogue_random_order_expr(alias='i'):
	# ORDER BY aléatoire déterministe par seed, mais vraiment différent d'un seed
	# à l'autre. L'ancienne formule ajoutait seulement le seed après une
	# multiplication fixe, ce qui ressemblait trop souvent à une simple rotation.
	alias = str(alias or 'i')
	prefix = '%s.' % alias if alias else ''
	tmdb = "ABS(CAST(COALESCE(%stmdb_id, '0') AS INTEGER))" % prefix
	order = "ABS(CAST(COALESCE(%ssource_order, 0) AS INTEGER))" % prefix
	return "ABS(((%s * ((? %% 104729) + 1009)) + (%s * ((? %% 130363) + 9176)) + (? * 37)) %% 2147483647)" % (tmdb, order)


def _catalogue_random_order_args(seed):
	try: seed = int(seed or 0)
	except: seed = _stable_random_seed(seed)
	return [seed, seed, seed]


# Filtres de sécurité pour le mode Aléatoire du catalogue local. Le catalogue
# peut contenir des listes très larges : on évite que l'aléatoire serve surtout
# des titres/genres clairement adultes, sans ajouter d'appel réseau à l'ouverture.
ALKOPASTE_RANDOM_BLOCKED_TEXT_TOKENS = (
	'porn', 'porno', 'pornographie', 'pornographique', 'xxx',
	'erotic', 'erotica', 'erotique', 'érotique', 'erotisme', 'érotisme',
	'softcore', 'hardcore', 'sexuel', 'sexuelle', 'sexual',
	'nudity', 'nudité', 'fetish', 'fetiche', 'fétiche'
)


def _catalogue_random_safe_text_sql(expr):
	parts, args = [], []
	for token in ALKOPASTE_RANDOM_BLOCKED_TEXT_TOKENS:
		parts.append("LOWER(COALESCE(%s, '')) NOT LIKE ?" % expr)
		args.append('%%%s%%' % token)
	return parts, args


def _catalogue_random_safe_where(alias='i'):
	alias = str(alias or 'i')
	prefix = '%s.' % alias if alias else ''
	where, args = _catalogue_random_safe_text_sql('%stitle' % prefix)
	term_checks = []
	for token in ALKOPASTE_RANDOM_BLOCKED_TEXT_TOKENS:
		term_checks.append("LOWER(COALESCE(ts.value, '')) LIKE ? OR LOWER(COALESCE(ts.label, '')) LIKE ?")
		args.extend(['%%%s%%' % token, '%%%s%%' % token])
	if term_checks:
		where.append("NOT EXISTS (SELECT 1 FROM terms ts WHERE ts.item_id=%sid AND ts.term_type IN ('genre','keyword','tag','category','group') AND (%s))" % (prefix, ' OR '.join(term_checks)))
	return where, args


def _catalogue_random_row_allowed(row):
	try: values = [row.get('title'), row.get('original_title'), row.get('genres'), row.get('networks')]
	except: values = []
	for value in values:
		if isinstance(value, (list, tuple, set)):
			text = ' '.join(str(i or '') for i in value)
		else:
			text = str(value or '')
		text = text.lower()
		if any(token in text for token in ALKOPASTE_RANDOM_BLOCKED_TEXT_TOKENS): return False
	return True


def _catalogue_is_tmdb_trending_sort(sort_mode=''):
	return str(sort_mode or '').strip().lower() in ('tmdb_trending', 'tmdb_trending_week', 'trending_tmdb', 'trending_order')


def _catalogue_tmdb_trending_ids(media_type='', max_pages=10):
	"""Ordre officiel TMDb /trending/{movie|tv}/week.

	Le Catalogue alkoPaste s'en sert seulement comme ordre/filtre externe :
	aucun média absent de la base catalogue n'est ajouté.
	"""
	media_type = str(media_type or '').strip().lower()
	is_tv = media_type in ('serie', 'series', 'tv', 'tvshow', 'tvshows')
	cache_key = 'alkopaste_catalogue_tmdb_trending_%s_v1' % ('tv' if is_tv else 'movie')
	cache = MainCache()
	cached = cache.get(cache_key)
	if cached:
		try: return [str(i) for i in cached if i]
		except: pass
	ids, seen = [], set()
	try:
		from indexers import tmdb_api
		func = tmdb_api.tmdb_tv_trending if is_tv else tmdb_api.tmdb_movies_trending
		for page in range(1, max(1, int(max_pages or 10)) + 1):
			data = func(page) or {}
			results = data.get('results', []) if isinstance(data, dict) else []
			if not results: break
			for item in results:
				tmdb_id = str(item.get('id') or '').strip() if isinstance(item, dict) else ''
				if tmdb_id and tmdb_id not in seen:
					seen.add(tmdb_id)
					ids.append(tmdb_id)
			try:
				total_pages = int(data.get('total_pages') or page)
			except:
				total_pages = page
			if page >= total_pages: break
	except Exception as e:
		try: kodi_utils.logger('Catalogue alkoPaste TMDb trending', 'ordre indisponible | media=%s | erreur=%s' % (media_type, type(e).__name__))
		except: pass
	if ids:
		try: cache.set(cache_key, ids, expiration=timedelta(hours=4))
		except: pass
	return ids


def _catalogue_sort_rows_by_tmdb_trending(rows, media_type=''):
	order_ids = _catalogue_tmdb_trending_ids(media_type)
	if not order_ids:
		return None
	order = dict((tmdb_id, idx) for idx, tmdb_id in enumerate(order_ids))
	filtered = []
	for row in rows or []:
		tmdb_id = str(row.get('tmdb_id') or '').strip()
		if tmdb_id in order:
			filtered.append(row)
	return sorted(filtered, key=lambda r: (order.get(str(r.get('tmdb_id') or '').strip(), 999999), int(r.get('source_order') or 0), str(r.get('title') or '').lower()))


def _catalogue_sort_rows_lazy(rows, sort_mode='', list_sort='', random_seed='', media_type=''):
	try:
		from modules.list_sorting import normalise_list_sort_key
		list_sort = normalise_list_sort_key(list_sort)
	except:
		list_sort = str(list_sort or '').strip().lower() or 'original'
	sort_mode = str(sort_mode or 'recent').strip().lower()
	if _catalogue_is_tmdb_trending_sort(sort_mode) and (not list_sort or list_sort == 'original'):
		trending_rows = _catalogue_sort_rows_by_tmdb_trending(rows, media_type)
		if trending_rows is not None:
			return trending_rows
	if list_sort and list_sort != 'original':
		if list_sort == 'random': sort_mode = 'random'
		elif list_sort.startswith('title'):
			return sorted(rows, key=lambda r: (str(r.get('title') or '').lower(), int(r.get('source_order') or 0)), reverse=list_sort.endswith('_desc'))
		elif list_sort.startswith('date'):
			return sorted(rows, key=lambda r: (int(r.get('year') or 0), str(r.get('title') or '').lower()), reverse=list_sort.endswith('_desc'))
		elif list_sort.startswith('added') or list_sort.startswith('watched'):
			# Dans la base catalogue, source_order petit = arrivée plus récente.
			reverse = False if list_sort.endswith('_desc') else True
			return sorted(rows, key=lambda r: int(r.get('source_order') or 0), reverse=reverse)
	if sort_mode == 'random':
		rows = [r for r in (rows or []) if _catalogue_random_row_allowed(r)]
		seed = _stable_random_seed(random_seed)
		mult_a = (seed % 104729) + 1009
		mult_b = (seed % 130363) + 9176
		def _rand_key(r):
			try: tmdb = abs(int(str(r.get('tmdb_id') or '0')))
			except: tmdb = 0
			try: order = abs(int(r.get('source_order') or 0))
			except: order = 0
			return abs(((tmdb * mult_a) + (order * mult_b) + (seed * 37)) % 2147483647)
		return sorted(rows, key=_rand_key)
	if sort_mode == 'az':
		return sorted(rows, key=lambda r: (str(r.get('title') or '').lower(), int(r.get('source_order') or 0)))
	if sort_mode in ('tmdb_order', 'tmdb', 'official', 'source', 'original'):
		return sorted(rows, key=lambda r: int(r.get('source_order') or 0))
	if sort_mode in ('date', 'new', 'newest', 'latest'):
		# Nouveautés locales : année de sortie descendante, puis ordre de la base
		# pour garder un résultat stable entre deux ouvertures de page.
		return sorted(rows, key=lambda r: (-int(r.get('year') or 0), int(r.get('source_order') or 0), str(r.get('title') or '').lower()))
	if sort_mode == 'rated':
		# Le mode lazy (fallback vieux schéma/pastes directs) ne transporte pas les
		# notes TMDb. On garde donc un ordre propre et stable plutôt qu'un faux tri.
		return sorted(rows, key=lambda r: (-int(r.get('year') or 0), int(r.get('source_order') or 0), str(r.get('title') or '').lower()))
	if sort_mode == 'popular':
		counts = {}
		for r in rows: counts[r.get('tmdb_id')] = counts.get(r.get('tmdb_id'), 0) + 1
		return sorted(rows, key=lambda r: (-counts.get(r.get('tmdb_id'), 0), int(r.get('source_order') or 0)))
	return sorted(rows, key=lambda r: int(r.get('source_order') or 0))


def _dedupe_rows_by_tmdb(rows):
	seen, out = set(), []
	for row in rows:
		tmdb_id = str(row.get('tmdb_id') or '').strip()
		if not tmdb_id or tmdb_id in seen: continue
		seen.add(tmdb_id)
		out.append(row)
	return out


def alkopaste_catalogue_ids(media_type, params_get, page_no=1):
	try: page_no = max(1, int(page_no or 1))
	except: page_no = 1
	section = str(params_get('catalogue_section', '') or '').strip()
	media_type = str(media_type or _catalogue_media_type_for_section(section)).strip()
	sort_mode = str(params_get('catalogue_sort', 'recent') or 'recent').strip()
	list_sort = str(params_get('list_sort', '') or '').strip()
	random_seed = str(params_get('list_random_seed', '') or '').strip()
	random_safe = str(sort_mode or '').strip().lower() == 'random' or str(list_sort or '').strip().lower() == 'random'
	filter_type = _catalogue_resolve_filter_type(str(params_get('catalogue_filter_type', '') or '').strip())
	filter_value = str(params_get('catalogue_filter_value', '') or '').strip()
	group1 = str(params_get('catalogue_group1', '') or '').strip()
	group2 = params_get('catalogue_group2')
	if group2 in ('', 'None', 'none', None): group2 = None
	page_size = ALKOPASTE_CATALOGUE_PAGE_SIZE
	offset = (page_no - 1) * page_size
	cache_key = _catalogue_cache_key('ids', 'random_safe_v1' if random_safe else '', section, media_type, sort_mode, list_sort, filter_type, filter_value, group1, group2 or '', page_no, random_seed if sort_mode == 'random' or list_sort == 'random' else '')
	cache = MainCache()
	cached = cache.get(cache_key)
	if cached:
		try: return list(cached.get('ids') or []), int(cached.get('total_pages') or page_no)
		except: pass
	try:
		need_full_sort = bool(filter_type or group1 or sort_mode in ('popular', 'random', 'az') or (list_sort and list_sort != 'original'))
		rows = []
		if need_full_sort:
			for row in _catalogue_iter_media_rows(section, media_type):
				 if _row_matches_catalogue_lazy(row, filter_type, filter_value, group1, group2): rows.append(row)
			rows = _dedupe_rows_by_tmdb(_catalogue_sort_rows_lazy(rows, sort_mode, list_sort, random_seed, media_type))
			page_rows = rows[offset:offset + page_size + 1]
		else:
			seen = set()
			needed = offset + page_size + 1
			for row in _catalogue_iter_media_rows(section, media_type):
				tmdb_id = str(row.get('tmdb_id') or '').strip()
				if not tmdb_id or tmdb_id in seen: continue
				seen.add(tmdb_id)
				rows.append(row)
				if len(rows) >= needed: break
			page_rows = rows[offset:offset + page_size + 1]
		ids = [str(row.get('tmdb_id')) for row in page_rows[:page_size] if row.get('tmdb_id')]
		total_pages = page_no + 1 if len(page_rows) > page_size else page_no
		try: cache.set(cache_key, {'ids': ids, 'total_pages': total_pages}, expiration=timedelta(hours=6))
		except: pass
		return ids, max(1, total_pages)
	except Exception as e:
		try: kodi_utils.logger('Catalogue alkoPaste', 'Lecture lazy impossible | section=%s | erreur=%s' % (section, type(e).__name__))
		except: pass
		return [], 1


def _catalogue_terms_cache(section, media_type):
	cache_key = _catalogue_cache_key('terms', section, media_type)
	cache = MainCache()
	cached = cache.get(cache_key)
	if cached: return cached
	terms = {'genre': {}, 'network': {}, 'year': {}, 'alpha': {}, 'group_roots': {}, 'group_children': {}}
	try:
		for row in _catalogue_iter_media_rows(section, media_type):
			for value in row.get('genres') or []:
				label = _catalogue_genre_label(value, media_type)
				if label: terms['genre'][value] = label
			if media_type == 'serie':
				for raw_network in row.get('networks') or []:
					value, label = _network_value_label(raw_network)
					if label and label.lower() not in ('tous', 'tout', 'all'): terms['network'][value] = label
			if row.get('year'): terms['year'][str(row.get('year'))] = str(row.get('year'))
			if row.get('alpha'): terms['alpha'][row.get('alpha')] = row.get('alpha')
			for raw_group in row.get('groups') or []:
				root, child = _theme_parts(raw_group)
				if root: terms['group_roots'][root] = root
				if root and child:
					terms['group_children'].setdefault(root, {})[child] = child
	except Exception as e:
		try: kodi_utils.logger('Catalogue alkoPaste', 'Index termes lazy impossible | section=%s | erreur=%s' % (section, type(e).__name__))
		except: pass
	try: cache.set(cache_key, terms, expiration=timedelta(hours=12))
	except: pass
	return terms


def alkopaste_catalogue_values(section, value_type, media_type=''):
	requested_value_type = str(value_type or 'genre').strip()
	value_type = _catalogue_resolve_filter_type(requested_value_type)
	media_type = str(media_type or _catalogue_media_type_for_section(section)).strip()
	if value_type == 'network' and media_type != 'serie': return []
	terms = _catalogue_terms_cache(section, media_type)
	bucket = terms.get(value_type if value_type in ('genre', 'network', 'year', 'alpha') else 'genre', {}) or {}
	items = []
	for value, label in bucket.items():
		label = _clean_list_value(label)
		value = _clean_list_value(value)
		if not label or not value: continue
		if value_type == 'genre':
			# Nettoyage final : pas de "Sans genre", pas de [], pas d'ID numérique non mappé.
			label = _catalogue_genre_label(value, media_type)
			if not label: continue
			items.append({'name': label, 'value': value, 'count': 0, 'icon': _catalogue_genre_icon(value, label)})
		else:
			items.append({'name': label, 'value': value, 'count': 0})
	if value_type == 'year':
		return sorted(items, key=lambda item: item.get('name', ''), reverse=True)
	return sorted(items, key=lambda item: item.get('name', '').lower())


def alkopaste_catalogue_theme_roots(section, media_type=''):
	media_type = str(media_type or _catalogue_media_type_for_section(section)).strip()
	terms = _catalogue_terms_cache(section, media_type)
	roots = terms.get('group_roots', {}) or {}
	children = terms.get('group_children', {}) or {}
	items = []
	for value, label in roots.items():
		items.append({'name': label, 'value': value, 'count': 0, 'has_children': bool(children.get(value))})
	return sorted(items, key=lambda item: item.get('name', '').lower())


def alkopaste_catalogue_theme_children(section, group1, media_type=''):
	media_type = str(media_type or _catalogue_media_type_for_section(section)).strip()
	terms = _catalogue_terms_cache(section, media_type)
	children = (terms.get('group_children', {}) or {}).get(_clean_list_value(group1), {}) or {}
	items = [{'name': label, 'value': value, 'count': 0} for value, label in children.items()]
	return sorted(items, key=lambda item: item.get('name', '').lower())


def alkopaste_catalogue_database_status():
	# État léger : le catalogue est navigable dès que les codes racines existent.
	try:
		ready = any(_catalogue_section_source_codes(section) for section in ALKOPASTE_CATALOGUE_SECTION_ROOTS.keys())
		return {'ready': bool(ready), 'catalogue_total': 0, 'last_sync': 0}
	except:
		return {'ready': True, 'catalogue_total': 0, 'last_sync': 0}


def _ensure_catalogue_ready(allow_sync=False):
	# Toujours vrai en mode lazy : la navigation ne dépend plus d'une DB préconstruite.
	return True


# ---------------------------------------------------------------------------
# Catalogue alkoPaste distant préconstruit
# ---------------------------------------------------------------------------
# Le gros travail est fait côté serveur : alkoFlix télécharge seulement une
# base SQLite déjà prête, puis navigue localement avec des requêtes légères.

def _catalogue_manifest_base_url(manifest_url=''):
	manifest_url = str(manifest_url or ALKOPASTE_CATALOGUE_REMOTE_MANIFEST).strip().split('?', 1)[0]
	return manifest_url.rsplit('/', 1)[0].rstrip('/')


def _catalogue_abs_url(url, manifest_url=''):
	url = str(url or '').strip()
	if not url: return ''
	if url.startswith('http://') or url.startswith('https://'): return url
	return '%s/%s' % (_catalogue_manifest_base_url(manifest_url), url.lstrip('/'))


def _catalogue_file_sha256(path):
	try:
		h = hashlib.sha256()
		with open(path, 'rb') as f:
			while True:
				chunk = f.read(1024 * 1024)
				if not chunk: break
				h.update(chunk)
		return h.hexdigest()
	except:
		return ''


def _catalogue_bytes_sha256(data):
	try: return hashlib.sha256(data or b'').hexdigest()
	except: return ''


def _catalogue_local_db_path():
	return kodi_utils.translate_path(ALKOPASTE_CATALOGUE_DB)


def _catalogue_table_exists(dbcon, table):
	try:
		row = dbcon.execute("""SELECT name FROM sqlite_master WHERE type='table' AND name=?""", (table,)).fetchone()
		return bool(row)
	except:
		return False


def _catalogue_is_remote_schema(dbcon):
	return _catalogue_table_exists(dbcon, 'items') and _catalogue_table_exists(dbcon, 'terms')


def _catalogue_local_schema_version(dbcon):
	try:
		if not _catalogue_table_exists(dbcon, 'meta'): return 0
		row = dbcon.execute("""SELECT value FROM meta WHERE key='schema_version'""").fetchone()
		return _safe_int(row['value'] if row else 0, 0) or 0
	except:
		return 0


def _catalogue_has_required_remote_columns(dbcon):
	# Schéma catalogue attendu depuis v1.9.7/v1.9.8.
	# Ces colonnes permettent les tris locaux rapides sans appel TMDb à l'ouverture.
	try:
		cols = set(row['name'] for row in dbcon.execute("""PRAGMA table_info(items)""").fetchall())
		required = set(('vote_average', 'vote_count', 'rating_score', 'popularity', 'date_key'))
		return required.issubset(cols)
	except:
		return False


def _catalogue_remote_schema_current(dbcon):
	try:
		if not _catalogue_is_remote_schema(dbcon): return False
		version = _catalogue_local_schema_version(dbcon)
		return version >= ALKOPASTE_CATALOGUE_DB_VERSION and _catalogue_has_required_remote_columns(dbcon)
	except:
		return False


def _catalogue_local_schema_current():
	dbcon = None
	try:
		path = _catalogue_local_db_path()
		if not os.path.exists(path): return False
		dbcon = sqlite3.connect(path)
		dbcon.row_factory = sqlite3.Row
		return _catalogue_remote_schema_current(dbcon)
	except:
		return False
	finally:
		try:
			if dbcon: dbcon.close()
		except: pass


def _catalogue_remote_ready():
	dbcon = None
	try:
		path = _catalogue_local_db_path()
		if not os.path.exists(path): return False
		dbcon = sqlite3.connect(path)
		dbcon.row_factory = sqlite3.Row
		# Une vieille base locale v1/v2 ne doit plus être considérée prête :
		# elle sera remplacée par la base serveur schema v3 à la prochaine synchro.
		if not _catalogue_remote_schema_current(dbcon): return False
		row = dbcon.execute("""SELECT COUNT(*) AS total FROM items""").fetchone()
		return int(row['total'] or 0) > 0
	except:
		return False
	finally:
		try:
			if dbcon: dbcon.close()
		except: pass


def _catalogue_remote_count():
	dbcon = None
	try:
		path = _catalogue_local_db_path()
		if not os.path.exists(path): return 0
		dbcon = sqlite3.connect(path)
		dbcon.row_factory = sqlite3.Row
		if not _catalogue_is_remote_schema(dbcon): return 0
		return int(dbcon.execute("""SELECT COUNT(*) AS total FROM items""").fetchone()['total'] or 0)
	except:
		return 0
	finally:
		try:
			if dbcon: dbcon.close()
		except: pass


def _catalogue_remote_meta(key, default=''):
	dbcon = None
	try:
		path = _catalogue_local_db_path()
		if not os.path.exists(path): return default
		dbcon = sqlite3.connect(path)
		dbcon.row_factory = sqlite3.Row
		if not _catalogue_table_exists(dbcon, 'meta'): return default
		row = dbcon.execute("""SELECT value FROM meta WHERE key=?""", (key,)).fetchone()
		return row['value'] if row else default
	except:
		return default
	finally:
		try:
			if dbcon: dbcon.close()
		except: pass


def _catalogue_remote_set_meta(db_path, values):
	try:
		dbcon = sqlite3.connect(db_path)
		dbcon.execute("""CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT)""")
		for key, value in (values or {}).items():
			dbcon.execute("""INSERT OR REPLACE INTO meta(key, value) VALUES(?, ?)""", (str(key), str(value)))
		dbcon.commit()
		dbcon.close()
	except:
		pass


def _catalogue_remote_validate(db_path):
	dbcon = None
	try:
		dbcon = sqlite3.connect(db_path)
		dbcon.row_factory = sqlite3.Row
		if not _catalogue_is_remote_schema(dbcon): return 0
		# Le catalogue actuel doit transporter les champs de tri v3.
		# Sans ça, les menus Mieux notés/Populaires retomberaient sur des tris incomplets.
		if not _catalogue_remote_schema_current(dbcon): return 0
		row = dbcon.execute("""SELECT COUNT(*) AS total FROM items""").fetchone()
		return int(row['total'] or 0)
	except:
		return 0
	finally:
		try:
			if dbcon: dbcon.close()
		except: pass


def _catalogue_remote_sync_due():
	try:
		last_sync = _safe_int(_catalogue_remote_meta('last_sync', '0'), 0) or 0
		if not last_sync: return True
		return int(time.time()) - last_sync >= int(DB_SYNC_INTERVAL_HOURS * 3600)
	except:
		return True


def _download_remote_catalogue_database(force=False):
	# En automatique, on respecte l'intervalle local alkoFlix.
	# Le service peut se réveiller plus souvent, mais le catalogue ne retélécharge
	# pas la base ni le manifest avant 24 h, sauf demande manuelle/forcée.
	if not force and _catalogue_remote_ready() and not _catalogue_remote_sync_due():
		return {'ok': True, 'skipped': True, 'reason': 'not_due', 'pastes': 0, 'links': 0, 'catalogue': _catalogue_remote_count()}
	manifest_url = ALKOPASTE_CATALOGUE_REMOTE_MANIFEST
	request_manifest_url = _alkopaste_remote_cache_bust_url(manifest_url) if force else manifest_url
	try:
		response = requests.get(request_manifest_url, timeout=20, headers=_alkopaste_remote_no_cache_headers())
		response.raise_for_status()
		manifest = response.json() or {}
	except Exception as e:
		if not force and _catalogue_remote_ready():
			return {'ok': True, 'skipped': True, 'reason': 'manifest_unavailable_using_local', 'pastes': 0, 'links': 0, 'catalogue': _catalogue_remote_count()}
		return {'ok': False, 'skipped': False, 'reason': 'manifest_unavailable', 'pastes': 0, 'links': 0, 'catalogue': 0}

	version = str(manifest.get('version') or '')
	compressed = manifest.get('compressed') or {}
	db_info = manifest.get('db') or {}
	remote_marker = version or str(compressed.get('sha256') or db_info.get('sha256') or '')
	local_marker = _catalogue_remote_meta('remote_marker', '')
	local_schema_current = _catalogue_local_schema_current()
	# Si l'utilisateur a encore l'ancienne base catalogue locale, on force le
	# remplacement même si un vieux marqueur distant semble identique.
	if not local_schema_current:
		local_marker = ''
	if not force and remote_marker and local_marker == remote_marker and _catalogue_remote_ready():
		return {'ok': True, 'skipped': True, 'reason': 'not_changed', 'pastes': 0, 'links': 0, 'catalogue': _catalogue_remote_count()}

	gz_url = _catalogue_abs_url(compressed.get('url') or db_info.get('url') or 'alkopaste_catalogue.db.gz', manifest_url)
	if force and gz_url:
		gz_url = _alkopaste_remote_cache_bust_url(gz_url)
	if not gz_url:
		return {'ok': False, 'skipped': False, 'reason': 'missing_db_url', 'pastes': 0, 'links': 0, 'catalogue': 0}

	try:
		response = requests.get(gz_url, timeout=120, headers=_alkopaste_remote_no_cache_headers())
		response.raise_for_status()
		payload = response.content or b''
	except:
		return {'ok': False, 'skipped': False, 'reason': 'download_failed', 'pastes': 0, 'links': 0, 'catalogue': 0}

	expected_gz_sha = str(compressed.get('sha256') or '').strip().lower()
	expected_db_sha = str(db_info.get('sha256') or '').strip().lower()
	payload_sha = _catalogue_bytes_sha256(payload).lower()

	# v1.5.41 :
	# On ne bloque plus sur le SHA du .gz. Le serveur peut modifier l'encodage
	# ou servir un payload déjà transformé. On installe seulement si la base
	# SQLite finale est lisible et valide.
	try:
		if payload.startswith(b'SQLite format 3'):
			db_bytes = payload
		else:
			db_bytes = gzip.decompress(payload)
	except:
		db_bytes = payload

	try:
		final_sha = _catalogue_bytes_sha256(db_bytes).lower()
		if expected_gz_sha and payload_sha != expected_gz_sha:
			kodi_utils.logger('Catalogue alkoPaste distant', 'SHA .gz différent du manifest, validation SQLite utilisée.')
		if expected_db_sha and final_sha != expected_db_sha:
			kodi_utils.logger('Catalogue alkoPaste distant', 'SHA DB différent du manifest, validation SQLite utilisée.')
	except:
		pass

	try:
		profile_path = kodi_utils.translate_path('special://profile/addon_data/plugin.video.alkoflix/')
		if not os.path.exists(profile_path): os.makedirs(profile_path)
		db_path = _catalogue_local_db_path()
		# Temp d'installation volontairement hors liste de nettoyage :
		# la v1.9.9 pouvait supprimer *.download juste avant os.replace(),
		# ce qui renvoyait FileNotFoundError malgré une base serveur valide.
		tmp_path = db_path + '.installing'
		try:
			if os.path.exists(tmp_path): os.remove(tmp_path)
		except:
			pass
		with open(tmp_path, 'wb') as f:
			f.write(db_bytes)
		count = _catalogue_remote_validate(tmp_path)
		if count <= 0:
			try: os.remove(tmp_path)
			except: pass
			return {'ok': False, 'skipped': False, 'reason': 'invalid_sqlite', 'pastes': 0, 'links': 0, 'catalogue': 0}
		_catalogue_remote_set_meta(tmp_path, {
			'schema_version': str(ALKOPASTE_CATALOGUE_DB_VERSION),
			'remote_manifest': manifest_url,
			'remote_marker': remote_marker,
			'remote_version': version,
			'last_sync': int(time.time()),
			'generated_at': manifest.get('generated_at') or '',
			'source': 'remote'
		})
		_delete_alkopaste_catalogue_database_files()
		os.replace(tmp_path, db_path)
		try: _clear_alkopaste_catalogue_runtime_cache()
		except: pass
		return {'ok': True, 'skipped': False, 'reason': 'downloaded', 'pastes': 0, 'links': 0, 'catalogue': count, 'generated_at': manifest.get('generated_at') or '', 'remote_marker': remote_marker}
	except Exception as e:
		try:
			if tmp_path and os.path.exists(tmp_path): os.remove(tmp_path)
		except: pass
		try:
			kodi_utils.logger('Catalogue alkoPaste distant', 'Installation DB impossible | erreur=%s | detail=%s' % (type(e).__name__, str(e)))
		except: pass
		return {'ok': False, 'skipped': False, 'reason': type(e).__name__, 'pastes': 0, 'links': 0, 'catalogue': 0}


def _remote_db_connect():
	dbcon = sqlite3.connect(_catalogue_local_db_path())
	dbcon.row_factory = sqlite3.Row
	try:
		dbcon.execute("""PRAGMA query_only = ON""")
		dbcon.execute("""PRAGMA temp_store = MEMORY""")
		dbcon.execute("""PRAGMA mmap_size = 268435456""")
	except:
		pass
	return dbcon


def _remote_table_columns(dbcon, table='items'):
	try:
		return set(str(row['name']) for row in dbcon.execute("PRAGMA table_info(%s)" % table).fetchall())
	except:
		return set()


def _remote_has_item_column(dbcon, column):
	try: return str(column or '') in (_remote_table_columns(dbcon, 'items') if dbcon else set())
	except: return False


def _remote_first_item_column(dbcon, candidates):
	try: cols = _remote_table_columns(dbcon, 'items') if dbcon else set()
	except: cols = set()
	for candidate in candidates or ():
		if candidate in cols: return candidate
	return ''


def _remote_rating_columns(dbcon):
	# Compatibilité avec plusieurs noms possibles côté base serveur. L'important
	# est que la lecture reste 100 % locale à l'ouverture du menu. Si la base
	# actuelle n'a pas encore ces colonnes, le tri retombe proprement sur l'année
	# au lieu de lancer des appels TMDb par média.
	rating_score_col = _remote_first_item_column(dbcon, ('rating_score', 'tmdb_rating_score', 'weighted_rating'))
	rating_col = _remote_first_item_column(dbcon, ('vote_average', 'tmdb_vote_average', 'tmdb_rating', 'rating', 'score'))
	votes_col = _remote_first_item_column(dbcon, ('vote_count', 'tmdb_vote_count', 'tmdb_votes', 'votes'))
	return rating_col, votes_col, rating_score_col


def _remote_date_order_expr(dbcon, alias='i'):
	prefix = '%s.' % alias if alias else ''
	if _remote_has_item_column(dbcon, 'date_key'):
		return "COALESCE(CAST(%sdate_key AS INTEGER), COALESCE(CAST(%syear AS INTEGER), 0) * 10000, 0)" % (prefix, prefix)
	return "COALESCE(CAST(%syear AS INTEGER), 0) * 10000" % prefix


def _remote_popularity_order_expr(dbcon, alias='i'):
	pop_col = _remote_first_item_column(dbcon, ('popularity', 'tmdb_popularity', 'popular_score'))
	if not pop_col: return ''
	prefix = '%s.' % alias if alias else ''
	return "COALESCE(CAST(%s%s AS REAL), 0)" % (prefix, pop_col)


def _remote_rating_order_sql(dbcon, alias='i'):
	rating_col, votes_col, rating_score_col = _remote_rating_columns(dbcon)
	if not rating_col and not rating_score_col:
		return ''
	prefix = '%s.' % alias if alias else ''
	votes_expr = "COALESCE(CAST(%s%s AS INTEGER), 0)" % (prefix, votes_col) if votes_col else '0'
	rating_expr = "COALESCE(CAST(%s%s AS REAL), 0)" % (prefix, rating_col) if rating_col else '0'
	if rating_score_col:
		score_expr = "COALESCE(CAST(%s%s AS REAL), 0)" % (prefix, rating_score_col)
		return "%s DESC, %s DESC, %s DESC" % (score_expr, votes_expr, rating_expr)
	return "%s DESC, %s DESC" % (rating_expr, votes_expr)


def _remote_order_clause(sort_mode='', list_sort='', random_seed='', dbcon=None):
	try:
		from modules.list_sorting import normalise_list_sort_key
		list_sort = normalise_list_sort_key(list_sort)
	except:
		list_sort = str(list_sort or '').strip().lower() or 'original'
	sort_mode = str(sort_mode or 'recent').strip().lower()
	date_expr = _remote_date_order_expr(dbcon, 'i')
	if list_sort and list_sort != 'original':
		if list_sort == 'random': sort_mode = 'random'
		elif list_sort.startswith('title'):
			return "LOWER(COALESCE(i.title, '')) %s, i.source_order ASC" % ('DESC' if list_sort.endswith('_desc') else 'ASC'), []
		elif list_sort.startswith('date'):
			return "%s %s, LOWER(COALESCE(i.title, '')) ASC" % (date_expr, 'DESC' if list_sort.endswith('_desc') else 'ASC'), []
		elif list_sort.startswith('rating'):
			rating_order = _remote_rating_order_sql(dbcon, 'i')
			if rating_order:
				direction = 'DESC' if list_sort.endswith('_desc') else 'ASC'
				if direction == 'ASC':
					rating_col, votes_col, rating_score_col = _remote_rating_columns(dbcon)
					primary_col = rating_score_col or rating_col
					votes_expr = "COALESCE(CAST(i.%s AS INTEGER), 0) ASC" % votes_col if votes_col else '0 ASC'
					return "COALESCE(CAST(i.%s AS REAL), 0) ASC, %s, %s ASC, i.source_order ASC" % (primary_col, votes_expr, date_expr), []
				return "%s, %s DESC, i.source_order ASC, LOWER(COALESCE(i.title, '')) ASC" % (rating_order, date_expr), []
			return "%s DESC, i.source_order ASC, LOWER(COALESCE(i.title, '')) ASC" % date_expr, []
		elif list_sort.startswith('popular') or list_sort.startswith('popularity'):
			popularity_expr = _remote_popularity_order_expr(dbcon, 'i')
			direction = 'DESC' if list_sort.endswith('_desc') else 'ASC'
			if popularity_expr:
				return "%s %s, %s DESC, i.source_order ASC, LOWER(COALESCE(i.title, '')) ASC" % (popularity_expr, direction, date_expr), []
			return "%s DESC, i.source_order ASC, LOWER(COALESCE(i.title, '')) ASC" % date_expr, []
		elif list_sort.startswith('added') or list_sort.startswith('watched'):
			# Dans le Catalogue alkoPaste, source_order=0 est le plus récent.
			return 'i.source_order %s' % ('ASC' if list_sort.endswith('_desc') else 'DESC'), []
	if sort_mode == 'random':
		seed = _stable_random_seed(random_seed)
		return '%s ASC' % _catalogue_random_order_expr('i'), _catalogue_random_order_args(seed)
	if sort_mode == 'az':
		return "LOWER(COALESCE(i.title, '')) ASC, i.source_order ASC", []
	if sort_mode in ('tmdb_order', 'tmdb', 'official', 'source', 'original'):
		return 'i.source_order ASC', []
	if sort_mode in ('date', 'new', 'newest', 'latest'):
		return "%s DESC, i.source_order ASC, LOWER(COALESCE(i.title, '')) ASC" % date_expr, []
	if sort_mode == 'rated':
		rating_order = _remote_rating_order_sql(dbcon, 'i')
		if rating_order:
			return "%s, %s DESC, i.source_order ASC, LOWER(COALESCE(i.title, '')) ASC" % (rating_order, date_expr), []
		return "%s DESC, i.source_order ASC, LOWER(COALESCE(i.title, '')) ASC" % date_expr, []
	if sort_mode == 'popular':
		popularity_expr = _remote_popularity_order_expr(dbcon, 'i')
		if popularity_expr:
			return "%s DESC, %s DESC, i.source_order ASC, LOWER(COALESCE(i.title, '')) ASC" % (popularity_expr, date_expr), []
		return 'i.source_order ASC', []
	return 'i.source_order ASC', []



CATALOGUE_CLASSIFICATION_COUNTRIES = ('FR', 'CA', 'US')

CATALOGUE_CERTIFICATION_ORDER = {
	'FR': {'U': 0, 'TP': 0, 'TOUS PUBLICS': 0, '10': 10, '-10': 10, '12': 12, '-12': 12, '16': 16, '-16': 16, '18': 18, '-18': 18},
	'CA': {'G': 0, 'PG': 8, '13+': 13, '14A': 14, '16+': 16, '18A': 18, '18+': 18, 'R': 18, 'A': 18},
	'US': {'G': 0, 'TV-Y': 0, 'TV-G': 0, 'PG': 7, 'TV-Y7': 7, 'TV-Y7-FV': 7, 'TV-PG': 7, 'PG-13': 13, 'TV-14': 14, 'R': 17, 'TV-MA': 17, 'NC-17': 18, 'X': 18},
}


def _catalogue_classification_country():
	try:
		from modules import settings
		country = str(settings.certification_country() or 'FR').upper()
	except:
		country = 'FR'
	return country if country in CATALOGUE_CLASSIFICATION_COUNTRIES else 'FR'


def _catalogue_resolve_filter_type(filter_type=''):
	filter_type = str(filter_type or '').strip()
	if filter_type in ('classification', 'certification', 'mpaa'):
		return 'certification_%s' % _catalogue_classification_country().lower()
	return filter_type


def _catalogue_filter_values(filter_value=''):
	values = []
	for value in str(filter_value or '').split(','):
		value = _clean_list_value(value)
		if value and value not in values: values.append(value)
	return values


def _catalogue_certification_sort_key(value='', label=''):
	country = _catalogue_classification_country()
	age_map = CATALOGUE_CERTIFICATION_ORDER.get(country) or CATALOGUE_CERTIFICATION_ORDER.get('FR', {})
	def _norm(v):
		try: v = str(v or '').strip().upper()
		except: v = ''
		v = v.replace('RATED ', '').replace('CLASSIFICATION ', '')
		v = v.replace(' ', '')
		return v
	keys = [_norm(value), _norm(label)]
	for key in keys:
		if key in age_map:
			return (age_map[key], key)
	for key in keys:
		m = re.search(r'(\d+)', key)
		if m:
			try: return (int(m.group(1)), key)
			except: pass
	return (999, _norm(label) or _norm(value))

def _remote_where_filters(section, media_type, filter_type='', filter_value='', group1='', group2=None, random_safe=False):
	section_sql, section_args = _remote_item_section_where(section, media_type, 'i')
	where = [section_sql]
	args = list(section_args)
	filter_type = _catalogue_resolve_filter_type(str(filter_type or '').strip())
	filter_value = str(filter_value or '').strip()
	group1 = str(group1 or '').strip()
	group2 = None if group2 in ('', 'None', 'none', None) else str(group2 or '').strip()
	if filter_type and filter_value:
		if filter_type == 'genre' and ',' in str(filter_value or ''):
			for genre_value in _catalogue_filter_values(filter_value):
				where.append("""EXISTS (
					SELECT 1 FROM terms t
					WHERE t.item_id=i.id AND t.term_type=?
					  AND (LOWER(t.value)=LOWER(?) OR LOWER(t.label)=LOWER(?))
				)""")
				args.extend([filter_type, genre_value, genre_value])
		# Pour les plateformes TMDb, les menus natifs peuvent forcer une région
		# (ex. 87:US pour Acorn). Le builder inscrit maintenant les deux formes
		# quand TMDb les fournit: provider_id seul et provider_id:REGION.
		# On accepte donc la valeur exacte ET le provider_id seul, afin qu'un
		# dossier régional ne tombe pas vide si la base locale n'a que la forme
		# globale. Aucun appel réseau n'est ajouté ici.
		elif filter_type == 'provider' and ':' in filter_value:
			provider_id = filter_value.split(':', 1)[0].strip()
			where.append("""EXISTS (
				SELECT 1 FROM terms t
				WHERE t.item_id=i.id AND t.term_type=?
				  AND (LOWER(t.value)=LOWER(?) OR LOWER(t.value)=LOWER(?) OR LOWER(t.label)=LOWER(?))
			)""")
			args.extend([filter_type, filter_value, provider_id, filter_value])
		elif filter_type == 'network':
			aliases, network_id = _network_filter_aliases(filter_value)
			if aliases:
				alias_placeholders = ','.join(['LOWER(?)'] * len(aliases))
				conditions = ["LOWER(t.value) IN (%s)" % alias_placeholders, "LOWER(t.label) IN (%s)" % alias_placeholders]
				if network_id:
					conditions.append("LOWER(t.value) LIKE LOWER(?)")
				where.append("""EXISTS (
					SELECT 1 FROM terms t
					WHERE t.item_id=i.id AND t.term_type=?
					  AND (%s)
				)""" % ' OR '.join(conditions))
				args.append(filter_type)
				args.extend(aliases)
				args.extend(aliases)
				if network_id:
					args.append('%s:%%' % network_id)
			else:
				where.append("""EXISTS (
					SELECT 1 FROM terms t
					WHERE t.item_id=i.id AND t.term_type=?
					  AND (LOWER(t.value)=LOWER(?) OR LOWER(t.label)=LOWER(?))
				)""")
				args.extend([filter_type, filter_value, filter_value])
		else:
			where.append("""EXISTS (
				SELECT 1 FROM terms t
				WHERE t.item_id=i.id AND t.term_type=?
				  AND (LOWER(t.value)=LOWER(?) OR LOWER(t.label)=LOWER(?))
			)""")
			args.extend([filter_type, filter_value, filter_value])
	if group1:
		if group2:
			# Match robuste: certains builders stockent la valeur complète
			# "Listes TMDb:Populaires", d'autres peuvent fournir seulement le
			# libellé "Populaires". On accepte value OU label, sans casse.
			where.append("""EXISTS (
				SELECT 1 FROM terms tg
				WHERE tg.item_id=i.id AND tg.term_type='group'
				  AND LOWER(COALESCE(tg.root, ''))=LOWER(?)
				  AND (LOWER(tg.value)=LOWER(?) OR LOWER(tg.label)=LOWER(?))
			)""")
			args.extend([group1, group2, group2])
		else:
			where.append("""EXISTS (
				SELECT 1 FROM terms tg
				WHERE tg.item_id=i.id AND tg.term_type='group'
				  AND (LOWER(COALESCE(tg.root, ''))=LOWER(?) OR LOWER(tg.value)=LOWER(?) OR LOWER(tg.label)=LOWER(?))
			)""")
			args.extend([group1, group1, group1])
	if random_safe:
		safe_where, safe_args = _catalogue_random_safe_where('i')
		where.extend(safe_where)
		args.extend(safe_args)
	return ' AND '.join(where), args




def alkopaste_catalogue_all_id_set(media_type='film'):
	"""Retourne tous les IDs TMDb présents dans le Catalogue alkoPaste pour un type.

	Utilisé par les menus de comptes (Trakt/MDBList/TMDb) affichés dans le
	Catalogue alkoPaste : ces menus ne doivent jamais montrer un média absent du
	catalogue, même si le compte connecté le retourne.
	"""
	media_type = str(media_type or '').strip().lower()
	if media_type in ('movie', 'movies'):
		media_type = 'film'
	elif media_type in ('tv', 'show', 'shows', 'tvshow', 'tvshows', 'serie', 'series'):
		media_type = 'serie'
	if media_type not in ('film', 'serie') or not _catalogue_remote_ready():
		return set()
	db_marker = _catalogue_remote_meta('remote_marker', '') or _catalogue_remote_meta('generated_at', '')
	cache_key = _catalogue_cache_key('remote_all_id_set', db_marker, media_type)
	cache = MainCache()
	cached = cache.get(cache_key)
	if cached:
		try: return set(str(i) for i in (cached.get('ids') or []) if i)
		except: pass
	dbcon = None
	try:
		dbcon = _remote_db_connect()
		rows = dbcon.execute("SELECT DISTINCT i.tmdb_id FROM items i WHERE i.media_type=?", (media_type,)).fetchall()
		ids = set(str(row['tmdb_id']) for row in rows if row['tmdb_id'])
		try: cache.set(cache_key, {'ids': list(ids)}, expiration=timedelta(hours=6))
		except: pass
		return ids
	except Exception as e:
		try: kodi_utils.logger('Catalogue alkoPaste distant', 'Lecture IDs globaux impossible | media_type=%s | erreur=%s' % (media_type, type(e).__name__))
		except: pass
		return set()
	finally:
		try:
			if dbcon: dbcon.close()
		except: pass


def _alkopaste_catalogue_section_id_set(section, media_type='serie'):
	section = str(section or '').strip()
	media_type = str(media_type or _catalogue_media_type_for_section(section)).strip()
	if not section or not _catalogue_remote_ready(): return set()
	db_marker = _catalogue_remote_meta('remote_marker', '') or _catalogue_remote_meta('generated_at', '')
	cache_key = _catalogue_cache_key('remote_section_id_set', db_marker, section, media_type)
	cache = MainCache()
	cached = cache.get(cache_key)
	if cached:
		try: return set(str(i) for i in (cached.get('ids') or []) if i)
		except: pass
	dbcon = None
	try:
		dbcon = _remote_db_connect()
		section_sql, args = _remote_item_section_where(section, media_type, 'i')
		rows = dbcon.execute("SELECT DISTINCT i.tmdb_id FROM items i WHERE %s" % section_sql, tuple(args)).fetchall()
		ids = set(str(row['tmdb_id']) for row in rows if row['tmdb_id'])
		try: cache.set(cache_key, {'ids': list(ids)}, expiration=timedelta(hours=6))
		except: pass
		return ids
	except Exception as e:
		try: kodi_utils.logger('Catalogue alkoPaste distant', 'Lecture IDs section impossible | section=%s | erreur=%s' % (section, type(e).__name__))
		except: pass
		return set()
	finally:
		try:
			if dbcon: dbcon.close()
		except: pass



def _remote_group_where_for_catalogue(section, media_type, filter_type='', filter_value='', group1='', group2=None, random_safe=False):
	section_sql, section_args = _remote_item_section_where(section, media_type, 'i')
	where = [section_sql, "tg.term_type='group'"]
	args = list(section_args)
	group_any = str(group1 or '').strip().lower() in ('__any__', '*', 'any')
	if group_any and group2:
		where.append("(LOWER(tg.value)=LOWER(?) OR LOWER(tg.label)=LOWER(?))")
		args.extend([group2, group2])
	elif group2:
		where.append("LOWER(COALESCE(tg.root, ''))=LOWER(?)")
		where.append("(LOWER(tg.value)=LOWER(?) OR LOWER(tg.label)=LOWER(?))")
		args.extend([group1, group2, group2])
	else:
		where.append("(LOWER(COALESCE(tg.root, ''))=LOWER(?) OR LOWER(tg.value)=LOWER(?) OR LOWER(tg.label)=LOWER(?))")
		args.extend([group1, group1, group1])
	if filter_type and filter_value:
		if filter_type == 'genre' and ',' in str(filter_value or ''):
			for genre_value in _catalogue_filter_values(filter_value):
				where.append("""EXISTS (
					SELECT 1 FROM terms tf
					WHERE tf.item_id=i.id AND tf.term_type=?
					  AND (LOWER(tf.value)=LOWER(?) OR LOWER(tf.label)=LOWER(?))
				)""")
				args.extend([filter_type, genre_value, genre_value])
		else:
			where.append("""EXISTS (
				SELECT 1 FROM terms tf
				WHERE tf.item_id=i.id AND tf.term_type=?
				  AND (LOWER(tf.value)=LOWER(?) OR LOWER(tf.label)=LOWER(?))
			)""")
			args.extend([filter_type, filter_value, filter_value])
	if random_safe:
		safe_where, safe_args = _catalogue_random_safe_where('i')
		where.extend(safe_where)
		args.extend(safe_args)
	return where, args


def _remote_catalogue_tmdb_trending_ids(dbcon, section, media_type, filter_type='', filter_value='', group1='', group2=None, random_safe=False):
	order_ids = _catalogue_tmdb_trending_ids(media_type)
	if not order_ids:
		return []
	if group1:
		where, args = _remote_group_where_for_catalogue(section, media_type, filter_type, filter_value, group1, group2, random_safe=random_safe)
		sql = """SELECT i.tmdb_id, MIN(tg.source_order) AS term_order, MIN(i.source_order) AS item_order
			FROM items i JOIN terms tg ON tg.item_id=i.id
			WHERE %s GROUP BY i.tmdb_id""" % ' AND '.join(where)
		rows = dbcon.execute(sql, tuple(args)).fetchall()
	else:
		where_sql, args = _remote_where_filters(section, media_type, filter_type, filter_value, group1, group2, random_safe=random_safe)
		sql = """SELECT i.tmdb_id, MIN(i.source_order) AS item_order FROM items i WHERE %s GROUP BY i.tmdb_id""" % where_sql
		rows = dbcon.execute(sql, tuple(args)).fetchall()
	available = set()
	for row in rows:
		try:
			tmdb_id = str(row['tmdb_id'] or '').strip()
		except:
			tmdb_id = ''
		if tmdb_id:
			available.add(tmdb_id)
	return [tmdb_id for tmdb_id in order_ids if tmdb_id in available]


def alkopaste_catalogue_ids(media_type, params_get, page_no=1):
	try: page_no = max(1, int(page_no or 1))
	except: page_no = 1
	section = str(params_get('catalogue_section', '') or '').strip()
	media_type = str(media_type or _catalogue_media_type_for_section(section)).strip()
	if not _catalogue_remote_ready(): return [], 1
	page_size = ALKOPASTE_CATALOGUE_PAGE_SIZE
	try: full_skip = max(0, int(params_get('catalogue_full_skip', '0') or 0))
	except: full_skip = 0
	offset = ((page_no - 1) * page_size) + full_skip
	sort_mode = str(params_get('catalogue_sort', 'recent') or 'recent').strip()
	list_sort = str(params_get('list_sort', '') or '').strip()
	random_seed = str(params_get('list_random_seed', '') or '').strip()
	random_safe = str(sort_mode or '').strip().lower() == 'random' or str(list_sort or '').strip().lower() == 'random'
	filter_type = _catalogue_resolve_filter_type(str(params_get('catalogue_filter_type', '') or '').strip())
	filter_value = str(params_get('catalogue_filter_value', '') or '').strip()
	group1 = str(params_get('catalogue_group1', '') or '').strip()
	group2 = params_get('catalogue_group2')
	# La clé doit dépendre de la version distante installée. Sinon une ancienne page
	# reste servie pendant 6 h après une mise à jour manuelle réussie.
	db_marker = _catalogue_remote_meta('remote_marker', '') or _catalogue_remote_meta('generated_at', '')
	cache_key = _catalogue_cache_key('remote_ids', 'full_pages_v1', 'random_safe_v1' if random_safe else '', db_marker, section, media_type, sort_mode, list_sort, filter_type, filter_value, group1, group2 or '', page_no, full_skip, random_seed if sort_mode == 'random' or list_sort == 'random' else '')
	cache = MainCache()
	cached = cache.get(cache_key)
	if cached:
		try: return list(cached.get('ids') or []), int(cached.get('total_pages') or page_no)
		except: pass
	dbcon = None
	try:
		dbcon = _remote_db_connect()
		limit = page_size + 1
		if _catalogue_is_tmdb_trending_sort(sort_mode) and (not list_sort or list_sort in ('', 'original')):
			ordered_ids = _remote_catalogue_tmdb_trending_ids(dbcon, section, media_type, filter_type, filter_value, group1, group2, random_safe=random_safe)
			if ordered_ids:
				page_ids = ordered_ids[offset:offset + page_size]
				total_pages = page_no + 1 if len(ordered_ids) > offset + page_size else page_no
				try: cache.set(cache_key, {'ids': page_ids, 'total_pages': total_pages}, expiration=timedelta(hours=4))
				except: pass
				return page_ids, max(1, total_pages)
		if group1:
			# Les raccourcis/Listes thématiques doivent suivre l'ordre de la liste
			# elle-même, pas l'ordre global du média dans Derniers ajouts.
			# Sinon plusieurs menus finissent avec la même première page.
			section_sql, section_args = _remote_item_section_where(section, media_type, 'i')
			where = [section_sql, "tg.term_type='group'"]
			args = list(section_args)
			group_any = str(group1 or '').strip().lower() in ('__any__', '*', 'any')
			if group_any and group2:
				# Raccourcis éditoriaux remontés à la racine : on cible la sous-liste par
				# son libellé sans dépendre du nom exact du dossier parent dans la base.
				where.append("(LOWER(tg.value)=LOWER(?) OR LOWER(tg.label)=LOWER(?))")
				args.extend([group2, group2])
			elif group2:
				where.append("LOWER(COALESCE(tg.root, ''))=LOWER(?)")
				where.append("(LOWER(tg.value)=LOWER(?) OR LOWER(tg.label)=LOWER(?))")
				args.extend([group1, group2, group2])
			else:
				where.append("(LOWER(COALESCE(tg.root, ''))=LOWER(?) OR LOWER(tg.value)=LOWER(?) OR LOWER(tg.label)=LOWER(?))")
				args.extend([group1, group1, group1])
			if filter_type and filter_value:
				if filter_type == 'genre' and ',' in str(filter_value or ''):
					for genre_value in _catalogue_filter_values(filter_value):
						where.append("""EXISTS (
							SELECT 1 FROM terms tf
							WHERE tf.item_id=i.id AND tf.term_type=?
							  AND (LOWER(tf.value)=LOWER(?) OR LOWER(tf.label)=LOWER(?))
						)""")
						args.extend([filter_type, genre_value, genre_value])
				else:
					where.append("""EXISTS (
						SELECT 1 FROM terms tf
						WHERE tf.item_id=i.id AND tf.term_type=?
						  AND (LOWER(tf.value)=LOWER(?) OR LOWER(tf.label)=LOWER(?))
					)""")
					args.extend([filter_type, filter_value, filter_value])
			if random_safe:
				safe_where, safe_args = _catalogue_random_safe_where('i')
				where.extend(safe_where)
				args.extend(safe_args)
			try:
				from modules.list_sorting import normalise_list_sort_key
				normal_sort = normalise_list_sort_key(list_sort)
			except:
				normal_sort = str(list_sort or '').strip().lower() or 'original'
			rating_order = _remote_rating_order_sql(dbcon, 'i')
			if rating_order:
				rating_col, votes_col, rating_score_col = _remote_rating_columns(dbcon)
				primary_col = rating_score_col or rating_col
				rating_select = ", MAX(COALESCE(CAST(i.%s AS REAL), 0)) AS rating_order" % primary_col
				if rating_col: rating_select += ", MAX(COALESCE(CAST(i.%s AS REAL), 0)) AS vote_average_order" % rating_col
				else: rating_select += ", 0 AS vote_average_order"
				if votes_col: rating_select += ", MAX(COALESCE(CAST(i.%s AS INTEGER), 0)) AS votes_order" % votes_col
				else: rating_select += ", 0 AS votes_order"
			else:
				rating_select = ", 0 AS rating_order, 0 AS vote_average_order, 0 AS votes_order"
			popularity_expr = _remote_popularity_order_expr(dbcon, 'i')
			popularity_select = ", MAX(%s) AS popularity_order" % popularity_expr if popularity_expr else ", 0 AS popularity_order"
			date_expr = _remote_date_order_expr(dbcon, 'i')
			select_extra = "MIN(tg.source_order) AS term_order, MIN(i.source_order) AS item_order, MIN(LOWER(COALESCE(i.title, ''))) AS title_order, MAX(%s) AS date_order%s%s" % (date_expr, rating_select, popularity_select)
			order_args = []
			if normal_sort == 'random' or str(sort_mode or '').strip().lower() == 'random':
				seed = _stable_random_seed(random_seed)
				order_sql = '%s ASC' % _catalogue_random_order_expr('i')
				order_args = _catalogue_random_order_args(seed)
			elif normal_sort.startswith('title'):
				order_sql = "title_order %s, term_order ASC, item_order ASC" % ('DESC' if normal_sort.endswith('_desc') else 'ASC')
			elif normal_sort.startswith('date'):
				order_sql = "date_order %s, title_order ASC, term_order ASC" % ('DESC' if normal_sort.endswith('_desc') else 'ASC')
			elif normal_sort.startswith('rating'):
				order_sql = "rating_order %s, votes_order %s, vote_average_order %s, date_order DESC, term_order ASC, title_order ASC" % (('DESC', 'DESC', 'DESC') if normal_sort.endswith('_desc') else ('ASC', 'ASC', 'ASC')) if rating_order else "date_order DESC, term_order ASC, title_order ASC"
			elif normal_sort.startswith('popular') or normal_sort.startswith('popularity'):
				order_sql = "popularity_order %s, date_order DESC, term_order ASC, title_order ASC" % ('DESC' if normal_sort.endswith('_desc') else 'ASC') if popularity_expr else "date_order DESC, term_order ASC, title_order ASC"
			elif normal_sort.startswith('added') or normal_sort.startswith('watched'):
				# Tri contextuel explicite : « Ajout récent » doit rester l'ordre d'arrivée
				# dans la liste/base, même si le dossier catalogue a catalogue_sort=date
				# par défaut. Avant ce test arrivait trop tard, donc « Date récente »
				# et « Ajout récent » finissaient avec le même ordre.
				# source_order/term_order petits = plus récents dans la base générée.
				order_sql = "term_order %s, item_order ASC" % ('ASC' if normal_sort.endswith('_desc') else 'DESC')
			elif str(sort_mode or '').strip().lower() in ('date', 'new', 'newest', 'latest'):
				order_sql = "date_order DESC, term_order ASC, title_order ASC"
			elif str(sort_mode or '').strip().lower() == 'rated':
				if rating_order:
					order_sql = "rating_order DESC, votes_order DESC, vote_average_order DESC, date_order DESC, term_order ASC, title_order ASC"
				else:
					order_sql = "date_order DESC, term_order ASC, title_order ASC"
			elif str(sort_mode or '').strip().lower() == 'popular':
				order_sql = "popularity_order DESC, date_order DESC, term_order ASC, title_order ASC" if popularity_expr else "term_order ASC, item_order ASC"
			else:
				order_sql = "term_order ASC, item_order ASC"
			sql = """SELECT i.tmdb_id, %s FROM items i JOIN terms tg ON tg.item_id=i.id WHERE %s GROUP BY i.tmdb_id ORDER BY %s LIMIT ? OFFSET ?""" % (select_extra, ' AND '.join(where), order_sql)
			rows = dbcon.execute(sql, tuple(args + order_args + [limit, offset])).fetchall()
		else:
			where_sql, args = _remote_where_filters(section, media_type, filter_type, filter_value, group1, group2, random_safe=random_safe)
			order_sql, order_args = _remote_order_clause(sort_mode, list_sort, random_seed, dbcon)
			sql = """SELECT i.tmdb_id FROM items i WHERE %s ORDER BY %s LIMIT ? OFFSET ?""" % (where_sql, order_sql)
			rows = dbcon.execute(sql, tuple(args + order_args + [limit, offset])).fetchall()
		ids = [str(row['tmdb_id']) for row in rows[:page_size] if row['tmdb_id']]
		total_pages = page_no + 1 if len(rows) > page_size else page_no
		try: cache.set(cache_key, {'ids': ids, 'total_pages': total_pages}, expiration=timedelta(hours=6))
		except: pass
		return ids, max(1, total_pages)
	except Exception as e:
		try: kodi_utils.logger('Catalogue alkoPaste distant', 'Lecture IDs impossible | section=%s | erreur=%s' % (section, type(e).__name__))
		except: pass
		return [], 1
	finally:
		try:
			if dbcon: dbcon.close()
		except: pass


def alkopaste_catalogue_values(section, value_type, media_type=''):
	requested_value_type = str(value_type or 'genre').strip()
	value_type = _catalogue_resolve_filter_type(requested_value_type)
	media_type = str(media_type or _catalogue_media_type_for_section(section)).strip()
	if value_type == 'network' and media_type != 'serie': return []
	if not _catalogue_remote_ready(): return []
	dbcon = None
	try:
		dbcon = _remote_db_connect()
		section_sql, section_args = _remote_facet_section_where(section, media_type)
		rows = dbcon.execute("""SELECT value, label, item_count FROM facets WHERE %s AND facet_type=? ORDER BY sort_label ASC""" % section_sql, tuple(section_args + [value_type])).fetchall()
		items = []
		network_items = {}
		for row in rows:
			value = _clean_list_value(row['value'])
			label = _clean_list_value(row['label'])
			if not value or not label: continue
			if value_type == 'network':
				label = _canonical_network_label(label)
				value, label = _network_value_label(value if ':' in value else label)
				if label.lower() in ('tous', 'tout', 'all'): continue
				network_id = _network_id_from_value(value)
				key = ('id:%s' % network_id) if network_id else ('label:%s' % _network_alias_key(label))
				current = network_items.get(key)
				count = int(row['item_count'] or 0)
				if current:
					current['count'] = int(current.get('count') or 0) + count
					if network_id and ':' not in str(current.get('value') or ''):
						current['value'] = value
				else:
					network_items[key] = {'name': label, 'value': value, 'count': count}
				continue
			if value_type == 'genre':
				label = _catalogue_genre_label(value, media_type) or label
				if not label: continue
				items.append({'name': label, 'value': value, 'count': int(row['item_count'] or 0), 'icon': _catalogue_genre_icon(value, label)})
			else:
				items.append({'name': label, 'value': value, 'count': int(row['item_count'] or 0)})
		if value_type == 'network':
			items.extend(network_items.values())
		if value_type == 'year': return sorted(items, key=lambda item: item.get('name', ''), reverse=True)
		if value_type.startswith('certification_'):
			return sorted(items, key=lambda item: _catalogue_certification_sort_key(item.get('value'), item.get('name')))
		return sorted(items, key=lambda item: item.get('name', '').lower())
	except Exception as e:
		try: kodi_utils.logger('Catalogue alkoPaste distant', 'Valeurs impossibles | section=%s | type=%s | erreur=%s' % (section, value_type, type(e).__name__))
		except: pass
		return []
	finally:
		try:
			if dbcon: dbcon.close()
		except: pass


def alkopaste_catalogue_theme_roots(section, media_type=''):
	media_type = str(media_type or _catalogue_media_type_for_section(section)).strip()
	if not _catalogue_remote_ready(): return []
	dbcon = None
	try:
		dbcon = _remote_db_connect()
		section_sql, section_args = _remote_facet_section_where(section, media_type)
		rows = dbcon.execute("""SELECT root, SUM(item_count) AS item_count, MAX(CASE WHEN value <> root THEN 1 ELSE 0 END) AS has_children FROM facets WHERE %s AND facet_type='group' AND COALESCE(root, '') <> '' GROUP BY root ORDER BY LOWER(root) ASC""" % section_sql, tuple(section_args)).fetchall()
		items = []
		for row in rows:
			root = _clean_list_value(row['root'])
			if not root: continue
			items.append({'name': root, 'value': root, 'count': int(row['item_count'] or 0), 'has_children': bool(row['has_children'])})
		return items
	except Exception as e:
		try: kodi_utils.logger('Catalogue alkoPaste distant', 'Racines thèmes impossibles | section=%s | erreur=%s' % (section, type(e).__name__))
		except: pass
		return []
	finally:
		try:
			if dbcon: dbcon.close()
		except: pass


def alkopaste_catalogue_theme_children(section, group1, media_type=''):
	media_type = str(media_type or _catalogue_media_type_for_section(section)).strip()
	group1 = _clean_list_value(group1)
	if not _catalogue_remote_ready() or not group1: return []
	dbcon = None
	try:
		dbcon = _remote_db_connect()
		section_sql, section_args = _remote_facet_section_where(section, media_type)
		rows = dbcon.execute("""SELECT value, label, item_count FROM facets WHERE %s AND facet_type='group' AND LOWER(root)=LOWER(?) AND value <> root ORDER BY sort_label ASC""" % section_sql, tuple(section_args + [group1])).fetchall()
		return [{'name': _clean_list_value(row['label']), 'value': _clean_list_value(row['value']), 'count': int(row['item_count'] or 0)} for row in rows if _clean_list_value(row['label']) and _clean_list_value(row['value'])]
	except Exception as e:
		try: kodi_utils.logger('Catalogue alkoPaste distant', 'Sous-thèmes impossibles | section=%s | erreur=%s' % (section, type(e).__name__))
		except: pass
		return []
	finally:
		try:
			if dbcon: dbcon.close()
		except: pass


def alkopaste_catalogue_database_status():
	return {'ready': _catalogue_remote_ready(), 'catalogue_total': _catalogue_remote_count(), 'last_sync': _safe_int(_catalogue_remote_meta('last_sync', '0'), 0) or 0}


def _ensure_catalogue_ready(allow_sync=False):
	return _catalogue_remote_ready()


def sync_alkopaste_catalogue_database(force=False, rebuild=False):
	return _download_remote_catalogue_database(force=bool(force or rebuild))


def sync_alkopaste_catalogue_database_manual():
	try: kodi_utils.notification('Téléchargement du Catalogue alkoPaste...')
	except: pass
	result = sync_alkopaste_catalogue_database(force=True, rebuild=True)
	try:
		if result.get('ok'):
			generated = result.get('generated_at') or _catalogue_remote_meta('generated_at', '')
			if result.get('skipped'):
				text = 'Catalogue alkoPaste déjà disponible : %s médias.' % (result.get('catalogue', 0) or 0)
			else:
				text = 'Catalogue alkoPaste retéléchargé depuis le serveur : %s médias.' % (result.get('catalogue', 0) or 0)
			if generated:
				text += '\nGénéré : %s' % generated
			text += '\nAucun redémarrage nécessaire.'
			kodi_utils.ok_dialog(heading='alkoFlix', text=text, top_space=True)
			try: kodi_utils.container_refresh()
			except: pass
		else:
			kodi_utils.ok_dialog(heading='alkoFlix', text='Le Catalogue alkoPaste n’a pas pu être téléchargé depuis le serveur. Raison : %s' % (result.get('reason') or 'erreur inconnue'), top_space=True)
	except: pass
	return result


class source(BaseHosterSource):
	provider_key = 'alkopaste'
	provider_name = 'ALKO'
	priority = 0
	pack_capable = False
	hasMovies = True
	hasEpisodes = True

	def base_url(self):
		# Source interne publique : aucun champ URL dans les settings.
		return ALKOPASTE_BASE_URL

	def _make_raw_result(self, data, url, res_name, paste_title='', paste_year=None, size=0):
		res_name = clean_text(res_name)
		paste_title = clean_text(paste_title) or clean_text(data.get('tvshowtitle') or data.get('title'))
		paste_year = paste_year or data.get('year') or ''
		quality = normalize_quality(res_name)
		language = _release_language(res_name)
		size = _size_gb(size)
		if data.get('tvshowtitle'):
			display = '%s S%02dE%02d %s' % (paste_title, int(data.get('season') or 0), int(data.get('episode') or 0), res_name)
		else:
			display = '%s %s %s' % (paste_title, paste_year, res_name)
		display = clean_text(display)
		return {
			'link': url,
			'hoster': 'alldebrid' if hoster_key('', url) == 'alldebrid' else '',
			'quality': quality,
			'language': language,
			'raw_language': res_name,
			'display_name': display,
			'size': size
		}

	def _parse_matching_lines(self, content, data, wanted):
		results = []
		seen = set()
		try:
			lines = (content or '').splitlines()
			if not lines: return []
			base_url = _base_url_from_header(lines[0])
			target_tmdb_ids = _target_tmdb_ids(data)
			if not target_tmdb_ids: return []
			target_season = _safe_int(data.get('season'), None)
			target_episode = _safe_int(data.get('episode'), None)
			rows = []
			for line in lines[1:]:
				line = (line or '').strip()
				if not line: continue
				parts = line.split(';')
				if not _row_urls_raw(parts): continue
				cat = _normalize_cat(parts[COL_CAT].strip())
				# La colonne CAT du paste final est la référence :
				# film = film, serie/anime = série. Les index peuvent être mixtes.
				if cat != wanted: continue
				tmdb_id = parts[COL_TMDB].strip()
				if tmdb_id in target_tmdb_ids:
					rows.append(parts)
			for parts in rows:
				paste_title = parts[COL_TITLE].strip()
				paste_year = _safe_int(parts[COL_YEAR].strip(), None)
				res_raw = parts[COL_RES].strip()
				size_raw = _row_size_raw(parts)
				urls_raw = _row_urls_raw(parts)
				if wanted == 'serie':
					row_season = _safe_int(parts[COL_SAISON].strip(), None)
					season_values = _series_query_seasons(data, target_season)
					if target_season is not None and row_season is not None and season_values and row_season not in season_values: continue
					series_items = _series_urls(urls_raw)
					size_map = _series_size_map(size_raw)
					wanted_eps = _wanted_episodes_for_row(data, row_season, target_episode)
					for idx, (ep_num, suffix) in enumerate(series_items):
						if target_episode is not None and int(ep_num) not in wanted_eps: continue
						url = _full_url(base_url, suffix)
						if not url or url in seen: continue
						seen.add(url)
						size = size_map.get(int(ep_num), _size_at_index(size_raw, idx))
						results.append(self._make_raw_result(_display_data_for_episode(data, row_season, int(ep_num)), url, res_raw, paste_title, paste_year, size))
				else:
					res_list = _literal_list(res_raw)
					urls_list = _literal_list(urls_raw)
					if not res_list or not urls_list: continue
					for idx, (res_name, suffix) in enumerate(zip(res_list, urls_list)):
						url = _full_url(base_url, suffix)
						if not url or url in seen: continue
						seen.add(url)
						size = _size_at_index(size_raw, idx)
						results.append(self._make_raw_result(data, url, res_name, paste_title, paste_year, size))
		except Exception as e:
			try: kodi_utils.logger('alkoPaste', 'Parsing impossible | erreur=%s' % type(e).__name__)
			except: pass
		return results

	def _search_raw_direct(self, data, wanted):
		codes, _wanted = _code_entries_for_media('episode' if data.get('tvshowtitle') else 'movie')
		if not codes: return []
		results = []
		seen_links = set()
		for code in codes:
			url = _code_url(code)
			content = _fetch_text(url)
			if not content: continue
			for item in self._parse_matching_lines(content, data, wanted):
				link = item.get('link')
				if not link or link in seen_links: continue
				seen_links.add(link)
				results.append(item)
		return results

	def search(self, data):
		# Ne jamais consulter ni préparer la base de liens ALKO lorsque la source
		# est désactivée. Le Catalogue alkoPaste est totalement indépendant.
		if not _alkopaste_source_enabled(): return []
		wanted = 'serie' if data.get('tvshowtitle') else 'film'
		if not _target_tmdb_ids(data): return []
		# La recherche ALKO doit rester locale et rapide.
		# Si la base SQLite est prête, elle devient la source de vérité :
		# - résultat trouvé : on retourne les liens;
		# - aucun résultat : on retourne immédiatement [] sans reparcourir tous les raws.
		# Ancien comportement problématique : après une recherche DB vide, l'addon lançait
		# quand même le fallback raw direct. Cela donnait une impression de double recherche
		# et bloquait longtemps quand ALKO n'avait aucun lien pour le média demandé.
		if _db_ready():
			return _query_database(data, wanted)
		# ALKO reste DB-only, mais si la base locale n'est pas prête on tente
		# une récupération légère de la base distante au lieu de retourner zéro sans vérifier.
		# Aucun fallback raw direct : on ne reparcourt pas les pastes côté Kodi.
		try:
			_sync_alkopaste_source_database(force=False, rebuild=False)
		except Exception:
			pass
		if _db_ready():
			return _query_database(data, wanted)
		return []
