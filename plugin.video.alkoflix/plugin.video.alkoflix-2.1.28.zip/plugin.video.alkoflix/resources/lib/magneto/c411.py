# -*- coding: utf-8 -*-
# plugin.video.alkoflix
# resources/lib/magneto/c411.py

from modules.private_torznab import PrivateTorznabSource


class source(PrivateTorznabSource):
	provider_key = 'c411'
	provider_name = 'C411'
	api_setting = 'private.c411.api_key'
	base_url = 'https://c411.org/api'
	response_mode = 'xml'
	auth_mode = 'query_apikey'
	# C411 utilise une recherche stricte par ID : si un ID IMDb/TMDb est fourni,
	# la recherche se fait uniquement par ID. Aucun fallback texte ne doit être lancé
	# après une recherche par ID, afin d'éviter les remakes/suites mal associés.
	prefer_query_search = False
	prefer_id_then_query_search = False
	# Pour la recherche Torznab, C411 répond au paramètre apikey. Le Bearer concerne
	# surtout les endpoints d'upload/catégories et provoque un 401 en recherche.
	auth_modes = ('query_apikey',)
	# C411 peut retourner des titres de films localisés/alternatifs : on fait
	# confiance aux résultats API seulement pour les films recherchés par ID.
	# Les épisodes et packs de séries restent validés strictement par saison/épisode.
	trust_api_results = True
	priority = 2
