root_list = [
	{'name': 'Catalogue TMDb', 'iconImage': 'special://home/addons/plugin.video.alkoflix/resources/skins/Default/Icones de menu/tmdb.png', 'mode': 'navigator.main', 'action': 'TMDbCatalogueList'},
	{'name': 'Personnes', 'iconImage': 'user.png', 'mode': 'navigator.main', 'action': 'PeopleList'},
	{'name': 32450, 'iconImage': 'search.png', 'mode': 'navigator.search'},
	{'name': 32453, 'iconImage': 'favourites.png', 'mode': 'navigator.favourites'},
	{'name': 'Vos suivis de lecture', 'iconImage': 'watched.png', 'mode': 'navigator.in_progress'},
	{'name': 'Service(s)', 'iconImage': 'cle.png', 'mode': 'navigator.my_content'},
	{'name': 'Débrideur(s)', 'iconImage': 'premium.png', 'mode': 'navigator.premium'},
#	{'name': 32456, 'iconImage': 'tools.png', 'mode': 'navigator.tools'},
	{'name': 32456, 'iconImage': 'settings.png', 'mode': 'navigator.settings'}
]

# Les routes historiques restent strictement identiques. Le nouveau dossier
# Catalogue TMDb ne fait qu'ajouter un niveau visuel devant les six menus natifs.
# Les widgets de skins et raccourcis personnalisés qui appellent directement
# MovieList/TVShowList/etc. continuent donc de fonctionner sans conversion d'URL.
tmdb_catalogue_list = [
	{'name': 32028, 'iconImage': 'movies.png', 'mode': 'navigator.main', 'action': 'MovieList'},
	{'name': 32029, 'iconImage': 'tv.png', 'mode': 'navigator.main', 'action': 'TVShowList'},
	{'name': 'Docus & Télé', 'iconImage': 'genre_documentary.png', 'mode': 'navigator.main', 'action': 'DocumentaryList'},
	{'name': 'Famille', 'iconImage': 'genre_family.png', 'mode': 'navigator.main', 'action': 'FamilyList'},
	{'name': 'Dessins animés', 'iconImage': 'genre_animation.png', 'mode': 'navigator.main', 'action': 'AnimationList'},
	{'name': 'Animés japonais', 'iconImage': 'anime.png', 'mode': 'navigator.main', 'action': 'AnimeList'},
	{'name': 'Personnes', 'iconImage': 'user.png', 'mode': 'navigator.main', 'action': 'PeopleList'},
	{'name': 32450, 'iconImage': 'search.png', 'mode': 'navigator.search'},
	{'name': 32453, 'iconImage': 'favourites.png', 'mode': 'navigator.favourites'},
	{'name': 'Vos suivis de lecture', 'iconImage': 'watched.png', 'mode': 'navigator.tmdb_catalogue_progress'},
	{'name': 32474, 'iconImage': 'because_you_watched.png', 'mode': 'navigator.because_you_watched_combined', 'recommendation_group': 'all'}
]

movie_list = [
	{'name': 'Populaires', 'iconImage': 'popular.png', 'mode': 'build_movie_list', 'action': 'tmdb_movies_popular'},
	{'name': 'Tendances', 'iconImage': 'trending.png', 'mode': 'build_movie_list', 'action': 'tmdb_movies_trending'},
	{'name': 'Films aléatoires', 'iconImage': 'shuffle.png', 'mode': 'build_movie_list', 'action': 'tmdb_movies_random'},
	{'name': 'Les mieux notés', 'iconImage': 'most_voted.png', 'mode': 'build_movie_list', 'action': 'tmdb_movies_top_rated'},
	{'name': 'Nouveautés numériques', 'iconImage': 'dvd.png', 'mode': 'build_movie_list', 'action': 'tmdb_movies_latest_releases'},
	{'name': 'Sorties cinéma récentes', 'iconImage': 'fresh.png', 'mode': 'build_movie_list', 'action': 'tmdb_movies_premieres'},
	{'name': 'Blockbusters', 'iconImage': 'most_watched.png', 'mode': 'build_movie_list', 'action': 'tmdb_movies_blockbusters'},
	{'name': 'Sagas', 'iconImage': 'sets.png', 'mode': 'navigator.main', 'action': 'SagasMovieList'},
	{'name': 'Favoris (Films)', 'iconImage': 'favourites.png', 'mode': 'build_movie_list', 'action': 'favourites_movies'},
	{'name': 'Par genre', 'iconImage': 'genres.png', 'mode': 'navigator.genres', 'menu_type': 'movie'},
	{'name': 'Par année', 'iconImage': 'calender.png', 'mode': 'catalogue.native_years', 'native_type': 'movie'},
	{'name': 'Par langue', 'iconImage': 'languages.png', 'mode': 'catalogue.native_languages', 'native_type': 'movie'},
	{'name': 'Par plateforme', 'iconImage': 'netflix.png', 'mode': 'catalogue.native_providers', 'native_type': 'movie'},
	{'name': 'Amazon Channels', 'iconImage': 'amazon.png', 'mode': 'catalogue.amazon_channels', 'native_type': 'movie'},
	{'name': 32474, 'iconImage': 'because_you_watched.png', 'mode': 'navigator.because_you_watched', 'menu_type': 'movie', 'recommendation_group': 'movie_root'},
	{'name': 'Vos suivis de lecture', 'iconImage': 'watched.png', 'mode': 'navigator.viewing_movies', 'progress_group': 'movie_root'}
]

tvshow_list = [
	{'name': 'Populaires', 'iconImage': 'popular.png', 'mode': 'build_tvshow_list', 'action': 'tmdb_tv_popular'},
	{'name': 'Tendances', 'iconImage': 'trending.png', 'mode': 'build_tvshow_list', 'action': 'tmdb_tv_trending'},
	{'name': 'Séries aléatoires', 'iconImage': 'shuffle.png', 'mode': 'build_tvshow_list', 'action': 'tmdb_tv_random'},
	{'name': 'Les mieux notées', 'iconImage': 'most_voted.png', 'mode': 'build_tvshow_list', 'action': 'tmdb_tv_top_rated'},
	{'name': 'En diffusion cette semaine', 'iconImage': 'wifi.png', 'mode': 'build_tvshow_list', 'action': 'tmdb_tv_on_the_air'},
	{'name': 'Nouveautés', 'iconImage': 'dvd.png', 'mode': 'build_tvshow_list', 'action': 'tmdb_tv_premieres'},
	{'name': 'Favoris (Séries)', 'iconImage': 'favourites.png', 'mode': 'navigator.favourites_series', 'fav_group': 'root'},
	{'name': 'Par genre', 'iconImage': 'genres.png', 'mode': 'navigator.genres', 'menu_type': 'tvshow'},
	{'name': 'Par année', 'iconImage': 'calender.png', 'mode': 'catalogue.native_years', 'native_type': 'series'},
	{'name': 'Par langue', 'iconImage': 'languages.png', 'mode': 'catalogue.native_languages', 'native_type': 'series'},
	{'name': 'Par plateforme', 'iconImage': 'netflix.png', 'mode': 'catalogue.native_providers', 'native_type': 'series'},
	{'name': 'Diffuseurs', 'iconImage': 'networks.png', 'mode': 'catalogue.native_broadcasters'},
	{'name': 'Amazon Channels', 'iconImage': 'amazon.png', 'mode': 'catalogue.amazon_channels', 'native_type': 'series'},
	{'name': 32474, 'iconImage': 'because_you_watched.png', 'mode': 'navigator.because_you_watched', 'menu_type': 'tvshow', 'recommendation_group': 'tv_root'},
	{'name': 'Vos suivis de lecture', 'iconImage': 'watched.png', 'mode': 'navigator.viewing_tvshows', 'progress_group': 'tv_root'}
]

family_list = [
	{'name': 'Films familiaux', 'iconImage': 'movies.png', 'mode': 'navigator.main', 'action': 'FamilyMovieList'},
	{'name': 'Séries familiales', 'iconImage': 'tv.png', 'mode': 'navigator.main', 'action': 'FamilySeriesList'},
	{'name': 32474, 'iconImage': 'because_you_watched.png', 'mode': 'navigator.because_you_watched_combined', 'recommendation_group': 'family'},
	{'name': 'Vos suivis de lecture', 'iconImage': 'watched.png', 'mode': 'navigator.viewing_combined', 'progress_group': 'family'},
	{'name': 'Favoris', 'iconImage': 'favourites.png', 'mode': 'navigator.favourites_family'}
]

anime_list = [
	{'name': 'Séries animées japonaises', 'iconImage': 'tv.png', 'mode': 'navigator.main', 'action': 'AnimeSeriesList'},
	{'name': 'Films animés japonais', 'iconImage': 'movies.png', 'mode': 'navigator.main', 'action': 'AnimeMovieList'},
	{'name': 32474, 'iconImage': 'because_you_watched.png', 'mode': 'navigator.because_you_watched_combined', 'recommendation_group': 'anime'},
	{'name': 'Vos suivis de lecture', 'iconImage': 'watched.png', 'mode': 'navigator.viewing_combined', 'progress_group': 'anime'},
	{'name': 'Favoris', 'iconImage': 'favourites.png', 'mode': 'navigator.favourites_anime'}
]


animation_list = [
	{'name': 'Films d’animation', 'iconImage': 'movies.png', 'mode': 'navigator.main', 'action': 'AnimationMovieList'},
	{'name': 'Séries d’animation', 'iconImage': 'tv.png', 'mode': 'navigator.main', 'action': 'AnimationSeriesList'},
	{'name': 32474, 'iconImage': 'because_you_watched.png', 'mode': 'navigator.because_you_watched_combined', 'recommendation_group': 'animation'},
	{'name': 'Vos suivis de lecture', 'iconImage': 'watched.png', 'mode': 'navigator.viewing_combined', 'progress_group': 'animation'},
	{'name': 'Favoris', 'iconImage': 'favourites.png', 'mode': 'navigator.favourites_animation'}
]

documentary_list = [
	{'name': 'Films', 'iconImage': 'movies.png', 'mode': 'navigator.main', 'action': 'DocumentaryMovieRootList'},
	{'name': 'Séries', 'iconImage': 'tv.png', 'mode': 'navigator.main', 'action': 'DocumentarySeriesRootList'},
	{'name': 32474, 'iconImage': 'because_you_watched.png', 'mode': 'navigator.because_you_watched_combined', 'recommendation_group': 'documentary'},
	{'name': 'Vos suivis de lecture', 'iconImage': 'watched.png', 'mode': 'navigator.viewing_combined', 'progress_group': 'documentary'},
	{'name': 'Favoris', 'iconImage': 'favourites.png', 'mode': 'navigator.favourites_documentary'},
]

# Sous-menus éditables : les dossiers générés par le catalogue passent ici par
# navigator.main afin de proposer les mêmes options Déplacer / Retirer / Restaurer
# que les menus principaux.
people_list = [
	{'name': 'Recherche', 'iconImage': 'search.png', 'mode': 'search_history', 'action': 'people'},
	{'name': 'Personnes populaires dans les films', 'iconImage': 'movies.png', 'mode': 'people.results', 'action': 'popular_movies'},
	{'name': 'Personnes populaires dans les séries', 'iconImage': 'tv.png', 'mode': 'people.results', 'action': 'popular_tvshows'},
	{'name': 'Favoris', 'iconImage': 'favourites.png', 'mode': 'people.favourites'}
]

def _sagas_list(saga_type):
	fav_type = 'collection_family' if saga_type == 'family' else 'collection_animation' if saga_type == 'animation' else 'collection_anime' if saga_type == 'anime' else 'collection'
	return [
		{'name': 'Recherche', 'iconImage': 'search.png', 'mode': 'search_history', 'action': 'tmdb_collections', 'saga_type': saga_type, 'fav_type': fav_type},
		{'name': 'Sagas de films', 'iconImage': 'sets.png', 'mode': 'build_movie_list', 'action': 'tmdb_movies_curated_collections', 'saga_type': saga_type, 'fav_type': fav_type},
		{'name': 'Favoris', 'iconImage': 'favourites.png', 'mode': 'catalogue.sagas_favourites', 'saga_type': saga_type, 'fav_type': fav_type}
	]

def _family_section_list(family_type, include_sagas=False, include_kids_networks=False):
	is_movie = family_type.startswith('movie')
	items = [
		{'name': 'Populaires', 'iconImage': 'popular.png', 'mode': 'build_movie_list' if is_movie else 'build_tvshow_list', 'action': 'tmdb_movies_family_popular' if family_type == 'movie_family' else 'tmdb_movies_family_animation_popular' if family_type == 'movie_animation' else 'tmdb_tv_family_popular' if family_type == 'series_family' else 'tmdb_tv_family_animation_popular', 'family_type': family_type},
		{'name': 'Films aléatoires' if is_movie else 'Séries aléatoires', 'iconImage': 'shuffle.png', 'mode': 'build_movie_list' if is_movie else 'build_tvshow_list', 'action': 'tmdb_movies_family_random' if family_type == 'movie_family' else 'tmdb_movies_family_animation_random' if family_type == 'movie_animation' else 'tmdb_tv_family_random' if family_type == 'series_family' else 'tmdb_tv_family_animation_random', 'family_type': family_type},
	]
	if not is_movie:
		items.append({'name': 'En diffusion cette semaine', 'iconImage': 'telecommande.png' if family_type == 'series_animation' else 'wifi.png', 'mode': 'build_tvshow_list', 'action': 'tmdb_tv_family_airing_this_week' if family_type == 'series_family' else 'tmdb_tv_family_animation_airing_this_week', 'family_type': family_type})
	if family_type == 'movie_animation':
		items.extend([
			{'name': 'Collection Pixar', 'iconImage': 'pixar.png', 'mode': 'build_movie_list', 'action': 'tmdb_movies_company', 'company_id': '3', 'family_type': 'movie_animation', 'fav_type': 'movie_animation'},
		])
	if include_sagas:
		items.append({'name': 'Sagas', 'iconImage': 'sets.png', 'mode': 'navigator.main', 'action': 'SagasFamilyList' if family_type == 'movie_family' else 'SagasAnimationList'})
	items.extend([
		{'name': 'Par genre', 'iconImage': 'genres.png', 'mode': 'catalogue.family_genres', 'family_type': family_type},
		{'name': 'Par année', 'iconImage': 'calender.png', 'mode': 'catalogue.family_years', 'family_type': family_type},
		{'name': 'Par plateforme', 'iconImage': 'netflix.png', 'mode': 'catalogue.family_providers', 'family_type': family_type},
	])
	if include_kids_networks:
		items.append({'name': 'Chaînes jeunesse', 'iconImage': 'networks.png', 'mode': 'catalogue.family_kids_networks'})
	if family_type not in ('movie_animation', 'series_animation'):
		items.append({'name': 'Amazon Channels famille & Enfants', 'iconImage': 'amazon.png', 'mode': 'catalogue.family_amazon_channels', 'family_type': family_type})
	# Les recommandations personnelles utilisent le même contexte éditorial que le
	# dossier de suivi : Famille reste Famille, Animation reste Animation.
	items.append({
		'name': 32474, 'iconImage': 'because_you_watched.png',
		'mode': 'navigator.because_you_watched', 'menu_type': 'movie' if is_movie else 'tvshow',
		'recommendation_group': family_type
	})
	# Même modèle que les sections alkoPaste : chaque sous-menu Films/Séries possède
	# son propre dossier de suivi, filtré strictement sur le contexte courant.
	items.append({
		'name': 'Vos suivis de lecture', 'iconImage': 'watched.png',
		'mode': 'navigator.viewing_movies' if is_movie else 'navigator.viewing_tvshows',
		'progress_group': family_type
	})
	return items

def _documentary_section_list(documentary_type, is_series=False):
	mode = 'build_tvshow_list' if is_series else 'build_movie_list'
	actions = {
		'movie_documentary': ('tmdb_movies_documentary_popular', 'tmdb_movies_documentary_random', None, None, 'tmdb_movies_documentary_genres', 'tmdb_movies_documentary_year', 'tmdb_movies_documentary_language', 'tmdb_movies_documentary_watch_provider', None),
		'movie_tv_movie': ('tmdb_movies_tv_movie_popular', 'tmdb_movies_tv_movie_random', None, None, 'tmdb_movies_tv_movie_genres', 'tmdb_movies_tv_movie_year', 'tmdb_movies_tv_movie_language', 'tmdb_movies_tv_movie_watch_provider', None),
		'series_documentary': ('tmdb_tv_documentary_popular', 'tmdb_tv_documentary_random', 'tmdb_tv_documentary_trending', 'tmdb_tv_documentary_airing_this_week', 'tmdb_tv_documentary_genres', 'tmdb_tv_documentary_year', 'tmdb_tv_documentary_language', 'tmdb_tv_documentary_watch_provider', 'tmdb_tv_documentary_networks'),
		'series_reality': ('tmdb_tv_reality_popular', 'tmdb_tv_reality_random', 'tmdb_tv_reality_trending', 'tmdb_tv_reality_airing_this_week', 'tmdb_tv_reality_genres', 'tmdb_tv_reality_year', 'tmdb_tv_reality_language', 'tmdb_tv_reality_watch_provider', 'tmdb_tv_reality_networks'),
		'series_talkshow': ('tmdb_tv_talkshow_popular', 'tmdb_tv_talkshow_random', 'tmdb_tv_talkshow_trending', 'tmdb_tv_talkshow_airing_this_week', 'tmdb_tv_talkshow_genres', 'tmdb_tv_talkshow_year', 'tmdb_tv_talkshow_language', 'tmdb_tv_talkshow_watch_provider', 'tmdb_tv_talkshow_networks'),
		'series_news': ('tmdb_tv_news_popular', 'tmdb_tv_news_random', 'tmdb_tv_news_trending', 'tmdb_tv_news_airing_this_week', 'tmdb_tv_news_genres', 'tmdb_tv_news_year', 'tmdb_tv_news_language', 'tmdb_tv_news_watch_provider', 'tmdb_tv_news_networks')
	}[documentary_type]
	popular, random, trending, airing_week, genre, year, language, provider, network = actions
	items = [
		{'name': 'Populaires', 'iconImage': 'popular.png', 'mode': mode, 'action': popular, 'documentary_type': documentary_type},
		{'name': 'Séries aléatoires' if is_series else 'Films aléatoires', 'iconImage': 'shuffle.png', 'mode': mode, 'action': random, 'documentary_type': documentary_type},
		{'name': 'Par genre', 'iconImage': 'genres.png', 'mode': 'catalogue.documentary_genres', 'documentary_type': documentary_type}
	]
	if trending: items.append({'name': 'Tendances', 'iconImage': 'trending.png', 'mode': mode, 'action': trending, 'documentary_type': documentary_type})
	if airing_week: items.append({'name': 'En diffusion cette semaine', 'iconImage': 'wifi.png', 'mode': mode, 'action': airing_week, 'documentary_type': documentary_type})
	items.extend([
		{'name': 'Par année', 'iconImage': 'calender.png', 'mode': 'catalogue.documentary_years', 'documentary_type': documentary_type},
		{'name': 'Par langue', 'iconImage': 'languages.png', 'mode': 'catalogue.documentary_languages', 'documentary_type': documentary_type},
		{'name': 'Par plateforme', 'iconImage': 'netflix.png', 'mode': 'catalogue.documentary_providers', 'documentary_type': documentary_type},
	])
	if network: items.append({'name': 'Diffuseurs', 'iconImage': 'networks.png', 'mode': 'catalogue.documentary_broadcasters', 'documentary_type': documentary_type})
	items.append({'name': 'Amazon Channels', 'iconImage': 'amazon.png', 'mode': 'catalogue.documentary_amazon_channels', 'documentary_type': documentary_type})
	items.append({
		'name': 32474, 'iconImage': 'because_you_watched.png',
		'mode': 'navigator.because_you_watched', 'menu_type': 'tvshow' if is_series else 'movie',
		'recommendation_group': documentary_type
	})
	items.append({
		'name': 'Vos suivis de lecture', 'iconImage': 'watched.png',
		'mode': 'navigator.viewing_tvshows' if is_series else 'navigator.viewing_movies',
		'progress_group': documentary_type
	})
	return items

def _anime_section_list(native_type):
	if native_type == 'anime_movie':
		return [
			{'name': 'Les plus vus', 'iconImage': 'watched.png', 'mode': 'build_movie_list', 'action': 'trakt_moviesanime_most_watched'},
			{'name': 'Populaire', 'iconImage': 'popular.png', 'mode': 'build_movie_list', 'action': 'tmdb_moviesanime_popular'},
			{'name': 'Aléatoires', 'iconImage': 'shuffle.png', 'mode': 'build_movie_list', 'action': 'tmdb_moviesanime_random'},
			{'name': 'Nouveautés', 'iconImage': 'dvd.png', 'mode': 'build_movie_list', 'action': 'tmdb_moviesanime_latest_releases'},
			{'name': 'Studio Ghibli', 'iconImage': 'ghibli.png', 'mode': 'build_movie_list', 'action': 'tmdb_movies_company', 'company_id': '10342', 'native_type': 'anime_movie', 'fav_type': 'anime_movie'},
			{'name': 'Sagas', 'iconImage': 'sets.png', 'mode': 'navigator.main', 'action': 'SagasAnimeList'},
			{'name': 'Genres', 'iconImage': 'genres.png', 'mode': 'catalogue.native_genres', 'native_type': 'anime_movie'},
			{'name': 'Années', 'iconImage': 'calender.png', 'mode': 'catalogue.native_years', 'native_type': 'anime_movie'},
			{'name': 'Par langue', 'iconImage': 'languages.png', 'mode': 'catalogue.native_languages', 'native_type': 'anime_movie'},
			{'name': 'Par plateforme', 'iconImage': 'netflix.png', 'mode': 'catalogue.native_providers', 'native_type': 'anime_movie'},
			{'name': 32474, 'iconImage': 'because_you_watched.png', 'mode': 'navigator.because_you_watched', 'menu_type': 'movie', 'recommendation_group': 'anime_movie'},
			{'name': 'Vos suivis de lecture', 'iconImage': 'watched.png', 'mode': 'navigator.viewing_movies', 'progress_group': 'anime_movie'},
		]
	return [
		{'name': 'Calendrier', 'iconImage': 'calender.png', 'mode': 'build_anime_calendar'},
		{'name': 'Tendances', 'iconImage': 'trending.png', 'mode': 'build_tvshow_list', 'action': 'trakt_tvanime_trending'},
		{'name': 'Les plus vues', 'iconImage': 'watched.png', 'mode': 'build_tvshow_list', 'action': 'trakt_tvanime_most_watched'},
		{'name': 'Populaire', 'iconImage': 'popular.png', 'mode': 'build_tvshow_list', 'action': 'tmdb_tvanime_popular'},
		{'name': 'Aléatoires', 'iconImage': 'shuffle.png', 'mode': 'build_tvshow_list', 'action': 'tmdb_tvanime_random'},
		{'name': 'Nouveautés', 'iconImage': 'fresh.png', 'mode': 'build_tvshow_list', 'action': 'tmdb_tvanime_premieres'},
		{'name': 'Genres', 'iconImage': 'genres.png', 'mode': 'catalogue.native_genres', 'native_type': 'anime_series'},
		{'name': 'Années', 'iconImage': 'calender.png', 'mode': 'catalogue.native_years', 'native_type': 'anime_series'},
		{'name': 'Par langue', 'iconImage': 'languages.png', 'mode': 'catalogue.native_languages', 'native_type': 'anime_series'},
		{'name': 'Par plateforme', 'iconImage': 'netflix.png', 'mode': 'catalogue.native_providers', 'native_type': 'anime_series'},
		{'name': 32474, 'iconImage': 'because_you_watched.png', 'mode': 'navigator.because_you_watched', 'menu_type': 'tvshow', 'recommendation_group': 'anime_series'},
		{'name': 'Vos suivis de lecture', 'iconImage': 'watched.png', 'mode': 'navigator.viewing_tvshows', 'progress_group': 'anime_series'},
	]

family_movie_list = _family_section_list('movie_family', include_sagas=True)
family_series_list = _family_section_list('series_family', include_kids_networks=True)
animation_movie_list = _family_section_list('movie_animation', include_sagas=True)
animation_series_list = _family_section_list('series_animation')
anime_series_list = _anime_section_list('anime_series')
anime_movie_list = _anime_section_list('anime_movie')
sagas_movie_list = _sagas_list('movie')
sagas_family_list = _sagas_list('family')
sagas_animation_list = _sagas_list('animation')
sagas_anime_list = _sagas_list('anime')
documentary_movie_root_list = [
	{'name': 'Films documentaires', 'iconImage': 'genre_documentary.png', 'mode': 'navigator.main', 'action': 'DocumentaryMovieDocumentaryList'},
	{'name': 'Téléfilms', 'iconImage': 'genre_tv.png', 'mode': 'navigator.main', 'action': 'DocumentaryTvMovieList'},
	{'name': 32474, 'iconImage': 'because_you_watched.png', 'mode': 'navigator.because_you_watched', 'menu_type': 'movie', 'recommendation_group': 'documentary'},
	{'name': 'Vos suivis de lecture', 'iconImage': 'watched.png', 'mode': 'navigator.viewing_movies', 'progress_group': 'documentary'},
]
documentary_series_root_list = [
	{'name': 'Séries documentaires', 'iconImage': 'genre_documentary.png', 'mode': 'navigator.main', 'action': 'DocumentarySeriesDocumentaryList'},
	{'name': 'Téléréalité', 'iconImage': 'genre_reality.png', 'mode': 'navigator.main', 'action': 'DocumentarySeriesRealityList'},
	{'name': 'Talk-shows', 'iconImage': 'genre_talk.png', 'mode': 'navigator.main', 'action': 'DocumentarySeriesTalkshowList'},
	{'name': 'Actualités', 'iconImage': 'genre_news.png', 'mode': 'navigator.main', 'action': 'DocumentarySeriesNewsList'},
	{'name': 32474, 'iconImage': 'because_you_watched.png', 'mode': 'navigator.because_you_watched', 'menu_type': 'tvshow', 'recommendation_group': 'documentary'},
	{'name': 'Vos suivis de lecture', 'iconImage': 'watched.png', 'mode': 'navigator.viewing_tvshows', 'progress_group': 'documentary'}
]
documentary_movie_documentary_list = _documentary_section_list('movie_documentary', False)
documentary_tv_movie_list = _documentary_section_list('movie_tv_movie', False)
documentary_series_documentary_list = _documentary_section_list('series_documentary', True)
documentary_series_reality_list = _documentary_section_list('series_reality', True)
documentary_series_talkshow_list = _documentary_section_list('series_talkshow', True)
documentary_series_news_list = _documentary_section_list('series_news', True)

alkopaste_catalogue_list = [
	{'name': 'Films', 'iconImage': 'movies.png', 'mode': 'catalogue.alkopaste_section', 'catalogue_section': 'films', 'catalogue_media_type': 'film'},
	{'name': 'Séries', 'iconImage': 'tv.png', 'mode': 'catalogue.alkopaste_section', 'catalogue_section': 'series', 'catalogue_media_type': 'serie'},
	{'name': 'Dessins animés', 'iconImage': 'genre_animation.png', 'mode': 'catalogue.alkopaste_folder', 'catalogue_folder': 'animation'},
	{'name': 'Docus & Télé', 'iconImage': 'genre_documentary.png', 'mode': 'catalogue.alkopaste_folder', 'catalogue_folder': 'documentaries'},
	{'name': 'Concerts & Spectacles', 'iconImage': 'in_theatres.png', 'mode': 'catalogue.alkopaste_folder', 'catalogue_folder': 'concerts_spectacles'},
	{'name': 'Contenu QC', 'iconImage': 'quebec.png', 'mode': 'catalogue.alkopaste_folder', 'catalogue_folder': 'qc'},
	{'name': 'Animés japonais', 'iconImage': 'anime.png', 'mode': 'catalogue.alkopaste_folder', 'catalogue_folder': 'anime'},
	{'name': 'Sagas', 'iconImage': 'sets.png', 'mode': 'navigator.main', 'action': 'SagasMovieList'},
	{'name': 'Personnes', 'iconImage': 'user.png', 'mode': 'navigator.main', 'action': 'PeopleList'},
	{'name': 'Recherche', 'iconImage': 'search.png', 'mode': 'navigator.search'}
]


main_menu_items = {
	'RootList': {'name': 32457, 'iconImage': 'alkoflix.png', 'mode': 'navigator.main', 'action': 'RootList'},
	'TMDbCatalogueList': root_list[0],
	'MovieList': tmdb_catalogue_list[0],
	'TVShowList': tmdb_catalogue_list[1],
	'DocumentaryList': tmdb_catalogue_list[2],
	'FamilyList': tmdb_catalogue_list[3],
	'AnimationList': tmdb_catalogue_list[4],
	'AnimeList': tmdb_catalogue_list[5],
	'PeopleList': root_list[1],
	'FamilyMovieList': {'name': 'Films familiaux', 'iconImage': 'movies.png', 'mode': 'navigator.main', 'action': 'FamilyMovieList'},
	'FamilySeriesList': {'name': 'Séries familiales', 'iconImage': 'tv.png', 'mode': 'navigator.main', 'action': 'FamilySeriesList'},
	'AnimationMovieList': {'name': 'Films d’animation', 'iconImage': 'movies.png', 'mode': 'navigator.main', 'action': 'AnimationMovieList'},
	'AnimationSeriesList': {'name': 'Séries d’animation', 'iconImage': 'tv.png', 'mode': 'navigator.main', 'action': 'AnimationSeriesList'},
	'AnimeSeriesList': {'name': 'Séries animées japonaises', 'iconImage': 'tv.png', 'mode': 'navigator.main', 'action': 'AnimeSeriesList'},
	'AnimeMovieList': {'name': 'Films animés japonais', 'iconImage': 'movies.png', 'mode': 'navigator.main', 'action': 'AnimeMovieList'},
	'SagasMovieList': {'name': 'Sagas', 'iconImage': 'sets.png', 'mode': 'navigator.main', 'action': 'SagasMovieList'},
	'SagasFamilyList': {'name': 'Sagas', 'iconImage': 'sets.png', 'mode': 'navigator.main', 'action': 'SagasFamilyList'},
	'SagasAnimationList': {'name': 'Sagas', 'iconImage': 'sets.png', 'mode': 'navigator.main', 'action': 'SagasAnimationList'},
	'SagasAnimeList': {'name': 'Sagas', 'iconImage': 'sets.png', 'mode': 'navigator.main', 'action': 'SagasAnimeList'},
	'DocumentaryMovieRootList': {'name': 'Films', 'iconImage': 'movies.png', 'mode': 'navigator.main', 'action': 'DocumentaryMovieRootList'},
	'DocumentarySeriesRootList': {'name': 'Séries', 'iconImage': 'tv.png', 'mode': 'navigator.main', 'action': 'DocumentarySeriesRootList'},
	'DocumentaryMovieDocumentaryList': {'name': 'Films documentaires', 'iconImage': 'genre_documentary.png', 'mode': 'navigator.main', 'action': 'DocumentaryMovieDocumentaryList'},
	'DocumentaryTvMovieList': {'name': 'Téléfilms', 'iconImage': 'genre_tv.png', 'mode': 'navigator.main', 'action': 'DocumentaryTvMovieList'},
	'DocumentarySeriesDocumentaryList': {'name': 'Séries documentaires', 'iconImage': 'genre_documentary.png', 'mode': 'navigator.main', 'action': 'DocumentarySeriesDocumentaryList'},
	'DocumentarySeriesRealityList': {'name': 'Téléréalité', 'iconImage': 'genre_reality.png', 'mode': 'navigator.main', 'action': 'DocumentarySeriesRealityList'},
	'DocumentarySeriesTalkshowList': {'name': 'Talk-shows', 'iconImage': 'genre_talk.png', 'mode': 'navigator.main', 'action': 'DocumentarySeriesTalkshowList'},
	'DocumentarySeriesNewsList': {'name': 'Actualités', 'iconImage': 'genre_news.png', 'mode': 'navigator.main', 'action': 'DocumentarySeriesNewsList'},
	'AlkoPasteCatalogueList': {'name': 'Catalogue alkoPaste', 'iconImage': 'marque-page.png', 'mode': 'catalogue.alkopaste_root', 'action': 'AlkoPasteCatalogueList'}
}

main_menus = {
	'RootList': root_list,
	'TMDbCatalogueList': tmdb_catalogue_list,
	'MovieList': movie_list,
	'TVShowList': tvshow_list,
	'DocumentaryList': documentary_list,
	'FamilyList': family_list,
	'AnimeList': anime_list,
	'AnimationList': animation_list,
	'PeopleList': people_list,
	'FamilyMovieList': family_movie_list,
	'FamilySeriesList': family_series_list,
	'AnimationMovieList': animation_movie_list,
	'AnimationSeriesList': animation_series_list,
	'AnimeSeriesList': anime_series_list,
	'AnimeMovieList': anime_movie_list,
	'SagasMovieList': sagas_movie_list,
	'SagasFamilyList': sagas_family_list,
	'SagasAnimationList': sagas_animation_list,
	'SagasAnimeList': sagas_anime_list,
	'DocumentaryMovieRootList': documentary_movie_root_list,
	'DocumentarySeriesRootList': documentary_series_root_list,
	'DocumentaryMovieDocumentaryList': documentary_movie_documentary_list,
	'DocumentaryTvMovieList': documentary_tv_movie_list,
	'DocumentarySeriesDocumentaryList': documentary_series_documentary_list,
	'DocumentarySeriesRealityList': documentary_series_reality_list,
	'DocumentarySeriesTalkshowList': documentary_series_talkshow_list,
	'DocumentarySeriesNewsList': documentary_series_news_list,
	'AlkoPasteCatalogueList': alkopaste_catalogue_list
}

default_menu_items = (
	'RootList',
	'TMDbCatalogueList',
	'MovieList',
	'TVShowList',
	'DocumentaryList',
	'FamilyList',
	'AnimeList',
	'AnimationList',
	'PeopleList',
	'AlkoPasteCatalogueList'
)
