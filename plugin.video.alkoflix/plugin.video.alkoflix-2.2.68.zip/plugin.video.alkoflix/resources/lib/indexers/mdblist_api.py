import re
import time
import requests
from threading import Thread
from caches import mdbl_cache
from caches.main_cache import cache_object, timedelta, MainCache
from caches.meta_cache import cache_function
from indexers.metadata import movie_external_id, tvshow_external_id
from modules import kodi_utils, settings
from modules.cache import check_databases
from modules.utils import make_thread_list, paginate_list, sort_for_article, jsondate_to_datetime, TaskPool
# logger = kodi_utils.logger

get_setting, set_setting, js2date = kodi_utils.get_setting, kodi_utils.set_setting, jsondate_to_datetime
review_provider_id = {1: 'Trakt', 2: 'TMDb', 3: 'RT', 4: 'Metacritics'}
rank_map = {'0': 'mild', '1': 'mild', '2': 'moderate', '3': 'moderate', '4': 'severe', '5': 'severe'}
guide_map = {'Nudity': 'Sex & Nudity', 'Violence': 'Violence & Gore', 'Profanity': 'Profanity', 'Alcohol': 'Alcohol, Drugs & Smoking'}
MDBL_FAVORITES_NAMES = ('favoris', 'favorites', 'favourites')
MAX_LIST_ITEMS, EXPIRES_1_HOURS = 250_000, 1
base_url = 'https://api.mdblist.com/%s'
timeout = 5.05
session = requests.Session()
session.mount('https://api.mdblist.com', requests.adapters.HTTPAdapter(pool_maxsize=100))
MDBLIST_DEFAULT_CLIENT_ID = 'EUk8hb6sCGab70Z08k9EKMv1kahOh311Xxk4fDrj'
MDBLIST_TOKEN_ENDPOINTS = ('oauth/token/', 'oauth/token')

def _safe_int(value, default=0):
	try: return int(value)
	except: return default

def _store_oauth_tokens(result):
	access_token = result.get('access_token')
	if not access_token: return False
	refresh_token = result.get('refresh_token') or get_setting('mdblist.refresh_token')
	expires = int(time.time()) + _safe_int(result.get('expires_in'), 2592000)
	set_setting('mdblist.auth_type', 'oauth')
	set_setting('mdblist.access_token', access_token)
	set_setting('mdblist.refresh_token', refresh_token or '')
	set_setting('mdblist.expires', str(expires))
	set_setting('mdblist.client_id', get_setting('mdblist.client_id') or MDBLIST_DEFAULT_CLIENT_ID)
	return True

def _refresh_oauth_token():
	refresh_token = get_setting('mdblist.refresh_token')
	if not refresh_token: return False
	client_id = get_setting('mdblist.client_id') or MDBLIST_DEFAULT_CLIENT_ID
	payload = {'grant_type': 'refresh_token', 'refresh_token': refresh_token, 'client_id': client_id}
	for endpoint in MDBLIST_TOKEN_ENDPOINTS:
		try:
			response = session.post(base_url % endpoint, data=payload, timeout=timeout)
			result = response.json() if 'json' in response.headers.get('Content-Type', '') else {}
		except requests.exceptions.RequestException as e:
			kodi_utils.logger('mdblist refresh error', str(e))
			continue
		if response.ok and _store_oauth_tokens(result): return True
	return False

def _oauth_headers():
	access_token = get_setting('mdblist.access_token')
	if not access_token: return None
	expires = _safe_int(get_setting('mdblist.expires'))
	if expires and time.time() > expires - 300:
		_refresh_oauth_token()
		access_token = get_setting('mdblist.access_token')
	return {'Authorization': 'Bearer %s' % access_token} if access_token else None

def _mdbl_account_active():
	return bool(get_setting('mdblist_user', '') or get_setting('mdblist.access_token', '') or get_setting('mdblist.token', ''))

def _mdbl_personal_path(path):
	path = str(path or '')
	return path.startswith(('sync/', 'watchlist/', 'user', 'upnext', 'calendar/')) or path in ('watchlist/items',)

def call_mdblist(path, params=None, json=None, method=None):
	params = dict(params or {})
	if _mdbl_personal_path(path) and not _mdbl_account_active():
		kodi_utils.logger('mdblist skipped', 'no account | path=%s' % path)
		return None
	headers = _oauth_headers()
	if not headers:
		params['apikey'] = get_setting('mdblist.token')
	try:
		response = session.request(method or 'get', base_url % path, params=params, json=json, headers=headers, timeout=timeout)
		if response.status_code in (401, 403) and headers and _refresh_oauth_token():
			headers = _oauth_headers()
			response = session.request(method or 'get', base_url % path, params=params, json=json, headers=headers, timeout=timeout)
		result = response.json() if 'json' in response.headers.get('Content-Type', '') else response.text
		if not response.ok: response.raise_for_status()
		return result
	except requests.exceptions.RequestException as e:
		kodi_utils.logger('mdblist error', str(e))

def mdbl_searchlists(query):
	query = requests.utils.quote(query)
	string = 'mdbl_searchlists_%s' % query
	url = 'lists/search?query=%s' % query
	return cache_object(call_mdblist, string, url, json=False, expiration=EXPIRES_1_HOURS)

def mdbl_userlists():
	if not _mdbl_account_active(): return []
	string = 'mdbl_userlists'
	url = 'lists/user'
	return cache_object(call_mdblist, string, url, json=False, expiration=EXPIRES_1_HOURS)

def mdbl_likedlists():
	"""Listes MDBList aimées par l'utilisateur connecté."""
	if not _mdbl_account_active(): return []
	string = 'mdbl_likedlists'
	url = 'lists/liked'
	result = cache_object(call_mdblist, string, url, json=False, expiration=EXPIRES_1_HOURS)
	if isinstance(result, dict):
		return result.get('lists') or result.get('items') or []
	return result or []

def _clear_mdbl_likedlists_cache():
	try: MainCache().delete('mdbl_likedlists')
	except: pass


def mdbl_like_a_list(params):
	"""Aime une liste MDBList via l'endpoint natif PUT /lists/{id}/like."""
	list_id = params.get('list_id')
	if not list_id or not _mdbl_account_active():
		return kodi_utils.notification(32574)
	result = call_mdblist('lists/%s/like' % list_id, method='put')
	if result is None:
		return kodi_utils.notification(32574)
	_clear_mdbl_likedlists_cache()
	kodi_utils.notification(32576)
	kodi_utils.container_refresh()


def mdbl_unlike_a_list(params):
	"""Retire l'aime d'une liste MDBList via DELETE /lists/{id}/like."""
	list_id = params.get('list_id')
	if not list_id or not _mdbl_account_active():
		return kodi_utils.notification(32574)
	result = call_mdblist('lists/%s/like' % list_id, method='delete')
	if result is None:
		return kodi_utils.notification(32574)
	_clear_mdbl_likedlists_cache()
	kodi_utils.notification(32576)
	kodi_utils.container_refresh()


def _mdbl_normalize_name(name):
	return re.sub(r'[^a-z0-9]+', '', str(name or '').lower())

def mdbl_create_static_list(name='Favoris', private=True):
	result = call_mdblist('lists/user/add', json={'name': name, 'private': private}, method='post')
	if not result or not result.get('id'): return None
	clear_mdbl_cache(silent=True)
	return {'id': result.get('id'), 'name': name, 'items': 0, 'dynamic': False, 'private': private}

def mdbl_favorites_list(create=False):
	user_lists = mdbl_userlists() or []
	favorites = [i for i in user_lists if not i.get('dynamic') and _mdbl_normalize_name(i.get('name')) in MDBL_FAVORITES_NAMES]
	if favorites:
		favorites.sort(key=lambda k: (0 if _mdbl_normalize_name(k.get('name')) == 'favoris' else 1, str(k.get('name', '')).lower()))
		return favorites[0]
	if not create: return None
	return mdbl_create_static_list()

def mdbl_externallists():
	string = 'mdbl_externallists'
	url = 'external/lists/user'
	return cache_object(call_mdblist, string, url, json=False, expiration=EXPIRES_1_HOURS)

def mdbl_toplists():
	string = 'mdbl_toplists'
	url = 'lists/top'
	return cache_object(call_mdblist, string, url, json=False)

def mdbl_parentsguide(imdb_id, media_type):
	media_type = 'show' if media_type == 'tvshow' else 'movie'
	url = 'https://www.mdblist.com/%s/%s' % (media_type, imdb_id)
	string = 'mdbl_%s_parentsguide_%s' % (media_type, imdb_id)
	params = {'url': url, 'action': 'mdbl_parentsguide'}
	return cache_function(get_mdbl, string, params)

def mdbl_media_info(imdb_id, media_type):
	if not (get_setting('mdblist.access_token') or get_setting('mdblist.token')): return
	media_type = 'show' if media_type == 'tvshow' else 'movie'
	string = 'mdbl_%s_mediainfo_%s' % (media_type, imdb_id)
	url = '%s/%s/%s?append_to_response=review' % ('imdb', media_type, imdb_id)
	return cache_function(call_mdblist, string, url)

def mdbl_media_info_batch(items, provider, media_type):
	url = '%s/%s' % (provider, media_type)
	return call_mdblist(url, json=items, method='post')

def mdblist_collection(media_type, page_no, letter):
	string = 'mdbl_collection'
	url = 'sync/collection'
	original_list = mdbl_cache.cache_mdbl_object(mdbl_collection_watchlist_items, string, url)
	if media_type == 'all':
		original_list = original_list['movies'] + original_list['shows']
		for i in original_list: i.update({'id': i['movie' if 'movie' in i else 'show']['ids']['tmdb']})
		return original_list
	original_list = original_list[media_type]
	key = 'movie' if media_type == 'movies' else 'show'
	for i in original_list: i.update({
		'id': i[key]['ids']['tmdb'], 'imdb_id': i[key]['ids']['imdb'],
		'title': i[key]['title'], 'release_year': i[key]['year']
	})
	sort_key = settings.lists_sort_order('collection')
	reverse = settings.lists_sort_reverse('collection')
	if   sort_key == 2: original_list.sort(key=lambda k: k.get('release_year') or '', reverse=reverse)
	elif sort_key == 1: original_list.sort(key=lambda k: k.get('collected_at') or '', reverse=reverse)
	else:
		original_list = sort_for_article(original_list, 'title', settings.ignore_articles())
		if reverse: original_list.reverse()
	if settings.paginate():
		limit = settings.page_limit()
		final_list, total_pages = paginate_list(original_list, page_no, letter, limit)
	else: final_list, total_pages = original_list, 1
	return final_list, total_pages

def mdblist_watchlist(media_type, page_no, letter):
	string = 'mdbl_watchlist'
	url = 'watchlist/items'
	original_list = mdbl_cache.cache_mdbl_object(mdbl_collection_watchlist_items, string, url)
	if media_type == 'all':
		original_list = original_list['movies'] + original_list['shows']
		return original_list
	original_list = original_list[media_type]
	sort_key = settings.lists_sort_order('watchlist')
	reverse = settings.lists_sort_reverse('watchlist')
	if   sort_key == 2: original_list.sort(key=lambda k: k.get('release_year') or 0, reverse=reverse)
	elif sort_key == 1: original_list.sort(key=lambda k: k.get('watchlist_at') or '', reverse=reverse)
	else:
		original_list = sort_for_article(original_list, 'title', settings.ignore_articles())
		if reverse: original_list.reverse()
	if settings.paginate():
		limit = settings.page_limit()
		final_list, total_pages = paginate_list(original_list, page_no, letter, limit)
	else: final_list, total_pages = original_list, 1
	return final_list, total_pages

def mdblist_favorites(media_type, page_no, letter):
	favorites_list = mdbl_favorites_list(create=False)
	if not favorites_list: return [], 1
	original_list = mdbl_list_items(str(favorites_list['id']), None) or []
	if media_type == 'all': return original_list
	media_type = 'movie' if media_type == 'movies' else 'show'
	original_list = [i for i in original_list if i.get('mediatype') == media_type]
	sort_key = settings.lists_sort_order('favorites')
	reverse = settings.lists_sort_reverse('favorites')
	if   sort_key == 2: original_list.sort(key=lambda k: k.get('release_year') or 0, reverse=reverse)
	elif sort_key == 1:
		date_items = any(k.get('added') or k.get('added_at') or k.get('created_at') for k in original_list)
		if date_items: original_list.sort(key=lambda k: k.get('added') or k.get('added_at') or k.get('created_at') or '', reverse=reverse)
		else: original_list.sort(key=lambda k: k.get('rank') or 0, reverse=not reverse)
	else:
		original_list = sort_for_article(original_list, 'title', settings.ignore_articles())
		if reverse: original_list.reverse()
	if settings.paginate():
		limit = settings.page_limit()
		final_list, total_pages = paginate_list(original_list, page_no, letter, limit)
	else: final_list, total_pages = original_list, 1
	return final_list, total_pages

def mdbl_collection_watchlist_items(url):
	params = {'limit': 5000 if 'sync' in url else 1000}
	items = {'movies': [], 'shows': []}
	try:
		for _ in range(MAX_LIST_ITEMS // params['limit']):
			result = call_mdblist(url, params=params)
			if result is None: break
			if 'movies' in result: items['movies'] += result['movies']
			if 'shows' in result: items['shows'] += result['shows']
			if not result['pagination']['has_more']: break
			if 'sync' in url:
				params['offset'] = result['pagination']['offset'] + result['pagination']['limit']
			else: params['offset'] = result['pagination']['page'] * result['pagination']['limit']
	except Exception:
		pass
	return items

def _mdbl_normalize_list_items(result):
	if not result: return []
	if isinstance(result, dict):
		merged = []
		for key, media_type in (('movies', 'movie'), ('shows', 'show')):
			for item in result.get(key, []) or []:
				item = dict(item)
				item.setdefault('mediatype', media_type)
				merged.append(item)
		result = merged
	for item in result:
		try:
			ids = item.get('ids') or {}
			item.setdefault('id', ids.get('tmdb') or item.get('tmdb') or item.get('tmdb_id'))
			item.setdefault('imdb_id', ids.get('imdb') or item.get('imdb'))
		except: pass
	return result

def mdbl_list_items(list_id, list_type):
	if list_id == 'collection': return mdblist_collection('all', None, '')
	if list_id == 'watchlist': return mdblist_watchlist('all', None, '')
	if list_id == 'favorites': return mdblist_favorites('all', None, '')
	if list_type == 'external': url = 'external/lists/%s/items' % list_id
	else: url = 'lists/%s/items' % list_id
	cache = MainCache()
	cache_get, cache_set = cache.get, cache.set
	string = 'mdbl_userlists_%s' % list_id
	result = cache_get(string)
	if result: return result
	result = _mdbl_normalize_list_items(call_mdblist(url, params={'unified': 'true'}))
	if result: cache_set(string, result, expiration=timedelta(hours=EXPIRES_1_HOURS))
	return result

def mdbl_modify_collection(data, action=True):
	if action: url, key = 'sync/collection', 'updated'
	else: url, key = 'sync/collection/remove', 'removed'
	if 'movies' in data: data['movies'] = [{'ids': i} for i in data['movies']]
	if 'shows' in data: data['shows'] = [{'ids': i} for i in data['shows']]
	result = call_mdblist(url, json=data, method='post')
	success = bool(result) and key in result and any(result[key][i] for i in ('movies', 'shows'))
	return success

def mdbl_modify_list(list_id, data, action=True):
	if action: url, key = 'add', 'added'
	else: url, key = 'remove', 'removed'
	if list_id == 'collection': return mdbl_modify_collection(data, action)
	elif list_id == 'watchlist': url = 'watchlist/items/%s' % url
	elif list_id == 'favorites':
		favorites_list = mdbl_favorites_list(create=action)
		if not favorites_list: return False
		url = 'lists/%s/items/%s' % (favorites_list['id'], url)
	else: url = 'lists/%s/items/%s' % (list_id, url)
	result = call_mdblist(url, json=data, method='post')
	success = bool(result) and key in result and any(result[key][i] for i in ('movies', 'shows'))
	return success


def _mdbl_valid_id(value):
	return not value in ('', 'None', None)

def _mdbl_ids_from_params(params):
	ids = {}
	for key in ('imdb', 'tmdb', 'tvdb'):
		value = params.get('%s_id' % key)
		if not _mdbl_valid_id(value): continue
		try: ids[key] = value if key == 'imdb' else int(value)
		except: ids[key] = value
	return ids

def _mdbl_rating_payload(params, rating=None):
	media_type = params.get('media_type')
	ids = _mdbl_ids_from_params(params)
	if not ids: return None, None
	if media_type == 'movie':
		item = {'ids': ids}
		if rating is not None: item['rating'] = int(rating)
		return {'movies': [item]}, 'movies'
	show = {'ids': ids}
	if media_type == 'episode':
		episode = {'number': int(params['episode'])}
		if rating is not None: episode['rating'] = int(rating)
		show['seasons'] = [{'number': int(params['season']), 'episodes': [episode]}]
		return {'shows': [show]}, 'episodes'
	if media_type == 'season':
		season = {'number': int(params['season'])}
		if rating is not None: season['rating'] = int(rating)
		show['seasons'] = [season]
		return {'shows': [show]}, 'seasons'
	if rating is not None: show['rating'] = int(rating)
	return {'shows': [show]}, 'shows'

def mdbl_set_rating(params, rating):
	data, success_key = _mdbl_rating_payload(params, rating)
	if not data: return False
	result = call_mdblist('sync/ratings', json=data, method='post')
	try: success = bool(result) and bool(result.get('updated'))
	except: success = bool(result)
	if success: mdbl_sync_activities()
	return success

def mdbl_remove_rating(params):
	data, success_key = _mdbl_rating_payload(params)
	if not data: return False
	result = call_mdblist('sync/ratings/remove', json=data, method='post')
	try: success = bool(result) and bool(result.get('removed'))
	except: success = bool(result)
	if success: mdbl_sync_activities()
	return success

def _mdbl_ids_match(ids, params):
	ids = ids or {}
	for key in ('tmdb', 'imdb', 'tvdb'):
		value = params.get('%s_id' % key)
		if _mdbl_valid_id(value) and str(ids.get(key)) == str(value): return True
	return False

def mdbl_user_ratings():
	params = {'limit': 1000, 'offset': 0}
	results = {'movies': [], 'shows': [], 'seasons': [], 'episodes': []}
	try:
		for _ in range(MAX_LIST_ITEMS // params['limit']):
			result = call_mdblist('sync/ratings', params=params)
			if result is None: break
			for key in results: results[key] += result.get(key, []) or []
			pagination = result.get('pagination') or {}
			if not pagination.get('has_more'): break
			params['offset'] = pagination.get('offset', params['offset']) + pagination.get('limit', params['limit'])
	except: pass
	return results

def mdbl_get_rating(params):
	media_type = params.get('media_type')
	data = mdbl_user_ratings()
	if media_type == 'movie':
		for item in data.get('movies', []):
			if _mdbl_ids_match((item.get('movie') or {}).get('ids'), params): return item.get('rating')
	elif media_type == 'episode':
		for item in data.get('episodes', []):
			episode = item.get('episode') or {}
			show = episode.get('show') or item.get('show') or {}
			try:
				if int(episode.get('season')) == int(params.get('season')) and int(episode.get('number')) == int(params.get('episode')) and _mdbl_ids_match(show.get('ids'), params):
					return item.get('rating')
			except: pass
	elif media_type == 'season':
		for item in data.get('seasons', []):
			season = item.get('season') or {}
			show = season.get('show') or item.get('show') or {}
			try:
				number = season.get('number', item.get('number'))
				if int(number) == int(params.get('season')) and _mdbl_ids_match(show.get('ids'), params):
					return item.get('rating')
			except: pass
	else:
		for item in data.get('shows', []):
			if _mdbl_ids_match((item.get('show') or {}).get('ids'), params): return item.get('rating')
	return None

def mdbl_watched_unwatched(action, media, media_id, tvdb_id=0, data=None, season=None, episode=None, key='tmdb'):
	if action == 'mark_as_watched': url, result_key = 'sync/watched', 'updated'
	else: url, result_key = 'sync/watched/remove', 'removed'
	try: media_id = {key: int(media_id)}
	except: pass
	if media == 'movies':
		success_key = 'movies'
		data = {'movies': [{'ids': media_id}]}
	else:
		success_key = 'episodes'
		if media == 'episode': data = {'shows': [{'seasons': [{'episodes': [{'number': int(episode)}], 'number': int(season)}], 'ids': media_id}]}
		else: data = {'shows': [{'ids': media_id, 'seasons': data}]}
	result = call_mdblist(url, json=data, method='post')
	success = result[result_key][success_key] > 0
	if success: clear_mdbl_upnext_cache()
	if not success:
		if media != 'movies' and tvdb_id != 0:
			return mdbl_watched_unwatched(action, media, tvdb_id, 0, data, season, episode, 'tvdb')
	return success

def mdbl_indicators_movies(watched_info):
	def _process(item):
		tmdb_id = get_mdbl_movie_id(item['movie']['ids'])
		if not tmdb_id: return
		insert_append((
			'movie', str(tmdb_id), '', '', item['last_watched_at'], item['movie']['title']
		))
	insert_list = []
	insert_append = insert_list.append
	watched_items = [(i,) for i in watched_info['movies']] # TaskPool requires tuple
	if not watched_items: return
#	threads = list(make_thread_list(_process, watched_items, Thread))
	for i in TaskPool().tasks(_process, watched_items, Thread): i.join()
	mdbl_cache.MDBLCache().set_bulk_movie_watched(insert_list)

def mdbl_indicators_tv(watched_info):
	def _process(item):
		tmdb_id = get_mdbl_tvshow_id(item['episode']['show']['ids'])
		if not tmdb_id: return
		season, episode = item['episode']['season'], item['episode']['number']
		insert_append((
			'episode', str(tmdb_id), season, episode, item['last_watched_at'], item['episode']['show']['title']
		))
	insert_list = []
	insert_append = insert_list.append
	watched_items = [(i,) for i in watched_info['episodes']] # TaskPool requires tuple
	if not watched_items: return
#	threads = list(make_thread_list(_process, watched_items, Thread))
	for i in TaskPool().tasks(_process, watched_items, Thread): i.join()
	mdbl_cache.MDBLCache().set_bulk_tvshow_watched(insert_list)

def mdbl_progress(action, media, media_id, percent, season=None, episode=None, resume_id=None, refresh_mdb=False):
	if action == 'clear_progress':
		url = 'scrobble/clear'
		data = {'id': resume_id}
	else:
		url = 'scrobble/pause'
		try: media_id = int(media_id)
		except: pass
		if media in ('movie', 'movies'): data = {'movie': {'ids': {'tmdb': media_id}}, 'progress': float(percent)}
		else: data = {'show': {'ids': {'tmdb': media_id}, 'season': {'number': int(season), 'episode': {'number': int(episode)}}}, 'progress': float(percent)}
	call_mdblist(url, json=data, method='post')
	if refresh_mdb: mdbl_sync_activities()

def mdbl_progress_movies(progress_info):
	def _process(item):
		tmdb_id = get_mdbl_movie_id(item['movie']['ids'])
		if not tmdb_id: return
		season, episode = '', ''
		insert_append((
			'movie', str(tmdb_id), season, episode, str(round(float(item['progress']), 1)),
			0, item['paused_at'], item['id'], item['movie']['title']
		))
	insert_list = []
	insert_append = insert_list.append
	progress_items = [i for i in progress_info if i['type'] == 'movie' and float(i['progress']) > 1]
	if progress_items:
		threads = list(make_thread_list(_process, progress_items, Thread))
		[i.join() for i in threads]
	mdbl_cache.MDBLCache().set_bulk_movie_progress(insert_list)

def mdbl_progress_tv(progress_info):
	def _process(item):
		tmdb_id = get_mdbl_tvshow_id(item['show']['ids'])
		if not tmdb_id: return
		season, episode = item['episode']['season'], item['episode']['number']
		if season < 1: return
		insert_append((
			'episode', str(tmdb_id), season, episode, str(round(float(item['progress']), 1)),
			0, item['paused_at'], item['id'], item['show']['title']
		))
	insert_list = []
	insert_append = insert_list.append
	progress_items = [i for i in progress_info if i['type'] == 'episode' and float(i['progress']) > 1]
	if progress_items:
		threads = list(make_thread_list(_process, progress_items, Thread))
		[i.join() for i in threads]
	mdbl_cache.MDBLCache().set_bulk_tvshow_progress(insert_list)

def get_mdbl_movie_id(item):
	if item['tmdb']: return item['tmdb']
	tmdb_id = None
	if item['imdb']:
		try:
			meta = movie_external_id('imdb_id', item['imdb'])
			tmdb_id = meta['id']
		except: pass
	return tmdb_id

def get_mdbl_tvshow_id(item):
	if item['tmdb']: return item['tmdb']
	tmdb_id = None
	if item['imdb']:
		try:
			meta = tvshow_external_id('imdb_id', item['imdb'])
			tmdb_id = meta['id']
		except: tmdb_id = None
	if not tmdb_id:
		if item['tvdb']:
			try:
				meta = tvshow_external_id('tvdb_id', item['tvdb'])
				tmdb_id = meta['id']
			except: tmdb_id = None
	return tmdb_id

def mdbl_calendar_days(current_date):
	"""Plage du calendrier MDBList, alignée sur les réglages calendrier existants."""
	from datetime import timedelta
	try: previous_days = int(get_setting('trakt.calendar_previous_days', '7'))
	except: previous_days = 7
	try: future_days = int(get_setting('trakt.calendar_future_days', '7'))
	except: future_days = 7
	start = (current_date - timedelta(days=max(0, previous_days))).strftime('%Y-%m-%d')
	finish = (current_date + timedelta(days=max(0, future_days))).strftime('%Y-%m-%d')
	return start, finish


def _mdbl_calendar_fetch(start, finish):
	"""Récupère et normalise calendar/events au format attendu par menus.episodes."""
	result = call_mdblist('calendar/events', params={'limit': 1000, 'start': start, 'end': finish})
	if not isinstance(result, dict): return []
	events = result.get('events') or result.get('items') or result.get('results') or []
	calendar = []
	seen = set()
	for item in events:
		try:
			if not isinstance(item, dict): continue
			if item.get('type') not in (None, '', 'episode'): continue
			season = item.get('season_number', item.get('season'))
			episode = item.get('episode_number', item.get('episode'))
			if season is None or episode is None or int(season) <= 0: continue
			tmdb_id = item.get('show_tmdb') or item.get('show_id') or ((item.get('show') or {}).get('ids') or {}).get('tmdb')
			if not tmdb_id: continue
			title = item.get('title') or (item.get('show') or {}).get('title') or ''
			first_aired = item.get('start') or item.get('air_date') or item.get('first_aired') or ''
			key = (str(tmdb_id), int(season), int(episode), str(first_aired))
			if key in seen: continue
			seen.add(key)
			calendar.append({
				'first_aired': first_aired,
				'season': int(season),
				'episode': int(episode),
				'sort_title': '%s s%02d e%02d' % (title, int(season), int(episode)),
				'media_ids': {'tmdb': int(tmdb_id)}
			})
		except Exception: pass
	return calendar


def mdbl_get_my_calendar(current_date):
	"""Calendrier personnel MDBList, mis en cache brièvement pour préserver le quota API."""
	start, finish = mdbl_calendar_days(current_date)
	string = 'mdbl_get_my_calendar_%s_%s' % (start, finish)
	try:
		return cache_object(_mdbl_calendar_fetch, string, [start, finish], expiration=0.25)
	except Exception as e:
		kodi_utils.logger('mdblist calendar error', '%s: %s' % (type(e).__name__, e))
		return []


def mdbl_get_activity():
	url = 'sync/last_activities'
	return call_mdblist(url)

def mdbl_playback_progress():
	url = 'sync/playback'
	return call_mdblist(url)

def _mdbl_upnext_fetch(_path='upnext'):
	"""Récupère le vrai Up Next MDBList avec pagination, sans le reconstruire depuis l'historique."""
	params = {'limit': 250}
	items = []
	seen_cursors = set()
	try:
		for _ in range(MAX_LIST_ITEMS // params['limit']):
			result = call_mdblist(_path, params=params)
			if result is None: return None
			if isinstance(result, list):
				items.extend([i for i in result if isinstance(i, dict)])
				break
			if not isinstance(result, dict): break
			page_items = result.get('items') or result.get('results') or result.get('data') or []
			if isinstance(page_items, list): items.extend([i for i in page_items if isinstance(i, dict)])
			pagination = result.get('pagination') or {}
			next_cursor = pagination.get('next_cursor') or result.get('next_cursor')
			if next_cursor:
				next_cursor = str(next_cursor)
				if next_cursor in seen_cursors: break
				seen_cursors.add(next_cursor)
				params['cursor'] = next_cursor
				params.pop('offset', None)
				continue
			if not pagination.get('has_more'): break
			if not page_items: break
			params.pop('cursor', None)
			params['offset'] = int(pagination.get('offset', params.get('offset', 0)) or 0) + int(pagination.get('limit', len(page_items)) or len(page_items))
	except Exception as e:
		kodi_utils.logger('mdblist upnext error', '%s: %s' % (type(e).__name__, e))
		return None
	return items


def _mdbl_upnext_timestamp(value):
	"""Normalise les timestamps MDBList pour le tri historique d'alkoFlix."""
	value = str(value or '').strip()
	if not value: return '2000-01-01T00:00:00Z'
	if value.endswith('Z') and '.' in value:
		value = value.split('.', 1)[0] + 'Z'
	return value


def _mdbl_upnext_items_cached():
	# Cache partagé entre « Prochain épisode » et les compteurs de progression.
	try:
		return cache_object(_mdbl_upnext_fetch, 'mdbl_upnext_native', 'upnext', expiration=0.05)
	except Exception:
		return _mdbl_upnext_fetch('upnext')


def mdbl_upnext():
	"""Retourne les prochains épisodes natifs MDBList au format attendu par le menu Episodes."""
	items = _mdbl_upnext_items_cached()
	if items is None: return None
	result = []
	seen = set()
	for item in items:
		try:
			show = item.get('show') if isinstance(item.get('show'), dict) else item
			episode_data = item.get('next_episode') or item.get('episode') or show.get('next_episode') or {}
			ids = show.get('ids') if isinstance(show.get('ids'), dict) else {}
			normalized_ids = {'tmdb': ids.get('tmdb'), 'imdb': ids.get('imdb'), 'tvdb': ids.get('tvdb')}
			tmdb_id = get_mdbl_tvshow_id(normalized_ids)
			if not tmdb_id: continue
			season = episode_data.get('season', episode_data.get('season_number'))
			episode = episode_data.get('episode', episode_data.get('number', episode_data.get('episode_number')))
			if season is None or episode is None: continue
			key = (str(tmdb_id), int(season), int(episode))
			if key in seen: continue
			seen.add(key)
			result.append({
				'media_ids': {'tmdb': int(tmdb_id)},
				'season': int(season),
				'episode': int(episode),
				'last_played': _mdbl_upnext_timestamp(item.get('last_watched_at') or show.get('last_watched_at')),
				'exact_episode': True
			})
		except Exception: pass
	return result


def mdbl_native_tv_progress():
	"""Progression séries telle que MDBList la fournit dans /upnext.

	MDBList expose progress.watched_episode_count et total_episode_count. Ce sont
	ces valeurs que TMDb Helper utilise pour déterminer les séries en cours.
	"""
	items = _mdbl_upnext_items_cached()
	if items is None: return {}
	result = {}
	for item in items:
		try:
			show = item.get('show') if isinstance(item.get('show'), dict) else item
			ids = show.get('ids') if isinstance(show.get('ids'), dict) else {}
			tmdb_id = get_mdbl_tvshow_id({'tmdb': ids.get('tmdb'), 'imdb': ids.get('imdb'), 'tvdb': ids.get('tvdb')})
			if not tmdb_id: continue
			progress = item.get('progress') if isinstance(item.get('progress'), dict) else show.get('progress') if isinstance(show.get('progress'), dict) else {}
			watched_raw = progress.get('watched_episode_count')
			aired_raw = progress.get('total_episode_count')
			if watched_raw is None or aired_raw is None: continue
			watched, aired = int(watched_raw or 0), int(aired_raw or 0)
			if aired > 0: watched = min(watched, aired)
			result[str(tmdb_id)] = {
				'media_id': str(tmdb_id),
				'title': show.get('title') or item.get('title') or '',
				'last_played': _mdbl_upnext_timestamp(item.get('last_watched_at') or show.get('last_watched_at')),
				'aired_episodes': aired,
				'watched_episodes': watched,
				'unwatched_episodes': max(0, aired - watched),
				'completed': bool(aired and watched >= aired)
			}
		except Exception: pass
	return result


def clear_mdbl_upnext_cache():
	try: MainCache().delete('mdbl_upnext_native')
	except: pass


def mdbl_watched_progress():
	params = {'limit': 5000}
	watched = {'movies': [], 'episodes': []}
	try:
		for _ in range(MAX_LIST_ITEMS // params['limit']):
			result = call_mdblist('sync/watched', params=params)
			if result is None: break
			if 'movies' in result: watched['movies'] += result['movies']
			if 'episodes' in result: watched['episodes'] += result['episodes']
			if not result['pagination']['has_more']: break
			params['offset'] = result['pagination']['offset'] + result['pagination']['limit']
	except Exception:
		pass
	return watched

def mdbl_dropped_items():
	# La liste Dropped n'est relue que lorsqu'un changement est signalé par
	# sync/last_activities (ou au tout premier accès si le cache n'existe pas).
	params = {'limit': 5000}
	dropped = []
	try:
		for _ in range(MAX_LIST_ITEMS // params['limit']):
			result = call_mdblist('sync/dropped', params=params)
			if result is None: return None
			dropped += result.get('shows', []) or []
			pagination = result.get('pagination', {}) or {}
			if not pagination.get('has_more'): break
			params['offset'] = pagination.get('offset', 0) + pagination.get('limit', params['limit'])
	except Exception:
		return None
	return dropped

def mdbl_dropped_show_ids():
	items = mdbl_dropped_items()
	if items is None: return None
	tmdb_ids = []
	for item in items:
		try:
			ids = (item.get('show') or {}).get('ids') or {}
			ids = {'tmdb': ids.get('tmdb'), 'imdb': ids.get('imdb'), 'tvdb': ids.get('tvdb')}
			tmdb_id = get_mdbl_tvshow_id(ids)
			if tmdb_id: tmdb_ids.append(str(tmdb_id))
		except: pass
	return tmdb_ids

def mdblist_droplist(media_type, page_no, letter):
	if not mdbl_cache.has_dropped_shows_entry():
		try:
			dropped_ids = mdbl_dropped_show_ids()
			if dropped_ids is not None: mdbl_cache.set_dropped_shows(dropped_ids)
		except: pass
	original_list = []
	for value in mdbl_cache.get_dropped_shows():
		try: original_list.append({'id': int(value), 'imdb_id': None})
		except: pass
	return original_list, 1

def mdbl_toggle_dropped(params):
	"""Bascule l'état Dropped d'une série MDBList et met le cache local à jour immédiatement."""
	if str(params.get('media_type') or '') not in ('tvshow', 'show', 'shows'):
		return False
	try:
		tmdb_id = params.get('tmdb_id')
		if not _mdbl_valid_id(tmdb_id):
			tmdb_id = get_mdbl_tvshow_id({
				'tmdb': None,
				'imdb': params.get('imdb_id'),
				'tvdb': params.get('tvdb_id')
			})
		if not _mdbl_valid_id(tmdb_id):
			kodi_utils.notification(32574)
			return False
		tmdb_id = str(tmdb_id)

		# Initialise le cache une seule fois si nécessaire pour connaître l'état actuel.
		if not mdbl_cache.has_dropped_shows_entry():
			dropped_ids = mdbl_dropped_show_ids()
			# Ne jamais deviner l'état Dropped si la lecture initiale échoue :
			# sinon un clic destiné à retirer une série pourrait la ré-ajouter.
			if dropped_ids is None:
				kodi_utils.notification(32574)
				return False
			mdbl_cache.set_dropped_shows(dropped_ids)
		current = {str(i) for i in (mdbl_cache.get_dropped_shows() or [])}
		mark_dropped = tmdb_id not in current

		ids = _mdbl_ids_from_params(params)
		if 'tmdb' not in ids:
			try: ids['tmdb'] = int(tmdb_id)
			except: ids['tmdb'] = tmdb_id
		item = {'ids': ids}
		if mark_dropped:
			# L'API accepte le timestamp explicite et cela rend l'activité Dropped
			# immédiatement identifiable lors du prochain cycle de synchronisation.
			item['dropped_at'] = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())
		url = 'sync/dropped' if mark_dropped else 'sync/dropped/remove'
		result = call_mdblist(url, json={'shows': [item]}, method='post')
		if result is None:
			kodi_utils.notification(32574)
			return False

		mdbl_cache.update_dropped_show(tmdb_id, dropped=mark_dropped)
		clear_mdbl_upnext_cache()
		message = 'Série marquée comme abandonnée' if mark_dropped else 'Série retirée des abandonnées'
		kodi_utils.notification(message, time=2500)
		kodi_utils.container_refresh()
		return True
	except Exception as e:
		kodi_utils.logger('mdblist dropped error', '%s: %s' % (type(e).__name__, e))
		kodi_utils.notification(32574)
		return False

def mdbl_sync_activities_thread(*args, **kwargs):
	Thread(target=mdbl_sync_activities, args=args, kwargs=kwargs).start()

def mdbl_sync_activities(force_update=False):
	def _get_timestamp(date_time):
		return int(time.mktime(date_time.timetuple()))
	def _compare(latest, cached, res_format='%Y-%m-%dT%H:%M:%SZ'):
		try: result = _get_timestamp(js2date(latest, res_format)) > _get_timestamp(js2date(cached, res_format))
		except: result = True
		return result
	if not get_setting('mdblist_user', ''): return 'no account'
	if force_update:
		check_databases()
		mdbl_cache.clear_all_mdbl_cache_data(refresh=False)
	latest = mdbl_get_activity()
	if latest is None:
		mdbl_cache.clear_all_mdbl_cache_data(refresh=False)
		return 'failed'
	progress_info = mdbl_playback_progress()
	if progress_info is None:
		mdbl_cache.clear_all_mdbl_cache_data(refresh=False)
		return 'failed'
	progress_info.sort(key=lambda k: k['paused_at'], reverse=True)
	latest['paused_at'] = progress_info[0]['paused_at'] if progress_info else None
	cached = mdbl_cache.reset_activity(latest)
	refresh_movies_watched = _compare(latest['watched_at'], cached['watched_at'])
	refresh_episodes_watched = _compare(latest['episode_watched_at'], cached['episode_watched_at'])
	success = 'not needed'
	if refresh_movies_watched or refresh_episodes_watched:
		success = 'success'
		watched_info = mdbl_watched_progress()
		if refresh_movies_watched: mdbl_indicators_movies(watched_info)
		if refresh_episodes_watched:
			mdbl_indicators_tv(watched_info)
			clear_mdbl_upnext_cache()
	if _compare(latest['paused_at'], cached['paused_at']):
		success = 'success'
		mdbl_progress_movies(progress_info)
		mdbl_progress_tv(progress_info)
	if _compare(latest['watchlisted_at'], cached['watchlisted_at']):
		success = 'success'
		mdbl_cache.clear_mdbl_collection_watchlist_data('watchlist')
	if _compare(latest['collected_at'], cached['collected_at']):
		success = 'success'
		mdbl_cache.clear_mdbl_collection_watchlist_data('collection')
	if _compare(latest.get('rated_at'), cached.get('rated_at')):
		success = 'success'
		try:
			from modules import user_ratings
			user_ratings.clear_user_ratings_cache(1)
		except: pass
	# MDBList expose le timestamp dropped_at dans last_activities : tant qu'il ne
	# change pas, aucun appel sync/dropped supplémentaire n'est effectué.
	latest_dropped = latest.get('dropped_at') or ''
	cached_dropped = (cached or {}).get('dropped_at') or ''
	if latest_dropped != cached_dropped:
		dropped_ids = mdbl_dropped_show_ids() if latest_dropped else []
		if dropped_ids is None:
			# Conserve l'ancienne liste et force un nouvel essai au prochain cycle.
			latest['dropped_at'] = (cached or {}).get('dropped_at')
			mdbl_cache.reset_activity(latest)
		else:
			mdbl_cache.set_dropped_shows(dropped_ids)
			success = 'success'
	return success

def clear_mdbl_cache(silent=False):
	from modules.kodi_utils import path_exists, clear_property, database_connect, maincache_db
	try:
		if not path_exists(maincache_db): return True
		dbcon = database_connect(maincache_db, isolation_level=None)
		dbcur = dbcon.cursor()
		dbcur.execute("""PRAGMA synchronous = OFF""")
		dbcur.execute("""PRAGMA journal_mode = OFF""")
		dbcur.execute("""SELECT id FROM maincache WHERE id LIKE ?""", ('mdbl_%',))
		mdb_results = [str(i[0]) for i in dbcur.fetchall()]
		if not mdb_results: return True
		dbcur.execute("""DELETE FROM maincache WHERE id LIKE ?""", ('mdbl_%',))
		for i in mdb_results: clear_property(i)
		return True
	except: return False

def get_mdbl(params):
	results = []
	action = params['action']
	url = params['url']
	response = requests.get(url, timeout=timeout)
	if action == 'mdbl_parentsguide':
		def _process():
			for key, val in guide_map.items():
				try:
					if not (match := re.search(rf"{key}\:\ \d", html)): continue
					rank = rank_map[match.group().split(': ')[-1]]
					yield {'title': val, 'ranking': rank, 'listings': []}
				except: pass
		html = response.text.replace('\n', ' ')
		results = list(_process())
	return results

