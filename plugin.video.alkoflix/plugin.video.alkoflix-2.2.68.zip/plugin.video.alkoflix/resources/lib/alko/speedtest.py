# -*- coding: utf-8 -*-
# plugin.video.alkoflix
# resources/lib/alko/speedtest.py

import requests
from concurrent.futures import ThreadPoolExecutor as TPE, as_completed
from time import monotonic
import xbmc, xbmcaddon, xbmcgui
from modules.source_utils import external_sources as fs_sources
from modules.utils import manual_function_import

log = xbmc.log
Addon = xbmcaddon.Addon
list_item = xbmcgui.ListItem
dialog, select = xbmcgui.DialogProgress(), xbmcgui.Dialog().select
input, notification = xbmcgui.Dialog().input, xbmcgui.Dialog().notification

default_icon = Addon().getAddonInfo('icon')
movie_year_check_url = 'https://v2.sg.media-imdb.com/suggestion/t/%s.json'
total_str = 'TOTAL: [COLOR red][B]%s[/B][/COLOR]  |  '
total_str += '4K: [COLOR red][B]%d[/B][/COLOR]  |  1080p: [COLOR red][B]%d[/B][/COLOR]  |  '
total_str += '720p: [COLOR red][B]%d[/B][/COLOR]  |  SD: [COLOR red][B]%d[/B][/COLOR]'
input_str, nf_str = 'Enter a valid [B]Movie[/B] IMDb id:', 'Movie %s Not Found'
heading, resolutions = 'Magneto', '4K 1080p 720p SD'

NYAA_TEST_DATA = {
	'imdb': 'tt0245429',
	'tmdb': '129',
	'tmdb_id': '129',
	'title': 'Spirited Away',
	'aliases': ['Sen to Chihiro no Kamikakushi'],
	'year': '2001',
	'rootname': 'Spirited Away (2001)',
	'source_test': True
}


def _nyaa_test_data():
	"""Prépare le média dédié au test NYAA, avec sa vraie pochette si disponible."""
	data = dict(NYAA_TEST_DATA)
	data['poster'] = default_icon
	try:
		result = requests.get(movie_year_check_url % data['imdb'], timeout=5)
		if result.ok:
			payload = result.json()
			item = next((i for i in payload.get('d', []) if i.get('id') == data['imdb']), None)
			if item:
				data['poster'] = item.get('i', {}).get('imageUrl') or default_icon
				data['title'] = item.get('l') or data['title']
				data['year'] = str(item.get('y') or data['year'])
				data['rootname'] = '%s (%s)' % (data['title'], data['year'])
	except Exception:
		pass
	return data


def _refresh_settings_cache():
	# Le test est souvent lancé directement depuis la fenêtre des réglages. On force
	# une relecture afin qu'un manifest Custom 1/2 soit testé même si son interrupteur
	# provider.* est désactivé ou vient tout juste d'être modifié.
	try: xbmcgui.Window(10000).clearProperty('alkoflix_settings')
	except: pass

def _speedtest_sources():
	modules = list(fs_sources(ret_all=True))
	known = set(str(provider or '').lower() for provider, module in modules)
	# Filet de sécurité : les manifests personnalisés configurés doivent apparaître
	# dans « Tester toutes les sources » même lorsqu'ils sont désactivés comme source
	# normale. ret_all=True le prévoit déjà; ceci couvre aussi un cache/listing Kodi
	# incomplet au moment où la fenêtre de réglages est encore ouverte.
	for provider, import_path in (
		('zone_telechargement', 'magneto.hosters.zone_telechargement'),
		('wawacity', 'magneto.hosters.wawacity'),
		('free_telecharger', 'magneto.hosters.free_telecharger')
	):
		try:
			if provider in known: continue
			module = manual_function_import(import_path, 'source')
			modules.append((provider, module))
			known.add(provider)
		except Exception as e:
			log('>> alkoFlix <<: TEST ALL SOURCES | import failed | %s | %s' % (provider, type(e).__name__), xbmc.LOGINFO)

	for provider, setting_id, import_path in (
		('custom_1', 'custom_1.manifest_url', 'magneto.custom_1'),
		('custom_2', 'custom_2.manifest_url', 'magneto.custom_2')
	):
		try:
			manifest_url = Addon().getSetting(setting_id).strip()
			if not manifest_url or provider in known: continue
			module = manual_function_import(import_path, 'source')
			modules.append((provider, module))
			known.add(provider)
		except:
			pass
	return modules

def _resolve_movie_tmdb_id(imdb_id):
	# ALKO/alkoPaste est volontairement DB-only et cherche strictement par TMDb ID.
	# Le test des sources ne fournissait que l'IMDb ID, donc ALKO était bien appelée,
	# mais recevait une fiche impossible à chercher dans sa base SQLite locale.
	try:
		from indexers.tmdb_api import movie_external_id
		result = movie_external_id('imdb_id', imdb_id)
		tmdb_id = str((result or {}).get('id') or '').strip()
		return tmdb_id if tmdb_id and tmdb_id not in ('0', 'None', 'none', 'null') else ''
	except Exception as e:
		try:
			if Addon().getSetting('debug.enabled') == 'true': log('SpeedTest TMDb resolve failed: %s' % type(e).__name__, xbmc.LOGDEBUG)
		except: pass
	return ''

def get_movie_source(module):
	try:
		log('>> alkoFlix <<: TEST ALL SOURCES | start | %s' % str(module.name).upper(), xbmc.LOGINFO)
		start_time = monotonic()
		module.results = module.sources(module.data, {})
		module.elapsed = round(monotonic() - start_time, 3)
		if module.results is None:
			raise Exception('%s: %s fatal error' % (heading.upper(), module.name.upper()))
		for result in module.results:
			quality = result.get('quality')
			if not quality in module.metrics: module.metrics['SD'] += 1
			else: module.metrics[quality] = module.metrics.get(quality, 0) + 1
		log('>> alkoFlix <<: TEST ALL SOURCES | done | %s | results=%d | %.3fs' % (str(module.name).upper(), len(module.results or []), module.elapsed), xbmc.LOGINFO)
	except Exception as e:
		try: log('>> alkoFlix <<: TEST ALL SOURCES | error | %s | %s: %s' % (str(module.name).upper(), type(e).__name__, e), xbmc.LOGINFO)
		except: pass
		try:
			if Addon().getSetting('debug.enabled') == 'true': log(str(e), xbmc.LOGDEBUG)
		except: pass
	return module

def module_factory(modules, data=None):
	items = []
	for provider, module in modules:
		if not module.hasMovies: continue
		m = module()
		m.results, m.elapsed = None, 0
		module_data = dict(data or {})
		if str(provider or '').lower() == 'nyaa':
			module_data = _nyaa_test_data()
		m.name, m.data = provider, module_data
		m.metrics = dict.fromkeys(resolutions.split(), 0)
		items.append(m)
	return items

def _make_items(modules):
	for i, module in enumerate(modules):
		try:
			values = list(module.metrics.values())
			total = 'NONE' if module.results is None else sum(values)
			line1 = '%s: %.3fs' % (module.name.upper(), module.elapsed)
			line2 = total_str % (total, *values)
			icon = module.data['poster'] or default_icon
			item = list_item(line1, line2, offscreen=True)
			item.setArt({'icon': icon})
			yield item
		except: pass

def magneto():
	data = {'imdb': 'tt0448134', 'title': 'Sunshine', 'aliases': [], 'year': 2007}
	data['poster'] = default_icon

	imdb_id = input(input_str, defaultt=data['imdb'])
	url = movie_year_check_url % imdb_id
	dialog.create(heading, 'Please Wait...')
	dialog.update(0, 'Fetching Metadata...')
	result = requests.get(url, timeout=5)
	if result.ok:
		result = result.json()
		items = (i for i in result['d'] if i['id'] == imdb_id)
		items = next(items, None) or dialog.close()
		if not items: return notification(heading, nf_str % imdb_id, time=3000)
		data['poster'] = items.get('i', {}).get('imageUrl')
		data['title'] = items.get('l')
		data['imdb'] = items.get('id')
		data['year'] = items.get('y')
	tmdb_id = _resolve_movie_tmdb_id(data.get('imdb') or imdb_id)
	if tmdb_id:
		data['tmdb'] = tmdb_id
		data['tmdb_id'] = tmdb_id
	data['rootname'] = '%s (%s)' % (data['title'], data['year'])
	data['year'] = str(data['year'])

	_refresh_settings_cache()
	modules = module_factory(_speedtest_sources(), data)
	try: log('>> alkoFlix <<: TEST ALL SOURCES | modules=%s' % ','.join(str(i.name).upper() for i in modules), xbmc.LOGINFO)
	except: pass
	len_modules = len(modules)
	line0 = 'Title: %s' % data['rootname']
	with TPE(len_modules or 1) as tpe:
		futures = [tpe.submit(get_movie_source, i) for i in modules]
		for i, future in enumerate(as_completed(futures), 1):
			module = future.result()
			module_title = module.data.get('rootname') or data['rootname']
			line0 = 'Title: %s' % module_title
			line1 = 'Source: %s' % module.name.upper()
			line2 = 'Elapsed: %.3f' % module.elapsed
			line3 = 'Results: %3d' % sum(module.metrics.values())
			dialog.update(int(i / len_modules * 100), '[CR]'.join((line0, line1, line2, line3)))
	dialog.update(100, 'Processing Results...')
	modules.sort(key=lambda k: k.elapsed)
	results = [i for i in modules if i.results]
	modules = results + [i for i in modules if not i in results]
	items = list(_make_items(modules))
	dialog.close()
	select(f"{heading} - {data['rootname']}", items, useDetails=True)

