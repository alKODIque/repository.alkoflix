# -*- coding: utf-8 -*-
# plugin.video.alkoflix
# resources/lib/caches/watched_cache.py

import json
from datetime import datetime, timezone
from threading import Thread
from indexers import metadata
from indexers.mdblist_api import mdbl_watched_unwatched, mdbl_progress, mdbl_upnext, mdbl_native_tv_progress, clear_mdbl_upnext_cache
from indexers.trakt_api import trakt_watched_unwatched, trakt_official_status, trakt_progress, trakt_native_tv_progress, trakt_native_unwatched_episodes, clear_trakt_native_tv_progress_cache
from caches.mdbl_cache import clear_mdbl_collection_watchlist_data
from caches.trakt_cache import clear_trakt_collection_watchlist_data
from caches.favourites_cache import _meta_is_japanese, _meta_has_genre_id, _meta_has_genre_name
from modules import kodi_utils, settings, utils
from modules.list_sorting import apply_simple_context_sort, normalise_list_sort_key
# logger = kodi_utils.logger

timeout = 20
ls, sleep = kodi_utils.local_string, kodi_utils.sleep
progressDialogBG, execJSONRPC = kodi_utils.progressDialogBG, kodi_utils.execJSONRPC
get_datetime, adjust_premiered_date = utils.get_datetime, utils.adjust_premiered_date
make_thread_list = utils.make_thread_list
clean_file_name, paginate_list = utils.clean_file_name, utils.paginate_list
WATCHED_DB, TRAKT_DB, MDBL_DB = kodi_utils.watched_db, kodi_utils.trakt_db, kodi_utils.mdbl_db
indicators_dict = {0: WATCHED_DB, 1: TRAKT_DB, 2: MDBL_DB}

# Pour « Continuer à regarder », une série encore en diffusion qui paraît à jour
# avec les métadonnées en cache reçoit un contrôle TMDb ciblé. Les éventuels
# nouveaux totaux sont conservés pour le rendu de la liste durant cette requête
# Kodi, sans invalider ni raccourcir le cache global des métadonnées.
_fresh_aired_episode_overrides = {}

def _trakt_playback_fallback(message):
	try: kodi_utils.logger('trakt playback fallback', message)
	except: pass

def _database_connect(database_file):
	return kodi_utils.database_connect(database_file, timeout=timeout, isolation_level=None)

def set_PRAGMAS(dbcon):
	dbcur = dbcon.cursor()
	dbcur.execute("""PRAGMA synchronous = OFF""")
	dbcur.execute("""PRAGMA journal_mode = OFF""")
	return dbcur

def get_database(watched_indicators):
	return indicators_dict[watched_indicators]


def _safe_indicator(watched_indicators):
	try: return int(watched_indicators)
	except: return 0


def _local_last_played():
	return get_last_played_value(WATCHED_DB)


def _provider_datetime_to_local(value):
	"""Convertit une date Trakt/MDBList en date locale SQLite alkoFlix.

	Le fournisseur Local utilise toujours ``YYYY-MM-DD HH:MM:SS``. Conserver des
	dates ISO UTC dans watched.db rend notamment le tri « Prochain épisode »
	incohérent une fois Local sélectionné.
	"""
	raw = str(value or '').strip()
	if not raw: return ''
	try:
		iso_value = raw[:-1] + '+00:00' if raw.endswith('Z') else raw
		dt = datetime.fromisoformat(iso_value)
		if dt.tzinfo is None:
			# Une valeur déjà locale/naïve reste le même instant local.
			return dt.strftime('%Y-%m-%d %H:%M:%S')
		return dt.astimezone().strftime('%Y-%m-%d %H:%M:%S')
	except:
		# Valeurs locales historiques déjà au bon format.
		try: return datetime.strptime(raw[:19], '%Y-%m-%d %H:%M:%S').strftime('%Y-%m-%d %H:%M:%S')
		except: return raw


def _reset_local_watched_schema(dbcur):
	"""Recrée l'état Local comme un watched.db neuf, dans la transaction active."""
	for table in ('watched_status', 'progress', 'dropped_status'):
		dbcur.execute('DROP TABLE IF EXISTS %s' % table)
	dbcur.execute("""CREATE TABLE watched_status
				(db_type text, media_id text, season integer, episode integer, last_played text, title text,
				 unique(db_type, media_id, season, episode))""")
	dbcur.execute("""CREATE TABLE progress
				(db_type text, media_id text, season integer, episode integer, resume_point text, curr_time text,
				 last_played text, resume_id integer, title text, unique(db_type, media_id, season, episode))""")
	dbcur.execute("""CREATE TABLE dropped_status
				(media_id text primary key, title text, dropped_at text)""")


def _delete_bookmark_from_db(watched_indicators, media_type, tmdb_id, season='', episode=''):
	try:
		dbcon = _database_connect(get_database(_safe_indicator(watched_indicators)))
		dbcur = set_PRAGMAS(dbcon)
		dbcur.execute("""DELETE FROM progress WHERE db_type = ? AND media_id = ? AND season = ? AND episode = ?""", (media_type, tmdb_id, season, episode))
		return True
	except: return False


def _mirror_watched_status_to_local(action, media_type='', tmdb_id='', season='', episode='', title=''):
	# La base locale reste le filet de sécurité, même si Trakt ou MDBList
	# sont choisis comme fournisseur actif.
	try:
		dbcon = _database_connect(WATCHED_DB)
		dbcur = set_PRAGMAS(dbcon)
		if action == 'mark_as_watched':
			dbcur.execute("""INSERT OR REPLACE INTO watched_status VALUES (?, ?, ?, ?, ?, ?)""", (media_type, tmdb_id, season, episode, _local_last_played(), title))
		elif action == 'mark_as_unwatched':
			dbcur.execute("""DELETE FROM watched_status WHERE (db_type = ? and media_id = ? and season = ? and episode = ?)""", (media_type, tmdb_id, season, episode))
		return True
	except Exception as e:
		_trakt_playback_fallback('Miroir local watched_status impossible -> %s: %s' % (type(e).__name__, e))
		return False


def _mirror_batch_watched_status_to_local(insert_list, action):
	try:
		dbcon = _database_connect(WATCHED_DB)
		dbcur = set_PRAGMAS(dbcon)
		if action == 'mark_as_watched':
			last_played = _local_last_played()
			local_insert = [(i[0], i[1], i[2], i[3], last_played, i[5]) for i in insert_list]
			dbcur.executemany("""INSERT OR REPLACE INTO watched_status VALUES (?, ?, ?, ?, ?, ?)""", local_insert)
		elif action == 'mark_as_unwatched':
			dbcur.executemany("""DELETE FROM watched_status WHERE (db_type = ? and media_id = ? and season = ? and episode = ?)""", insert_list)
		return True
	except Exception as e:
		_trakt_playback_fallback('Miroir local batch watched_status impossible -> %s: %s' % (type(e).__name__, e))
		return False


def _provider_account_connected(watched_indicators):
	provider = _safe_indicator(watched_indicators)
	if provider == 1:
		return bool(kodi_utils.get_setting('trakt_user', '') or kodi_utils.get_setting('trakt.token', ''))
	if provider == 2:
		return bool(kodi_utils.get_setting('mdblist_user', '') or kodi_utils.get_setting('mdblist.access_token', '') or kodi_utils.get_setting('mdblist.token', ''))
	return False


def _refresh_provider_watched_cache(watched_indicators, force=False):
	provider = _safe_indicator(watched_indicators)
	if provider not in (1, 2) or not _provider_account_connected(provider): return 'no account'
	try:
		if provider == 1:
			from indexers.trakt_api import trakt_sync_activities
			# Une synchro manuelle Trakt -> Local doit repartir de l'API Trakt,
			# pas du pointeur sync/last_activities déjà en cache. Sinon un trakt.db
			# incomplet peut être recopié tel quel dans watched.db et vider les
			# dossiers construits depuis les épisodes vus (dont Prochain épisode).
			return trakt_sync_activities(force_update=bool(force))
		from indexers.mdblist_api import mdbl_sync_activities
		return mdbl_sync_activities(force_update=bool(force))
	except Exception as e:
		try: kodi_utils.logger('watched provider refresh', 'provider=%s | %s: %s' % (provider, type(e).__name__, e))
		except: pass
		return 'failed'



def _local_dropped_rows():
	"""Retourne les abandons stockés dans watched.db, indépendamment du fournisseur actif."""
	dbcon = None
	try:
		dbcon = _database_connect(WATCHED_DB)
		dbcur = set_PRAGMAS(dbcon)
		dbcur.execute("""CREATE TABLE IF NOT EXISTS dropped_status
					(media_id text primary key, title text, dropped_at text)""")
		return dbcur.execute("""SELECT media_id, title, dropped_at FROM dropped_status""").fetchall()
	except Exception as e:
		try: kodi_utils.logger('watched dropped local read', '%s: %s' % (type(e).__name__, e))
		except: pass
		return []
	finally:
		try:
			if dbcon: dbcon.close()
		except: pass


def _provider_dropped_rows(watched_indicators):
	"""Lit les séries abandonnées directement sur Trakt/MDBList.

	Retourne None si la lecture distante échoue afin de ne jamais confondre
	"liste vide" avec "service indisponible" et vider le Local par erreur.
	"""
	provider = _safe_indicator(watched_indicators)
	try:
		if provider == 1:
			from indexers.trakt_api import call_trakt, get_trakt_tvshow_id
			result, status = call_trakt(
				'users/hidden/dropped',
				params={'limit': 1000, 'type': 'show'},
				with_auth=True,
				pagination=False,
				return_status=True
			)
			if status not in (200, 201, 204) or result is None: return None
			rows = []
			for item in result or []:
				show = (item or {}).get('show') or {}
				ids = show.get('ids') or {}
				tmdb_id = ids.get('tmdb') or get_trakt_tvshow_id(ids)
				if tmdb_id in ('', None): continue
				rows.append((str(tmdb_id), str(show.get('title') or ''), _provider_datetime_to_local((item or {}).get('hidden_at') or '')))
			return rows
		if provider == 2:
			from indexers.mdblist_api import mdbl_dropped_items, get_mdbl_tvshow_id
			items = mdbl_dropped_items()
			if items is None: return None
			rows = []
			for item in items or []:
				show = (item or {}).get('show') or {}
				ids = show.get('ids') or {}
				tmdb_id = ids.get('tmdb') or get_mdbl_tvshow_id({
					'tmdb': ids.get('tmdb'), 'imdb': ids.get('imdb'), 'tvdb': ids.get('tvdb')
				})
				if tmdb_id in ('', None): continue
				rows.append((str(tmdb_id), str(show.get('title') or ''), _provider_datetime_to_local((item or {}).get('dropped_at') or '')))
			return rows
	except Exception as e:
		try: kodi_utils.logger('watched dropped provider read', 'provider=%s | %s: %s' % (provider, type(e).__name__, e))
		except: pass
	return None


def _write_provider_dropped_from_local(watched_indicators):
	"""Fusionne les abandons Local vers le fournisseur sans rien retirer à distance.

	Retourne ``(ok, total_local, skipped)``. Pour MDBList, ``not_found`` signifie
	qu'une série précise n'a pas pu être ajoutée (notamment si elle n'existe pas
	dans son historique) ; ce n'est pas une panne globale de la synchro.
	"""
	provider = _safe_indicator(watched_indicators)
	local_rows = _local_dropped_rows()
	remote_rows = _provider_dropped_rows(provider)
	if remote_rows is None:
		return False, 0, 0
	remote_ids = {str(i[0]) for i in remote_rows if i and i[0] not in ('', None)}
	missing = [i for i in local_rows if i and str(i[0]) not in remote_ids]
	if not missing:
		return True, len(local_rows), 0
	skipped = 0
	try:
		if provider == 1:
			from indexers.trakt_api import call_trakt
			from caches import trakt_cache
			for batch in _chunks(missing, 100):
				shows = []
				for media_id, _title, _dropped_at in batch:
					try: tmdb_id = int(media_id)
					except: tmdb_id = media_id
					shows.append({'ids': {'tmdb': tmdb_id}})
				_result, status = call_trakt('users/hidden/dropped', data={'shows': shows}, return_status=True)
				if status not in (200, 201, 204): return False, 0, skipped
				for media_id, _title, _dropped_at in batch:
					trakt_cache.update_trakt_hidden_data('dropped', media_id, hidden=True)
		else:
			from indexers.mdblist_api import call_mdblist
			from caches import mdbl_cache
			for batch in _chunks(missing, 100):
				shows = []
				for media_id, _title, dropped_at in batch:
					try: tmdb_id = int(media_id)
					except: tmdb_id = media_id
					item = {'ids': {'tmdb': tmdb_id}}
					provider_date = _watched_at_for_provider(dropped_at, provider)
					if provider_date: item['dropped_at'] = provider_date
					shows.append(item)
				result = call_mdblist('sync/dropped', json={'shows': shows}, method='post')
				if not _mdbl_sync_write_ok(result):
					return False, 0, skipped
				batch_skipped = max(0, _mdbl_not_found_count(result))
				skipped += batch_skipped
				if batch_skipped:
					try: kodi_utils.logger('watched dropped mdbl sync', 'ignored_not_found=%s' % batch_skipped)
					except: pass
				# Le cache local MDBList n'est mis à jour qu'après une relecture
				# distante, afin de ne pas marquer comme abandonnée une série que
				# MDBList vient justement de refuser en not_found.
		return True, len(local_rows), skipped
	except Exception as e:
		try: kodi_utils.logger('watched dropped local to provider', 'provider=%s | %s: %s' % (provider, type(e).__name__, e))
		except: pass
		return False, 0, skipped



def _provider_progress_rows_from_playback(provider, playback):
	"""Reconstruit les reprises via le moteur natif du fournisseur puis les relit.

	Le dossier « Continuer à regarder » du fournisseur et la copie vers Local
	doivent parler exactement la même langue. On évite donc une seconde
	normalisation parallèle des payloads playback dans la synchro manuelle.
	"""
	try:
		provider = _safe_indicator(provider)
		if provider == 1:
			from indexers.trakt_api import trakt_progress_movies, trakt_progress_tv
			trakt_progress_movies(playback or [])
			trakt_progress_tv(playback or [])
		elif provider == 2:
			from indexers.mdblist_api import mdbl_progress_movies, mdbl_progress_tv
			# MDBList peut envelopper /sync/playback dans {items:[...]}; les fonctions
			# natives attendent la liste réelle.
			items = playback
			if isinstance(items, dict):
				items = items.get('items') or items.get('results') or items.get('data') or []
			mdbl_progress_movies(items or [])
			mdbl_progress_tv(items or [])
		else:
			return []
		dbcon = _database_connect(get_database(provider))
		dbcur = set_PRAGMAS(dbcon)
		rows = dbcur.execute("""SELECT db_type, media_id, season, episode, resume_point, curr_time, last_played, resume_id, title FROM progress""").fetchall()
		result = []
		for row in rows:
			try:
				result.append((row[0], str(row[1]), row[2], row[3], row[4], row[5], _provider_datetime_to_local(row[6]), row[7], row[8]))
			except: continue
		try: dbcon.close()
		except: pass
		return result
	except Exception as e:
		try: kodi_utils.logger('watched provider progress snapshot', 'provider=%s | %s: %s' % (provider, type(e).__name__, e))
		except: pass
		return None


def _provider_snapshot_rows(watched_indicators):
	"""Construit un instantané distant Vu/Reprise sans dépendre d'un cache ancien.

	Les épisodes vus sont reconstruits directement depuis l'API. Les reprises sont
	normalisées par le moteur natif Trakt/MDBList, puis relues depuis son cache :
	cela garantit que Local reçoit exactement les mêmes films/épisodes « en cours »
	que le fournisseur lui-même.
	"""
	provider = _safe_indicator(watched_indicators)
	watched_rows = []
	try:
		if provider == 1:
			from indexers.trakt_api import trakt_fetch_all_pages, trakt_playback_progress, get_trakt_movie_id, get_trakt_tvshow_id
			from modules.utils import jsondate_to_datetime
			movies = trakt_fetch_all_pages({'path': 'sync/watched/movies', 'params': {'limit': 250}, 'with_auth': True})
			shows = trakt_fetch_all_pages({'path': 'sync/watched/shows', 'params': {'limit': 250, 'extended': 'progress'}, 'with_auth': True})
			playback = trakt_playback_progress()
			if movies is None or shows is None or playback is None: return None
			for item in movies or []:
				try:
					movie = item.get('movie') or {}
					tmdb_id = get_trakt_movie_id(movie.get('ids') or {})
					if not tmdb_id: continue
					watched_rows.append(('movie', str(tmdb_id), '', '', _provider_datetime_to_local(item.get('last_watched_at') or ''), movie.get('title') or ''))
				except: continue
			for item in shows or []:
				try:
					show = item.get('show') or {}
					tmdb_id = get_trakt_tvshow_id(show.get('ids') or {})
					if not tmdb_id: continue
					title = show.get('title') or ''
					reset_at = item.get('reset_at')
					try: reset_dt = jsondate_to_datetime(reset_at, '%Y-%m-%dT%H:%M:%S.%fZ') if reset_at else None
					except: reset_dt = None
					for season in item.get('seasons') or []:
						try: season_no = int(season.get('number'))
						except: continue
						for ep in season.get('episodes') or []:
							try:
								ep_no = int(ep.get('number'))
								last_watched_at = ep.get('last_watched_at') or ''
								if reset_dt and last_watched_at:
									try:
										if reset_dt > jsondate_to_datetime(last_watched_at, '%Y-%m-%dT%H:%M:%S.%fZ'): continue
									except: pass
								watched_rows.append(('episode', str(tmdb_id), season_no, ep_no, _provider_datetime_to_local(last_watched_at), title))
							except: continue
				except: continue
			progress_rows = _provider_progress_rows_from_playback(provider, playback)
			if progress_rows is None: return None
			return watched_rows, progress_rows

		if provider == 2:
			from indexers.mdblist_api import call_mdblist, mdbl_playback_progress, get_mdbl_movie_id, get_mdbl_tvshow_id
			params = {'limit': 5000}
			movies, episodes = [], []
			seen_cursors = set()
			for _ in range(1000):
				result = call_mdblist('sync/watched', params=params)
				if result is None or not isinstance(result, dict): return None
				movies.extend(result.get('movies') or [])
				episodes.extend(result.get('episodes') or [])
				pagination = result.get('pagination') or {}
				next_cursor = pagination.get('next_cursor') or result.get('next_cursor')
				if next_cursor:
					next_cursor = str(next_cursor)
					if next_cursor in seen_cursors: break
					seen_cursors.add(next_cursor)
					params['cursor'] = next_cursor
					params.pop('offset', None)
					continue
				if not pagination.get('has_more'): break
				page_count = len(result.get('movies') or []) + len(result.get('episodes') or []) + len(result.get('shows') or []) + len(result.get('seasons') or [])
				if page_count <= 0: break
				params.pop('cursor', None)
				params['offset'] = int(pagination.get('offset', params.get('offset', 0)) or 0) + int(pagination.get('limit', params.get('limit', 5000)) or params.get('limit', 5000))
			playback = mdbl_playback_progress()
			if playback is None: return None
			for item in movies:
				try:
					movie = item.get('movie') or {}
					tmdb_id = get_mdbl_movie_id({'tmdb': (movie.get('ids') or {}).get('tmdb'), 'imdb': (movie.get('ids') or {}).get('imdb'), 'tvdb': (movie.get('ids') or {}).get('tvdb')})
					if not tmdb_id: continue
					watched_rows.append(('movie', str(tmdb_id), '', '', _provider_datetime_to_local(item.get('last_watched_at') or ''), movie.get('title') or ''))
				except: continue
			for item in episodes:
				try:
					ep = item.get('episode') or {}
					show = ep.get('show') or item.get('show') or {}
					tmdb_id = get_mdbl_tvshow_id({'tmdb': (show.get('ids') or {}).get('tmdb'), 'imdb': (show.get('ids') or {}).get('imdb'), 'tvdb': (show.get('ids') or {}).get('tvdb')})
					if not tmdb_id: continue
					season_no, ep_no = int(ep.get('season')), int(ep.get('number'))
					watched_rows.append(('episode', str(tmdb_id), season_no, ep_no, _provider_datetime_to_local(item.get('last_watched_at') or ''), show.get('title') or ''))
				except: continue
			progress_rows = _provider_progress_rows_from_playback(provider, playback)
			if progress_rows is None: return None
			return watched_rows, progress_rows
	except Exception as e:
		try: kodi_utils.logger('watched provider snapshot', 'provider=%s | %s: %s' % (provider, type(e).__name__, e))
		except: pass
	return None

def sync_watched_provider_to_local(watched_indicators=None, reconcile=True, refresh_provider=False):
	"""Copie le fournisseur vers Local depuis un instantané distant complet.

	Le Local ne dépend plus du contenu momentané de trakt.db/mdbl.db. C'est
	important pour « Prochain épisode », qui exige les épisodes vus détaillés.
	"""
	provider = settings.watched_indicators() if watched_indicators is None else _safe_indicator(watched_indicators)
	if provider not in (1, 2): return {'success': False, 'watched': 0, 'progress': 0, 'dropped': 0}
	if not _provider_account_connected(provider): return {'success': False, 'watched': 0, 'progress': 0, 'dropped': 0}
	snapshot = _provider_snapshot_rows(provider)
	if snapshot is None:
		return {'success': False, 'watched': 0, 'progress': 0, 'dropped': 0}
	watched_rows, progress_rows = snapshot
	dropped_rows = _provider_dropped_rows(provider)
	if dropped_rows is None:
		return {'success': False, 'watched': 0, 'progress': 0, 'dropped': 0}
	dest = None
	try:
		dest = _database_connect(WATCHED_DB)
		dst = set_PRAGMAS(dest)
		dst.execute('BEGIN IMMEDIATE')
		if reconcile:
			# Une synchronisation fournisseur -> Local est une restauration complète :
			# on recrée les tables comme lors de la suppression manuelle de watched.db.
			# Cela évite qu'un ancien schéma/état SQLite survive entre deux fournisseurs.
			_reset_local_watched_schema(dst)
		else:
			dst.execute("""CREATE TABLE IF NOT EXISTS watched_status
					(db_type text, media_id text, season integer, episode integer, last_played text, title text,
					 unique(db_type, media_id, season, episode))""")
			dst.execute("""CREATE TABLE IF NOT EXISTS progress
					(db_type text, media_id text, season integer, episode integer, resume_point text, curr_time text,
					 last_played text, resume_id integer, title text, unique(db_type, media_id, season, episode))""")
			dst.execute("""CREATE TABLE IF NOT EXISTS dropped_status
					(media_id text primary key, title text, dropped_at text)""")
		if watched_rows:
			dst.executemany("""INSERT OR REPLACE INTO watched_status VALUES (?, ?, ?, ?, ?, ?)""", watched_rows)
		if progress_rows:
			dst.executemany("""INSERT OR REPLACE INTO progress VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""", progress_rows)
		if dropped_rows:
			dst.executemany("""INSERT OR REPLACE INTO dropped_status (media_id, title, dropped_at) VALUES (?, ?, ?)""", dropped_rows)
		dest.commit()
		# Rafraîchit ensuite le cache fournisseur pour ses propres menus, mais une
		# éventuelle panne ici ne peut plus effacer le Local qui vient d'être écrit.
		if refresh_provider:
			try: _refresh_provider_watched_cache(provider, force=False)
			except: pass
		try: kodi_utils.logger('watched provider to local', 'DIRECT | provider=%s | watched=%s | episodes=%s | progress=%s | dropped=%s | reconcile=%s' % (provider, len(watched_rows), len([i for i in watched_rows if i[0] == 'episode']), len(progress_rows), len(dropped_rows), reconcile))
		except: pass
		return {'success': True, 'watched': len(watched_rows), 'progress': len(progress_rows), 'dropped': len(dropped_rows)}
	except Exception as e:
		try:
			if dest: dest.rollback()
		except: pass
		try: kodi_utils.logger('watched provider to local', 'FAILED DIRECT | provider=%s | %s: %s' % (provider, type(e).__name__, e))
		except: pass
		return {'success': False, 'watched': 0, 'progress': 0, 'dropped': 0}
	finally:
		try:
			if dest: dest.close()
		except: pass


def _watched_at_for_provider(value, watched_indicators):
	"""Convertit last_played vers le format UTC attendu par Trakt/MDBList.

	La base Local enregistre les actions faites dans alkoFlix en heure locale
	(YYYY-MM-DD HH:MM:SS), tandis qu'une synchro provenant de Trakt/MDBList
	peut déjà contenir une date ISO UTC. Dans les deux cas, on conserve
	l'instant d'origine au lieu de laisser le service distant utiliser "maintenant".
	"""
	raw = str(value or '').strip()
	if not raw: return ''
	try:
		iso_value = raw[:-1] + '+00:00' if raw.endswith('Z') else raw
		dt = datetime.fromisoformat(iso_value)
		# Une date locale alkoFlix est volontairement naïve : astimezone() lui
		# applique le fuseau du système Kodi avant la conversion UTC.
		if dt.tzinfo is None: dt = dt.astimezone()
		dt = dt.astimezone(timezone.utc)
		if _safe_indicator(watched_indicators) == 1:
			return '%s.%03dZ' % (dt.strftime('%Y-%m-%dT%H:%M:%S'), dt.microsecond // 1000)
		return dt.strftime('%Y-%m-%dT%H:%M:%SZ')
	except Exception:
		# Ne jamais jeter un historique pour une ancienne valeur inhabituelle :
		# les APIs acceptent aussi plusieurs variantes ISO 8601.
		return raw


def _local_watched_payload(watched_indicators):
	dbcon = None
	try:
		dbcon = _database_connect(WATCHED_DB)
		dbcur = set_PRAGMAS(dbcon)
		watched_rows = dbcur.execute("""SELECT db_type, media_id, season, episode, last_played FROM watched_status""").fetchall()
		progress_rows = dbcur.execute("""SELECT db_type, media_id, season, episode, resume_point FROM progress""").fetchall()
	except:
		watched_rows, progress_rows = [], []
	finally:
		try:
			if dbcon: dbcon.close()
		except: pass

	movies, shows_map = [], {}
	for db_type, media_id, season, episode, last_played in watched_rows:
		try:
			watched_at = _watched_at_for_provider(last_played, watched_indicators)
			if db_type == 'movie':
				item = {'ids': {'tmdb': int(media_id)}}
				if watched_at: item['watched_at'] = watched_at
				movies.append(item)
			elif db_type == 'episode':
				show = shows_map.setdefault(int(media_id), {})
				season_map = show.setdefault(int(season), {})
				season_map[int(episode)] = watched_at
		except: pass
	shows = []
	for tmdb_id, seasons in shows_map.items():
		season_data = []
		for season_no in sorted(seasons):
			episodes = []
			for ep in sorted(seasons[season_no]):
				if ep < 0: continue
				item = {'number': ep}
				watched_at = seasons[season_no].get(ep)
				if watched_at: item['watched_at'] = watched_at
				episodes.append(item)
			if episodes: season_data.append({'number': season_no, 'episodes': episodes})
		if season_data: shows.append({'ids': {'tmdb': tmdb_id}, 'seasons': season_data})
	return movies, shows, progress_rows


def _chunks(items, size):
	items = list(items or [])
	for pos in range(0, len(items), size): yield items[pos:pos + size]


def _mdbl_not_found_count(result):
	"""Retourne le nombre d'éléments explicitement refusés par MDBList."""
	if not isinstance(result, dict): return -1
	not_found = result.get('not_found') or {}
	if isinstance(not_found, dict):
		total = 0
		for value in not_found.values():
			if isinstance(value, list): total += len(value)
			else:
				try: total += int(value or 0)
				except: pass
		return total
	if isinstance(not_found, list): return len(not_found)
	try: return int(not_found or 0)
	except: return 0


def _mdbl_sync_write_ok(result):
	"""Retourne True quand MDBList a réellement répondu à l'écriture.

	Les éléments ``not_found`` sont des refus unitaires (par exemple une série
	absente de l'historique MDBList) et ne doivent pas transformer toute la
	synchronisation en échec. Ils sont comptés séparément et signalés à
	l'utilisateur.
	"""
	return isinstance(result, dict)


def sync_watched_local_to_provider(watched_indicators, refresh_provider=True):
	"""Fusionne Local vers Trakt/MDBList sans supprimer l'historique distant."""
	provider = _safe_indicator(watched_indicators)
	if provider not in (1, 2) or not _provider_account_connected(provider):
		return {'success': False, 'watched': 0, 'progress': 0, 'dropped': 0}
	movies, shows, progress_rows = _local_watched_payload(provider)
	ok = True
	skipped = 0
	try:
		if provider == 1:
			from indexers.trakt_api import call_trakt
			for batch in _chunks(movies, 100):
				_result, status = call_trakt('sync/history', data={'movies': batch}, return_status=True)
				ok = ok and status in (200, 201, 204)
			for batch in _chunks(shows, 50):
				_result, status = call_trakt('sync/history', data={'shows': batch}, return_status=True)
				ok = ok and status in (200, 201, 204)
		else:
			from indexers.mdblist_api import call_mdblist
			for batch in _chunks(movies, 100):
				result = call_mdblist('sync/watched', json={'movies': batch}, method='post')
				if not _mdbl_sync_write_ok(result):
					ok = False
				else:
					batch_skipped = max(0, _mdbl_not_found_count(result))
					skipped += batch_skipped
					if batch_skipped:
						try: kodi_utils.logger('watched mdbl sync', 'movies ignored_not_found=%s' % batch_skipped)
						except: pass
			for batch in _chunks(shows, 50):
				result = call_mdblist('sync/watched', json={'shows': batch}, method='post')
				if not _mdbl_sync_write_ok(result):
					ok = False
				else:
					batch_skipped = max(0, _mdbl_not_found_count(result))
					skipped += batch_skipped
					if batch_skipped:
						try: kodi_utils.logger('watched mdbl sync', 'shows ignored_not_found=%s' % batch_skipped)
						except: pass

		progress_count = 0
		for db_type, media_id, season, episode, resume_point in progress_rows:
			try:
				percent = float(resume_point or 0)
				if percent <= 0 or percent >= 100: continue
				if provider == 1: trakt_progress('set_progress', db_type, media_id, percent, season, episode, refresh_trakt=False)
				else: mdbl_progress('set_progress', db_type, media_id, percent, season, episode, refresh_mdb=False)
				progress_count += 1
			except Exception:
				ok = False
		dropped_ok, dropped_count, dropped_skipped = _write_provider_dropped_from_local(provider)
		skipped += dropped_skipped
		ok = ok and dropped_ok
		if refresh_provider: _refresh_provider_watched_cache(provider)
		watched_count = len(movies) + sum(len(s.get('episodes') or []) for show in shows for s in show.get('seasons') or [])
		try: kodi_utils.logger('watched local to provider', 'provider=%s | watched=%s | progress=%s | dropped=%s | skipped=%s | success=%s' % (provider, watched_count, progress_count, dropped_count, skipped, ok))
		except: pass
		return {'success': bool(ok), 'watched': watched_count, 'progress': progress_count, 'dropped': dropped_count, 'skipped': skipped}
	except Exception as e:
		try: kodi_utils.logger('watched local to provider', 'FAILED | provider=%s | %s: %s' % (provider, type(e).__name__, e))
		except: pass
		return {'success': False, 'watched': 0, 'progress': 0, 'dropped': 0, 'skipped': skipped}


def manual_watched_sync(params):
	provider_name = str(params.get('provider') or '').strip().lower()
	direction = str(params.get('direction') or '').strip().lower()
	provider = 1 if provider_name == 'trakt' else 2 if provider_name in ('mdblist', 'mdbl') else 0
	name = 'Trakt' if provider == 1 else 'MDBList' if provider == 2 else ''
	if not provider or not _provider_account_connected(provider):
		kodi_utils.notification('%s non connecté' % (name or 'Service'), time=3000)
		return False
	if direction == 'to_local':
		if not kodi_utils.confirm_dialog(heading='Synchronisation des visionnages', text='Remplacer les statuts locaux alkoFlix par ceux de %s ?' % name): return False
		result = sync_watched_provider_to_local(provider, reconcile=True, refresh_provider=True)
		message = '%s → Local : synchronisation terminée' % name if result.get('success') else '%s → Local : synchronisation impossible' % name
	else:
		if not kodi_utils.confirm_dialog(heading='Synchronisation des visionnages', text='Fusionner les statuts locaux alkoFlix vers %s ?[CR][CR]Aucun historique présent sur %s ne sera supprimé.' % (name, name)): return False
		result = sync_watched_local_to_provider(provider, refresh_provider=True)
		if result.get('success'):
			skipped = int(result.get('skipped') or 0)
			if provider == 2 and skipped:
				message = 'Local → MDBList : terminée (%s élément%s ignoré%s par MDBList)' % (skipped, '' if skipped == 1 else 's', '' if skipped == 1 else 's')
			else:
				message = 'Local → %s : synchronisation terminée' % name
		else:
			message = 'Local → %s : synchronisation impossible' % name
	kodi_utils.notification(message, time=3500)
	return bool(result.get('success'))

def _mdbl_dropped_ids(watched_indicators):
	try:
		if _safe_indicator(watched_indicators) != 2: return set()
		from caches import mdbl_cache
		return set(str(i) for i in (mdbl_cache.get_dropped_shows() or []))
	except: return set()

def _trakt_dropped_ids(watched_indicators):
	try:
		if _safe_indicator(watched_indicators) != 1: return set()
		from indexers.trakt_api import trakt_get_hidden_items
		return set(map(str, trakt_get_hidden_items('dropped')))
	except: return set()

def _local_dropped_ids(watched_indicators):
	try:
		if _safe_indicator(watched_indicators) != 0: return set()
		dbcon = _database_connect(WATCHED_DB)
		dbcur = set_PRAGMAS(dbcon)
		dbcur.execute("""CREATE TABLE IF NOT EXISTS dropped_status
					(media_id text primary key, title text, dropped_at text)""")
		dbcur.execute("""SELECT media_id FROM dropped_status""")
		return {str(i[0]) for i in dbcur.fetchall() if i and i[0] not in ('', None)}
	except: return set()

def _active_dropped_ids(watched_indicators):
	return _local_dropped_ids(watched_indicators) | _mdbl_dropped_ids(watched_indicators) | _trakt_dropped_ids(watched_indicators)

def get_dropped_tvshow_ids(watched_indicators=None):
	try: watched_indicators = settings.watched_indicators() if watched_indicators is None else int(watched_indicators)
	except: watched_indicators = settings.watched_indicators()
	return _active_dropped_ids(watched_indicators)

def toggle_local_dropped(params):
	"""Bascule l'état Abandonné dans le fournisseur de visionnage local alkoFlix."""
	tmdb_id = str(params.get('tmdb_id') or '').strip()
	if not tmdb_id or tmdb_id == 'None':
		kodi_utils.notification(32574)
		return False
	title = str(params.get('title') or '')
	try:
		dbcon = _database_connect(WATCHED_DB)
		dbcur = set_PRAGMAS(dbcon)
		dbcur.execute("""CREATE TABLE IF NOT EXISTS dropped_status
					(media_id text primary key, title text, dropped_at text)""")
		dbcur.execute("""SELECT media_id FROM dropped_status WHERE media_id = ?""", (tmdb_id,))
		is_dropped = not dbcur.fetchone() is None
		if is_dropped:
			dbcur.execute("""DELETE FROM dropped_status WHERE media_id = ?""", (tmdb_id,))
			message = 'Série retirée des abandonnées'
		else:
			dropped_at = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
			dbcur.execute("""INSERT OR REPLACE INTO dropped_status (media_id, title, dropped_at) VALUES (?, ?, ?)""", (tmdb_id, title, dropped_at))
			message = 'Série marquée comme abandonnée'
		kodi_utils.notification(message, time=2500)
		kodi_utils.container_refresh()
		return True
	except Exception as e:
		try: kodi_utils.logger('alkoflix dropped error', '%s: %s' % (type(e).__name__, e))
		except: pass
		kodi_utils.notification(32574)
		return False

def get_local_dropped_tvshows(dummy_arg, page_no, letter, paginate=None, list_sort='', list_random_seed=''):
	"""Retourne les séries abandonnées stockées dans watched.db pour le fournisseur local."""
	paginate = settings.paginate() if paginate is None else paginate
	try:
		dbcon = _database_connect(WATCHED_DB)
		dbcur = set_PRAGMAS(dbcon)
		dbcur.execute("""CREATE TABLE IF NOT EXISTS dropped_status
					(media_id text primary key, title text, dropped_at text)""")
		dbcur.execute("""SELECT media_id, title, dropped_at FROM dropped_status ORDER BY dropped_at DESC""")
		data = [{'media_id': str(i[0]), 'title': i[1] or '', 'last_played': i[2] or ''} for i in dbcur.fetchall() if i and i[0] not in ('', None)]
	except: data = []
	if list_sort and normalise_list_sort_key(list_sort) != 'original':
		data = apply_simple_context_sort(data, {'list_sort': list_sort, 'list_random_seed': list_random_seed}, date_key='last_played', added_key='last_played', watched_key='last_played')
	if paginate: return paginate_list(data, page_no, letter, settings.page_limit())
	return data, 1

def _catalogue_filter_rows(media_type, data, catalogue_section, id_getter):
	allowed_ids = _progress_catalogue_ids(media_type, catalogue_section)
	if allowed_ids is None: return data
	return [i for i in data if str(id_getter(i) or '') in allowed_ids]

def get_next_episodes(watched_info, watched_indicators=None, catalogue_section='', progress_group=''):
	seen = set()
	try: watched_indicators = settings.watched_indicators() if watched_indicators is None else int(watched_indicators)
	except: watched_indicators = settings.watched_indicators()
	dropped = _active_dropped_ids(watched_indicators)
	if watched_indicators == 2:
		# MDBList expose directement le prochain épisode exact via /upnext.
		# Ne pas le reconstruire avec « dernier épisode vu + 1 ».
		native = mdbl_upnext()
		if native is not None:
			native = [i for i in native if str(i.get('media_ids', {}).get('tmdb')) not in dropped]
			native = _catalogue_filter_rows('tvshow', native, catalogue_section, lambda i: i.get('media_ids', {}).get('tmdb'))
			return native
	# Comportement de la stable 2.2.43 : le plus grand SxxEyy vu est
	# l'ancre de progression ET sa propre date last_played sert au tri.
	# On conserve seulement l'exclusion S00 introduite ensuite.
	def _regular_watched_row(row):
		try: return not row[0] is None and int(row[1]) > 0 and not str(row[0]) in dropped
		except: return False
	watched_info = [i for i in watched_info if _regular_watched_row(i)]
	watched_info = _catalogue_filter_rows('tvshow', watched_info, catalogue_section, lambda i: i[0])
	watched_info.sort(key=lambda x: (x[0], x[1], x[2]), reverse=True)
	return [
		{'media_ids': {'tmdb': int(i[0])}, 'season': int(i[1]), 'episode': int(i[2]), 'last_played': i[4]}
		for i in watched_info
		if not (i[0] in seen or seen.add(i[0]))
	]

def get_resumetime(bookmarks, tmdb_id, season='', episode=''):
	try: resume_point, curr_time, resume_id = detect_bookmark(bookmarks, tmdb_id, season, episode)
	except: resume_point, curr_time, resume_id = 0, 0, 0
	try: progress = str(int(round(float(resume_point))))
	except: progress = '0'
	try: resumetime = str(int(round(float(curr_time))))
	except: resumetime = '0'
	return resumetime, progress

def set_resumetime(resumetime, progress, duration):
	try: resumetime, progress = float(resumetime), float(progress)
	except: return float(0), duration
	return resumetime or progress * duration / 100, duration

def detect_bookmark(bookmarks, tmdb_id, season='', episode=''):
	return [(i[1], i[2], i[5]) for i in bookmarks if i[0] == str(tmdb_id) and i[3] == season and i[4] == episode][0]

def get_bookmarks(watched_indicators, media_type):
	try:
		dbcon = _database_connect(get_database(watched_indicators))
		dbcur = set_PRAGMAS(dbcon)
		result = dbcur.execute("""SELECT media_id, resume_point, curr_time, season, episode, resume_id FROM progress WHERE db_type = ?""", (media_type,))
		return result.fetchall()
	except: pass

def _erase_bookmark_local_only(watched_indicators, media_type, tmdb_id, season='', episode=''):
	_delete_bookmark_from_db(watched_indicators, media_type, tmdb_id, season, episode)


def _valid_resume_id(value):
	return value not in (None, '', 0, '0', False)


def _remote_resume_id(watched_indicators, media_type, tmdb_id, season='', episode=''):
	"""Retourne l'ID réel de la reprise chez le fournisseur actif.

	Trakt et MDBList utilisent un identifiant de playback distinct du TMDb ID.
	Cet ID doit être conservé pour pouvoir supprimer précisément une progression.
	"""
	try:
		target = str(tmdb_id)
		if watched_indicators == 1:
			from indexers.trakt_api import trakt_playback_progress, get_trakt_movie_id, get_trakt_tvshow_id
			items = trakt_playback_progress() or []
			for item in items:
				try:
					if media_type in ('movie', 'movies'):
						if item.get('type') != 'movie': continue
						if str(get_trakt_movie_id((item.get('movie') or {}).get('ids') or {})) != target: continue
					else:
						if item.get('type') != 'episode': continue
						if str(get_trakt_tvshow_id((item.get('show') or {}).get('ids') or {})) != target: continue
						ep = item.get('episode') or {}
						if (int(ep.get('season', -1)), int(ep.get('number', -1))) != (int(season), int(episode)): continue
					resume_id = item.get('id')
					if _valid_resume_id(resume_id): return resume_id
				except: continue
		elif watched_indicators == 2:
			from indexers.mdblist_api import mdbl_playback_progress, get_mdbl_movie_id, get_mdbl_tvshow_id
			items = mdbl_playback_progress() or []
			for item in items:
				try:
					if media_type in ('movie', 'movies'):
						if item.get('type') != 'movie': continue
						if str(get_mdbl_movie_id((item.get('movie') or {}).get('ids') or {})) != target: continue
					else:
						if item.get('type') != 'episode': continue
						if str(get_mdbl_tvshow_id((item.get('show') or {}).get('ids') or {})) != target: continue
						ep = item.get('episode') or {}
						if (int(ep.get('season', -1)), int(ep.get('number', -1))) != (int(season), int(episode)): continue
					resume_id = item.get('id')
					if _valid_resume_id(resume_id): return resume_id
				except: continue
	except Exception as e:
		_trakt_playback_fallback('ID reprise distante introuvable -> provider=%s | %s: %s' % (watched_indicators, type(e).__name__, e))
	return None


def _get_resume_id(watched_indicators, media_type, tmdb_id, season='', episode='', remote_fallback=True):
	try:
		bookmarks = get_bookmarks(watched_indicators, media_type) or []
		resume_id = detect_bookmark(bookmarks, tmdb_id, season, episode)[2]
		if _valid_resume_id(resume_id): return resume_id
	except: pass
	if remote_fallback and watched_indicators in (1, 2):
		return _remote_resume_id(watched_indicators, media_type, tmdb_id, season, episode)
	return None


def _store_bookmark_local(watched_indicators, media_type, tmdb_id, curr_time, total_time, title, season='', episode='', resume_point=None, resume_id=0):
	try:
		if resume_point is None:
			adjusted_current_time = max(float(curr_time) - 5, 0)
			resume_point = round(adjusted_current_time / float(total_time) * 100, 1)
		data_base = get_database(watched_indicators)
		last_played = get_last_played_value(data_base)
		_erase_bookmark_local_only(watched_indicators, media_type, tmdb_id, season, episode)
		dbcon = _database_connect(data_base)
		dbcur = set_PRAGMAS(dbcon)
		dbcur.execute("""INSERT OR REPLACE INTO progress VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
					(media_type, tmdb_id, season, episode, str(resume_point), str(curr_time), last_played, resume_id or 0, title))
		return True
	except Exception as e:
		_trakt_playback_fallback('Point de reprise local impossible -> %s: %s' % (type(e).__name__, e))
		return False


def set_bookmark(media_type, tmdb_id, curr_time, total_time, title, season='', episode=''):
	try:
		adjusted_current_time = max(float(curr_time) - 5, 0)
		resume_point = round(adjusted_current_time/float(total_time)*100, 1)
		watched_indicators = settings.watched_indicators()
		resume_id = 0
		if watched_indicators == 1:
			try:
				trakt_progress('set_progress', media_type, tmdb_id, resume_point, season, episode, refresh_trakt=True)
				resume_id = _get_resume_id(watched_indicators, media_type, tmdb_id, season, episode, remote_fallback=True) or 0
			except Exception as e: _trakt_playback_fallback('Trakt progression ignorée, reprise locale conservée -> %s: %s' % (type(e).__name__, e))
		elif watched_indicators == 2:
			try:
				mdbl_progress('set_progress', media_type, tmdb_id, resume_point, season, episode, refresh_mdb=True)
				resume_id = _get_resume_id(watched_indicators, media_type, tmdb_id, season, episode, remote_fallback=True) or 0
			except Exception as e: _trakt_playback_fallback('MDBList progression ignorée, reprise locale conservée -> %s: %s' % (type(e).__name__, e))
		_store_bookmark_local(watched_indicators, media_type, tmdb_id, curr_time, total_time, title, season, episode, resume_point, resume_id)
		if settings.sync_kodi_library_watchstatus():
			set_bookmark_kodi_library(media_type, tmdb_id, curr_time, total_time, season, episode)
		kodi_utils.container_refresh()
	except Exception as e:
		_trakt_playback_fallback('Point de reprise impossible -> %s: %s' % (type(e).__name__, e))

def erase_bookmark(media_type, tmdb_id, season='', episode='', refresh='false'):
	try:
		watched_indicators = settings.watched_indicators()
		if media_type == 'episode': season, episode = int(season), int(episode)
		# Toujours utiliser le véritable ID de playback du fournisseur. Les anciennes
		# versions pouvaient avoir sauvegardé 0 dans la colonne resume_id ; dans ce
		# cas on le retrouve directement chez Trakt/MDBList avant la suppression.
		resume_id = _get_resume_id(watched_indicators, media_type, tmdb_id, season, episode, remote_fallback=True)
		if watched_indicators in (1, 2) and _valid_resume_id(resume_id):
			try:
				if watched_indicators == 1:
					trakt_progress('clear_progress', media_type, tmdb_id, 0, season, episode, resume_id, refresh_trakt=True)
				else:
					mdbl_progress('clear_progress', media_type, tmdb_id, 0, season, episode, resume_id, refresh_mdb=True)
			except Exception as e:
				_trakt_playback_fallback('Suppression progression distante impossible -> provider=%s | id=%s | %s: %s' % (watched_indicators, resume_id, type(e).__name__, e))
		# La progression est une couche indépendante du statut Vu : retirer la
		# reprise ne touche jamais watched_status. Le prochain rendu retombe donc
		# naturellement sur le Vu historique s'il existe.
		_delete_bookmark_from_db(watched_indicators, media_type, tmdb_id, season, episode)
		if refresh == 'true':
			# Une action manuelle doit rafraîchir le conteneur courant ET les widgets.
			# TMDb Helper fait également les deux après une modification de progression.
			kodi_utils.container_refresh()
			try: kodi_utils.widget_refresh()
			except: pass
	except Exception as e:
		_trakt_playback_fallback('Suppression point de reprise impossible -> %s: %s' % (type(e).__name__, e))

def batch_erase_bookmark(watched_indicators, insert_list, action):
	try:
		if action == 'mark_as_watched': modified_list = [(i[0], i[1], i[2], i[3]) for i in insert_list]
		else: modified_list = insert_list
		if watched_indicators == 1:
			def _process(arg):
				try: trakt_progress(*arg)
				except: pass
			process_list = []
			process_list_append = process_list.append
			media_type = insert_list[0][0]
			tmdb_id = insert_list[0][1]
			bookmarks = get_bookmarks(watched_indicators, media_type)
			for i in insert_list:
				try: resume_point, curr_time, resume_id = detect_bookmark(bookmarks, tmdb_id, i[2], i[3])
				except: continue
				process_list_append(('clear_progress', i[0], i[1], 0, i[2], i[3], resume_id))
			if process_list: threads = list(make_thread_list(_process, process_list, Thread))
		elif watched_indicators == 2:
			def _process(arg):
				try: mdbl_progress(*arg)
				except: pass
			process_list = []
			process_list_append = process_list.append
			media_type = insert_list[0][0]
			tmdb_id = insert_list[0][1]
			bookmarks = get_bookmarks(watched_indicators, media_type)
			for i in insert_list:
				try: resume_point, curr_time, resume_id = detect_bookmark(bookmarks, tmdb_id, i[2], i[3])
				except: continue
				process_list_append(('clear_progress', i[0], i[1], 0, i[2], i[3], resume_id))
			if process_list: threads = list(make_thread_list(_process, process_list, Thread))
		dbcon = _database_connect(get_database(watched_indicators))
		dbcur = set_PRAGMAS(dbcon)
		dbcur.executemany("""DELETE FROM progress where db_type = ? and media_id = ? and season = ? and episode = ?""", modified_list)
	except: pass

def get_watched_info_movie(watched_indicators):
	info = []
	try:
		dbcon = _database_connect(get_database(watched_indicators))
		dbcur = set_PRAGMAS(dbcon)
		dbcur.execute("""SELECT media_id, title, last_played FROM watched_status WHERE db_type = ?""", ('movie',))
		info = dbcur.fetchall()
	except: pass
	return info

def get_watched_info_tv(watched_indicators):
	info = []
	try:
		dbcon = _database_connect(get_database(watched_indicators))
		dbcur = set_PRAGMAS(dbcon)
		dbcur.execute("""SELECT media_id, season, episode, title, last_played FROM watched_status WHERE db_type = ?""", ('episode',))
		info = dbcur.fetchall()
	except: pass
	return info

def _progress_catalogue_ids(media_type, section=''):
	"""IDs autorisés par une section du Catalogue alkoPaste.

	None signifie qu'aucune restriction de catalogue n'est demandée. Une section
	explicite qui ne retourne aucun ID reste volontairement vide : un menu
	alkoPaste ne doit jamais déborder sur le catalogue TMDb général.
	"""
	section = str(section or '').strip()
	if not section: return None
	# Un dossier alkoPaste parent peut regrouper plusieurs sections du même type
	# (ex. Docus & Télé = documentary_series + replay). Le séparateur « | »
	# permet de conserver les sections sources distinctes tout en construisant une
	# vue de suivi/recommandation commune, sans modifier le contenu des catalogues.
	sections = [i.strip() for i in section.split('|') if i.strip()]
	try:
		from magneto.alkopaste import alkopaste_catalogue_section_id_set
		wanted = 'film' if str(media_type or '').lower() in ('movie', 'film') else 'serie'
		allowed = set()
		for section_id in sections:
			allowed.update(str(i) for i in alkopaste_catalogue_section_id_set(section_id, wanted) if i)
		return allowed
	except Exception as e:
		try: kodi_utils.logger('in-progress catalogue filter', 'section=%s | error=%s' % (section, e))
		except: pass
		return set()


def _progress_matches_context(media_type, meta, progress_group=''):
	"""Filtre les suivis selon exactement le tiroir TMDb/alkoPaste affiché."""
	group = str(progress_group or '').strip().lower()
	if group in ('', 'all', 'global', 'combined'): return True
	media_type = 'movie' if str(media_type or '').lower() in ('movie', 'film') else 'tvshow'
	animation = _meta_has_genre_id(meta, ('16',)) or _meta_has_genre_name(meta, ('animation', 'anime', 'animé', 'dessin animé', 'dessins animés'))
	japanese_animation = bool(animation and _meta_is_japanese(meta))
	family = _meta_has_genre_id(meta, ('10751', '10762')) or _meta_has_genre_name(meta, ('family', 'famille', 'kids', 'enfants'))

	if media_type == 'movie':
		documentary = _meta_has_genre_id(meta, ('99', '10770')) or _meta_has_genre_name(meta, ('documentary', 'documentaire', 'tv movie', 'téléfilm', 'telefilm'))
		is_doc = _meta_has_genre_id(meta, ('99',)) or _meta_has_genre_name(meta, ('documentary', 'documentaire'))
		is_tv_movie = _meta_has_genre_id(meta, ('10770',)) or _meta_has_genre_name(meta, ('tv movie', 'téléfilm', 'telefilm'))
		# Un Téléfilm reste un film pour les suivis du tiroir Films, tout en étant
		# également visible dans Docus & Télé. Seuls les vrais documentaires (99)
		# et l'animation restent exclus du groupe Films racine.
		if group == 'movie_root': return not (animation or is_doc)
		if group in ('documentary', 'documentary_movie_root'): return documentary
		if group == 'movie_documentary': return is_doc
		if group == 'movie_tv_movie': return is_tv_movie
		if group in ('family', 'movie_family'): return family
		if group in ('animation', 'movie_animation'): return bool(animation and not japanese_animation)
		if group in ('anime', 'anime_movie'): return japanese_animation
	else:
		is_doc = _meta_has_genre_id(meta, ('99',)) or _meta_has_genre_name(meta, ('documentary', 'documentaire'))
		is_news = _meta_has_genre_id(meta, ('10763',)) or _meta_has_genre_name(meta, ('news', 'actualité', 'actualités'))
		is_reality = _meta_has_genre_id(meta, ('10764',)) or _meta_has_genre_name(meta, ('reality', 'téléréalité', 'telerealite', 'télé-réalité'))
		is_talk = _meta_has_genre_id(meta, ('10767',)) or _meta_has_genre_name(meta, ('talk', 'talk show', 'talk-show', 'talkshow'))
		documentary = bool(is_doc or is_news or is_reality or is_talk)
		if group == 'tv_root': return not (animation or documentary)
		if group in ('documentary', 'documentary_series_root'): return documentary
		if group == 'series_documentary': return is_doc
		if group == 'series_reality': return is_reality
		if group == 'series_talkshow': return is_talk
		if group == 'series_news': return is_news
		if group in ('family', 'series_family'): return family
		if group in ('animation', 'series_animation'): return bool(animation and not japanese_animation)
		if group in ('anime', 'anime_series'): return japanese_animation
	return True


def _progress_filter_rows_by_meta(media_type, rows, progress_group='', id_getter=None):
	"""Applique le filtre éditorial à une liste déjà issue du cache de visionnage.

	L'ordre d'origine est conservé même si les métadonnées sont chargées en parallèle.
	"""
	rows = list(rows or [])
	group = str(progress_group or '').strip().lower()
	if not rows or group in ('', 'all', 'global', 'combined'): return rows
	id_getter = id_getter or (lambda item: item.get('media_id') if isinstance(item, dict) else item)
	meta_user_info = settings.metadata_user_info()
	keep_ids = set()
	def _process(item):
		try:
			tmdb_id = id_getter(item)
			if tmdb_id in ('', None): return
			tmdb_id = str(tmdb_id)
			if str(media_type).lower() in ('movie', 'film'):
				meta = metadata.movie_meta('tmdb_id', tmdb_id, meta_user_info, get_datetime())
			else:
				meta = metadata.tvshow_meta('tmdb_id', tmdb_id, meta_user_info, get_datetime())
			if meta and not meta.get('blank_entry', False) and _progress_matches_context(media_type, meta, group):
				keep_ids.add(tmdb_id)
		except: pass
	threads = list(make_thread_list(_process, rows, Thread))
	[i.join() for i in threads]
	result = []
	for item in rows:
		try:
			if str(id_getter(item)) in keep_ids: result.append(item)
		except: pass
	return result


def _in_progress_movie_candidates(watched_indicators, progress_group='', catalogue_section=''):
	dbcon = _database_connect(get_database(watched_indicators))
	dbcur = set_PRAGMAS(dbcon)
	dbcur.execute("""SELECT media_id, last_played, title FROM progress WHERE db_type = ?""", ('movie',))
	data = [{'media_id': str(i[0]), 'title': i[2], 'last_played': i[1]} for i in dbcur.fetchall() if i[0] not in ('', None)]
	allowed_ids = _progress_catalogue_ids('movie', catalogue_section)
	if allowed_ids is not None:
		data = [i for i in data if i['media_id'] in allowed_ids]
	group = str(progress_group or '').strip().lower()
	if not data or group in ('', 'all', 'global', 'combined'): return data
	meta_user_info = settings.metadata_user_info()
	filtered = []
	filtered_append = filtered.append
	def _process(item):
		try:
			meta = metadata.movie_meta('tmdb_id', item['media_id'], meta_user_info, get_datetime())
			if meta and not meta.get('blank_entry', False) and _progress_matches_context('movie', meta, group): filtered_append(item)
		except: pass
	threads = list(make_thread_list(_process, data, Thread))
	[i.join() for i in threads]
	return filtered


def _tvshow_run_is_finished(meta):
	# Une série n'est réellement « terminée » que lorsque TMDb indique que sa
	# diffusion est finie. Être à jour sur tous les épisodes déjà diffusés ne
	# suffit pas : Returning Series / In Production restent des suivis en cours.
	try:
		status = str((meta or {}).get('status') or '').strip().lower()
		return status in ('ended', 'canceled', 'cancelled')
	except: return False


def _fresh_regular_aired_episode_count(tmdb_id, meta_user_info):
	"""Retourne le nombre actuel d'épisodes réguliers déjà diffusés selon TMDb.

	Ce contrôle ne passe volontairement pas par le cache de fiche série : il sert
	uniquement à départager le cas ambigu « série en diffusion mais compteur à
	100 % ». La saison 00 n'entre jamais dans ce total.
	"""
	try:
		data = metadata.tvshow_data(tmdb_id, meta_user_info.get('language', 'fr'), meta_user_info.get('tmdb_api'))
		if not data or data.get('success', True) is False: return None
		status = str(data.get('status') or '').strip().lower()
		# Pour une série réellement terminée, number_of_episodes correspond au
		# total des saisons régulières TMDb (les Specials/S00 sont séparés).
		if status in ('ended', 'canceled', 'cancelled'):
			return max(0, int(data.get('number_of_episodes') or 0))
		last_ep = data.get('last_episode_to_air') or {}
		try:
			last_season = int(last_ep.get('season_number') or 0)
			last_episode = int(last_ep.get('episode_number') or 0)
		except: last_season, last_episode = 0, 0
		# Certaines fiches TMDb en diffusion ont un last_episode_to_air vide ou
		# momentanément en retard alors que next_episode_to_air est déjà renseigné.
		# Dans ce cas, « prochain épisode - 1 » est un meilleur repère que
		# number_of_episodes, qui inclut aussi les épisodes futurs déjà créés.
		if last_season <= 0 or last_episode <= 0:
			next_ep = data.get('next_episode_to_air') or {}
			try:
				next_season = int(next_ep.get('season_number') or 0)
				next_episode = int(next_ep.get('episode_number') or 0)
			except: next_season, next_episode = 0, 0
			if next_season <= 0 or next_episode <= 0: return None
			last_season, last_episode = next_season, max(0, next_episode - 1)
		total = last_episode
		for season in data.get('seasons') or []:
			season_no = int(season.get('season_number') or 0)
			if 0 < season_no < last_season:
				total += int(season.get('episode_count') or 0)
		return max(0, total)
	except: return None


def get_effective_total_aired_eps(tmdb_id, aired_eps):
	"""Applique le total frais calculé pour « Continuer à regarder », s'il existe."""
	try:
		return int(_fresh_aired_episode_overrides.get(str(tmdb_id), aired_eps) or 0)
	except:
		try: return int(aired_eps or 0)
		except: return 0


def _in_progress_tv_candidates(watched_indicators, progress_group='', catalogue_section='', continue_watching=False):
	# « Continuer à regarder » doit signifier la même chose pour tous les fournisseurs :
	# conserver uniquement les séries pour lesquelles il reste au moins un épisode
	# déjà diffusé et non vu. Les épisodes futurs/non diffusés ne rendent jamais une
	# série éligible à ce suivi.
	candidates = {}
	def _remember(media_id, title='', last_played=''):
		if media_id in ('', None): return
		media_id = str(media_id)
		current = candidates.get(media_id)
		if not current:
			candidates[media_id] = {'media_id': media_id, 'title': title or '', 'last_played': last_played or ''}
			return
		if str(last_played or '') > str(current.get('last_played') or ''):
			current.update({'title': title or current.get('title') or '', 'last_played': last_played or current.get('last_played') or ''})

	watched_info = get_watched_info_tv(watched_indicators)
	provider_progress = get_provider_tv_progress(watched_indicators) if watched_indicators in (1, 2) else {}
	# Pour « Continuer à regarder », les fournisseurs distants font foi : on part
	# directement de leur liste de séries dont la progression est incomplète.
	if continue_watching and provider_progress:
		for native_item in provider_progress.values():
			try:
				if int(native_item.get('unwatched_episodes') or 0) <= 0: continue
				_remember(native_item.get('media_id'), native_item.get('title', ''), native_item.get('last_played', ''))
			except: pass
	else:
		for i in watched_info:
			try: _remember(i[0], i[3], i[4])
			except: pass
	try:
		dbcon = _database_connect(get_database(watched_indicators))
		dbcur = set_PRAGMAS(dbcon)
		dbcur.execute("""SELECT media_id, last_played, title FROM progress WHERE db_type = ?""", ('episode',))
		for media_id, last_played, title in dbcur.fetchall():
			# Une reprise active est indépendante du compteur "watched" du fournisseur.
			# Exemple : S01E01 entamé d'une nouvelle série n'existe pas encore dans
			# la liste native des séries regardées Trakt/MDBList, mais doit malgré
			# tout faire apparaître la série dans « Continuer à regarder ».
			_remember(media_id, title, last_played)
	except: pass
	allowed_ids = _progress_catalogue_ids('tvshow', catalogue_section)
	dropped = _active_dropped_ids(watched_indicators)
	prelim_data = [i for i in candidates.values() if not str(i['media_id']) in dropped]
	if allowed_ids is not None:
		prelim_data = [i for i in prelim_data if i['media_id'] in allowed_ids]
	if not prelim_data: return []
	meta_user_info = settings.metadata_user_info()
	group = str(progress_group or '').strip().lower()
	data = []
	data_append = data.append
	def _process(item):
		try:
			tmdb_id = item['media_id']
			meta = metadata.tvshow_meta('tmdb_id', tmdb_id, meta_user_info, get_datetime())
			if not meta or meta.get('blank_entry', False): return
			aired_eps = get_effective_total_aired_eps(tmdb_id, meta.get('total_aired_eps'))
			provider_status = get_watched_status_tvshow_provider(watched_indicators, watched_info, tmdb_id, aired_eps, provider_progress)
			watched_status = provider_status[:4]
			# Continuer à regarder = ce qui est disponible maintenant, pour TOUS les fournisseurs.
			# Si le cache TMDb dit que tout est vu mais que la série est encore en
			# diffusion, on vérifie UNE FOIS le total actuel directement auprès de
			# TMDb. Ainsi, un nouvel épisode fait réapparaître la série immédiatement
			# sans raccourcir le cache global ni toucher à « Prochain épisode ».
			if continue_watching and watched_status[0] != 0:
				if watched_indicators == 0 and not _tvshow_run_is_finished(meta):
					fresh_aired_eps = _fresh_regular_aired_episode_count(tmdb_id, meta_user_info)
					if fresh_aired_eps is not None:
						_fresh_aired_episode_overrides[str(tmdb_id)] = fresh_aired_eps
						watched_status = get_watched_status_tvshow(watched_info, tmdb_id, fresh_aired_eps)
				if watched_status[0] != 0: return
			# Hors « Continuer à regarder », conserver le comportement existant.
			if watched_status[0] != 0 and _tvshow_run_is_finished(meta): return
			if not _progress_matches_context('tvshow', meta, group): return
			data_append(item)
		except: pass
	threads = list(make_thread_list(_process, prelim_data, Thread))
	[i.join() for i in threads]
	return data


def _sort_progress_items(data, list_sort='', list_random_seed=''):
	if list_sort and normalise_list_sort_key(list_sort) != 'original':
		return apply_simple_context_sort(data, {'list_sort': list_sort, 'list_random_seed': list_random_seed}, date_key='last_played', added_key='last_played', watched_key='last_played')
	return sorted(data, key=lambda x: x.get('last_played') or '', reverse=True)


def get_in_progress_movies(dummy_arg, page_no, letter, list_sort='', list_random_seed='', watched_indicators=None, progress_group='', catalogue_section=''):
	try: watched_indicators = settings.watched_indicators() if watched_indicators is None else int(watched_indicators)
	except: watched_indicators = settings.watched_indicators()
	paginate = settings.paginate()
	limit = settings.page_limit()
	data = _in_progress_movie_candidates(watched_indicators, progress_group, catalogue_section)
	if not data: return [], 1
	original_list = _sort_progress_items(data, list_sort, list_random_seed)
	if paginate: final_list, total_pages = paginate_list(original_list, page_no, letter, limit)
	else: final_list, total_pages = original_list, 1
	return final_list, total_pages

def _dedup_recent_tvshows_from_watched(watched_indicators):
	# Retourne les séries présentes dans l'historique de visionnage, dédupliquées
	# par série et triées sur le dernier épisode vu. Cette approche reste légère :
	# aucune requête TMDb n'est nécessaire pour remplir le menu/widget.
	watched_info = get_watched_info_tv(watched_indicators)
	dropped = _active_dropped_ids(watched_indicators)
	candidates = {}
	for media_id, season, episode, title, last_played in watched_info:
		if media_id in ('', None) or str(media_id) in dropped: continue
		media_id = str(media_id)
		current = candidates.get(media_id)
		if not current or str(last_played or '') > str(current.get('last_played') or ''):
			candidates[media_id] = {'media_id': media_id, 'title': title or '', 'last_played': last_played or ''}
	return list(candidates.values())


def _paginate_progress_tvshows(data, page_no, letter, paginate, list_sort='', list_random_seed='', log_name='trakt in-progress tvshows'):
	limit = settings.page_limit()
	if not data:
		try: kodi_utils.logger(log_name, 'EMPTY | source=watched_status')
		except: pass
		return [], 1
	if list_sort and normalise_list_sort_key(list_sort) != 'original':
		original_list = apply_simple_context_sort(data, {'list_sort': list_sort, 'list_random_seed': list_random_seed}, date_key='last_played', added_key='last_played', watched_key='last_played')
	else:
		original_list = sorted(data, key=lambda x: x.get('last_played') or '', reverse=True)
	if paginate: final_list, total_pages = paginate_list(original_list, page_no, letter, limit)
	else: final_list, total_pages = original_list, 1
	try: kodi_utils.logger(log_name, 'source=watched_status | candidates=%s | page_items=%s | page=%s/%s' % (len(original_list), len(final_list), page_no, total_pages))
	except: pass
	return final_list, total_pages


def get_in_progress_tvshows(dummy_arg, page_no, letter, paginate=None, watched_indicators=None, list_sort='', list_random_seed=''):
	# « Séries vues récemment » : historique de séries réellement visionnées,
	# et non seulement épisodes laissés en reprise.
	try: watched_indicators = settings.watched_indicators() if watched_indicators is None else int(watched_indicators)
	except: watched_indicators = settings.watched_indicators()
	paginate = settings.paginate() if paginate is None else paginate
	data = _dedup_recent_tvshows_from_watched(watched_indicators)
	return _paginate_progress_tvshows(data, page_no, letter, paginate, list_sort, list_random_seed, 'recent tvshows')


def get_in_progress_unwatched_tvshows(dummy_arg, page_no, letter, paginate=None, watched_indicators=None, list_sort='', list_random_seed='', progress_group='', catalogue_section='', continue_watching=False):
	# Le mode strict n'est activé que par le dossier « Continuer à regarder », mais
	# sa définition est identique pour alkoFlix/local, Trakt et MDbList.
	try: watched_indicators = settings.watched_indicators() if watched_indicators is None else int(watched_indicators)
	except: watched_indicators = settings.watched_indicators()
	paginate = settings.paginate() if paginate is None else paginate
	data = _in_progress_tv_candidates(watched_indicators, progress_group, catalogue_section, continue_watching)
	return _paginate_progress_tvshows(data, page_no, letter, paginate, list_sort, list_random_seed, 'in-progress tvshows')


def get_in_progress_combined(dummy_arg, page_no, letter, progress_group='all', movie_catalogue_section='', tv_catalogue_section='', watched_indicators=None, list_sort='', list_random_seed=''):
	"""Liste mixte Films + Séries en cours, avec un seul ordre et une seule pagination."""
	try: watched_indicators = settings.watched_indicators() if watched_indicators is None else int(watched_indicators)
	except: watched_indicators = settings.watched_indicators()
	movies = _in_progress_movie_candidates(watched_indicators, progress_group, movie_catalogue_section)
	tvshows = _in_progress_tv_candidates(watched_indicators, progress_group, tv_catalogue_section)
	data = []
	for item in movies:
		row = dict(item); row['media_type'] = 'movie'; data.append(row)
	for item in tvshows:
		row = dict(item); row['media_type'] = 'tvshow'; data.append(row)
	if not data: return [], 1
	original_list = _sort_progress_items(data, list_sort, list_random_seed)
	if settings.paginate():
		return paginate_list(original_list, page_no, letter, settings.page_limit())
	return original_list, 1

def get_in_progress_episodes(list_sort='', list_random_seed='', watched_indicators=None, catalogue_section='', progress_group=''):
	try: watched_indicators = settings.watched_indicators() if watched_indicators is None else int(watched_indicators)
	except: watched_indicators = settings.watched_indicators()
	dbcon = _database_connect(get_database(watched_indicators))
	dbcur = set_PRAGMAS(dbcon)
	dbcur.execute("""SELECT media_id, season, episode, resume_point, last_played, title FROM progress WHERE db_type = ?""", ('episode',))
	rows = dbcur.fetchall()
	dropped = _active_dropped_ids(watched_indicators)
	rows = [i for i in rows if not i[0] == '' and not str(i[0]) in dropped]
	rows = _catalogue_filter_rows('tvshow', rows, catalogue_section, lambda i: i[0])
	rows = _progress_filter_rows_by_meta('tvshow', rows, progress_group, lambda i: i[0])
	data = [
		{'media_ids': {'tmdb': i[0]}, 'season': int(i[1]), 'episode': int(i[2]), 'resume_point': float(i[3]), 'last_played': i[4], 'title': i[5]}
		for i in rows
	]
	if list_sort and normalise_list_sort_key(list_sort) != 'original': episode_list = apply_simple_context_sort(data, {'list_sort': list_sort, 'list_random_seed': list_random_seed}, date_key='last_played', added_key='last_played', watched_key='last_played')
	else: episode_list = sorted(data, key=lambda k: k.get('last_played') or '', reverse=True)
	return episode_list

def get_watched_items(media_type, page_no, letter, paginate=None, list_sort='', list_random_seed='', watched_indicators=None, catalogue_section='', progress_group=''):
	paginate = settings.paginate() if paginate is None else paginate
	limit = settings.page_limit()
	try: watched_indicators = settings.watched_indicators() if watched_indicators is None else int(watched_indicators)
	except: watched_indicators = settings.watched_indicators()
	if media_type == 'tvshow':
		# « Séries terminées » : il faut deux conditions cumulatives : TMDb doit
		# indiquer que la série est réellement finie (Ended/Canceled), ET tous les
		# épisodes diffusés doivent être vus. Être simplement « à jour » ne suffit pas.
		watched_info = get_watched_info_tv(watched_indicators)
		candidates = {}
		for media_id, season, episode, title, last_played in watched_info:
			if media_id in ('', None): continue
			media_id = str(media_id)
			current = candidates.get(media_id)
			if not current or str(last_played or '') > str(current.get('last_played') or ''):
				candidates[media_id] = {'media_id': media_id, 'title': title or '', 'last_played': last_played or ''}
		data = list(candidates.values())
		data = _catalogue_filter_rows(media_type, data, catalogue_section, lambda i: i.get('media_id'))
		if data:
			meta_user_info = settings.metadata_user_info()
			completed = []
			completed_append = completed.append
			def _process(item):
				try:
					tmdb_id = str(item['media_id'])
					meta = metadata.tvshow_meta('tmdb_id', tmdb_id, meta_user_info, get_datetime())
					if not meta or meta.get('blank_entry', False): return
					if not _progress_matches_context('tvshow', meta, progress_group): return
					status = get_watched_status_tvshow_provider(watched_indicators, watched_info, tmdb_id, meta.get('total_aired_eps'))[:4]
					if _tvshow_run_is_finished(meta) and status[0] == 1: completed_append(item)
				except: pass
			threads = list(make_thread_list(_process, data, Thread))
			[i.join() for i in threads]
			data = completed
	else:
		# Un film présent dans watched_status est, par définition, terminé.
		watched_info = get_watched_info_movie(watched_indicators)
		data = [{'media_id': i[0], 'title': i[1], 'last_played': i[2]} for i in watched_info]
		data = _catalogue_filter_rows(media_type, data, catalogue_section, lambda i: i.get('media_id'))
		data = _progress_filter_rows_by_meta('movie', data, progress_group, lambda i: i.get('media_id'))
	if list_sort and normalise_list_sort_key(list_sort) != 'original': original_list = apply_simple_context_sort(data, {'list_sort': list_sort, 'list_random_seed': list_random_seed}, date_key='last_played', added_key='last_played', watched_key='last_played')
	else: original_list = sorted(data, key=lambda x: x.get('last_played') or '', reverse=True)
	if paginate: final_list, total_pages = paginate_list(original_list, page_no, letter, limit)
	else: final_list, total_pages = original_list, 1
	return final_list, total_pages

def _resume_episode_keys(watched_indicators, tmdb_id):
	"""Épisodes actuellement entamés pour une série chez le fournisseur actif.

	La reprise est une couche distincte du statut Vu. Elle doit donc rester
	visible dans « Continuer à regarder » même si le fournisseur n'a encore
	aucun épisode terminé pour cette série.
	"""
	keys = set()
	try:
		dbcon = _database_connect(get_database(_safe_indicator(watched_indicators)))
		dbcur = set_PRAGMAS(dbcon)
		dbcur.execute("""SELECT season, episode, resume_point, curr_time FROM progress WHERE db_type = ? AND media_id = ?""", ('episode', str(tmdb_id)))
		for season, episode, resume_point, curr_time in dbcur.fetchall():
			try:
				# Une ligne de reprise valide suffit. Les S00 entamés restent eux aussi
				# reprenables, sans pour autant entrer dans le compteur global série.
				if float(resume_point or 0) <= 0 and float(curr_time or 0) <= 0: continue
				keys.add((int(season), int(episode)))
			except: continue
	except: pass
	return keys


def get_continue_watching_episode_keys(watched_indicators, tmdb_id):
	"""Retourne les épisodes autorisés dans « Continuer à regarder ».

	Pour Trakt/MDBList, le prochain épisode natif du fournisseur reste la source
	de vérité. On lui ajoute toutefois les épisodes avec une reprise active : un
	épisode entamé doit toujours rester accessible, même avant le premier épisode
	complètement vu de la série.

	None signifie que la donnée native n'est pas disponible et autorise le repli
	local historique. Un set vide signifie qu'il n'y a actuellement aucun épisode
	actionnable.
	"""
	try: provider = int(watched_indicators)
	except: provider = 0
	resume_keys = _resume_episode_keys(provider, tmdb_id)
	if provider == 1:
		progress = trakt_native_tv_progress() or {}
		item = progress.get(str(tmdb_id))
		if not item: return resume_keys or None
		episodes = trakt_native_unwatched_episodes(tmdb_id, item)
		if episodes is None: return resume_keys or None
		keys = {(int(i['season']), int(i['episode'])) for i in episodes}
		return keys | resume_keys
	if provider == 2:
		try:
			progress = mdbl_native_tv_progress() or {}
			item = progress.get(str(tmdb_id))
			if not item: return resume_keys or None
			expected = max(0, int(item.get('unwatched_episodes') or 0))
			if expected <= 0: return resume_keys

			# /upnext MDBList ne fournit qu'un seul épisode par série. Il sert donc
			# uniquement de point de départ canonique, pas de liste complète.
			native = mdbl_upnext()
			if native is None: return resume_keys or None
			next_key = None
			for ep in native:
				try:
					if str((ep.get('media_ids') or {}).get('tmdb')) != str(tmdb_id): continue
					candidate = (int(ep.get('season')), int(ep.get('episode')))
					if candidate[0] > 0 and candidate[1] > 0:
						next_key = candidate
						break
				except: pass
			if not next_key: return resume_keys or None

			# Comme pour Trakt, on conserve ensuite tous les épisodes réguliers déjà
			# diffusés à partir du point de départ natif, jusqu'au nombre réellement
			# non vu annoncé par MDBList. Les anciens trous ne réapparaissent pas.
			meta_user_info = settings.metadata_user_info()
			current_date = get_datetime()
			meta = metadata.tvshow_meta('tmdb_id', tmdb_id, meta_user_info, current_date)
			if not meta or meta.get('blank_entry', False): return {next_key} | resume_keys
			episodes_data = metadata.all_episodes_meta(meta, meta_user_info, Thread) or []
			adjust_hours = settings.date_offset()
			available = []
			for ep in episodes_data:
				try:
					season_no, episode_no = int(ep.get('season') or 0), int(ep.get('episode') or 0)
					if season_no <= 0 or episode_no <= 0: continue
					key = (season_no, episode_no)
					if key < next_key: continue
					premiered = ep.get('premiered')
					if not premiered: continue
					episode_date = adjust_premiered_date(premiered, adjust_hours)[0]
					if episode_date and episode_date <= current_date: available.append(key)
				except: pass
			available = sorted(set(available))
			if next_key not in available: available.insert(0, next_key)
			return set(available[:expected]) | resume_keys
		except Exception as e:
			try: kodi_utils.logger('mdbl native continue error', 'tmdb_id=%s | %s: %s' % (tmdb_id, type(e).__name__, e))
			except: pass
			return resume_keys or None
	return None

def get_provider_tv_progress(watched_indicators):
	"""Retourne la progression native du fournisseur actif, quand il en fournit une."""
	try: watched_indicators = int(watched_indicators)
	except: watched_indicators = 0
	try:
		if watched_indicators == 1: return trakt_native_tv_progress() or {}
		if watched_indicators == 2: return mdbl_native_tv_progress() or {}
	except Exception as e:
		try: kodi_utils.logger('native tv progress', 'provider=%s | %s: %s' % (watched_indicators, type(e).__name__, e))
		except: pass
	return {}


def get_watched_status_tvshow_provider(watched_indicators, watched_info, tmdb_id, aired_eps, provider_progress=None):
	"""Statut série en donnant priorité aux compteurs natifs Trakt/MDBList.

	Retourne playcount, overlay, watched, unwatched, aired. Pour le fournisseur
	local alkoFlix (ou si le service distant ne fournit pas cette série), on garde
	le calcul TMDb/local existant comme repli.
	"""
	tmdb_id = str(tmdb_id)
	try: provider = int(watched_indicators)
	except: provider = 0
	if provider in (1, 2):
		try:
			progress = provider_progress if provider_progress is not None else get_provider_tv_progress(provider)
			item = (progress or {}).get(tmdb_id)
			if item and int(item.get('aired_episodes') or 0) > 0:
				aired = max(0, int(item.get('aired_episodes') or 0))
				watched = max(0, int(item.get('watched_episodes') or 0))
				if aired > 0: watched = min(watched, aired)
				unwatched = max(0, aired - watched)
				playcount, overlay = (1, 5) if aired and watched >= aired else (0, 4)
				return playcount, overlay, watched, unwatched, aired
		except Exception: pass
	playcount, overlay, watched, unwatched = get_watched_status_tvshow(watched_info, tmdb_id, aired_eps)
	try: aired = max(0, int(aired_eps or 0))
	except: aired = 0
	return playcount, overlay, watched, unwatched, aired


def get_watched_status_movie(watched_info, tmdb_id):
	try:
		watched = [i for i in watched_info if i[0] == tmdb_id]
		if watched: return 1, 5
		return 0, 4
	except: return 0, 4

def get_watched_status_tvshow(watched_info, tmdb_id, aired_eps):
	# Le total TMDb des épisodes diffusés concerne les saisons régulières. Les
	# épisodes S00/Specials gardent leur propre statut « vu », mais ne doivent
	# jamais gonfler le compteur global d'une série ni la faire passer à 100 %.
	playcount, overlay, watched = 0, 4, 0
	try: aired_eps = max(0, int(aired_eps or 0))
	except: aired_eps = 0
	unwatched = aired_eps
	try:
		def _regular_episode(row):
			try: return row[0] == tmdb_id and int(row[1]) > 0
			except: return False
		watched = len([i for i in watched_info if _regular_episode(i)])
		unwatched = max(0, aired_eps - watched)
		if watched >= aired_eps and aired_eps != 0: playcount, overlay = 1, 5
	except: pass
	return playcount, overlay, watched, unwatched

def get_watched_status_season(watched_info, tmdb_id, season, aired_eps):
	playcount, overlay, watched = 0, 4, 0
	try: aired_eps = max(0, int(aired_eps or 0))
	except: aired_eps = 0
	unwatched = aired_eps
	try:
		raw_watched = len([i for i in watched_info if i[0] == tmdb_id and i[1] == season])
		# Un épisode futur marqué vu par un service externe ne doit pas rendre le
		# compteur de saison négatif ni gonfler la progression disponible.
		watched = min(raw_watched, aired_eps) if aired_eps else 0
		unwatched = max(0, aired_eps - watched)
		if watched >= aired_eps and aired_eps != 0: playcount, overlay = 1, 5
	except: pass
	return playcount, overlay, watched, unwatched

def get_watched_status_episode(watched_info, tmdb_id, season='', episode=''):
	try:
		watched = [i for i in watched_info if i[0] == tmdb_id and (i[1], i[2]) == (season, episode)]
		if watched: return 1, 5
		else: return 0, 4
	except: return 0, 4

def mark_as_watched_unwatched_movie(params):
	media_type, action = 'movie', params.get('action')
	tmdb_id, title, year = params.get('tmdb_id'), params.get('title'), params.get('year')
	refresh, from_playback = params.get('refresh', 'true') == 'true', params.get('from_playback', 'false') == 'true'
	watched_indicators = settings.watched_indicators()
	if watched_indicators == 1:
		trakt_ok = True
		if from_playback and not settings.trakt_token() and trakt_official_status(media_type) is False:
			kodi_utils.sleep(3000)
		else:
			trakt_ok = trakt_watched_unwatched(action, 'movies', tmdb_id)
			if not trakt_ok and from_playback:
				kodi_utils.sleep(1500)
				trakt_ok = trakt_watched_unwatched(action, 'movies', tmdb_id)
			if not trakt_ok:
				if not from_playback: return kodi_utils.notification(32574)
				_trakt_playback_fallback('Film marqué localement malgré une réponse Trakt invalide -> title=%s | tmdb_id=%s' % (title, tmdb_id))
		clear_trakt_collection_watchlist_data('watchlist', media_type)
	elif watched_indicators == 2:
		if not mdbl_watched_unwatched(action, 'movies', tmdb_id): return kodi_utils.notification(32574)
		clear_mdbl_collection_watchlist_data('watchlist')
	mark_as_watched_unwatched(watched_indicators, media_type, tmdb_id, action, title=title)
	# « Marquer comme vu » est une action explicite et doit devenir l'état
	# courant du film. On retire donc toute reprise précédente (locale et,
	# lorsque disponible, Trakt/MDBList). Une lecture ultérieure pourra créer
	# une nouvelle reprise et remettre naturellement le film « En cours ».
	if action == 'mark_as_watched': erase_bookmark(media_type, tmdb_id)
	if settings.sync_kodi_library_watchstatus():
		mark_as_watched_unwatched_kodi_library(media_type, action, title, year)
	if refresh: kodi_utils.container_refresh()

def mark_as_watched_unwatched_tvshow(params):
	tmdb_id, action = params.get('tmdb_id'), params.get('action')
	try: tvdb_id = int(params.get('tvdb_id', '0'))
	except: tvdb_id = 0
	watched_indicators = settings.watched_indicators()
	kodi_utils.progressDialogBG.create(ls(32577), '')
	data_base = get_database(watched_indicators)
	title, year = params.get('title', ''), params.get('year', '')
	meta_user_info = settings.metadata_user_info()
	adjust_hours = settings.date_offset()
	current_date = get_datetime()
	insert_list = []
	insert_append = insert_list.append
	meta = metadata.tvshow_meta('tmdb_id', tmdb_id, meta_user_info, get_datetime())
	season_data = meta['season_data']
	season_data = [i for i in season_data if i['season_number'] > 0]
	total = len(season_data)
	last_played = get_last_played_value(data_base)
	for count, item in enumerate(season_data, 1):
		season_number = item['season_number']
		ep_data = metadata.season_episodes_meta(season_number, meta, meta_user_info)
		for ep in ep_data:
			season_number = ep['season']
			ep_number = ep['episode']
			display = 'S%.2dE%.2d' % (int(season_number), int(ep_number))
			kodi_utils.progressDialogBG.update(int(float(count)/float(total)*100), ls(32577), '%s' % display)
			episode_date, premiered = adjust_premiered_date(ep['premiered'], adjust_hours)
			if not episode_date or current_date < episode_date: continue
			insert_append(make_batch_insert(action, 'episode', tmdb_id, season_number, ep_number, last_played, title))
	if watched_indicators == 1:
		if not trakt_watched_unwatched(action, 'shows', tmdb_id, tvdb_id): return kodi_utils.notification(32574)
		clear_trakt_collection_watchlist_data('watchlist', 'tvshow')
		clear_trakt_native_tv_progress_cache()
	elif watched_indicators == 2:
		data = []
		episodes = {}
		for i in insert_list:
			if not isinstance(episodes.get(i[2]), list): episodes[i[2]] = []
			episodes[i[2]].append({'number': i[3]})
		for k, v in episodes.items():
			if action == 'mark_as_watched':
				for i in v: i['watched_at'] = last_played
			data += [{'number': k, 'episodes': v}]
		if not mdbl_watched_unwatched(action, 'shows', tmdb_id, tvdb_id, data): return kodi_utils.notification(32574)
		clear_mdbl_collection_watchlist_data('watchlist')
		clear_mdbl_upnext_cache()
	batch_mark_as_watched_unwatched(watched_indicators, insert_list, action)
	kodi_utils.progressDialogBG.close()
	if settings.sync_kodi_library_watchstatus(): batch_mark_kodi_library(action, insert_list, title, year)
	kodi_utils.container_refresh()

def mark_as_watched_unwatched_season(params):
	season, action = int(params.get('season')), params.get('action')
	if season == 0: return kodi_utils.notification(32575)
	try: tvdb_id = int(params.get('tvdb_id', '0'))
	except: tvdb_id = 0
	tmdb_id, title, year = params.get('tmdb_id'), params.get('title'), params.get('year')
	watched_indicators = settings.watched_indicators()
	insert_list = []
	insert_append = insert_list.append
	kodi_utils.progressDialogBG.create(ls(32577), '')
	data_base = get_database(watched_indicators)
	meta_user_info = settings.metadata_user_info()
	adjust_hours = settings.date_offset()
	current_date = get_datetime()
	meta = metadata.tvshow_meta('tmdb_id', tmdb_id, meta_user_info, get_datetime())
	ep_data = metadata.season_episodes_meta(season, meta, meta_user_info)
	last_played = get_last_played_value(data_base)
	for count, item in enumerate(ep_data, 1):
		season_number = item['season']
		ep_number = item['episode']
		display = 'S%.2dE%.2d' % (season_number, ep_number)
		episode_date, premiered = adjust_premiered_date(item['premiered'], adjust_hours)
		if not episode_date or current_date < episode_date: continue
		kodi_utils.progressDialogBG.update(int(float(count) / float(len(ep_data)) * 100), ls(32577), '%s' % display)
		insert_append(make_batch_insert(action, 'episode', tmdb_id, season_number, ep_number, last_played, title))
	if watched_indicators == 1:
		if not trakt_watched_unwatched(action, 'season', tmdb_id, tvdb_id, season): return kodi_utils.notification(32574)
		clear_trakt_collection_watchlist_data('watchlist', 'tvshow')
		clear_trakt_native_tv_progress_cache()
	elif watched_indicators == 2:
		episodes = [{'number': i[3]} for i in insert_list]
		if action == 'mark_as_watched':
			for i in episodes: i['watched_at'] = last_played
		data = [{'number': season, 'episodes': episodes}]
		if not mdbl_watched_unwatched(action, 'season', tmdb_id, tvdb_id, data): return kodi_utils.notification(32574)
		clear_mdbl_collection_watchlist_data('watchlist')
		clear_mdbl_upnext_cache()
	batch_mark_as_watched_unwatched(watched_indicators, insert_list, action)
	kodi_utils.progressDialogBG.close()
	if settings.sync_kodi_library_watchstatus(): batch_mark_kodi_library(action, insert_list, title, year)
	kodi_utils.container_refresh()

def mark_as_watched_unwatched_episode(params):
	season, episode = int(params.get('season')), int(params.get('episode'))
	# Un épisode S00 reste un épisode individuel valide : il peut être marqué
	# vu/non vu chez alkoFlix, Trakt ou MDBList. Son statut est conservé mais il
	# reste exclu des compteurs globaux de progression de la série.
	media_type, action = 'episode', params.get('action')
	try: tvdb_id = int(params.get('tvdb_id', '0'))
	except: tvdb_id = 0
	tmdb_id, title, year = params.get('tmdb_id'), params.get('title'), params.get('year')
	refresh, from_playback = params.get('refresh', 'true') == 'true', params.get('from_playback', 'false') == 'true'
	watched_indicators = settings.watched_indicators()
	trakt_changed = True
	if watched_indicators == 1:
		trakt_result = {'success': True, 'changed': True}
		if from_playback and not settings.trakt_token() and trakt_official_status(media_type) is False:
			kodi_utils.sleep(3000)
		else:
			trakt_result = trakt_watched_unwatched(action, media_type, tmdb_id, tvdb_id, season, episode, return_details=True)
			if not trakt_result.get('success') and from_playback:
				kodi_utils.sleep(1500)
				trakt_result = trakt_watched_unwatched(action, media_type, tmdb_id, tvdb_id, season, episode, return_details=True)
			if not trakt_result.get('success'):
				if not from_playback: return kodi_utils.notification(32574)
				_trakt_playback_fallback('Épisode marqué localement malgré une réponse Trakt invalide -> title=%s | tmdb_id=%s | S%sE%s' % (title, tmdb_id, season, episode))
		trakt_changed = bool(trakt_result.get('changed', True))
		clear_trakt_collection_watchlist_data('watchlist', 'tvshow')
		clear_trakt_native_tv_progress_cache()
	elif watched_indicators == 2:
		if not mdbl_watched_unwatched(action, media_type, tmdb_id, tvdb_id, None, season, episode):
			return kodi_utils.notification(32574)
		clear_mdbl_collection_watchlist_data('watchlist')
		clear_mdbl_upnext_cache()
	# Si Trakt a accepté la requête mais n'a pas réellement ajouté/supprimé cet
	# épisode de son historique comptabilisé, ne pas fabriquer un faux indicateur
	# local qui disparaîtrait au prochain resync. C'est le même résultat visuel que
	# TMDb Helper : action acceptée, mais pas de marqueur si Trakt ne le comptabilise pas.
	if watched_indicators != 1 or trakt_changed:
		mark_as_watched_unwatched(watched_indicators, media_type, tmdb_id, action, season, episode, title)
	if settings.sync_kodi_library_watchstatus():
		mark_as_watched_unwatched_kodi_library(media_type, action, title, year, season, episode)
	if refresh: kodi_utils.container_refresh()

def mark_as_watched_unwatched(watched_indicators, media_type='', tmdb_id='', action='', season='', episode='', title=''):
	try:
		data_base = get_database(watched_indicators)
		last_played = get_last_played_value(data_base)
		dbcon = _database_connect(data_base)
		dbcur = set_PRAGMAS(dbcon)
		if action == 'mark_as_watched':
			dbcur.execute("""INSERT OR IGNORE INTO watched_status VALUES (?, ?, ?, ?, ?, ?)""", (media_type, tmdb_id, season, episode, last_played, title))
		elif action == 'mark_as_unwatched':
			dbcur.execute("""DELETE FROM watched_status WHERE (db_type = ? and media_id = ? and season = ? and episode = ?)""", (media_type, tmdb_id, season, episode))
		erase_bookmark(media_type, tmdb_id, season, episode)
	except: kodi_utils.notification(32574)

def batch_mark_as_watched_unwatched(watched_indicators, insert_list, action):
	try:
		dbcon = _database_connect(get_database(watched_indicators))
		dbcur = set_PRAGMAS(dbcon)
		if action == 'mark_as_watched':
			dbcur.executemany("""INSERT OR IGNORE INTO watched_status VALUES (?, ?, ?, ?, ?, ?)""", insert_list)
		elif action == 'mark_as_unwatched':
			dbcur.executemany("""DELETE FROM watched_status WHERE (db_type = ? and media_id = ? and season = ? and episode = ?)""", insert_list)
		batch_erase_bookmark(watched_indicators, insert_list, action)
	except: kodi_utils.notification(32574)

def get_last_played_value(database_type):
	if database_type == WATCHED_DB: return datetime.now().strftime('%Y-%m-%d %H:%M:%S')
	elif database_type == MDBL_DB: return datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%SZ')
	else: return datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%S.000Z')

def make_batch_insert(action, media_type, tmdb_id, season, episode, last_played, title):
	if action == 'mark_as_watched': return (media_type, tmdb_id, season, episode, last_played, title)
	else: return (media_type, tmdb_id, season, episode)

def batch_mark_kodi_library(action, insert_list, title, year):
	in_library = get_library_video('tvshow', title, year)
	if not in_library: return
	if batch_mark_episodes_as_watched_unwatched_kodi_library(action, in_library, insert_list): kodi_utils.notification(32787)

def clear_local_bookmarks():
	try:
		dbcon = _database_connect(kodi_utils.get_video_database_path())
		dbcur = set_PRAGMAS(dbcon)
		file_ids = dbcur.execute("""SELECT idFile FROM files WHERE strFilename LIKE 'plugin.video.alkoflix%'""").fetchall()
		for i in ('bookmark', 'streamdetails', 'files'):
			dbcur.executemany("""DELETE FROM %s WHERE idFile = ?""" % i, file_ids)
	except: pass

def get_library_video(media_type, title, year, season=None, episode=None):
	try:
		years = range(int(year)-1, int(year)+2)
		filters = [{"field": "year", "operator": "is", "value": str(i)} for i in years]
		properties = ["imdbnumber", "title", "originaltitle", "file"] if media_type == 'movie' else ["title", "year"]
		params = {"filter": {"or": filters}, "properties": properties}
		if media_type == 'movie':
			r = execJSONRPC(json.dumps({"jsonrpc": "2.0", "method": "VideoLibrary.GetMovies", "params": params, "id": 1}))
			r = json.loads(r)['result']['movies']
			try:
				r = [i for i in r if clean_file_name(title).lower() in clean_file_name(i['title']).lower()][0]
				return r
			except:
				return None
		elif media_type  == 'tvshow':
			r = execJSONRPC(json.dumps({"jsonrpc": "2.0", "method": "VideoLibrary.GetTVShows", "params": params, "id": 1}))
			r = json.loads(r)['result']['tvshows']
			try:
				r = [
					i for i in r
					if clean_file_name(title).lower()
					in (clean_file_name(i['title']).lower() if not ' (' in i['title'] else clean_file_name(i['title']).lower().split(' (')[0])
				][0]
				return r
			except:
				return None
	except: pass

def set_bookmark_kodi_library(media_type, tmdb_id, curr_time, total_time, season='', episode=''):
	meta_user_info = settings.metadata_user_info()
	try:
		if media_type == 'movie': info = metadata.movie_meta('tmdb_id', tmdb_id, meta_user_info, get_datetime())
		else: info = metadata.tvshow_meta('tmdb_id', tmdb_id, meta_user_info, get_datetime())
		title, year = info['title'], info['year']
		years = range(int(year)-1, int(year)+2)
		filters = [{"field": "year", "operator": "is", "value": str(i)} for i in years]
		params = {"filter": {"or": filters}, "properties": ["title"]}
		method = 'VideoLibrary.GetMovies' if media_type == 'movie' else 'VideoLibrary.GetTVShows'
		r = execJSONRPC(json.dumps({"jsonrpc": "2.0", "method": method, "params": params, "id": 1}))
		r = json.loads(r)['result']['movies'] if media_type == 'movie' else json.loads(r)['result']['tvshows']
		if media_type == 'movie': r = [i for i in r if clean_file_name(title).lower() in clean_file_name(i['title']).lower()][0]
		else:
			r = [
				i for i in r
				if clean_file_name(title).lower()
				in (clean_file_name(i['title']).lower() if not ' (' in i['title'] else clean_file_name(i['title']).lower().split(' (')[0])
			][0]
		if media_type == 'episode':
			filters = [{"field": "season", "operator": "is", "value": str(season)}, {"field": "episode", "operator": "is", "value": str(episode)}]
			params = {"filter": {"and": filters}, "properties": ["file"], "tvshowid": r['tvshowid']}
			r = execJSONRPC(json.dumps({"jsonrpc": "2.0", "method": "VideoLibrary.GetEpisodes", "params": params, "id": 1}))
			r = json.loads(r)['result']['episodes'][0]
		if media_type == 'movie': method, id_name, library_id = 'VideoLibrary.SetMovieDetails', 'movieid', r['movieid']
		else: method, id_name, library_id = 'VideoLibrary.SetEpisodeDetails', 'episodeid', r['episodeid']
		query = {"jsonrpc": "2.0", "id": "setResumePoint", "method": method, "params": {id_name: library_id, "resume": {"position": curr_time, "total": total_time}}}
		execJSONRPC(json.dumps(query))
	except: pass

def get_bookmark_kodi_library(media_type, tmdb_id, season='', episode=''):
	resume = '0'
	meta_user_info = settings.metadata_user_info()
	try:
		if media_type == 'movie': info = metadata.movie_meta('tmdb_id', tmdb_id, meta_user_info, get_datetime())
		else: info = metadata.tvshow_meta('tmdb_id', tmdb_id, meta_user_info, get_datetime())
		title, year = info['title'], info['year']
		years = range(int(year)-1, int(year)+2)
		filters = [{"field": "year", "operator": "is", "value": str(i)} for i in years]
		properties = ["title", "resume"] if media_type == 'movie' else ["title"]
		params = {"filter": {"or": filters}, "properties": properties}
		method = 'VideoLibrary.GetMovies' if media_type == 'movie' else 'VideoLibrary.GetTVShows'
		r = execJSONRPC(json.dumps({"jsonrpc": "2.0", "method": method, "params": params, "id": 1}))
		r = json.loads(r)['result']['movies'] if media_type == 'movie' else json.loads(r)['result']['tvshows']
		if media_type == 'movie': r = [i for i in r if clean_file_name(title).lower() in clean_file_name(i['title']).lower()][0]
		else:
			r = [
				i for i in r
				if clean_file_name(title).lower()
				in (clean_file_name(i['title']).lower() if not ' (' in i['title'] else clean_file_name(i['title']).lower().split(' (')[0])
			][0]
		if media_type == 'episode':
			filters = [{"field": "season", "operator": "is", "value": str(season)}, {"field": "episode", "operator": "is", "value": str(episode)}]
			params = {"filter": {"and": filters}, "properties": ["file"], "tvshowid": r['tvshowid']}
			r = execJSONRPC(json.dumps({"jsonrpc": "2.0", "method": "VideoLibrary.GetEpisodes", "params": params, "id": 1}))
			r = json.loads(r)['result']['episodes'][0]
		if media_type == 'movie': method, id_name, library_id, results_key = 'VideoLibrary.GetMovieDetails', 'movieid', r['movieid'], 'moviedetails'
		else: method, id_name, library_id, results_key = 'VideoLibrary.GetEpisodeDetails', 'episodeid', r['episodeid'], 'episodedetails'
		query = {"jsonrpc": "2.0", "id": "getResumePoint", "method": method, "params": {id_name: library_id, "properties": ["title", "resume"]}}
		r = json.loads(execJSONRPC(json.dumps(query)))
		resume = r["result"][results_key]["resume"]["position"]
		return resume
	except: pass

def mark_as_watched_unwatched_kodi_library(media_type, action, title, year, season=None, episode=None):
	try:
		playcount = 1 if action == 'mark_as_watched' else 0
		years = range(int(year)-1, int(year)+2)
		filters = [{"field": "year", "operator": "is", "value": str(i)} for i in years]
		params = {"filter": {"or": filters}, "properties": ["title"]}
		method = 'VideoLibrary.GetMovies' if media_type == 'movie' else 'VideoLibrary.GetTVShows'
		r = execJSONRPC(json.dumps({"jsonrpc": "2.0", "method": method, "params": params, "id": 1}))
		r = json.loads(r)['result']['movies'] if media_type == 'movie' else json.loads(r)['result']['tvshows']
		if media_type == 'movie': r = [i for i in r if clean_file_name(title).lower() in clean_file_name(i['title']).lower()][0]
		else:
			r = [
				i for i in r
				if clean_file_name(title).lower()
				in (clean_file_name(i['title']).lower() if not ' (' in i['title'] else clean_file_name(i['title']).lower().split(' (')[0])
			][0]
		if media_type == 'episode':
			filters = [{"field": "season", "operator": "is", "value": str(season)}, {"field": "episode", "operator": "is", "value": str(episode)}]
			params = {"filter": {"and": filters}, "properties": ["file"], "tvshowid": r['tvshowid']}
			r = execJSONRPC(json.dumps({"jsonrpc": "2.0", "method": "VideoLibrary.GetEpisodes", "params": params, "id": 1}))
			r = json.loads(r)['result']['episodes'][0]
		if media_type == 'movie': method, id_name, library_id = 'VideoLibrary.SetMovieDetails', 'movieid', r['movieid']
		else: method, id_name, library_id = 'VideoLibrary.SetEpisodeDetails', 'episodeid', r['episodeid']
		query = {"jsonrpc": "2.0", "method": method, "params": {id_name: library_id, "playcount": playcount}, "id": 1}
		execJSONRPC(json.dumps(query))
		query = {"jsonrpc": "2.0", "id": "setResumePoint", "method": method, "params": {id_name: library_id, "resume": {"position": 0,}}}
		execJSONRPC(json.dumps(query))
	except: pass

def batch_mark_episodes_as_watched_unwatched_kodi_library(action, show_info, episode_list):
	playcount = 1 if action == 'mark_as_watched' else 0
	tvshowid = str(show_info['tvshowid'])
	ep_ids, action_list = [], []
	ep_ids_append, action_append = ep_ids.append, action_list.append
	progressDialogBG.create(ls(32577), '')
	try:
		for item in episode_list:
			try:
				season = item[2]
				episode = item[3]
				filters = [{"field": "season", "operator": "is", "value": str(season)}, {"field": "episode", "operator": "is", "value": str(episode)}]
				params = {"filter": {"and": filters}, "properties": ["file", "playcount"], "tvshowid": tvshowid}
				r = execJSONRPC(json.dumps({"jsonrpc": "2.0", "method": "VideoLibrary.GetEpisodes", "params": params, "id": 1}))
				r = json.loads(r)['result']['episodes'][0]
				ep_ids_append((r['episodeid'], r['playcount']))
			except: pass
		for count, item in enumerate(ep_ids, 1):
			try:
				ep_id = item[0]
				current_playcount = item[1]
				if int(current_playcount) != playcount:
					sleep(50)
					display = ls(32856)
					progressDialogBG.update(int(float(count) / float(len(ep_ids)) * 100), ls(32577), display)
					query = {"jsonrpc": "2.0", "method": "VideoLibrary.SetEpisodeDetails", "params": {"episodeid": ep_id, "playcount": playcount}, "id": 1}
					action_append(query)
				else: pass
			except: pass
		r = execJSONRPC(json.dumps(action_list))
		progressDialogBG.close()
		return r
	except: pass

