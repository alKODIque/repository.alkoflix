# -*- coding: utf-8 -*-
# plugin.video.alkoflix
# Fenêtre modale Discover Trakt inspirée du flux de TMDb Helper.

from modules import kodi_utils


class TraktDiscoverDialog(kodi_utils.window_xml_dialog):
    LIST_ID = 3
    SAVE_ID = 5
    UNUSED_ID = 6
    CLOSE_ID = 7
    RESET_ID = 8

    def __init__(self, *args, **kwargs):
        # WindowXMLDialog est initialisé par Kodi via __new__ à partir du nom XML
        # et du chemin passés au constructeur; on conserve seulement nos données.
        self.controller = kwargs.get('controller')
        self.result = None
        self._closed = False

    def onInit(self):
        try: self.getControl(1).setLabel('Trakt Discover')
        except Exception: pass
        try: self.getControl(self.SAVE_ID).setLabel('Enregistrer')
        except Exception: pass
        try: self.getControl(self.UNUSED_ID).setVisible(False)
        except Exception: pass
        try: self.getControl(self.CLOSE_ID).setLabel('Fermer')
        except Exception: pass
        try: self.getControl(self.RESET_ID).setLabel('Réinitialiser')
        except Exception: pass
        self.build_menu()

    def _item(self, label, action, icon='', filter_key=''):
        li = kodi_utils.make_listitem()
        li.setLabel(label)
        li.setProperty('alkoflix.discover.action', action)
        if filter_key:
            li.setProperty('alkoflix.discover.filter_key', filter_key)
        if icon:
            try:
                icon_path = self.controller._icon(icon)
                li.setArt({'icon': icon_path, 'thumb': icon_path})
            except Exception:
                pass
        return li

    def _option_label(self, label, value=None):
        value = str(value or '').strip()
        return '%s : %s' % (label, value) if value else label

    def _filter_value_label(self, config, key):
        value = str(config.get(key) or '').strip()
        return value

    def build_menu(self, select_action=None):
        if self._closed or not self.controller:
            return
        config = self.controller._discover_get()
        media_label = {'movie': 'Films', 'tv': 'Séries', 'combined': 'Combiné'}.get(config.get('media_type'), 'Films')
        list_label = self.controller._discover_list_label(config.get('list_type'))
        cert_label = config.get('certifications_label') or str(config.get('certifications') or '').upper()

        rows = [
            self._item('Liste : %s' % list_label, 'list', 'tendance.png'),
            self._item('Type : %s' % media_label, 'media', 'film.png'),
            self._item(self._option_label('Mot clé', config.get('query')), 'query', 'recherche.png'),
            self._item(self._option_label('Années', config.get('years')), 'years', 'annees.png'),
            self._item(self._option_label('Genres', config.get('genres_label')), 'genres', 'genre.png'),
            self._item(self._option_label('Certifications', cert_label), 'certification', 'bouclier.png'),
            self._item(self._option_label('Disponibilité', {
                '': 'Tous les services de streaming',
                'any': 'Disponible sur un service de streaming',
                'favorites': 'Services de streaming favoris',
                'subscriptions': 'Abonnements aux services de streaming',
            }.get(str(config.get('watchnow') or ''), config.get('watchnow_label'))), 'availability', 'justwatch.png'),
            self._item('Médias non vus seulement : %s' % ('Oui' if bool(config.get('hide_watched', False)) else 'Non'), 'hide_watched', 'eye-slash.png'),
        ]
        for key in ('runtimes', 'ratings', 'votes', 'tmdb_ratings', 'tmdb_votes', 'imdb_ratings', 'imdb_votes', 'rt_meters', 'rt_user_meters', 'metascores'):
            label = self.controller._discover_filter_label(key)
            rows.append(self._item(self._option_label(label, self._filter_value_label(config, key)), 'range', 'filtre.png', key))

        # Extensions alkoFlix : elles restent disponibles en plus du flux TMDb Helper.
        rows.extend([
            self._item('Enregistrer', 'save', 'marque-page.png'),
            self._item('Ajouter au menu', 'export_menu', 'menu-lateral.png'),
            self._item('Ajouter à un dossier personnel', 'export_folder', 'dossier.png'),
        ])

        try:
            control = self.getControl(self.LIST_ID)
            current = control.getSelectedPosition()
            control.reset()
            control.addItems(rows)
            self.setFocus(control)
            if select_action:
                for idx, row in enumerate(rows):
                    if row.getProperty('alkoflix.discover.action') == select_action:
                        control.selectItem(idx)
                        break
            elif current >= 0 and current < len(rows):
                control.selectItem(current)
        except Exception as exc:
            kodi_utils.logger('Trakt Discover dialog', 'build_menu failed: %s' % exc)

    def refresh(self, select_action=None):
        self.build_menu(select_action=select_action)

    def _selected(self):
        try:
            return self.getControl(self.LIST_ID).getSelectedItem()
        except Exception:
            return None

    def _run_selected(self):
        item = self._selected()
        if not item or not self.controller:
            return
        action = item.getProperty('alkoflix.discover.action')
        filter_key = item.getProperty('alkoflix.discover.filter_key')
        if action == 'media':
            return self.controller.discover_media()
        if action == 'list':
            return self.controller.discover_list()
        if action == 'query':
            return self.controller.discover_query()
        if action == 'years':
            return self.controller.discover_years()
        if action == 'genres':
            return self.controller.discover_genres()
        if action == 'certification':
            return self.controller.discover_certification()
        if action == 'availability':
            return self.controller.discover_availability()
        if action == 'hide_watched':
            return self.controller.discover_hide_watched()
        if action == 'range':
            old_params = self.controller.params
            try:
                self.controller.params = dict(old_params or {})
                self.controller.params['filter_key'] = filter_key
                return self.controller.discover_range()
            finally:
                self.controller.params = old_params
        if action == 'save':
            return self._save()
        if action == 'export_menu':
            self.result = ('export', 'menu')
            return self.close()
        if action == 'export_folder':
            self.result = ('export', 'folder')
            return self.close()

    def _save(self):
        if not self.controller:
            return
        if self.controller.discover_save():
            self.result = ('saved', None)
            self.close()

    def _reset(self):
        if self.controller:
            self.controller.discover_reset()

    def onAction(self, action):
        try: action_id = action.getId()
        except Exception: action_id = int(action)
        if action_id in kodi_utils.window_xml_closing_actions:
            return self.close()
        if action_id not in kodi_utils.window_xml_selection_actions:
            return
        try: focus_id = self.getFocusId()
        except Exception: focus_id = 0
        if focus_id == self.LIST_ID:
            return self._run_selected()
        if focus_id == self.SAVE_ID:
            return self._save()
        if focus_id == self.RESET_ID:
            return self._reset()
        if focus_id == self.CLOSE_ID:
            return self.close()

    def close(self):
        self._closed = True
        try:
            return kodi_utils.window_xml_dialog.close(self)
        except Exception:
            pass
