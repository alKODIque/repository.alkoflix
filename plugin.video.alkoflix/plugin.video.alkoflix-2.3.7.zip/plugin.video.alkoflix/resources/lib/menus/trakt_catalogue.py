# -*- coding: utf-8 -*-
# plugin.video.alkoflix
# Catalogue Trakt public et Discover Trakt.

import json
import sys
import time
from datetime import datetime, timedelta

from caches.main_cache import MainCache
from modules import kodi_utils, settings


DISCOVER_PROPERTY = 'alkoflix_trakt_discover_params'
SAVED_CACHE_KEY = 'alkoflix_trakt_discover_saved'

GENRE_FR = {
    'action': 'Action',
    'adventure': 'Aventure',
    'animation': 'Animation',
    'anime': 'Animé',
    'comedy': 'Comédie',
    'crime': 'Crime',
    'documentary': 'Documentaire',
    'drama': 'Drame',
    'family': 'Famille',
    'fantasy': 'Fantastique',
    'game-show': 'Jeu télévisé',
    'history': 'Histoire',
    'home-and-garden': 'Maison & jardin',
    'horror': 'Horreur',
    'mini-series': 'Mini-série',
    'music': 'Musique',
    'mystery': 'Mystère',
    'news': 'Actualités',
    'reality': 'Téléréalité',
    'romance': 'Romance',
    'science-fiction': 'Science-fiction',
    'soap': 'Feuilleton',
    'special-interest': 'Intérêt particulier',
    'sport': 'Sport',
    'talk-show': 'Talk-show',
    'thriller': 'Thriller',
    'war': 'Guerre',
    'western': 'Western',
    'children': 'Jeunesse'
}


GENRE_ICONS = {
    'action': 'genre_action.png',
    'adventure': 'genre_adventure.png',
    'animation': 'genre_animation.png',
    'anime': 'genre_animation.png',
    'comedy': 'genre_comedy.png',
    'crime': 'genre_crime.png',
    'documentary': 'genre_documentary.png',
    'drama': 'genre_drama.png',
    'family': 'genre_family.png',
    'fantasy': 'genre_fantasy.png',
    'game-show': 'genre_tv.png',
    'history': 'genre_history.png',
    'home-and-garden': 'genre_tv.png',
    'horror': 'genre_horror.png',
    'mini-series': 'genre_tv.png',
    'music': 'genre_music.png',
    'mystery': 'genre_mystery.png',
    'news': 'genre_news.png',
    'reality': 'genre_reality.png',
    'romance': 'genre_romance.png',
    'science-fiction': 'genre_scifi.png',
    'soap': 'genre_soap.png',
    'special-interest': 'genre_tv.png',
    'sport': 'genre_tv.png',
    'talk-show': 'genre_talk.png',
    'thriller': 'genre_thriller.png',
    'war': 'genre_war.png',
    'western': 'genre_western.png',
    'children': 'genre_kids.png'
}


TRAKT_LOCAL_GENRE_ALIASES = {
    'movie': {
        'action': ('28', 'action'), 'adventure': ('12', 'aventure'),
        'animation': ('16', 'animation'), 'anime': ('16', 'animation'),
        'comedy': ('35', 'comédie', 'comedie'), 'crime': ('80', 'crime'),
        'documentary': ('99', 'documentaire'), 'drama': ('18', 'drame'),
        'family': ('10751', 'famille'), 'fantasy': ('14', 'fantastique'),
        'history': ('36', 'histoire'), 'horror': ('27', 'horreur'),
        'music': ('10402', 'musique'), 'mystery': ('9648', 'mystère', 'mystere'),
        'romance': ('10749', 'romance'), 'science-fiction': ('878', 'science-fiction'),
        'thriller': ('53', 'thriller'), 'war': ('10752', 'guerre'),
        'western': ('37', 'western')
    },
    'tv': {
        'action': ('10759', 'action & adventure', 'action et aventure'),
        'adventure': ('10759', 'action & adventure', 'action et aventure'),
        'animation': ('16', 'animation'), 'anime': ('16', 'animation'),
        'comedy': ('35', 'comédie', 'comedie'), 'crime': ('80', 'crime'),
        'documentary': ('99', 'documentaire'), 'drama': ('18', 'drame'),
        'family': ('10751', 'famille'), 'fantasy': ('10765', 'science-fiction et fantastique'),
        'history': ('18', 'drame'), 'horror': ('9648', 'mystère', 'mystere'),
        'mystery': ('9648', 'mystère', 'mystere'), 'news': ('10763', 'actualités', 'actualites'),
        'reality': ('10764', 'téléréalité', 'telerealite'),
        'romance': ('18', 'drame'), 'science-fiction': ('10765', 'science-fiction et fantastique'),
        'soap': ('10766', 'soap'), 'talk-show': ('10767', 'talk-show'),
        'war': ('10768', 'guerre et politique'), 'western': ('37', 'western'),
        'children': ('10762', 'jeunesse')
    }
}

LIST_LABELS = {
    'trending': 'Tendances',
    'popular': 'Populaires',
    'played': 'Les plus visionnés',
    'watched': 'Les plus regardés',
    'anticipated': 'Anticipés'
}

FILTER_LABELS = {
    'years': 'Années',
    'runtimes': 'Durée (minutes)',
    'ratings': 'Note Trakt',
    'votes': 'Votes Trakt',
    'tmdb_ratings': 'Note TMDb',
    'tmdb_votes': 'Votes TMDb',
    'imdb_ratings': 'Note IMDb',
    'imdb_votes': 'Votes IMDb',
    'rt_meters': 'Rotten Tomatoes',
    'rt_user_meters': 'Rotten Tomatoes - utilisateurs',
    'metascores': 'Metacritic'
}


def _display_range(value):
    value = str(value or '').strip()
    return value if value else 'Tous'


def _discover_defaults():
    return {'media_type': 'movie', 'list_type': 'trending', 'hide_watched': False}


def _safe_json_load(value, default):
    try:
        data = json.loads(value)
        return data if isinstance(data, type(default)) else default
    except Exception:
        return default


class TraktCatalogue:
    def __init__(self, params):
        self.params = params or {}
        try: self.handle = int(sys.argv[1])
        except Exception: self.handle = int(self.params.get('handle', 0) or 0)
        self.fanart = settings.addon_fanart()
        self.name = self.params.get('name') or 'Catalogue Trakt'
        self._local_facet_cache = {}
        self._discover_modal_active = False
        self._discover_dialog = None

    def _icon(self, name):
        value = str(name or '').strip()
        if '://' in value or value.startswith('/'):
            return kodi_utils.resolve_icon_path(value)
        return kodi_utils.menu_icons_path(value)

    def _genre_icon(self, slug):
        filename = GENRE_ICONS.get(str(slug or '').strip().lower())
        return kodi_utils.media_path(filename) if filename else self._icon('genre.png')

    def _local_only(self):
        try: return bool(settings.trakt_catalogue_alkopaste_only())
        except Exception: return False

    def _local_facets(self, media_type):
        media_type = str(media_type or '').strip().lower()
        if media_type in self._local_facet_cache: return self._local_facet_cache[media_type]
        try:
            from magneto.alkopaste import alkopaste_catalogue_local_facets
            if media_type == 'combined':
                movie = alkopaste_catalogue_local_facets('film') or {}
                tv = alkopaste_catalogue_local_facets('serie') or {}
                data = {
                    'count': int(movie.get('count') or 0) + int(tv.get('count') or 0),
                    'years': sorted(set(movie.get('years') or []).union(tv.get('years') or []), reverse=True),
                    'genres': sorted(set(movie.get('genres') or []).union(tv.get('genres') or [])),
                    'certifications_us': sorted(set(movie.get('certifications_us') or []).union(tv.get('certifications_us') or []))
                }
            else:
                data = alkopaste_catalogue_local_facets('film' if media_type == 'movie' else 'serie') or {}
        except Exception:
            data = {'count': 0, 'years': [], 'genres': [], 'certifications_us': []}
        self._local_facet_cache[media_type] = data
        return data

    def _media_available(self, media_type):
        if not self._local_only(): return True
        return int((self._local_facets(media_type) or {}).get('count') or 0) > 0

    def _genre_aliases(self, media_type, slug):
        media_type = 'movie' if media_type == 'movie' else 'tv'
        slug = str(slug or '').strip().lower()
        aliases = set(str(i).lower() for i in TRAKT_LOCAL_GENRE_ALIASES.get(media_type, {}).get(slug, ()) if i)
        aliases.add(slug)
        label = GENRE_FR.get(slug)
        if label: aliases.add(label.lower())
        return aliases

    def _genre_available(self, media_type, slug):
        if not self._local_only(): return True
        if media_type == 'combined':
            return self._genre_available('movie', slug) or self._genre_available('tv', slug)
        facets = set((self._local_facets(media_type) or {}).get('genres') or [])
        aliases = self._genre_aliases(media_type, slug)
        # Pour les genres Trakt sans équivalent TMDb direct (sport, game-show, etc.),
        # ne pas masquer arbitrairement : ils peuvent tout de même retourner des
        # médias possédant un autre genre TMDb connu dans alkoPaste.
        mapped = TRAKT_LOCAL_GENRE_ALIASES.get('movie' if media_type == 'movie' else 'tv', {}).get(str(slug or '').lower())
        return bool(facets.intersection(aliases)) if mapped else True

    def _year_available(self, media_type, years):
        if not self._local_only(): return True
        if media_type == 'combined': return self._year_available('movie', years) or self._year_available('tv', years)
        available = set(str(i) for i in ((self._local_facets(media_type) or {}).get('years') or []))
        value = str(years or '').strip()
        try:
            if '-' in value:
                a, b = value.split('-', 1); a, b = int(a), int(b)
                return any(str(y) in available for y in range(min(a,b), max(a,b)+1))
            return value in available
        except Exception:
            return True

    def _cert_available(self, media_type, cert):
        if not self._local_only(): return True
        if media_type == 'combined': return self._cert_available('movie', cert) or self._cert_available('tv', cert)
        values = set((self._local_facets(media_type) or {}).get('certifications_us') or [])
        return str(cert or '').strip().lower() in values if values else True

    def _has_local_candidates(self, media_type, years='', genre='', certifications=''):
        if not self._local_only(): return True
        if media_type == 'combined':
            return self._has_local_candidates('movie', years, genre, certifications) or self._has_local_candidates('tv', years, genre, certifications)
        try:
            from magneto.alkopaste import alkopaste_catalogue_has_candidates
            aliases = self._genre_aliases(media_type, genre) if genre else []
            return alkopaste_catalogue_has_candidates(
                'film' if media_type == 'movie' else 'serie', years=years,
                genre_values=aliases, certifications=certifications
            )
        except Exception:
            return True

    def _add(self, params, label, icon='trakt.png', is_folder=True, fanart=None, context_items=None):
        # Les sous-menus Trakt sont dynamiques et ne passent pas par Navigator._add_item().
        # On leur applique donc ici le même menu contextuel que les menus natifs :
        # ajout au menu principal / dossier personnel, avec les tris compatibles.
        params = dict(params or {})
        params.setdefault('name', label)
        icon_path = self._icon(icon)
        params.setdefault('iconImage', icon_path)
        url = kodi_utils.build_url(params)
        listitem = kodi_utils.make_listitem()
        listitem.setLabel(label)
        listitem.setArt(kodi_utils.clean_art({
            'icon': icon_path, 'poster': icon_path, 'thumb': icon_path,
            'fanart': fanart or self.fanart, 'banner': icon_path, 'landscape': icon_path
        }))
        if is_folder and not str(params.get('mode') or '').startswith('menu_editor.'):
            try:
                cm = kodi_utils.menu_editor_context(params, label, icon_path, True)
                cm += kodi_utils.tmdb_genre_sort_context(params, label, icon_path, True)
                cm += kodi_utils.list_sort_context(params, label, icon_path, True)
                if context_items:
                    cm += list(context_items)
                if cm: listitem.addContextMenuItems(cm, replaceItems=False)
            except Exception: pass
        kodi_utils.add_item(self.handle, url, listitem, is_folder)

    def _finish(self, category=None):
        kodi_utils.set_category(self.handle, category or self.name)
        kodi_utils.set_content(self.handle, '')
        kodi_utils.end_directory(self.handle)
        kodi_utils.set_view_mode('view.main', '')

    @staticmethod
    def _result_params(media_type, list_type, name, extra=None):
        if media_type == 'combined':
            params = {
                'mode': 'trakt_catalogue.combined_results',
                'action': 'trakt_catalogue_combined',
                'trakt_list_type': list_type,
                'trakt_catalogue': 'true',
                'name': name
            }
        else:
            is_movie = media_type == 'movie'
            params = {
                'mode': 'build_movie_list' if is_movie else 'build_tvshow_list',
                'action': 'trakt_catalogue_movies' if is_movie else 'trakt_catalogue_tv',
                'trakt_list_type': list_type,
                'trakt_catalogue': 'true',
                'name': name
            }
        if extra:
            for key, value in extra.items():
                if value not in ('', None, [], {}): params[key] = value
        return params

    def media_group(self):
        list_type = self.params.get('group_kind', 'trending')
        label = LIST_LABELS.get(list_type, self.name)
        if self._media_available('movie') or list_type == 'anticipated':
            self._add(self._result_params('movie', list_type, '%s - Films' % label), 'Films', 'film.png')
        if self._media_available('tv') or list_type == 'anticipated':
            self._add(self._result_params('tv', list_type, '%s - Séries' % label), 'Séries', 'television.png')
        if self._media_available('combined') or list_type == 'anticipated':
            self._add(self._result_params('combined', list_type, '%s - Combiné' % label), 'Combiné', 'liste.png')
        self._finish(label)

    def most_watched(self):
        self._add(self._result_params('movie', 'played', 'Films les plus visionnés'), 'Films les plus visionnés', 'lecture-bouton.png')
        self._add(self._result_params('tv', 'played', 'Séries les plus visionnées'), 'Séries les plus visionnées', 'lecture-bouton.png')
        self._add(self._result_params('combined', 'played', 'Combiné - les plus visionnés'), 'Combiné - les plus visionnés', 'liste.png')
        self._add(self._result_params('movie', 'watched', 'Films les plus regardés'), 'Films les plus regardés', 'eye2.png')
        self._add(self._result_params('tv', 'watched', 'Séries les plus regardées'), 'Séries les plus regardées', 'eye2.png')
        self._add(self._result_params('combined', 'watched', 'Combiné - les plus regardés'), 'Combiné - les plus regardés', 'liste.png')
        self._add(self._result_params('movie', 'boxoffice', 'Top 10 box-office'), 'Top 10 box-office', 'trophee.png')
        self._finish('Les plus regardés')

    def type_group(self):
        group_kind = self.params.get('group_kind', 'genres')
        method = 'genres' if group_kind == 'genres' else 'years'
        label = 'Genres' if group_kind == 'genres' else 'Années'
        if self._media_available('movie'):
            self._add({'mode': 'trakt_catalogue.%s' % method, 'media_type': 'movie', 'name': '%s - Films' % label}, 'Films', 'film.png')
        if self._media_available('tv'):
            self._add({'mode': 'trakt_catalogue.%s' % method, 'media_type': 'tv', 'name': '%s - Séries' % label}, 'Séries', 'television.png')
        if self._media_available('combined'):
            self._add({'mode': 'trakt_catalogue.%s' % method, 'media_type': 'combined', 'name': '%s - Combiné' % label}, 'Combiné', 'liste.png')
        self._finish(label)

    def genres(self):
        from indexers.trakt_api import trakt_catalogue_genres
        media_type = self.params.get('media_type', 'movie')
        try:
            if media_type == 'combined':
                merged = {}
                for source_type in ('movie', 'tv'):
                    for item in trakt_catalogue_genres(source_type) or []:
                        slug = str(item.get('slug') or '').strip()
                        if slug: merged[slug] = item
                genres = list(merged.values())
            else:
                genres = trakt_catalogue_genres(media_type) or []
        except Exception: genres = []
        for item in sorted(genres, key=lambda x: GENRE_FR.get(str(x.get('slug') or '').lower(), str(x.get('name') or '')).lower()):
            slug = str(item.get('slug') or '').strip()
            if not slug: continue
            label = GENRE_FR.get(slug.lower(), str(item.get('name') or slug).strip())
            # TMDb Helper ouvre ensuite toutes les listes Trakt compatibles avec le
            # filtre de genre. On conserve ce comportement plutôt que de forcer
            # directement la liste « Populaires ».
            self._add({'mode': 'trakt_catalogue.genre_menu', 'media_type': media_type, 'genres': slug, 'genre_label': label, 'name': label}, label, self._genre_icon(slug))
        self._finish(self.name)

    def genre_menu(self):
        media_type = self.params.get('media_type', 'movie')
        genre = str(self.params.get('genres') or '').strip()
        genre_label = str(self.params.get('genre_label') or genre).strip()
        if not genre:
            return self._finish('Genre Trakt')
        base = {'genres': genre}
        rows = (
            ('trending', 'Tendances', 'tendance.png'),
            ('popular', 'Populaires', 'classement.png'),
            ('played', 'Les plus visionnés', 'lecture-bouton.png'),
            ('watched', 'Les plus regardés', 'eye2.png'),
            ('anticipated', 'Anticipés', 'rocket.png')
        )
        has_local_genre = self._has_local_candidates(media_type, genre=genre)
        for list_type, label, icon in rows:
            if self._local_only() and list_type != 'anticipated' and not has_local_genre: continue
            name = '%s (%s)' % (label, genre_label)
            self._add(self._result_params(media_type, list_type, name, base), name, icon)

        # Les décennies sont elles aussi des entrées filtrables dans TMDb Helper.
        current_decade = (datetime.now().year // 10) * 10
        for decade in range(current_decade, 1899, -10):
            years = '%s-%s' % (decade, decade + 9)
            if not self._has_local_candidates(media_type, years=years, genre=genre): continue
            label = 'Populaires %s - années %s' % (genre_label, decade)
            self._add(self._result_params(media_type, 'popular', label, {'genres': genre, 'years': years}), label, 'annees.png')

        # Les classifications filtrées ne sont présentes que pour les films dans le
        # menu Genres de TMDb Helper.
        if media_type in ('movie', 'combined'):
            for cert in ('G', 'PG', 'PG-13', 'R', 'NR'):
                if not self._has_local_candidates(media_type, genre=genre, certifications=cert.lower()): continue
                label = '%s %s (%s)' % ('Certification', cert, genre_label)
                self._add(self._result_params(media_type, 'popular', label, {'genres': genre, 'certifications': cert.lower()}), label, 'bouclier.png')
        self._finish(genre_label)

    def years(self):
        media_type = self.params.get('media_type', 'movie')
        if self._local_only():
            years = []
            for value in (self._local_facets(media_type) or {}).get('years') or []:
                try: years.append(int(value))
                except: pass
            years = sorted(set(years), reverse=True)
        else:
            years = list(range(datetime.now().year, 1899, -1))
        for year in years:
            label = str(year)
            self._add(self._result_params(media_type, 'popular', label, {'years': label}), label, 'annee.png')
        self._finish(self.name)

    def decades(self):
        current_decade = (datetime.now().year // 10) * 10
        for decade in range(current_decade, 1899, -10):
            years = '%s-%s' % (decade, decade + 9)
            if self._local_only() and not self._year_available('combined', years): continue
            label = 'Années %s' % decade
            self._add({'mode': 'trakt_catalogue.decade', 'decade': str(decade), 'name': label}, label, 'annees.png')
        self._finish('Décennies')

    def decade(self):
        try: decade = int(self.params.get('decade'))
        except Exception: decade = 2020
        years = '%s-%s' % (decade, decade + 9)
        label = 'Années %s' % decade
        if self._year_available('movie', years):
            self._add(self._result_params('movie', 'popular', '%s - Films' % label, {'years': years}), 'Films', 'film.png')
        if self._year_available('tv', years):
            self._add(self._result_params('tv', 'popular', '%s - Séries' % label, {'years': years}), 'Séries', 'television.png')
        if self._year_available('combined', years):
            self._add(self._result_params('combined', 'popular', '%s - Combiné' % label, {'years': years}), 'Combiné', 'liste.png')
        self._finish(label)

    def certifications(self):
        for cert in ('G', 'PG', 'PG-13', 'R', 'NR'):
            if not self._cert_available('movie', cert): continue
            self._add(self._result_params('movie', 'popular', 'Certification %s' % cert, {'certifications': cert.lower()}), cert, 'bouclier.png')
        self._finish('Certifications')

    def calendar(self):
        # Les calendriers « all » sont volontairement séparés du calendrier personnel.
        # Ils restent donc utilisables sans compte Trakt lorsque l'endpoint public le permet.
        rows = (
            ('calendar_shows', 'Séries à l’antenne', 'tele-en-direct.png', 'tv'),
            ('calendar_premieres', 'Premières de séries', 'rocket.png', 'tv'),
            ('calendar_new', 'Nouvelles séries', 'ajouts-recents.png', 'tv'),
            ('calendar_movies', 'Sorties cinéma', 'film.png', 'movie'),
            ('calendar_dvd', 'Sorties DVD / numériques', 'disque-dur.png', 'movie')
        )
        for list_type, label, icon, media_type in rows:
            self._add(self._result_params(media_type, list_type, label), label, icon)
        self._finish('Calendrier Trakt')

    def lists(self):
        self._add({'mode': 'build_trakt_list.get_trakt_trending_popular_lists', 'list_type': 'trending', 'trakt_catalogue': 'true', 'name': 'Listes tendances'}, 'Listes tendances', 'tendance.png')
        self._add({'mode': 'build_trakt_list.get_trakt_trending_popular_lists', 'list_type': 'popular', 'trakt_catalogue': 'true', 'name': 'Listes populaires'}, 'Listes populaires', 'classement.png')
        # La recherche de listes de l'API Trakt actuelle demande une session utilisateur.
        # On la masque sans compte afin que chaque entrée du catalogue public reste utilisable.
        if settings.trakt_token():
            self._add({'mode': 'build_trakt_list.search_trakt_lists', 'trakt_catalogue': 'true', 'name': 'Recherche de listes'}, 'Rechercher une liste', 'recherche.png')
        self._finish('Listes Trakt')

    def search(self):
        self._add({'mode': 'search_history', 'action': 'trakt_movie', 'trakt_catalogue': 'true', 'name': 'Recherche Trakt - Films'}, 'Films', 'film.png')
        self._add({'mode': 'search_history', 'action': 'trakt_tvshow', 'trakt_catalogue': 'true', 'name': 'Recherche Trakt - Séries'}, 'Séries', 'television.png')
        self._add({'mode': 'search_history', 'action': 'trakt_combined', 'trakt_catalogue': 'true', 'name': 'Recherche Trakt - Combiné'}, 'Combiné', 'liste.png')
        if settings.trakt_token():
            self._add({'mode': 'build_trakt_list.search_trakt_lists', 'trakt_catalogue': 'true', 'name': 'Recherche de listes'}, 'Listes Trakt', 'liste.png')
        self._finish('Recherche Trakt')

    @staticmethod
    def _combined_interleave(movie_rows, tv_rows):
        result = []
        max_len = max(len(movie_rows or []), len(tv_rows or []))
        for idx in range(max_len):
            if idx < len(movie_rows or []):
                item = dict(movie_rows[idx] or {}); item['media_type'] = 'movie'; result.append(item)
            if idx < len(tv_rows or []):
                item = dict(tv_rows[idx] or {}); item['media_type'] = 'tv'; result.append(item)
        return result

    @staticmethod
    def _combined_item_tmdb_id(item):
        try:
            from urllib.parse import parse_qs, urlsplit
            values = parse_qs(urlsplit(str(item[0])).query).get('tmdb_id') or []
            return str(values[0]) if values else ''
        except Exception:
            return ''

    def combined_results(self):
        from indexers.trakt_api import trakt_catalogue_media, trakt_catalogue_local_pool
        try: page_no = max(1, int(self.params.get('new_page', '1') or 1))
        except Exception: page_no = 1
        list_type = str(self.params.get('trakt_list_type') or 'trending').strip().lower()
        list_sort = str(self.params.get('list_sort') or '').strip()
        random_seed = str(self.params.get('list_random_seed') or '').strip()
        try:
            from modules.list_sorting import normalise_list_sort_key
            sort_key = normalise_list_sort_key(list_sort)
        except Exception:
            sort_key = list_sort.lower() or 'original'
        local_global_sort = self._local_only() and list_type != 'anticipated' and sort_key != 'original'
        try: page_size = max(1, int(settings.page_limit())) if settings.paginate() else 1000000
        except Exception: page_size = 20

        if local_global_sort:
            movie_rows, _ = trakt_catalogue_local_pool('movie', self.params)
            tv_rows, _ = trakt_catalogue_local_pool('tv', self.params)
            combined = []
            for row in movie_rows or []:
                item = dict(row or {}); item['media_type'] = 'movie'; combined.append(item)
            for row in tv_rows or []:
                item = dict(row or {}); item['media_type'] = 'tv'; combined.append(item)
            try:
                from magneto.alkopaste import alkopaste_catalogue_sort_mixed_id_dicts
                combined = alkopaste_catalogue_sort_mixed_id_dicts(combined, sort_key, random_seed)
            except Exception as e:
                kodi_utils.logger('Catalogue Trakt tri combiné', str(e))
            total_pages = max(1, (len(combined) + page_size - 1) // page_size)
            start = (page_no - 1) * page_size
            page_data = combined[start:start + page_size]
        else:
            # Sans tri global, 20 éléments combinés = 10 films + 10 séries par
            # demi-page source. Cela évite de jeter la moitié d'une page Trakt.
            source_page = ((page_no - 1) // 2) + 1
            half = (page_no - 1) % 2
            movie_rows, movie_pages = trakt_catalogue_media('movie', self.params, source_page)
            tv_rows, tv_pages = trakt_catalogue_media('tv', self.params, source_page)
            if list_sort:
                try:
                    from modules.list_sorting import apply_context_id_sort
                    movie_rows = apply_context_id_sort(movie_rows, 'movie', {'list_sort': list_sort, 'list_random_seed': random_seed})
                    tv_rows = apply_context_id_sort(tv_rows, 'tv', {'list_sort': list_sort, 'list_random_seed': random_seed})
                except Exception: pass
            merged = self._combined_interleave(movie_rows or [], tv_rows or [])
            start = half * page_size
            page_data = merged[start:start + page_size]
            source_total = max(int(movie_pages or 1), int(tv_pages or 1))
            total_pages = source_total * 2
            if source_page >= source_total:
                tail_pages = max(1, (len(merged) + page_size - 1) // page_size)
                total_pages = ((source_total - 1) * 2) + tail_pages

        movie_ids = [str(i.get('tmdb') or '') for i in page_data if i.get('media_type') == 'movie' and i.get('tmdb')]
        tv_ids = [str(i.get('tmdb') or '') for i in page_data if i.get('media_type') == 'tv' and i.get('tmdb')]
        movie_items, tv_items = [], []
        try:
            if movie_ids:
                from menus.movies import Movies
                movie_items = Movies({'list': movie_ids, 'id_type': 'tmdb_id', 'action': 'trakt_catalogue_combined_worker', 'name': self.name, 'trakt_catalogue': 'true', 'trakt_list_type': list_type, 'discover_hide_watched': self.params.get('discover_hide_watched', 'false')}).worker()
        except Exception as e:
            kodi_utils.logger('Catalogue Trakt combiné films', str(e))
        try:
            if tv_ids:
                from menus.tvshows import TVShows
                tv_items = TVShows({'list': tv_ids, 'id_type': 'tmdb_id', 'action': 'trakt_catalogue_combined_worker', 'name': self.name, 'trakt_catalogue': 'true', 'trakt_list_type': list_type, 'discover_hide_watched': self.params.get('discover_hide_watched', 'false')}).worker()
        except Exception as e:
            kodi_utils.logger('Catalogue Trakt combiné séries', str(e))

        item_map = {}
        for item in movie_items or []:
            tmdb_id = self._combined_item_tmdb_id(item)
            if tmdb_id: item_map[('movie', tmdb_id)] = item
        for item in tv_items or []:
            tmdb_id = self._combined_item_tmdb_id(item)
            if tmdb_id: item_map[('tv', tmdb_id)] = item
        combined_items = []
        for row in page_data:
            item = item_map.get((row.get('media_type'), str(row.get('tmdb') or '')))
            if item: combined_items.append(item)
        if combined_items: kodi_utils.add_items(self.handle, combined_items)

        if total_pages > page_no:
            next_params = dict(self.params)
            next_params['new_page'] = str(page_no + 1)
            next_params['mode'] = 'trakt_catalogue.combined_results'
            next_params['action'] = 'trakt_catalogue_combined'
            for key in ('handle', 'iconImage', 'isFolder'):
                next_params.pop(key, None)
            kodi_utils.add_dir(self.handle, next_params, kodi_utils.local_string(32799), iconImage=kodi_utils.media_path('item_next.png'))
        kodi_utils.set_category(self.handle, self.name)
        kodi_utils.set_sort_method(self.handle, 'tvshows')
        kodi_utils.set_content(self.handle, 'tvshows')
        kodi_utils.end_directory(self.handle, False if kodi_utils.external_browse() else None)
        kodi_utils.set_view_mode('view.tvshows', 'tvshows')

    # ---------- Discover Trakt ----------
    def _discover_get(self):
        config = _safe_json_load(kodi_utils.get_property(DISCOVER_PROPERTY), {})
        if not config:
            config = _discover_defaults()
            self._discover_set(config)
        return config

    def _discover_set(self, config):
        kodi_utils.set_property(DISCOVER_PROPERTY, json.dumps(config, ensure_ascii=False, sort_keys=True))

    def _discover_list_label(self, list_type):
        return LIST_LABELS.get(list_type, 'Tendances')

    def _discover_filter_label(self, key):
        return FILTER_LABELS.get(key, str(key or ''))

    def _discover_label(self, config):
        media = {'movie': 'Films', 'tv': 'Séries', 'combined': 'Combiné'}.get(config.get('media_type'), 'Films')
        base = self._discover_list_label(config.get('list_type'))
        return '%s - %s' % (base, media)

    def _discover_result_params(self, config, name=None):
        media_type = config.get('media_type', 'movie')
        list_type = config.get('list_type', 'trending')
        filter_keys = (
            'query', 'years', 'genres', 'certifications', 'watchnow', 'runtimes',
            'ratings', 'votes', 'tmdb_ratings', 'tmdb_votes', 'imdb_ratings',
            'imdb_votes', 'rt_meters', 'rt_user_meters', 'metascores'
        )
        extra = {k: config.get(k) for k in filter_keys if config.get(k) not in ('', None)}
        if bool(config.get('hide_watched', False)):
            # Réutilise le filtre Discover natif des builders Films/Séries.
            # Il respecte automatiquement le fournisseur de suivi actif
            # (Local, Trakt ou MDbList).
            extra['discover_hide_watched'] = 'true'
        return self._result_params(media_type, list_type, name or self._discover_label(config), extra)

    @staticmethod
    def _discover_option_label(label, value=None):
        value = str(value or '').strip()
        return '%s : %s' % (label, value) if value else label

    def discover(self):
        # Même logique que TMDb Helper : le dossier Discover affiche d'abord
        # « Nouveau... », puis directement les recherches enregistrées.
        self._add({'mode': 'trakt_catalogue.discover_new', 'name': 'Nouveau...'}, 'Nouveau...', 'recherche-avancee.png')
        for row in self._saved_get():
            config = row.get('config') or {}
            name = str(row.get('name') or self._discover_label(config))
            media_type = str(config.get('media_type') or 'movie')
            icon = 'film.png' if media_type == 'movie' else ('television.png' if media_type == 'tv' else 'liste.png')
            saved_id = str(row.get('id') or '')
            delete_url = kodi_utils.build_url({'mode': 'trakt_catalogue.discover_delete', 'saved_id': saved_id, 'name': name})
            context = [('Supprimer cette recherche', 'RunPlugin(%s)' % delete_url)] if saved_id else []
            self._add(self._discover_result_params(config, name=name), name, icon, True, context_items=context)
        self._finish('Découvrir Trakt')

    def _discover_refresh(self, select_action=None):
        if self._discover_modal_active and self._discover_dialog is not None:
            try:
                return self._discover_dialog.refresh(select_action=select_action)
            except Exception as exc:
                kodi_utils.logger('Trakt Discover', 'modal refresh failed: %s' % exc)
        kodi_utils.navigation_update({'mode': 'trakt_catalogue.discover_editor', 'name': 'Nouveau...'})

    def _run_discover_dialog(self, reset=False):
        if reset:
            self._discover_set(_discover_defaults())
        try:
            from windows.trakt_discover import TraktDiscoverDialog
            dialog = TraktDiscoverDialog('DialogSelect.xml', kodi_utils.get_addoninfo('path'), controller=self)
            self._discover_modal_active = True
            self._discover_dialog = dialog
            dialog.doModal()
            result = dialog.result
        except Exception as exc:
            kodi_utils.logger('Trakt Discover', 'modal failed: %s' % exc)
            result = None
        finally:
            self._discover_modal_active = False
            self._discover_dialog = None
            try: del dialog
            except Exception: pass
        return result

    def discover_new(self):
        result = self._run_discover_dialog(reset=True)
        if result:
            action, value = result
            if action == 'export' and value:
                self._discover_export_target(value)
        # Comme TMDb Helper, après fermeture du modal on retrouve Nouveau... et
        # les recherches sauvegardées dans le dossier Discover.
        self.discover()

    def discover_editor(self):
        # Compatibilité avec les anciens raccourcis 2.2.90 : ouvrir le même modal
        # en conservant la configuration courante.
        result = self._run_discover_dialog(reset=False)
        if result:
            action, value = result
            if action == 'export' and value:
                self._discover_export_target(value)
        self.discover()

    def discover_media(self):
        config = self._discover_get()
        labels = ['Films', 'Séries', 'Combiné']
        values = ['movie', 'tv', 'combined']
        try: current = values.index(config.get('media_type'))
        except Exception: current = 0
        choice = kodi_utils.dialog.select('Discover Trakt - Type de média', labels, preselect=current)
        if choice < 0: return
        config['media_type'] = values[choice]
        # Genres et certifications dépendent du type de média.
        config.pop('certifications', None); config.pop('certifications_label', None)
        config.pop('genres', None); config.pop('genres_label', None)
        self._discover_set(config)
        self._discover_refresh('media')

    def discover_list(self):
        config = self._discover_get()
        # « Anticipés » reste toujours proposé dans Discover, même lorsque la
        # restriction alkoPaste est active : cette catégorie est volontairement
        # hors filtrage local puisqu'elle sert à découvrir du contenu à venir.
        keys = ('trending', 'popular', 'played', 'watched', 'anticipated')
        labels = [LIST_LABELS[k] for k in keys]
        try: current = keys.index(config.get('list_type'))
        except Exception: current = 0
        choice = kodi_utils.dialog.select('Discover Trakt - Liste de départ', labels, preselect=current)
        if choice < 0: return
        config['list_type'] = keys[choice]
        self._discover_set(config)
        self._discover_refresh('list')

    def discover_query(self):
        config = self._discover_get()
        value = kodi_utils.dialog.input('Discover Trakt - Mot clé', defaultt=str(config.get('query') or ''))
        if value is None: return
        value = str(value).strip()
        if value: config['query'] = value
        else: config.pop('query', None)
        self._discover_set(config)
        self._discover_refresh('query')

    def discover_hide_watched(self):
        config = self._discover_get()
        config['hide_watched'] = not bool(config.get('hide_watched', False))
        self._discover_set(config)
        self._discover_refresh('hide_watched')

    def _discover_select_range(self, title, values, labels, current='', clear_label='Aucun filtre'):
        current = str(current or '').strip()
        parts = current.split('-', 1) if current else ['', '']
        options = [clear_label] + list(labels)
        try: pre_min = list(values).index(parts[0]) + 1 if parts[0] else 0
        except Exception: pre_min = 0
        choice = kodi_utils.dialog.select('%s - minimum' % title, options, preselect=pre_min)
        if choice < 0: return None
        if choice == 0: return ''
        minimum = str(values[choice - 1])
        # Maximum : conserve seulement les valeurs >= au minimum dans leur ordre naturel.
        try:
            min_num = float(minimum)
            valid = [(str(v), str(l)) for v, l in zip(values, labels) if float(v) >= min_num]
        except Exception:
            valid = [(str(v), str(l)) for v, l in zip(values, labels)]
        max_values = [v for v, _ in valid]
        max_labels = ['Sans maximum'] + [l for _, l in valid]
        try: pre_max = max_values.index(parts[1]) + 1 if len(parts) > 1 and parts[1] else 0
        except Exception: pre_max = 0
        choice2 = kodi_utils.dialog.select('%s - maximum' % title, max_labels, preselect=pre_max)
        if choice2 < 0: return None
        maximum = max_values[choice2 - 1] if choice2 > 0 else ''
        return '%s-%s' % (minimum, maximum) if maximum else minimum

    def discover_years(self):
        config = self._discover_get()
        current_year = datetime.now().year
        values = [str(i) for i in range(current_year + 5, 1899, -1)]
        value = self._discover_select_range('Années', values, values, config.get('years', ''))
        if value is None: return
        if value: config['years'] = value
        else: config.pop('years', None)
        self._discover_set(config)
        self._discover_refresh('years')

    def discover_genres(self):
        from indexers.trakt_api import trakt_catalogue_genres
        config = self._discover_get()
        media_type = config.get('media_type', 'movie')
        if media_type == 'combined':
            merged = {}
            for source_type in ('movie', 'tv'):
                for item in trakt_catalogue_genres(source_type) or []:
                    slug = str(item.get('slug') or '').strip()
                    if slug: merged[slug] = item
            genres = list(merged.values())
        else:
            genres = trakt_catalogue_genres(media_type) or []
        values, labels = [], []
        for item in sorted(genres, key=lambda x: GENRE_FR.get(str(x.get('slug') or '').lower(), str(x.get('name') or '')).lower()):
            slug = str(item.get('slug') or '').strip()
            if not slug: continue
            if config.get('list_type') != 'anticipated' and not self._genre_available(media_type, slug): continue
            values.append(slug)
            labels.append(GENRE_FR.get(slug.lower(), str(item.get('name') or slug).strip()))
        current = [i for i in str(config.get('genres') or '').replace('%2C', ',').split(',') if i]
        preselect = [idx for idx, slug in enumerate(values) if slug in current]
        choice = kodi_utils.dialog.multiselect('Discover Trakt - Genres', labels, preselect=preselect)
        if choice is None: return
        if choice:
            selected = [values[i] for i in choice]
            config['genres'] = ','.join(selected)
            config['genres_label'] = ', '.join(labels[i] for i in choice)
        else:
            config.pop('genres', None); config.pop('genres_label', None)
        self._discover_set(config)
        self._discover_refresh('genres')

    def discover_certification(self):
        from indexers.trakt_api import trakt_catalogue_certifications
        config = self._discover_get()
        media_type = config.get('media_type', 'movie')
        if media_type == 'combined':
            merged = {}
            for source_type in ('movie', 'tv'):
                for item in trakt_catalogue_certifications(source_type) or []:
                    cert = str(item.get('certification') or '').strip().lower()
                    if cert: merged[cert] = item
            rows = list(merged.values())
        else:
            rows = trakt_catalogue_certifications(media_type) or []
        values, labels = [], []
        for item in rows:
            cert = str(item.get('certification') or '').strip()
            if not cert or cert.lower() in values: continue
            if config.get('list_type') != 'anticipated' and not self._cert_available(media_type, cert): continue
            values.append(cert.lower()); labels.append(cert.upper())
        if not values and media_type in ('movie', 'combined'):
            values = ['g', 'pg', 'pg-13', 'r', 'nr']
            labels = ['G', 'PG', 'PG-13', 'R', 'NR']
        current = [i.strip().lower() for i in str(config.get('certifications') or '').replace('%2C', ',').split(',') if i.strip()]
        preselect = [idx for idx, value in enumerate(values) if value in current]
        choice = kodi_utils.dialog.multiselect('Discover Trakt - Certifications', labels, preselect=preselect)
        if choice is None: return
        if choice:
            selected = [values[i] for i in choice]
            config['certifications'] = ','.join(selected)
            config['certifications_label'] = ', '.join(labels[i] for i in choice)
        else:
            config.pop('certifications', None); config.pop('certifications_label', None)
        self._discover_set(config)
        self._discover_refresh('certification')

    def discover_availability(self):
        config = self._discover_get()
        values = ['', 'any']
        labels = ['Tous les services de streaming', 'Disponible sur un service de streaming']
        # Ces deux valeurs sont personnalisées par le compte Trakt.
        if settings.trakt_token():
            values.extend(['favorites', 'subscriptions'])
            labels.extend(['Services de streaming favoris', 'Abonnements aux services de streaming'])
        try: current = values.index(str(config.get('watchnow') or ''))
        except Exception: current = 0
        choice = kodi_utils.dialog.select('Discover Trakt - Disponibilité', labels, preselect=current)
        if choice < 0: return
        value = values[choice]
        if value:
            config['watchnow'] = value
            config['watchnow_label'] = labels[choice]
        else:
            config.pop('watchnow', None); config.pop('watchnow_label', None)
        self._discover_set(config)
        self._discover_refresh('availability')

    def discover_range(self):
        config = self._discover_get()
        key = self.params.get('filter_key')
        if key not in FILTER_LABELS: return
        label = FILTER_LABELS[key]
        current = str(config.get(key) or '')

        # TMDb Helper : notes via listes de valeurs; votes via saisie numérique
        # simple; durée via bornes numériques.
        percent_keys = ('ratings', 'rt_meters', 'rt_user_meters')
        ten_scale_keys = ('tmdb_ratings', 'imdb_ratings', 'metascores')
        vote_keys = ('votes', 'tmdb_votes', 'imdb_votes')
        if key in percent_keys:
            values = [str(i) for i in range(0, 101, 5)]
            labels = ['%s %%' % i for i in range(0, 101, 5)]
            value = self._discover_select_range(label, values, labels, current)
            if value is None: return
        elif key in ten_scale_keys:
            values = ['%.1f' % (i / 10.0) for i in range(0, 101, 5)]
            labels = list(values)
            value = self._discover_select_range(label, values, labels, current)
            if value is None: return
        elif key in vote_keys:
            value = kodi_utils.dialog.input('%s - minimum' % label, defaultt=current.split('-', 1)[0] if current else '', type=kodi_utils.xbmcgui.INPUT_NUMERIC)
            if value is None: return
            value = str(value).strip()
        else:
            parts = current.split('-', 1) if current else ['', '']
            minimum = kodi_utils.dialog.input('%s - minimum' % label, defaultt=parts[0] if parts else '', type=kodi_utils.xbmcgui.INPUT_NUMERIC)
            if minimum is None: return
            maximum = kodi_utils.dialog.input('%s - maximum' % label, defaultt=parts[1] if len(parts) > 1 else '', type=kodi_utils.xbmcgui.INPUT_NUMERIC)
            if maximum is None: return
            minimum, maximum = str(minimum).strip(), str(maximum).strip()
            value = '%s-%s' % (minimum, maximum) if minimum and maximum else (minimum or maximum)

        if value: config[key] = value
        else: config.pop(key, None)
        self._discover_set(config)
        self._discover_refresh('range')

    def _discover_export_target(self, target):
        config = dict(self._discover_get())
        name = self._discover_label(config)
        final_params = self._discover_result_params(config, name=name)
        icon = self._icon('recherche-avancee.png')
        final_params['iconImage'] = icon
        mode = 'menu_editor.shortcut_folder_add_item' if str(target or '').strip().lower() == 'folder' else 'menu_editor.add_external'
        url_params = {
            'mode': mode,
            'name': name,
            'menu_item': json.dumps(final_params, ensure_ascii=False),
            'iconImage': icon
        }
        kodi_utils.execute_builtin('RunPlugin(%s)' % kodi_utils.build_url(url_params))

    def discover_export(self):
        target = str(self.params.get('target') or 'menu').strip().lower()
        return self._discover_export_target(target)

    def discover_reset(self):
        self._discover_set(_discover_defaults())
        self._discover_refresh()

    def _saved_get(self):
        rows = MainCache().get(SAVED_CACHE_KEY)
        return list(rows) if isinstance(rows, list) else []

    def _saved_set(self, rows):
        MainCache().set(SAVED_CACHE_KEY, list(rows), expiration=timedelta(days=3650))

    def discover_save(self):
        config = dict(self._discover_get())
        default_name = self._discover_label(config)
        name = kodi_utils.dialog.input('Nom de la recherche Discover', defaultt=default_name)
        if not name or not str(name).strip(): return False
        rows = self._saved_get()
        saved_id = str(time.time_ns()) if hasattr(time, 'time_ns') else str(int(time.time() * 1000000))
        rows.insert(0, {'id': saved_id, 'name': str(name).strip(), 'config': config})
        # Garde une liste raisonnable et légère sur Android.
        self._saved_set(rows[:50])
        kodi_utils.notification('Recherche Discover enregistrée')
        if not self._discover_modal_active:
            kodi_utils.navigation_update({'mode': 'trakt_catalogue.discover', 'name': 'Découvrir Trakt'})
        return True

    def discover_saved(self):
        rows = self._saved_get()
        if rows:
            self._add({'mode': 'trakt_catalogue.discover_delete', 'name': 'Supprimer une recherche'}, 'Supprimer une recherche...', 'poubelle.png', False)
        for row in rows:
            config = row.get('config') or {}
            name = row.get('name') or self._discover_label(config)
            self._add(self._discover_result_params(config, name=name), name, 'marque-page.png')
        self._finish('Recherches Discover sauvegardées')

    def discover_delete(self):
        rows = self._saved_get()
        if not rows: return kodi_utils.notification('Aucune recherche sauvegardée')
        saved_id = str(self.params.get('saved_id') or '')
        if saved_id:
            new_rows = [row for row in rows if str(row.get('id') or '') != saved_id]
            if len(new_rows) == len(rows): return kodi_utils.notification('Recherche introuvable')
            rows = new_rows
        else:
            labels = [str(i.get('name') or 'Discover') for i in rows]
            choice = kodi_utils.dialog.select('Supprimer une recherche', labels)
            if choice < 0: return
            rows.pop(choice)
        self._saved_set(rows)
        kodi_utils.notification('Recherche supprimée')
        kodi_utils.navigation_update({'mode': 'trakt_catalogue.discover', 'name': 'Découvrir Trakt'})
