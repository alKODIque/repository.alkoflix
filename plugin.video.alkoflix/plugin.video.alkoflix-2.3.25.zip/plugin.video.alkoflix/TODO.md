# TODO alkoFlix — navigation des séries

- [ ] Mémoriser le groupe alternatif choisi par série et le réutiliser dans « Continuer à regarder » et « À suivre », avec une commande pour revenir au découpage TMDb standard.

## Limite actuelle à annoncer

Le choix d’un groupe alternatif est conservé pendant la lecture et l’enchaînement Up Next. En revenant par « Continuer à regarder » ou « À suivre », la liste reprend encore l’ordre et la numérotation TMDb habituels. Les épisodes vus et les reprises restent associés aux identifiants TMDb d’origine, selon le fournisseur de suivi sélectionné : local alkoFlix, Trakt ou MDbList.

Cette mémorisation est prévue pour une évolution ultérieure ; elle n’est pas incluse dans la version 2.3.24.

## Limitation liée aux liens

La reconnaissance du bon épisode dépend aussi du nommage des liens et fichiers proposés par leurs uploadeurs. Un numéro ambigu, incomplet ou incorrect peut entraîner la sélection d’un mauvais épisode ; tous les cas ne peuvent pas être évités automatiquement.
