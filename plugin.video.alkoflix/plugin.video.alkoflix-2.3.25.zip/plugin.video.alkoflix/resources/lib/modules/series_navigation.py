# -*- coding: utf-8 -*-
"""Series navigation data; canonical S/E remain the tracking identifiers."""

from threading import Thread
from indexers import metadata, tmdb_api
from caches import watched_cache
from modules import settings
from modules.utils import adjust_premiered_date


def episode_key(item):
	return int(item['season']), int(item['episode'])


def group_episode_rows(groups, group_id):
	"""Keep TMDb's group order separately from the canonical episode key."""
	rows = []
	for group in sorted(groups or [], key=lambda item: int(item.get('order') or 0)):
		for item in sorted(group.get('episodes') or [], key=lambda item: int(item.get('order') or 0)):
			try:
				season, episode = int(item['season_number']), int(item['episode_number'])
				if season < 0 or episode < 1: continue
				rows.append({
					'season': season, 'episode': episode, 'title': item.get('name') or '',
					'plot': item.get('overview') or '', 'premiered': item.get('air_date') or '',
					'custom_season': int(group['order']), 'custom_episode': int(item['order']) + 1,
					'episode_group_id': group_id, 'episode_subgroup_id': str(group['id'])
				})
			except (KeyError, TypeError, ValueError):
				continue
	return rows


def next_group_episode(meta, user_info):
	"""The next entry may jump seasons or reverse the canonical TMDb order."""
	group_id = meta['episode_group_id']
	rows = group_episode_rows(tmdb_api.episode_group_details(group_id, user_info.get('tmdb_api')), group_id)
	key = episode_key(meta)
	subgroup_id = str(meta.get('episode_subgroup_id') or '')
	for position, row in enumerate(rows):
		if episode_key(row) != key: continue
		if subgroup_id and row['episode_subgroup_id'] != subgroup_id: continue
		if meta.get('custom_episode') is not None and row['custom_episode'] != int(meta['custom_episode']): continue
		return rows[position + 1] if position + 1 < len(rows) else None
	return None


def follow_episode_data(meta, user_info, provider, watched_info, bookmarks, current_date, adjust_hours):
	"""Reuse the active provider's continuation rules without writing history."""
	tmdb_id = meta['tmdb_id']
	keys = watched_cache.get_continue_watching_episode_keys(provider, tmdb_id, watched_info)
	has_history = keys is not None or any(
		str(row[0]) == str(tmdb_id) and int(row[1]) > 0 for row in watched_info)
	has_resume = any(
		str(row[0]) == str(tmdb_id) and int(row[3]) > 0 and (float(row[1] or 0) > 0 or float(row[2] or 0) > 0)
		for row in bookmarks)
	if not has_history and not has_resume:
		seasons = sorted(int(row['season_number']) for row in meta.get('season_data') or [] if int(row['season_number']) > 0)
		return (metadata.season_episodes_meta(seasons[0], meta, user_info) or [], None) if seasons else ([], None)
	episodes = metadata.all_episodes_meta(meta, user_info, Thread) or []
	if not settings.show_specials(): episodes = [row for row in episodes if int(row['season']) != 0]
	keys = watched_cache.extend_continue_provider_keys(provider, tmdb_id, watched_info, keys, episodes, current_date, adjust_hours)
	return episodes, keys


def follow_episode_is_eligible(item, tmdb_id, watched_info, provider_keys, bookmarks, current_date, adjust_hours):
	"""À suivre permet aussi de parcourir les épisodes cyan de la série.

	Les dates futures/inconnues n'excluent pas ces épisodes, même lorsque le
	fournisseur ne les inclut pas encore dans sa progression native. Les règles
	de Continuer à regarder restent inchangées dans watched_cache.
	"""
	try:
		key = episode_key(item)
		if key[0] < 0 or key[1] <= 0: return False
		resumetime, progress = watched_cache.get_resumetime(bookmarks, tmdb_id, *key)
		if progress != '0' or resumetime != '0': return True
		if watched_cache.get_watched_status_episode(watched_info, str(tmdb_id), *key)[0]: return False
		episode_date = adjust_premiered_date(item.get('premiered'), adjust_hours)[0]
		if not episode_date or current_date < episode_date: return True
		return provider_keys is None or key in provider_keys
	except (TypeError, ValueError, KeyError):
		return False


def visible_group_rows(rows, tmdb_id, watched_info, bookmarks, current_date, adjust_hours, show_unaired, hide_watched):
	"""Filter before pagination, using the same visibility rules as Seasons."""
	visible = []
	for row in rows:
		season, episode = episode_key(row)
		resumetime, progress = watched_cache.get_resumetime(bookmarks, tmdb_id, season, episode)
		has_resume = progress != '0' or resumetime != '0'
		watched = watched_cache.get_watched_status_episode(watched_info, str(tmdb_id), season, episode)[0]
		date = adjust_premiered_date(row.get('premiered'), adjust_hours)[0]
		unaired = not date or current_date < date
		if unaired and not show_unaired and not has_resume: continue
		if hide_watched and watched and not unaired and not has_resume: continue
		visible.append(row)
	return visible


def enrich_group_rows(rows, meta, user_info):
	"""Fetch only the canonical seasons needed by the selected page."""
	seasons = {season: {
		episode_key(row): row for row in metadata.season_episodes_meta(season, meta, user_info) or []
	} for season in sorted({row['season'] for row in rows})}
	result = []
	for row in rows:
		# Retain localized titles, durations, cast, artwork and episode metadata.
		item = dict(seasons[row['season']].get(episode_key(row)) or {})
		for key, value in row.items():
			if key in ('title', 'plot', 'premiered') and item.get(key): continue
			item[key] = value
		item.setdefault('mediatype', 'episode')
		item.setdefault('director', '')
		item.setdefault('writer', '')
		item.setdefault('rating', 0)
		item.setdefault('votes', 0)
		result.append(item)
	return result
