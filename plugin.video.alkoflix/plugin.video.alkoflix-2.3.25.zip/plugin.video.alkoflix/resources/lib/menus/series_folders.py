# -*- coding: utf-8 -*-
"""Extra series folders, alongside the standard TMDb seasons."""

import sys
from indexers import metadata, tmdb_api
from caches.watched_cache import get_watched_info_tv, get_watched_status_episode
from modules import kodi_utils, settings
from modules.utils import adjust_premiered_date, get_datetime

FOLLOW_LABEL, GROUPS_LABEL = 'À suivre', 'Groupes alternatifs'
CONTEXT_KEYS = (
	'tmdb_id', 'catalogue_id', 'parent_fav_type', 'series_fav_type', 'tv_fav_type',
	'anime_context', 'watched_indicators', 'ignore_menu_hide_watched'
)
GROUP_TYPES = {
	'Original air date': 'Diffusion originale', 'Absolute': 'Ordre absolu', 'DVD': 'DVD',
	'Digital': 'Diffusion numérique', 'Story arc': 'Arcs narratifs', 'Production': 'Production', 'TV': 'Télévision'
}


def context_params(params):
	return {key: params[key] for key in CONTEXT_KEYS if key in params}


def folder_item(params, meta, label, plot='', artwork=None, properties=None):
	poster = settings.resolve_poster_art(meta, kodi_utils.media_path('tv.png'))
	_, _, fanart_main, fanart_backup = settings.get_art_provider()
	fanart = meta.get(fanart_main) or meta.get(fanart_backup) or ''
	landscape = settings.resolve_landscape_art(meta, fanart or poster)
	art = {
		'poster': poster, 'icon': poster, 'thumb': landscape, 'fanart': fanart, 'landscape': landscape,
		'tvshow.poster': poster, 'tvshow.landscape': landscape,
		'clearlogo': meta.get('clearlogo') or meta.get('tmdblogo') or ''
	}
	if artwork: art.update(artwork)
	item = kodi_utils.make_listitem()
	item.setLabel(label)
	item.setArt(kodi_utils.clean_art(art))
	item.setProperties(dict({'label_override': label, 'IsPlayable': 'false'}, **(properties or {})))
	total = int((properties or {}).get('totalepisodes') or 0)
	seen = int((properties or {}).get('watchedepisodes') or 0)
	playcount = 1 if total and seen >= total else 0
	info = {'mediatype': 'tvshow', 'title': label, 'tvshowtitle': meta.get('title') or '', 'plot': plot,
		'playcount': playcount, 'overlay': 5 if playcount else 4}
	if kodi_utils.get_kodi_version() < 20:
		item.setInfo('video', info)
		item.setUniqueIDs({'tmdb': str(meta['tmdb_id'])})
	else:
		video = item.getVideoInfoTag(offscreen=True)
		video.setMediaType('tvshow')
		video.setTitle(label)
		video.setTvShowTitle(info['tvshowtitle'])
		video.setPlot(plot)
		video.setPlaycount(playcount)
		video.setUniqueIDs({'tmdb': str(meta['tmdb_id'])})
	return kodi_utils.build_url(params), item, True


def special_season_items(params, meta):
	# Targeted season views (e.g. favourites) must remain targeted.
	if 'season' in params and params['season'] != 'all': return []
	base = context_params(params)
	base['tmdb_id'] = meta['tmdb_id']
	items = []
	for mode, label, plot in (
		('groups', GROUPS_LABEL, 'Parcourir les découpages TMDb alternatifs : ordre absolu, arcs narratifs, DVD et autres regroupements disponibles.'),
		('follow', FOLLOW_LABEL, 'Reprendre les épisodes en cours et poursuivre la série selon votre fournisseur de suivi. Pour une série jamais commencée, afficher les épisodes de la première saison.\n\nÀ noter : ce dossier utilise encore l’ordre TMDb habituel. Le choix d’un groupe alternatif n’est pas mémorisé pour les dossiers de suivi.')
	):
		if mode == 'groups' and not tmdb_api.episode_groups(meta['tmdb_id'], settings.metadata_user_info().get('tmdb_api')): continue
		if mode == 'follow' and params.get('season') == 'all': continue
		properties = {'IsSpecial': 'true', 'specialseason': label}
		if params.get('season') == 'all': properties['SpecialSort'] = 'top'
		artwork = None
		if mode == 'follow':
			from modules.artwork_utils import menu_icon_artwork
			artwork = menu_icon_artwork(kodi_utils.menu_icons_path('lecture-bouton.png'))
		items.append(folder_item(
			dict(base, mode='series_folders.%s' % mode), meta, label, plot, artwork,
			properties
		))
	return items


class SeriesFolders:
	def __init__(self, params):
		self.params = params
		self.user_info = settings.metadata_user_info()
		self.current_date = get_datetime()
		self.meta = None

	def _metadata(self):
		if self.meta is None:
			self.meta = metadata.tvshow_meta('tmdb_id', self.params['tmdb_id'], self.user_info, self.current_date)
		return self.meta

	def _finish(self, items, label):
		handle = int(sys.argv[1])
		kodi_utils.add_items(handle, items)
		kodi_utils.set_category(handle, '%s — %s' % (self._metadata().get('title') or '', label))
		kodi_utils.set_sort_method(handle, 'unsorted')
		kodi_utils.set_content(handle, 'seasons')
		kodi_utils.end_directory(handle, False)
		kodi_utils.set_view_mode('view.seasons', 'seasons')

	def groups(self):
		meta = self._metadata()
		base, items = context_params(self.params), []
		groups = tmdb_api.episode_groups(meta['tmdb_id'], self.user_info.get('tmdb_api'))
		for group in groups:
			label = group.get('name') or GROUP_TYPES.get(group.get('type'), str(group.get('type') or GROUPS_LABEL))
			kind = GROUP_TYPES.get(group.get('type'), str(group.get('type') or ''))
			plot = '%s · %s groupes · %s épisodes' % (kind, group.get('group_count') or 0, group.get('episode_count') or 0)
			if group.get('description'): plot += '\n\n%s' % group['description']
			params = dict(base, mode='series_folders.group_seasons', episode_group_id=group['id'], group_name=label)
			items.append(folder_item(params, meta, label, plot))
		self._finish(items, GROUPS_LABEL)

	def group_seasons(self):
		from modules.series_navigation import group_episode_rows
		meta, items = self._metadata(), []
		provider = int(self.params.get('watched_indicators', settings.watched_indicators()))
		watched = get_watched_info_tv(provider)
		group_id = self.params['episode_group_id']
		groups = tmdb_api.episode_group_details(group_id, self.user_info.get('tmdb_api'))
		base = context_params(self.params)
		for group in groups:
			label = group.get('name') or 'Groupe %s' % group.get('order', '')
			rows = group_episode_rows([group], group_id)
			aired = []
			for row in rows:
				aired_date = adjust_premiered_date(row['premiered'], settings.date_offset())[0]
				if aired_date and aired_date <= self.current_date: aired.append(row)
			count = len({(row['season'], row['episode']) for row in aired})
			seen = sum(get_watched_status_episode(watched, str(meta['tmdb_id']), *key)[0] for key in {(row['season'], row['episode']) for row in aired})
			props = {'group_season': str(group.get('order', '')), 'totalepisodes': str(count), 'watchedepisodes': str(seen), 'unwatchedepisodes': str(max(0, count - seen))}
			if count and 0 < seen < count: props['WatchedProgress'] = str(int(seen * 100 / count))
			params = dict(base, mode='series_folders.group_episodes', episode_group_id=group_id,
				episode_subgroup_id=group['id'], group_name=self.params.get('group_name', ''), subgroup_name=label)
			items.append(folder_item(params, meta, label, '%s épisodes' % len(rows), properties=props))
		self._finish(items, self.params.get('group_name') or GROUPS_LABEL)

	def follow(self):
		from menus.seasons import Seasons
		params = dict(context_params(self.params), mode='build_episode_list', series_view='follow', season='all')
		Seasons(params).run()

	def group_episodes(self):
		from menus.seasons import Seasons
		params = dict(self.params, mode='build_episode_list', series_view='group', season='all')
		Seasons(params).run()
