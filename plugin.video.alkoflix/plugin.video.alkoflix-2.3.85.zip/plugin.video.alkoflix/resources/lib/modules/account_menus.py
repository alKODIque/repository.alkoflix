"""Actions de gestion des comptes connectés pour les fiches Kodi."""
from modules import kodi_utils

_MANAGERS = (
    ('trakt', kodi_utils.local_string(32198), 'trakt_manager_choice'),
    ('mdblist', kodi_utils.local_string(32200), 'mdbl_manager_choice'),
    ('tmdblist', 'Gestion TMDb', 'tmdb_manager_choice'),
)


def manager_entries(services, media_type, tmdb_id, imdb_id=None, tvdb_id=None):
    if not tmdb_id or str(tmdb_id) in ('0', 'None'):
        return
    parent_show = media_type in ('season', 'episode')
    params = {'tmdb_id': tmdb_id, 'imdb_id': imdb_id or 'None', 'tvdb_id': tvdb_id or 'None',
              'media_type': 'tvshow' if parent_show else media_type}
    for key, label, mode in _MANAGERS:
        if services.get(key):
            command = 'RunPlugin(%s)' % kodi_utils.build_url(dict(params, mode=mode))
            yield key, label + ' (série)' if parent_show else label, command


def show_manager_items(services, media_type, tmdb_id, imdb_id, tvdb_id):
    return [(label, command) for _, label, command in
            manager_entries(services, media_type, tmdb_id, imdb_id, tvdb_id)]
