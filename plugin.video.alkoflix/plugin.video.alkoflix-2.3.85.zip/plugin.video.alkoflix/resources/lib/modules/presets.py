# -*- coding: utf-8 -*-
# plugin.video.alkoflix
# resources/lib/modules/presets.py

import base64
import gzip
import io
import json
import xml.etree.ElementTree as ET

from modules import kodi_utils
from modules.alkopastes_api import API_URL, _mask_code
from modules.settings_compat import RETIRED_SETTING_IDS, is_retired_setting, active_setting_ids, active_settings_defaults

PRESET_BACKUP_TYPE = 'alkoflix_settings_preset_backup'
PRESET_BACKUP_VERSION = 1
PRESET_MAX_SETTINGS_BYTES = 4 * 1024 * 1024
PRESET_CODES = {
	'1080p': '7LAefBmA',
	'4k': 'yBmDcFEH'
}
PRESET_LABELS = {
	'1080p': 'Réglages optimisés 1080p',
	'4k': 'Réglages optimisés 4K'
}
REMOVED_PRESET_SETTING_IDS = set(RETIRED_SETTING_IDS) | {
	'provider.ygg', 'provider.torr9', 'private.torr9.api_key', 'provider.movix', 'results.movix_fallback',
	'provider.hydracker', 'private.hydracker.api_key',
	'catalogue.alkopaste.enabled', 'nextep.include_airdate'
}

# Ces réglages ne doivent jamais être écrasés par un préréglage officiel.
# Ils couvrent les comptes, tokens, codes de sauvegarde, clés API personnelles,
# manifests perso, trackers privés et autres données liées à l'utilisateur/appareil.
PROTECTED_EXACT = set((
	# Préréglages visibles : on les réapplique après restauration selon le choix local.
	'preset.apply_1080p', 'preset.apply_4k',
	'preset.autoplay', 'preset.autoplay_display',
	'preset.certification.country', 'preset.certification.country_display', 'preset.certification.country_choice',
	'preset.active_profile',
	'trakt_catalogue.alkopaste_only',
	# Les échéances des tâches appartiennent à l'installation, pas au préréglage.
	'alkoflix.update_check.due', 'database.maintenance.due',

	# Manifests et sources personnelles.
	# On conserve les URLs/noms et options privées, mais pas l'état activé/désactivé
	# des sources : un préréglage officiel doit pouvoir couper un manifest déjà configuré.
	'catalogue.custom.manifest_url',
	'aiostreams_custom.manifest_url', 'aiostreams_custom.prefer_debrid',
	'lumio.manifest_url',
	'custom_1.name', 'custom_1.manifest_url',
	'custom_2.name', 'custom_2.manifest_url',
	'results.apply_to_external_sources',

	# Trackers privés : garder les clés personnelles, mais pas l'état activé/désactivé.
	# Les préréglages optimisés doivent pouvoir les désactiver sans effacer les API.
	'private.c411.api_key',
	'private.tr4ker.api_key',
	'private.v3x.api_key',
	'private.draupnirr.api_key',
	'private.yggreborn.api_key',

	# Comptes / services / clés personnelles.
	'rpdb_api_key', 'get_rpdb_movies', 'get_rpdb_series',
	'fanarttv.use_own_key', 'fanart_client_key_user', 'fanarttv.default',
	'tmdb.use_own_key', 'tmdb_api_user',
	'subtitles.apikey',
	'provider.easynews', 'easynews_user', 'easynews_password',

	# Débrideurs et clouds personnels.
	'ad.token', 'ad.account_id', 'ad.enabled', 'ad.torrent.enabled', 'ad.hoster.enabled',
	'store_torrent.alldebrid', 'provider.ad_cloud', 'ad_cloud.title_filter', 'check.ad_cloud',
	'results.sort_adcloud_first', 'ad.priority', 'ad.expires',
	'rd.client_id', 'rd.secret', 'rd.refresh', 'rd.token', 'rd.username', 'rd.enabled',
	'rd.torrent.enabled', 'rd.hoster.enabled', 'store_torrent.real-debrid', 'provider.rd_cloud',
	'rd_cloud.title_filter', 'check.rd_cloud', 'results.sort_rdcloud_first', 'rd.priority', 'rd.expires',
	'tb.token', 'tb.account_id', 'tb.enabled', 'tb.torrent.enabled', 'store_torrent.torbox',
	'provider.torboxnews', 'store_usenet.torbox', 'tb.user_engines_only', 'provider.tb_cloud',
	'tb_cloud.title_filter', 'check.tb_cloud', 'results.sort_tbcloud_first', 'tb.priority', 'tb.expires',

	# Statuts, comptes et favoris externes.
	'trakt_indicators_active', 'mdbl_indicators_active', 'watched_indicators', 'amble.indicators',
	'ratings.provider',
	'trakt.refresh', 'trakt.expires', 'trakt.token', 'trakt_user',
	'mdblist.auth_type', 'mdblist.access_token', 'mdblist.refresh_token', 'mdblist.expires',
	'mdblist.token', 'mdblist_user',
	'tmdb.session_id', 'tmdb.session_account_id', 'tmdb.username', 'tmdb.token', 'tmdb.account_id',
	'favourites.sync_trakt', 'favourites.sync_tmdb', 'root.favourites.source',

	# alkoPastes : codes, rôles, synchro, appareils.
	'alkopastes_user', 'alkopastes.api_mode', 'alkopastes.api_key_user',
	'alkopastes.favourites_secondary_lock', 'alkopastes.favourites_multi_device',
	'alkopastes.favourites_sync_enabled', 'alkopastes.favourites_auto_restore_enabled',
	'alkopastes.favourites_auto_restore_interval', 'alkopastes.favourites_single_device',
	'alkopastes.favourites_auto_restore_due', 'alkopastes.favourites_auto_restore_last_hash',
	'alkopastes.favourites_auto_restore_backoff_count', 'alkopastes.favourites_sync_pending',
	'alkopastes.favourites_sync_pending_at', 'alkopastes.favourites_sync_last_flush',
	'alkopastes.favourites_cleanup_last', 'alkopastes.favourites_device_hash',
	'alkopastes.userdata_master_installation', 'alkopastes.userdata_secondary_installation_v2',
	'alkopastes.userdata_multi_backup_code', 'alkopastes.userdata_backup_code',
	'alkopastes.userdata_multi_device', 'alkopastes.userdata_secondary_installation',
	'alkopastes.userdata_backup_mode', 'alkopastes.userdata_installation_role',
	'alkopastes.userdata_auto_backup', 'alkopastes.userdata_auto_backup_interval',
	'alkopastes.userdata_auto_backup_due', 'alkopastes.userdata_auto_restore',
	'alkopastes.userdata_auto_restore_due', 'alkopastes.userdata_auto_restore_last_created',
	'alkopastes.userdata_device_id', 'alkopastes.userdata_master_device_hash',

	# Contrôle parental : ne jamais toucher au PIN ni à l'état de verrouillage.
	'parental.pin_hash', 'parental.settings_unlocked', 'parental.pin_backup_code'
))

PROTECTED_PREFIXES = (
	'private.',
	'alkopastes.',
	'favourites.',
	'trakt.',
	'mdblist.',
	'tmdb.session_',
	'parental.pin',
)

PROTECTED_SUBSTRINGS = (
	'.manifest_url',
	'_api_user',
	'api_key',
	'.token',
	'.refresh',
	'.secret',
	'.password',
)


def _preset_key(value):
	value = str(value or '').strip().lower()
	if value in ('4k', '4K'.lower(), 'uhd'): return '4k'
	return '1080p'


def _preset_quality(preset):
	return '4K' if _preset_key(preset) == '4k' else '1080p'


def _setting_is_protected(setting_id):
	setting_id = str(setting_id or '').strip()
	if not setting_id: return True
	if setting_id in PROTECTED_EXACT: return True
	lower = setting_id.lower()
	if any(lower.startswith(prefix) for prefix in PROTECTED_PREFIXES): return True
	if any(part in lower for part in PROTECTED_SUBSTRINGS): return True
	return False


def _preset_api_key():
	# Les préréglages officiels doivent fonctionner même si l'utilisateur n'a pas
	# connecté son propre compte alkoPastes. On réutilise donc la clé intégrée
	# prévue pour les actions publiques de l'addon, au lieu de la clé utilisateur.
	try:
		return kodi_utils._get_alkopastes_api_key()
	except Exception:
		return '135e78a79a84713d11e4c0fa269097fa99e46b5ffb3eab9a6982f1005e0e972d'


def _request_preset(method, action, payload=None, params=None, timeout=60.0):
	import requests
	params = dict(params or {})
	params['action'] = action
	safe_params = dict(params)
	if 'id' in safe_params: safe_params['id'] = _mask_code(safe_params.get('id'))
	if 'p_code' in safe_params: safe_params['p_code'] = _mask_code(safe_params.get('p_code'))
	if 'slug' in safe_params: safe_params['slug'] = _mask_code(safe_params.get('slug'))
	payload_keys = sorted(list((payload or {}).keys())) if isinstance(payload, dict) else []
	kodi_utils.logger('alkoFlix presets request', 'START | method=%s | action=%s | params=%s | payload_keys=%s' % (method, action, safe_params, payload_keys))
	headers = {
		'X-API-Key': _preset_api_key(),
		'Content-Type': 'application/json',
		'User-Agent': 'alkoFlix/%s' % kodi_utils.get_addoninfo('version')
	}
	if method == 'GET':
		response = requests.get(API_URL, params=params, headers=headers, timeout=timeout)
	elif method == 'POST':
		response = requests.post(API_URL, params=params, data=json.dumps(payload or {}, ensure_ascii=False).encode('utf-8'), headers=headers, timeout=timeout)
	else:
		response = requests.delete(API_URL, params=params, headers=headers, timeout=timeout)
	try:
		data = response.json()
	except Exception:
		data = {'success': False, 'error': response.text[:500] if hasattr(response, 'text') else 'Réponse invalide'}
	if response.status_code not in (200, 201) or not data.get('success'):
		error = data.get('error') or data.get('message') or 'Erreur HTTP %s' % response.status_code
		kodi_utils.logger('alkoFlix presets request', 'FAIL | method=%s | action=%s | status=%s | error=%s' % (method, action, response.status_code, error))
		raise Exception(error)
	kodi_utils.logger('alkoFlix presets request', 'OK | method=%s | action=%s | status=%s | keys=%s' % (method, action, response.status_code, sorted(list(data.keys()))))
	return data


def _get_preset_content(code):
	code = str(code or '').strip()
	kodi_utils.logger('alkoFlix preset restore get', 'START | code=%s' % _mask_code(code))
	result = _request_preset('GET', 'get', params={'id': code}, timeout=60.0)
	paste = result.get('paste') or {}
	content = paste.get('content') or ''
	if isinstance(content, (dict, list)):
		content = json.dumps(content, ensure_ascii=False)
	else:
		content = str(content or '')
	kodi_utils.logger('alkoFlix preset restore get', 'OK | code=%s | content_len=%s | title=%s' % (_mask_code(code), len(content), str(paste.get('title') or '')[:80]))
	return content


def _parse_preset_payload(content):
	data = json.loads(content)
	if not isinstance(data, dict) or data.get('type') != PRESET_BACKUP_TYPE:
		raise Exception('Le code indiqué ne contient pas un préréglage alkoFlix valide.')
	try: version = int(data.get('version') or 0)
	except Exception: version = 0
	if isinstance(data.get('version'), bool) or version != PRESET_BACKUP_VERSION:
		raise Exception('Le format de ce préréglage n’est pas pris en charge par cette version d’alkoFlix.')
	files = data.get('files') or []
	if not isinstance(files, list) or not all(isinstance(item, dict) for item in files):
		raise ValueError('Liste de fichiers de préréglage invalide.')
	items = [item for item in files if str(item.get('name') or '').lower() == 'settings.xml']
	if len(items) != 1: raise ValueError('Le préréglage doit contenir un seul settings.xml.')
	item = items[0]
	if item.get('encoding') not in ('base64', 'base64+gzip'):
		raise ValueError('Encodage de préréglage invalide.')
	encoded = item.get('data')
	if not isinstance(encoded, str) or len(encoded) > PRESET_MAX_SETTINGS_BYTES * 4 // 3 + 4096:
		raise ValueError('Préréglage trop volumineux ou incomplet.')
	raw = base64.b64decode(encoded, validate=True)
	if item.get('encoding') == 'base64+gzip':
		with gzip.GzipFile(fileobj=io.BytesIO(raw), mode='rb') as reader:
			raw = reader.read(PRESET_MAX_SETTINGS_BYTES + 1)
	if len(raw) > PRESET_MAX_SETTINGS_BYTES:
		raise ValueError('Préréglage trop volumineux.')
	if item.get('size') is not None and int(item['size']) != len(raw):
		raise ValueError('Taille du préréglage incorrecte.')
	return raw


def _settings_values_from_xml(raw):
	try:
		text = raw.decode('utf-8-sig') if isinstance(raw, bytes) else str(raw or '')
	except Exception:
		text = raw.decode('utf-8', 'ignore') if isinstance(raw, bytes) else str(raw or '')
	root = ET.fromstring(text)
	if root.tag != 'settings': raise ValueError('Réglages de préréglage invalides.')
	values = {}
	for item in root.iter('setting'):
		setting_id = item.get('id')
		if not setting_id: continue
		value = item.get('value') if item.get('value') is not None else (item.text or '')
		values[setting_id] = value
	return values


def _setting_bool(value):
	return str(value or '').strip().lower() == 'true'


def _certification_display(country_code):
	country_code = str(country_code or 'FR').upper()
	return 'Canada' if country_code == 'CA' else 'France'


def _apply_certification_country(country_code):
	country_code = 'CA' if str(country_code or '').upper() in ('CA', 'CANADA', '1') else 'FR'
	display = _certification_display(country_code)
	kodi_utils.set_setting('preset.certification.country', country_code)
	kodi_utils.set_setting('preset.certification.country_display', display)
	kodi_utils.set_setting('preset.certification.country_choice', '1' if country_code == 'CA' else '0')
	try:
		from modules import dialogs
		dialogs._apply_certification_country(country_code, notify=False)
	except Exception as exc:
		kodi_utils.logger('alkoFlix preset certification apply failed', '%s: %s' % (type(exc).__name__, exc))
		kodi_utils.set_setting('certification.country', country_code)
		kodi_utils.set_setting('certification.country_display', display)
		kodi_utils.set_setting('parental.certification_country_display', display)
	return country_code


def _apply_autoplay(value):
	value = 'true' if _setting_bool(value) else 'false'
	display = 'Activée' if value == 'true' else 'Désactivée'
	kodi_utils.set_setting('preset.autoplay', value)
	kodi_utils.set_setting('preset.autoplay_display', display)
	kodi_utils.set_setting('auto_play_movie', value)
	kodi_utils.set_setting('auto_play_episode', value)
	return value


def preset_autoplay_choice():
	choices = (('Désactivée', 'false'), ('Activée', 'true'))
	current = 'true' if _setting_bool(kodi_utils.get_setting('preset.autoplay', 'false')) else 'false'
	preselect = [1 if current == 'true' else 0]
	list_items = [{'line1': item[0]} for item in choices]
	kwargs = {'items': json.dumps(list_items), 'heading': 'Lecture automatique', 'preselect': preselect}
	choice = kodi_utils.select_dialog(choices, **kwargs)
	if choice is None: return None
	label, value = choice
	_apply_autoplay(value)
	try: kodi_utils.notification('Lecture automatique : %s' % label.lower(), 2000)
	except Exception: pass
	return value


def preset_certification_country_choice():
	choices = (('France', 'FR'), ('Canada', 'CA'))
	current = str(kodi_utils.get_setting('preset.certification.country', '') or kodi_utils.get_setting('certification.country', 'FR') or 'FR').upper()
	preselect = [1 if current == 'CA' else 0]
	list_items = [{'line1': item[0]} for item in choices]
	kwargs = {'items': json.dumps(list_items), 'heading': 'Pays de certification', 'preselect': preselect}
	choice = kodi_utils.select_dialog(choices, **kwargs)
	if choice is None: return None
	label, country_code = choice
	_apply_certification_country(country_code)
	try:
		from modules.cache import clear_cache
		clear_cache('meta', silent=True)
	except Exception: pass
	try: kodi_utils.notification('Pays de certification : %s' % label, 2000)
	except Exception: pass
	return country_code


def _country_from_preset_control():
	choice = str(kodi_utils.get_setting('preset.certification.country_choice', '') or '').strip()
	if choice in ('1', 'CA') or choice.lower() == 'canada': return 'CA'
	if choice in ('0', 'FR') or choice.lower() == 'france': return 'FR'
	country = str(kodi_utils.get_setting('preset.certification.country', '') or kodi_utils.get_setting('certification.country', 'FR') or 'FR').upper()
	return 'CA' if country == 'CA' else 'FR'


def _local_preset_options():
	autoplay = 'true' if _setting_bool(kodi_utils.get_setting('preset.autoplay', 'false')) else 'false'
	country = _country_from_preset_control()
	return autoplay, country


def _set_preset_selection(preset):
	preset = str(preset or '').strip().lower()
	if preset in ('1080p', '1080'):
		active = '1080p'
	elif preset in ('4k', 'uhd'):
		active = '4k'
	else:
		active = 'none'
	try: kodi_utils.set_setting('preset.apply_1080p', 'true' if active == '1080p' else 'false')
	except Exception: pass
	try: kodi_utils.set_setting('preset.apply_4k', 'true' if active == '4k' else 'false')
	except Exception: pass
	try: kodi_utils.set_setting('preset.active_profile', active)
	except Exception: pass
	return active


def _reset_preset_apply_toggles():
	return _set_preset_selection('none')


def sync_preset_controls_from_settings(clear_meta=False):
	# Les contrôles visibles de l’onglet Préréglages pilotent les vrais réglages internes.
	# On marque la synchro pour éviter que le service se relance en boucle pendant les setSetting().
	kodi_utils.set_property('alkoflix_preset_settings_syncing', 'true')
	try:
		autoplay, country = _local_preset_options()
		_apply_autoplay(autoplay)
		_apply_certification_country(country)
		if clear_meta:
			try:
				from modules.cache import clear_cache
				clear_cache('meta', silent=True)
			except Exception: pass
		try: kodi_utils.clear_property('alkoflix_settings')
		except Exception: pass
		return autoplay, country
	finally:
		kodi_utils.clear_property('alkoflix_preset_settings_syncing')


def _apply_values(values):
	from modules import video_filters
	values = dict(values or {})
	if video_filters.PRIORITY_ID not in values or values[video_filters.PRIORITY_ID] == 'legacy':
		_, previous = video_filters.read(kodi_utils.get_setting)
		values.update(video_filters.legacy_updates(values, previous))
	changed = 0
	protected = 0
	known_ids = active_setting_ids()
	for setting_id, value in sorted((values or {}).items()):
		# Une ancienne copie d’un préréglage officiel peut encore contenir YGG ou TORR9.
		# Ces sources retirées ne doivent jamais être recréées dans le profil.
		if setting_id in REMOVED_PRESET_SETTING_IDS or is_retired_setting(setting_id) or setting_id not in known_ids:
			continue
		if _setting_is_protected(setting_id):
			protected += 1
			continue
		try:
			kodi_utils.set_setting(setting_id, str(value if value is not None else ''))
			changed += 1
		except Exception as exc:
			kodi_utils.logger('alkoFlix preset setting skipped', '%s | %s: %s' % (setting_id, type(exc).__name__, exc))
			raise
	return changed, protected


OFFICIAL_PRESET_SOURCE_OVERRIDES = {
	# Métadonnées
	'image_resolutions': '3',

	# Sources alkoFlix intégrées
	'provider.alkopaste': 'true',
	'provider.comet': 'false',
	'provider.nyaa': 'false',

	# Trackers privés : on conserve les clés API, mais le préréglage coupe les sources.
	'provider.c411': 'false',
	'provider.tr4ker': 'false',
	'provider.v3x': 'false',
	'provider.draupnirr': 'false',
	'provider.yggreborn': 'false',

	# Manifests externes : on conserve les URLs/noms, mais le préréglage coupe les sources.
	'provider.aiostreams': 'false',
	'provider.lumio': 'false',
	'provider.custom_1': 'false',
	'provider.custom_2': 'false',

	# Mode et comportement de recherche
	'sources.alkoflix_mode': '0',
	'search.finish.early': 'true',
	'results.private_trackers_first': 'false',
	'results.comet_fallback': 'true',
	'results.alkopaste_fallback': 'false',
	'results.nyaa_fallback': 'false',
	'results.c411_fallback': 'false',
	'results.tr4ker_fallback': 'false',
	'results.v3x_fallback': 'false',
	'results.draupnirr_fallback': 'false',
	'results.yggreborn_fallback': 'false',
	'results.max_per_resolution': '5',
	'results.max_total': '10',
	'results.include.unknown.size': 'true'
}


def _set_preset_setting(setting_id, value):
	# setSetting() peut être appelé pendant que la fenêtre des réglages est ouverte.
	# On garde cette petite fonction dédiée pour centraliser le comportement et
	# faciliter les overrides officiels, sans toucher aux clés/API/URLs protégées.
	kodi_utils.set_setting(setting_id, str(value if value is not None else ''))


def _apply_official_preset_overrides():
	# Les préréglages officiels téléchargés peuvent provenir d'anciens codes paste.
	# Ces overrides locaux gardent le comportement publié à jour sans toucher aux
	# données personnelles : clés API, tokens, noms et URLs de manifests restent en place.
	changed = 0
	for setting_id, value in sorted(OFFICIAL_PRESET_SOURCE_OVERRIDES.items()):
		try:
			_set_preset_setting(setting_id, value)
			changed += 1
		except Exception as exc:
			kodi_utils.logger('alkoFlix preset override skipped', '%s | %s: %s' % (setting_id, type(exc).__name__, exc))
			raise
	return changed


def apply_settings_preset(preset):
	if kodi_utils.get_property('alkoflix_userdata_restoring') == 'true':
		return kodi_utils.notification('Une restauration alkoFlix est en cours.', 3000)
	kodi_utils.set_property('alkoflix_preset_applying', 'true')
	previous_active = str(kodi_utils.get_setting('preset.active_profile', 'none') or 'none').strip().lower()
	preset = _preset_key(preset)
	quality = _preset_quality(preset)
	code = PRESET_CODES.get(preset, '')
	label = PRESET_LABELS.get(preset, 'Préréglage alkoFlix')
	if not code:
		_set_preset_selection(previous_active)
		kodi_utils.clear_property('alkoflix_preset_applying')
		return kodi_utils.ok_dialog(text='Préréglage introuvable.', top_space=True)
	autoplay, country = _local_preset_options()
	text = ('%s[CR][CR]'
		'Ce préréglage va réappliquer les réglages généraux alkoFlix optimisés pour [B]%s[/B].[CR][CR]'
		'Vos comptes, clés API, manifests personnels, sauvegardes, favoris, codes et données personnelles seront conservés.[CR][CR]'
		'Lecture automatique : [B]%s[/B][CR]'
		'Pays de certification : [B]%s[/B][CR][CR]'
		'Continuer ?') % (label, quality, 'activée' if autoplay == 'true' else 'désactivée', _certification_display(country))
	if not kodi_utils.confirm_dialog(text=text, ok_label='Appliquer', cancel_label='Annuler', top_space=True):
		_set_preset_selection(previous_active)
		kodi_utils.clear_property('alkoflix_preset_applying')
		return
	kodi_utils.show_busy_dialog()
	previous_values = None
	try:
		settings_xml = _parse_preset_payload(_get_preset_content(code))
		values = _settings_values_from_xml(settings_xml)
		# A failed preset must not leave half of a new source configuration behind.
		previous_values = {key: kodi_utils.get_setting(key, default) for key, default in active_settings_defaults().items()}
		changed, protected = _apply_values(values)
		overrides_changed = _apply_official_preset_overrides()
		kodi_utils.logger('alkoFlix preset sources', 'profile=%s | primary=alkopaste | fallback=comet | max_total=10 | max_per_resolution=5' % preset)
		# Les deux choix faits dans l’onglet Préréglages gagnent toujours sur le fichier téléchargé.
		_apply_autoplay(autoplay)
		_apply_certification_country(country)
		kodi_utils.set_setting('results.priority_quality', quality)
		kodi_utils.set_setting('results.priority_quality_display', quality)
		kodi_utils.set_setting('results.sort_priority', 'quality')
		kodi_utils.set_setting('results.sort_priority_display', 'Qualité')
		try:
			from modules.cache import clear_cache
			clear_cache('meta', silent=True)
		except Exception: pass
		try: kodi_utils.clear_property('alkoflix_settings')
		except Exception: pass
		_set_preset_selection(preset)
		kodi_utils.clear_property('alkoflix_preset_applying')
		kodi_utils.hide_busy_dialog()
		message = ('Préréglage appliqué avec succès.[CR][CR]'
			'Profil : [B]%s[/B][CR]'
			'Réglages appliqués : [B]%s[/B][CR]'
			'Réglages optimisés actualisés : [B]%s[/B][CR]'
			'Réglages protégés conservés : [B]%s[/B][CR][CR]'
			'Fermez puis rouvrez les paramètres si une ligne affichée ne se rafraîchit pas immédiatement.') % (label, changed, overrides_changed, protected)
		return kodi_utils.ok_dialog(text=message, top_space=True)
	except Exception as exc:
		if previous_values is not None:
			failed = []
			for setting_id, value in previous_values.items():
				try: kodi_utils.set_setting(setting_id, str(value or ''))
				except Exception: failed.append(setting_id)
			kodi_utils.logger('alkoFlix preset rollback', 'complete=%s | failed_settings=%s' % (not failed, ','.join(failed) or 'none'))
		_set_preset_selection(previous_active)
		kodi_utils.clear_property('alkoflix_preset_applying')
		kodi_utils.hide_busy_dialog()
		kodi_utils.logger('alkoFlix preset restore error', '%s: %s' % (type(exc).__name__, exc))
		return kodi_utils.ok_dialog(text='Erreur pendant l’application du préréglage.[CR][CR]%s' % exc, top_space=True)
