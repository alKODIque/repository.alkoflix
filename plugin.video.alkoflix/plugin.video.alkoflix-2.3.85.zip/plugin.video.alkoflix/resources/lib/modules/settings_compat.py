"""Compatibility rules shared by settings readers and imports."""

RETIRED_HOSTER_PROVIDERS = frozenset(('wawacity', 'free_telecharger'))

RETIRED_NATIVE_PROVIDERS = RETIRED_HOSTER_PROVIDERS | frozenset((
    'mediafusion', 'piratebay', 'hydracker', 'ygg', 'torr9', 'movix',
    'zone_telechargement',
))

RETIRED_SETTING_IDS = frozenset((
    'provider.zone_telechargement', 'results.zone_telechargement_fallback',
    'hoster.zone_telechargement.url',
    'provider.wawacity', 'results.wawacity_fallback', 'hoster.wawacity.url',
    'provider.free_telecharger', 'results.free_telecharger_fallback', 'hoster.free_telecharger.url',
    'provider.alkopaste_urls',
    'auto_resume_movie', 'auto_resume_episode',
    'calendar.provider',
))


def is_retired_setting(setting_id):
    value = str(setting_id or '')
    return value in RETIRED_SETTING_IDS or value.startswith((
        'hoster.zone_telechargement.', 'hoster.wawacity.', 'hoster.free_telecharger.',
    ))


def active_setting_ids():
	return frozenset(active_settings_defaults())


def active_settings_defaults():
    """Fail closed when the installed schema is unavailable during an import."""
    import xml.etree.ElementTree as ET
    from modules import kodi_utils
    path = 'special://home/addons/plugin.video.alkoflix/resources/settings.xml'
    reader = kodi_utils.open_file(path, 'r')
    try:
        content = reader.read()
    finally:
        reader.close()
    root = ET.fromstring(content)
    if root.get('version') == '1':
        # Action buttons have no stored value. String-backed selectors do.
        result = {item.get('id'): item.findtext('default', '')
                  for item in root.iter('setting') if item.get('id') and item.get('type') != 'action'}
    else:
        result = {item.get('id'): item.get('default', '')
                  for item in root.iter('setting') if item.get('id')}
    if not result:
        raise ValueError('Le schéma des réglages alkoFlix est vide.')
    return result


def subtitle_language_index(value):
    """Map values from older Wyzie profiles to Kodi's French/English list."""
    value = str(value or '').strip().lower()
    return '1' if value in ('1', '16', 'english', 'anglais', 'en', 'en-us', 'en_us',
                            'en-gb', 'en_gb', 'eng') else '0'
