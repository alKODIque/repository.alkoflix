"""Modes des filtres vidéo et classement indépendant des formats dans Sources."""

LABELS = {
    'remux': 'REMUX', 'bluray': 'Blu-ray', 'hevc': 'HEVC', 'hdr': 'HDR',
    'dv': 'Dolby Vision', 'av1': 'AV1', '3d': '3D', 'imax': 'IMAX',
}
PRIORITY_ID = 'results.video_top_formats'
OLD_ORDER_ID = 'results.video_filter_order'


def mode_id(key):
    return 'results.video_mode.' + key


def old_id(key):
    return 'include_3d_results' if key == '3d' else 'filter_' + key


def default_mode(key):
    return 1 if key == '3d' else 0


def ordered_keys(value):
    parts = (key.strip().lower() for key in str(value or '').split(','))
    return list(dict.fromkeys(key for key in parts if key in LABELS))


def stored_order(order):
    # Une liste explicitement vide doit se distinguer d’une ancienne installation.
    return ','.join(order) or 'none'


def legacy_updates(values, previous=()):
    """Convertit aussi les préréglages partiels, en conservant les formats hors préréglage."""
    if values.get(PRIORITY_ID, 'legacy') != 'legacy':
        return {}
    enabled = set(previous)
    updates = {}
    for key in LABELS:
        setting = old_id(key)
        if setting not in values:
            continue
        value = str(values[setting]).strip().lower()
        if key == '3d':
            value = {'true': '0', 'false': '1', 'prefer': '2', 'top': '3'}.get(value, value)
        if value not in ('0', '1', '2', '3'):
            continue
        if value == '3':
            enabled.add(key)
            value = '0'
        else:
            enabled.discard(key)
        updates[mode_id(key)] = value
    if updates or OLD_ORDER_ID in values:
        order = ordered_keys(values.get(OLD_ORDER_ID)) + list(previous) + list(LABELS)
        updates[PRIORITY_ID] = stored_order(key for key in dict.fromkeys(order) if key in enabled)
    return updates


def read(get):
    priority = get(PRIORITY_ID, 'legacy')
    if priority == 'legacy':
        # Kodi peut lancer un widget avant que le service ait fini la migration.
        values = {old_id(key): get(old_id(key), str(default_mode(key))) for key in LABELS}
        values[OLD_ORDER_ID] = get(OLD_ORDER_ID, '')
        converted = legacy_updates(values)
        return ({key: int(converted.get(mode_id(key), default_mode(key))) for key in LABELS},
                ordered_keys(converted.get(PRIORITY_ID)))
    modes = {}
    for key in LABELS:
        value = get(mode_id(key), str(default_mode(key)))
        modes[key] = int(value) if value in ('0', '1', '2') else default_mode(key)
    return modes, ordered_keys(priority)


def migrate(get, put):
    if get(PRIORITY_ID, 'legacy') != 'legacy':
        return
    modes, selected = read(get)
    # Écrire le classement en dernier permet de reprendre une conversion interrompue.
    for key, mode in modes.items():
        setting = mode_id(key)
        if get(setting, str(default_mode(key))) != str(mode):
            if put(setting, str(mode)) is False:
                raise RuntimeError('Conversion impossible pour ' + setting)
    if get(PRIORITY_ID, 'legacy') == 'legacy':
        if put(PRIORITY_ID, stored_order(selected)) is False:
            raise RuntimeError('Conversion impossible pour ' + PRIORITY_ID)
