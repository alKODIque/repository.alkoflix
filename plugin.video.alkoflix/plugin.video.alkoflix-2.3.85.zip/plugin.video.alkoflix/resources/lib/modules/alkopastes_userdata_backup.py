# -*- coding: utf-8 -*-
# plugin.video.alkoflix
# resources/lib/modules/alkopastes_userdata_backup.py

import base64
import gzip
import hashlib
import io
import os
import re
import shutil
import sqlite3
import tempfile
import sys
import time
import uuid
from contextlib import contextmanager
from datetime import datetime, timezone
from functools import wraps

import xbmcvfs

from modules import kodi_utils, alkopastes_master
from modules.alkopastes_api import has_user_api_key, api_key, _request, _mask_code

PROFILE_DIR = 'special://profile/addon_data/plugin.video.alkoflix/'
BACKUP_SETTING_LOCAL = 'alkopastes.userdata_backup_code'
BACKUP_SETTING_MULTI = 'alkopastes.userdata_multi_backup_code'
BACKUP_MODE_SETTING = 'alkopastes.userdata_backup_mode'
INSTALLATION_ROLE_SETTING = 'alkopastes.userdata_installation_role'
BACKUP_MULTI_DEVICE_SETTING = 'alkopastes.userdata_multi_device'
INSTALLATION_MASTER_SETTING = 'alkopastes.userdata_master_installation'
INSTALLATION_SECONDARY_SETTING = 'alkopastes.userdata_secondary_installation_v2'
USERDATA_AUTO_RESTORE_SETTING = 'alkopastes.userdata_auto_restore'
USERDATA_AUTO_RESTORE_DUE_SETTING = 'alkopastes.userdata_auto_restore_due'
USERDATA_AUTO_RESTORE_LAST_CREATED_SETTING = 'alkopastes.userdata_auto_restore_last_created'
USERDATA_MANUAL_ONLY_DEFAULTS = {
	'alkopastes.userdata_auto_backup': 'false',
	'alkopastes.userdata_auto_backup_interval': '0',
	'alkopastes.userdata_auto_backup_due': '0',
	USERDATA_AUTO_RESTORE_SETTING: 'false',
	USERDATA_AUTO_RESTORE_DUE_SETTING: '0',
	USERDATA_AUTO_RESTORE_LAST_CREATED_SETTING: ''
}
DEVICE_ID_SETTING = 'alkopastes.userdata_device_id'
MASTER_DEVICE_HASH_SETTING = 'alkopastes.userdata_master_device_hash'
BACKUP_NAME_SETTING = 'alkopastes.userdata_backup_name'
BACKUP_MODE_LOCAL = '0'
BACKUP_MODE_MULTI = '1'
INSTALLATION_ROLE_SECONDARY = '0'
INSTALLATION_ROLE_MASTER = '1'
BACKUP_TYPE = 'alkoflix_userdata_backup'
BACKUP_VERSION = 2
RESTORE_IN_PROGRESS_PROPERTY = 'alkoflix_userdata_restoring'
BACKUP_IN_PROGRESS_PROPERTY = 'alkoflix_userdata_backing_up'

# La sauvegarde/restauration alkoFlix est toujours portable.
# On conserve uniquement les données utiles entre appareils et on exclut les caches techniques.
PORTABLE_EXACT = ('settings.xml',)
WATCHED_DATABASE = 'watched.db'
PORTABLE_DATABASES = (
	'navigator.db',       # Menus, dossiers/widgets personnalisés, icônes personnalisées
	WATCHED_DATABASE      # Statuts locaux de visionnement / reprise alkoFlix (mode local seulement)
)
# Les favoris disposent de leur propre mécanisme de sauvegarde/synchronisation alkoPastes.
# Ils ne doivent jamais être inclus ni restaurés via la sauvegarde userdata générale.
LEGACY_SEPARATE_DATABASES = ('favourites.db',)
NON_PORTABLE_DATABASES = (
	'maincache.db',
	'metacache.db',
	'debridcache.db',
	'providerscache.db',
	'traktcache4.db',
	'mdblcache.db',
	'views.db',
	'alkocache.db'
)
EXCLUDED_SUFFIX = ('-journal', '-wal', '-shm')

# Réglages propres à une autorisation de compte/appareil.
# Ils sont retirés de la sauvegarde portable et neutralisés lors d'une restauration
# afin de ne jamais cloner de tokens ou autorisations de compte entre deux profils Kodi.
AUTH_SETTING_DEFAULTS = {
	# Trakt / indicateurs de visionnage
	'trakt_user': '',
	'trakt.token': '',
	'trakt.refresh': '',
	'trakt.expires': '',
	'trakt_indicators_active': 'false',
	'watched_indicators': '0',

	# MDBList
	'mdblist_user': '',
	'mdblist.token': '',
	'mdblist.auth_type': '',
	'mdblist.access_token': '',
	'mdblist.refresh_token': '',
	'mdblist.expires': '',
	'mdblist.client_id': 'EUk8hb6sCGab70Z08k9EKMv1kahOh311Xxk4fDrj',
	'mdbl_indicators_active': 'false',

	# TMDb List / session TMDb utilisateur
	'tmdb.username': '',
	'tmdb.token': '',
	'tmdb.account_id': '',
	'tmdb.session_id': '',
	'tmdb.session_account_id': '',

	# La connexion au compte et le choix de sauvegarde appartiennent à chaque installation.
	'alkopastes_user': '',
	'alkopastes.api_key_user': '',
	'alkopastes.api_mode': '0',
	BACKUP_SETTING_MULTI: '',
	BACKUP_SETTING_LOCAL: '',
	BACKUP_NAME_SETTING: '',
	'alkopastes.userdata_choose_master': '',
	'alkopastes.userdata_choose_secondary': '',
	'alkopastes.userdata_backup_mode': BACKUP_MODE_LOCAL,
	'alkopastes.userdata_installation_role': INSTALLATION_ROLE_SECONDARY,
	'alkopastes.userdata_multi_device': 'false',
	'alkopastes.userdata_master_installation': 'false',
	'alkopastes.userdata_secondary_installation': 'false',
	'alkopastes.userdata_secondary_installation_v2': 'false',
	'alkopastes.userdata_auto_backup': 'false',
	'alkopastes.userdata_auto_backup_interval': '0',
	'alkopastes.userdata_auto_backup_due': '0',
	'alkopastes.userdata_auto_restore': 'false',
	'alkopastes.userdata_auto_restore_due': '0',
	'alkopastes.userdata_auto_restore_last_created': '',
	'alkopastes.favourites_secondary_lock': 'false',
	'alkopastes.favourites_auto_restore_due': '0',
	'alkopastes.favourites_auto_restore_last_hash': '',
	'alkopastes.favourites_auto_restore_backoff_count': '0',
	'alkopastes.favourites_sync_pending': 'false',
	'alkopastes.favourites_sync_pending_at': '0',
	'alkopastes.favourites_sync_last_flush': '0',
	'alkopastes.favourites_cleanup_last': '0',
	'alkopastes.userdata_device_id': '',
	'alkopastes.userdata_master_device_hash': '',
	'alkopastes.favourites_device_hash': '',

	# Contrôle parental : le PIN est portable, mais l'état déverrouillé ne l'est pas.
	'parental.settings_unlocked': 'false',
	'parental.pin_backup_code': '',

	# Débrideurs / services de liens
	'ad.account_id': '',
	'ad.token': '',
	'rd.username': '',
	'rd.client_id': '',
	'rd.secret': '',
	'rd.refresh': '',
	'rd.token': '',
	'tb.account_id': '',
	'tb.token': '',
	'easynews_user': '',
	'easynews_password': '',
	'provider.easynews': 'false',

	# Les clés API personnelles facultatives (Fanart.tv, TMDb, RPDb, Wyzie, etc.)
	# sont volontairement portables : elles font partie de la configuration alkoFlix
	# et peuvent être restaurées d'un appareil à l'autre.
}

# Lors d'une restauration, les réglages neutralisés dans la sauvegarde
# reprennent la valeur locale déjà présente sur l'appareil cible.
# Cela restaure les données portables sans cloner les comptes externes,
# ni l'identité technique ou le rôle maître/secondaire de l'appareil.
LOCAL_SETTINGS_TO_PRESERVE = tuple(AUTH_SETTING_DEFAULTS)

# Compatibilité WIP : ces réglages étaient auparavant stockés comme des sélecteurs 0/1.
# Les settings Kodi booléens doivent recevoir false/true, sinon Kodi refuse de relire
# la valeur restaurée depuis une sauvegarde plus ancienne.
LEGACY_BOOL_SETTING_VALUES = {
	'media.click_action': {'0': 'false', '1': 'true'},
	'info_extra.window': {'0': 'false', '1': 'true'}
}

_ACTIVE_SETTINGS_IDS_CACHE = None


def _active_settings_ids():
	# Sert à nettoyer les anciennes lignes directement dans le settings.xml restauré,
	# sans appeler le nettoyage du service après coup. C'est plus sûr depuis une
	# action lancée dans la fenêtre de réglages Kodi.
	global _ACTIVE_SETTINGS_IDS_CACHE
	if _ACTIVE_SETTINGS_IDS_CACHE is not None: return _ACTIVE_SETTINGS_IDS_CACHE
	try:
		import xml.etree.ElementTree as ET
		settings_path = 'special://home/addons/plugin.video.alkoflix/resources/settings.xml'
		file_obj = kodi_utils.open_file(settings_path, 'r')
		try: text = file_obj.read()
		finally: file_obj.close()
		if isinstance(text, bytes): text = text.decode('utf-8', 'ignore')
		root = ET.fromstring(text)
		_ACTIVE_SETTINGS_IDS_CACHE = set([item.get('id') for item in root.iter('setting') if item.get('id')])
		return _ACTIVE_SETTINGS_IDS_CACHE
	except Exception as exc:
		kodi_utils.logger('alkoPastes userdata restore settings ids cleanup skipped', '%s: %s' % (type(exc).__name__, exc))
		_ACTIVE_SETTINGS_IDS_CACHE = set()
		return _ACTIVE_SETTINGS_IDS_CACHE


def _setting_true(setting_id):
	try: return str(kodi_utils.get_setting(setting_id, 'false')).strip().lower() == 'true'
	except Exception: return False


def _master_selected():
	return _setting_true(INSTALLATION_MASTER_SETTING)


def _secondary_selected():
	return _setting_true(INSTALLATION_SECONDARY_SETTING)


def _role_selected():
	return _master_selected() or _secondary_selected()


def _backup_mode():
	# Réglage 2026 : le choix visible se fait entre installation maître et secondaire.
	# L'ancien interrupteur interne reste lu seulement pour compatibilité.
	if _role_selected() or _setting_true(BACKUP_MULTI_DEVICE_SETTING): return BACKUP_MODE_MULTI
	return BACKUP_MODE_LOCAL


def _installation_role():
	# Sécurité : si les deux rôles sont cochés par un ancien réglage cassé, on traite
	# l'installation comme secondaire tant que le choix n'est pas réinitialisé.
	if _master_selected() and not _secondary_selected(): return INSTALLATION_ROLE_MASTER
	return INSTALLATION_ROLE_SECONDARY


def _is_multi_device_mode():
	return _backup_mode() == BACKUP_MODE_MULTI


def _is_master_installation():
	return _installation_role() == INSTALLATION_ROLE_MASTER

def _active_backup_label():
	if _is_multi_device_mode():
		return 'maître' if _is_master_installation() else 'secondaire'
	return 'locale'


def _installation_device_id():
	# Identifiant local aléatoire, propre à ce profil Kodi.
	# Il n'est jamais copié dans une sauvegarde restaurée.
	try:
		device_id = str(kodi_utils.get_setting(DEVICE_ID_SETTING, '') or '').strip()
	except Exception:
		device_id = ''
	if len(device_id) >= 24:
		return device_id
	device_id = uuid.uuid4().hex
	kodi_utils.set_setting(DEVICE_ID_SETTING, device_id)
	if kodi_utils.get_setting(DEVICE_ID_SETTING, '') != device_id:
		raise IOError('Impossible d’enregistrer l’identité de cet appareil. Réessayez.')
	return device_id


def _current_master_device_hash():
	# Le hash public sert uniquement à reconnaître l'installation maître.
	# Le vrai identifiant local n'est pas envoyé à alkoPastes.
	device_id = _installation_device_id()
	digest = hashlib.sha256(('alkoFlix userdata master:%s' % device_id).encode('utf-8')).hexdigest()
	try:
		if str(kodi_utils.get_setting(MASTER_DEVICE_HASH_SETTING, '') or '') != digest:
			kodi_utils.set_setting(MASTER_DEVICE_HASH_SETTING, digest)
	except Exception:
		pass
	return digest



@contextmanager
def _backup_operation():
	# Un verrou SQLite est partagé par les interpréteurs Kodi et libéré même après un arrêt brutal.
	directory = kodi_utils.translate_path(PROFILE_DIR)
	os.makedirs(directory, exist_ok=True)
	lock = sqlite3.connect(os.path.join(directory, 'userdata_backup_lock.db'), timeout=0)
	try:
		try: lock.execute('BEGIN IMMEDIATE')
		except sqlite3.OperationalError as exc:
			raise RuntimeError('Une opération de sauvegarde est déjà en cours ou le profil est inaccessible.') from exc
		yield
	finally:
		lock.close()


def _manual_action(func):
	@wraps(func)
	def run(*args, **kwargs):
		try:
			with _backup_operation():
				return func(*args, **kwargs)
		except Exception as exc:
			kodi_utils.logger('alkoFlix sauvegarde maître', str(exc))
			return kodi_utils.ok_dialog(text=str(exc), top_space=True)
	return run


def _account_request():
	# Une opération garde la même clé pour toutes les pages, le GET et une éventuelle écriture.
	key = api_key()
	if not key:
		raise ValueError(kodi_utils.local_string(30906))
	def request(method, action, **kwargs):
		if api_key() != key:
			raise ValueError('Le compte alkoPaste a changé. Relancez l’opération.')
		return _request(method, action, timeout=60.0, log_name='alkoPastes userdata', account_key=key, **kwargs)
	return request


def _bound_code():
	return str(kodi_utils.get_setting(BACKUP_SETTING_MULTI, '') or '').strip()


def _choices(request):
	code = _bound_code() or kodi_utils.get_setting(BACKUP_SETTING_LOCAL, '')
	return alkopastes_master.choices(request, _validate_master, code)


def _validate_master(data):
	try: _validate_master_files(data)
	except (ValueError, TypeError) as exc:
		raise alkopastes_master.InvalidBackup(str(exc)) from exc


def _selected_snapshot(request):
	code = _bound_code()
	if not code:
		raise ValueError('Choisissez une sauvegarde dans Préréglages en sélectionnant le rôle de cet appareil.')
	snapshot = alkopastes_master.read(request, code, _validate_master)
	if not snapshot:
		raise ValueError('Ce code ne désigne plus une sauvegarde maître alkoFlix.')
	return snapshot


def _choose_saved(entries, create=False):
	# Sur une nouvelle installation, le premier choix est la sauvegarde la plus récente.
	if not create and len(entries) == 1: return entries[0].code
	labels = ['%s  ·  %s  ·  %s' % (e.name, e.date, e.code) for e in entries]
	if create: labels.append('Créer une nouvelle sauvegarde pour cet appareil…')
	bound = _bound_code()
	index = next((i for i, item in enumerate(entries) if item.code == bound), 0)
	choice = kodi_utils.dialog.select('Choisir une sauvegarde maître', labels, preselect=index)
	if choice < 0: return None
	return entries[choice].code if choice < len(entries) else ''


def _enter_name(entries, current=None):
	default = current.name if current else (kodi_utils.get_infolabel('System.FriendlyName') or '')
	while True:
		value = kodi_utils.dialog.input('Nom de la sauvegarde maître', defaultt=default)
		if not value: return None
		try:
			name = alkopastes_master.clean_name(value)
			if any(e.name.casefold() == name.casefold() and (not current or e.code != current.code) for e in entries):
				raise ValueError('Ce nom est déjà utilisé sur votre compte. Choisissez un nom distinct.')
			return name
		except ValueError as exc:
			kodi_utils.ok_dialog(text=str(exc), top_space=True)
			default = value


def _validate_master_files(data):
	import xml.etree.ElementTree as ET
	_validate_backup_header(data)
	names = set()
	budget = RESTORE_MAX_TOTAL_BYTES
	for item in data['files']:
		if not isinstance(item, dict):
			raise ValueError('Entrée de sauvegarde invalide.')
		name = str(item.get('name') or '').lower()
		if name not in ('settings.xml', 'navigator.db'):
			continue
		if name in names:
			raise ValueError('Fichier répété dans la sauvegarde.')
		names.add(name)
		raw = _decode_restore_item(item, budget)
		budget -= len(raw)
		if name == 'settings.xml':
			try: root = ET.fromstring(raw)
			except ET.ParseError as exc: raise ValueError('Réglages de sauvegarde illisibles.') from exc
			if root.tag != 'settings' or not root.findall('setting'):
				raise ValueError('Réglages de sauvegarde vides ou invalides.')
		else:
			temp_root = kodi_utils.translate_path('special://temp/')
			with tempfile.TemporaryDirectory(prefix='alkoflix_backup_check_', dir=temp_root) as directory:
				try: _validate_sqlite_bytes(raw, name, directory)
				except sqlite3.DatabaseError as exc:
					raise ValueError('Base de menus illisible.') from exc
	if not names:
		raise ValueError('La sauvegarde ne contient aucun fichier portable reconnu.')


def _persist_role(role, code, name=''):
	# En cas d’interruption, retirer les droits d’écriture avant de changer le rattachement.
	master = role == 'master'
	kodi_utils.set_setting(INSTALLATION_MASTER_SETTING, 'false')
	kodi_utils.set_setting(INSTALLATION_SECONDARY_SETTING, 'true' if role == 'secondary' else 'false')
	kodi_utils.set_setting(BACKUP_SETTING_LOCAL, '')
	kodi_utils.set_setting(BACKUP_SETTING_MULTI, code)
	kodi_utils.set_setting(BACKUP_NAME_SETTING, name)
	if master:
		kodi_utils.set_setting(INSTALLATION_MASTER_SETTING, 'true')
	normalize_alkoflix_userdata_role(refresh=True)
	kodi_utils.refresh_addon_settings_window()


def _migrate_legacy_backup_code_to_role():
	# Compatibilité avec l’ancien modèle : le code unique était stocké dans
	# alkopastes.userdata_backup_code. Dès qu’un rôle maître/secondaire est choisi,
	# on reprend ce code comme code de sauvegarde visible afin d’éviter de créer
	# ou de demander un nouveau code inutilement.
	try:
		legacy_code = str(kodi_utils.get_setting(BACKUP_SETTING_LOCAL, '') or '').strip()
		active_code = str(kodi_utils.get_setting(BACKUP_SETTING_MULTI, '') or '').strip()
	except Exception: return False
	if not legacy_code or active_code: return False
	if not _is_multi_device_mode() or not _role_selected(): return False
	try:
		kodi_utils.set_setting(BACKUP_SETTING_MULTI, legacy_code)
		kodi_utils.clear_property('alkoflix_settings')
		kodi_utils.logger('alkoPastes userdata legacy backup code migrated', '%s | role=%s' % (_mask_code(legacy_code), _active_backup_label()))
		try: kodi_utils.refresh_addon_settings_window()
		except Exception: pass
		return True
	except Exception as exc:
		kodi_utils.logger('alkoPastes userdata legacy backup code migration failed', '%s: %s' % (type(exc).__name__, exc))
		return False





def _ensure_alkopastes_connected():
	if has_user_api_key(): return True
	if kodi_utils.confirm_dialog(text=30906, ok_label=32455, cancel_label='Annuler', top_space=True):
		kodi_utils.execute_builtin('RunPlugin(plugin://plugin.video.alkoflix/?mode=myservices)')
	return False


def normalize_alkoflix_userdata_role(refresh=False):
	"""Synchronise les anciens réglages cachés avec le choix visible maître/secondaire."""
	master = _master_selected()
	secondary = _secondary_selected()
	changed = False
	values = {}
	# Un profil ambigu reste en lecture seule jusqu’à un choix explicite.
	if master and secondary:
		master = False
		values[INSTALLATION_MASTER_SETTING] = 'false'
	values['alkopastes.userdata_secondary_installation'] = 'true' if secondary else 'false'
	values['alkopastes.userdata_choose_master'] = '✓' if master else ''
	values['alkopastes.userdata_choose_secondary'] = '✓' if secondary else ''
	if master:
		values['alkopastes.favourites_secondary_lock'] = 'false'
		values.update({
			BACKUP_MULTI_DEVICE_SETTING: 'true',
			BACKUP_MODE_SETTING: BACKUP_MODE_MULTI,
			INSTALLATION_ROLE_SETTING: INSTALLATION_ROLE_MASTER,
			USERDATA_AUTO_RESTORE_SETTING: 'false',
			USERDATA_AUTO_RESTORE_DUE_SETTING: '0'
		})
	elif secondary:
		values['alkopastes.favourites_secondary_lock'] = 'true'
		values.update({
			BACKUP_MULTI_DEVICE_SETTING: 'true',
			BACKUP_MODE_SETTING: BACKUP_MODE_MULTI,
			INSTALLATION_ROLE_SETTING: INSTALLATION_ROLE_SECONDARY,
			'alkopastes.userdata_auto_backup': 'false',
			'alkopastes.userdata_auto_backup_due': '0',
			'alkopastes.userdata_auto_backup_interval': '0'
		})
	else:
		values['alkopastes.favourites_secondary_lock'] = 'false'
		values.update({
			BACKUP_MULTI_DEVICE_SETTING: 'false',
			BACKUP_MODE_SETTING: BACKUP_MODE_LOCAL,
			INSTALLATION_ROLE_SETTING: INSTALLATION_ROLE_SECONDARY,
			'alkopastes.userdata_auto_backup': 'false',
			'alkopastes.userdata_auto_backup_due': '0',
			USERDATA_AUTO_RESTORE_SETTING: 'false',
			USERDATA_AUTO_RESTORE_DUE_SETTING: '0'
		})
	values.update(USERDATA_MANUAL_ONLY_DEFAULTS)
	for setting_id, value in values.items():
		try:
			if str(kodi_utils.get_setting(setting_id, '')) != str(value):
				kodi_utils.set_setting(setting_id, value)
				changed = True
		except Exception as exc:
			kodi_utils.logger('alkoPastes userdata normalize setting failed', '%s | %s' % (setting_id, exc))
	if _migrate_legacy_backup_code_to_role(): changed = True
	if changed:
		try: kodi_utils.clear_property('alkoflix_settings')
		except Exception: pass
		if refresh:
			try: kodi_utils.refresh_addon_settings_window()
			except Exception: pass
	return changed



@_manual_action
def set_alkoflix_userdata_role(role):
	if role not in ('master', 'secondary'):
		raise ValueError('Choix d’appareil invalide.')
	if not _ensure_alkopastes_connected(): return
	request = _account_request()
	kodi_utils.show_busy_dialog()
	try: entries = _choices(request)
	finally: kodi_utils.hide_busy_dialog()
	if not entries and role == 'secondary':
		_persist_role(role, '')
		return kodi_utils.ok_dialog(text='Appareil secondaire. Aucune sauvegarde maître sur ce compte. Après sa création sur le maître, choisissez « Restaurer maintenant ».', top_space=True)
	code = _choose_saved(entries, create=role == 'master') if entries else ''
	if code is None: return
	name = None
	if not code:
		name = _enter_name(entries)
		if not name: return
	kodi_utils.show_busy_dialog()
	try:
		if not code:
			data = _build_backup_payload(initial=True)
			data['backup_name'] = name
			_validate_master(data)
			# Refaire la recherche après le clavier pour couvrir une création concurrente ou un envoi ambigu.
			if any(e.name.casefold() == name.casefold() for e in _choices(request)):
				raise ValueError('Une sauvegarde portant ce nom vient d’apparaître. Sélectionnez-la dans la liste.')
			code = alkopastes_master.write(request, data)
		else:
			snapshot = alkopastes_master.read(request, code, _validate_master)
			if not snapshot: raise ValueError('Le paste sélectionné a changé. Relancez la recherche.')
			name = snapshot.name
			if role == 'master':
				device = _current_master_device_hash()
				if snapshot.data.get('master_device_hash') != device:
					kodi_utils.hide_busy_dialog()
					text = ('Faire de cet appareil le maître de « %s » (code %s) ?[CR][CR]'
						'Il prend le relais du maître précédent. Les réglages et les menus déjà sauvegardés seront conservés.') % (name, code)
					if not kodi_utils.confirm_dialog(text=text, ok_label='Reprendre', cancel_label='Annuler', top_space=True): return
					kodi_utils.show_busy_dialog()
					data = dict(snapshot.data, master_device_hash=device, master_device_hash_version=1)
					alkopastes_master.write(request, data, snapshot, keep_title=True)
		_persist_role(role, code, name)
	finally:
		kodi_utils.hide_busy_dialog()
	label = 'Appareil maître' if role == 'master' else 'Appareil secondaire'
	return kodi_utils.ok_dialog(text='%s · %s[CR][CR]Code de sauvegarde : [B]%s[/B]' % (label, name, code), top_space=True)


@_manual_action
def rename_alkoflix_userdata_backup():
	if not _is_master_installation(): raise ValueError('Seul le maître peut renommer cette sauvegarde.')
	if not _ensure_alkopastes_connected(): return
	request = _account_request()
	remote = _selected_snapshot(request)
	_require_owner(remote)
	name = _enter_name(_choices(request), current=remote)
	if not name or name == remote.name: return
	alkopastes_master.write(request, dict(remote.data, backup_name=name), remote)
	kodi_utils.set_setting(BACKUP_NAME_SETTING, name)
	return kodi_utils.ok_dialog(text='Sauvegarde renommée « %s ». Son code est %s.' % (name, remote.code), top_space=True)


def forget_backup_binding():
	with _backup_operation():
		_persist_role('', '')


@_manual_action
def reset_alkoflix_userdata_settings():
	_persist_role('', '')
	return kodi_utils.ok_dialog(text='Le choix de l’appareil a été réinitialisé.', top_space=True)


def _is_backup_file(filename):
	name = str(filename or '')
	lower = name.lower()
	if not name or '/' in name or '\\' in name: return False
	if any(lower.endswith(suffix) for suffix in EXCLUDED_SUFFIX): return False
	return lower in PORTABLE_EXACT or lower in PORTABLE_DATABASES


def _is_watched_database(filename):
	return str(filename or '').lower() == WATCHED_DATABASE


def _current_watched_provider():
	try: return int(str(kodi_utils.get_setting('watched_indicators', '0') or '0').strip())
	except Exception: return 0


def _watched_database_portable_for_current_context():
	# watched.db reste une base locale de secours. Elle n'est portable que lorsque
	# le fournisseur Local est utilisé ET que la synchro dédiée des suivis via
	# alkoPastes n'est pas activée. Cela évite deux mécanismes concurrents capables
	# de restaurer les mêmes états de visionnage.
	if _is_multi_device_mode(): return False
	try:
		if str(kodi_utils.get_setting('alkopastes.watched_multi_device', 'false')).strip().lower() == 'true': return False
	except Exception: pass
	return _current_watched_provider() == 0


def _should_collect_backup_file(filename):
	return _is_backup_file(filename) and not _is_watched_database(filename)


def _should_restore_backup_file(filename, data=None):
	lower = str(filename or '').lower()
	if lower in LEGACY_SEPARATE_DATABASES:
		kodi_utils.logger('alkoPastes userdata restore write', 'SKIP | %s gérée séparément' % lower)
		return False
	if not _is_backup_file(filename): return False
	if not _is_watched_database(filename): return True
	backup_scope = str((data or {}).get('backup_scope') or '').strip().lower()
	if backup_scope == 'master' or not _watched_database_portable_for_current_context():
		kodi_utils.logger('alkoPastes userdata restore write', 'SKIP | watched.db non importée | provider=%s | local_scope=%s | backup_scope=%s' % (_current_watched_provider(), _active_backup_label(), backup_scope or 'unknown'))
		return False
	return True


def _read_binary(path):
	reader = xbmcvfs.File(path, 'rb')
	try:
		data = reader.readBytes()
	finally:
		reader.close()
	if isinstance(data, bytes): return data
	try: return bytes(data)
	except Exception: return str(data).encode('utf-8')


def _settings_line_id(line):
	match = re.search(r'id=[\"\']([^\"\']+)[\"\']', line)
	return match.group(1) if match else ''


def _settings_line_value(line):
	match = re.search(r'value=([\"\'])(.*?)\1', line)
	if match: return match.group(2)
	match = re.search(r'>(.*?)</setting>', line)
	return match.group(1) if match else None


def _escape_xml_value(value):
	value = str(value or '')
	return value.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;').replace('\"', '&quot;').replace("'", '&apos;')


def _replace_settings_value(line, value):
	value = _escape_xml_value(value)
	if ' value=' in line:
		return re.sub(r'value=([\"\'])(.*?)\1', lambda match: 'value=%s%s%s' % (match.group(1), value, match.group(1)), line, count=1)
	if '</setting>' in line:
		return re.sub(r'>(.*?)</setting>', '>%s</setting>' % value, line, count=1)
	return line




def _settings_entry_line(setting_id, value):
	# Kodi accepte les réglages utilisateur au format value= dans settings.xml.
	# Sert uniquement à réinjecter une valeur locale sensible absente de la sauvegarde restaurée.
	return '\t<setting id="%s" value="%s" />\n' % (_escape_xml_value(setting_id), _escape_xml_value(value))


def _should_append_preserved_setting(setting_id, value):
	# Si la sauvegarde source ne contient pas une ligne sensible, on réinjecte la valeur locale
	# seulement lorsqu'elle a réellement une valeur utile à préserver.
	default_value = AUTH_SETTING_DEFAULTS.get(setting_id, '')
	value = str(value or '')
	return value != '' and value != str(default_value or '')

def _local_settings_values(setting_ids):
	values = {}
	for setting_id in setting_ids:
		try:
			values[setting_id] = kodi_utils.get_setting(setting_id, '')
		except Exception:
			values[setting_id] = ''
	return values


def _sanitize_settings_xml(data, preserve_values=None):
	import xml.etree.ElementTree as ET
	from modules.settings_compat import active_setting_ids, is_retired_setting
	preserve_values = preserve_values or {}
	# Parse before restoring anything: line-based filtering could delete valid
	# settings alongside an obsolete key in a compact, single-line backup.
	root = ET.fromstring(data)
	if root.tag != 'settings': raise ValueError('Réglages de sauvegarde invalides')
	active_settings = active_setting_ids()
	changed = 0
	seen_settings = set()
	for item in list(root):
		setting_id = item.get('id')
		if (item.tag != 'setting' or setting_id not in active_settings
			or is_retired_setting(setting_id) or setting_id in seen_settings):
			root.remove(item)
			changed += 1
			continue
		seen_settings.add(setting_id)
		current = item.get('value') if item.get('value') is not None else (item.text or '')
		value = current
		if setting_id in AUTH_SETTING_DEFAULTS:
			value = preserve_values.get(setting_id, AUTH_SETTING_DEFAULTS[setting_id])
		else:
			mapping = LEGACY_BOOL_SETTING_VALUES.get(setting_id)
			if mapping:
				value = mapping.get(str(current or '').strip(), current)
		value = str(value or '')
		if value != current: changed += 1
		item.attrib.pop('default', None)
		item.set('value', value)
		item.text = None

	for setting_id, value in preserve_values.items():
		if setting_id in seen_settings: continue
		if setting_id not in AUTH_SETTING_DEFAULTS: continue
		if setting_id not in active_settings or is_retired_setting(setting_id): continue
		if not _should_append_preserved_setting(setting_id, value): continue
		ET.SubElement(root, 'setting', {'id': setting_id, 'value': str(value or '')})
		changed += 1
	return ET.tostring(root, encoding='utf-8', xml_declaration=True), changed


def _active_settings_defaults():
	# Retourne tous les réglages définis par la version installée ainsi que leur valeur par défaut.
	# Cela permet de restaurer via l'API Kodi sans remplacer settings.xml pendant que Kodi l'utilise.
	try:
		from modules.settings_compat import active_settings_defaults
		return active_settings_defaults()
	except Exception as exc:
		kodi_utils.logger('alkoPastes userdata restore settings defaults failed', '%s: %s' % (type(exc).__name__, exc))
		return {}


def _settings_values_from_xml(data):
	try:
		import xml.etree.ElementTree as ET
		if isinstance(data, bytes): content = data.decode('utf-8-sig', 'ignore')
		else: content = str(data or '')
		root = ET.fromstring(content)
		values = {}
		for item in root.iter('setting'):
			setting_id = item.get('id')
			if not setting_id: continue
			value = item.get('value')
			if value is None: value = item.text or ''
			values[setting_id] = str(value)
		return values
	except Exception as exc:
		kodi_utils.logger('alkoPastes userdata restore settings parse failed', '%s: %s' % (type(exc).__name__, exc))
		return None


def _restore_settings_via_kodi(data, preserve_values=None):
	# Sous Windows, remplacer physiquement settings.xml pendant que Kodi est actif est fragile :
	# le fichier peut être ouvert/caché par Kodi et les attributs du fichier temporaire peuvent suivre
	# le renommage. On applique donc les valeurs avec l'API officielle de réglages.
	preserve_values = preserve_values or {}
	values = _settings_values_from_xml(data)
	defaults = _active_settings_defaults()
	if values is None or not defaults: return False
	from modules.video_filters import legacy_updates, PRIORITY_ID
	values.update(legacy_updates(values))
	if values.get(PRIORITY_ID, 'legacy') == 'legacy': values[PRIORITY_ID] = 'none'
	try:
		for setting_id, default_value in defaults.items():
			if setting_id in preserve_values:
				desired = preserve_values.get(setting_id, '')
			else:
				desired = values.get(setting_id, default_value)
			kodi_utils.set_setting(setting_id, str(desired or ''))
		kodi_utils.clear_property('alkoflix_settings')
		kodi_utils.refresh_addon_settings_window()
		return True
	except Exception as exc:
		kodi_utils.logger('alkoPastes userdata restore settings apply failed', '%s: %s' % (type(exc).__name__, exc))
		return False


def _clear_windows_hidden_attribute(path):
	# Kodi/XBMC VFS peut conserver l'attribut Hidden d'un fichier temporaire au renommage sous Windows.
	# On retire uniquement Hidden/System des fichiers userdata alkoFlix; aucun effet sur Android/Linux.
	if not sys.platform.startswith('win'): return
	try:
		import ctypes
		translated = kodi_utils.translate_path(path)
		get_attrs = ctypes.windll.kernel32.GetFileAttributesW
		set_attrs = ctypes.windll.kernel32.SetFileAttributesW
		attrs = int(get_attrs(str(translated)))
		if attrs == -1 or attrs == 0xFFFFFFFF: return
		new_attrs = attrs & ~0x2 & ~0x4
		if new_attrs != attrs: set_attrs(str(translated), new_attrs)
	except Exception:
		pass


def _cleanup_restore_artifacts():
	# A13 : ne jamais effacer aveuglément les fichiers de récupération d'une
	# restauration interrompue. Ils peuvent être la seule copie de secours.
	for filename in ('settings.xml', 'navigator.db', 'favourites.db'):
		try:
			if kodi_utils.path_exists(PROFILE_DIR + filename):
				_clear_windows_hidden_attribute(PROFILE_DIR + filename)
		except Exception:
			pass
	return 0


def _write_binary(path, data):
	writer = xbmcvfs.File(path, 'wb')
	try:
		writer.write(data)
	finally:
		writer.close()
	return kodi_utils.path_exists(path)


def _file_size(path):
	try:
		stat = xbmcvfs.Stat(path)
		return int(stat.st_size())
	except Exception:
		try:
			translated = kodi_utils.translate_path(path)
			import os
			return os.path.getsize(translated)
		except Exception:
			return -1


def _validate_sqlite_file(path):
	# Validation légère mais très utile avant de remplacer une base existante.
	# Si la sauvegarde contient une base corrompue, on garde l'ancienne base locale.
	translated = kodi_utils.translate_path(path)
	con = None
	try:
		con = sqlite3.connect(translated, timeout=30)
		result = con.execute('PRAGMA integrity_check').fetchone()
		return bool(result and str(result[0]).lower() == 'ok')
	finally:
		try:
			if con: con.close()
		except Exception:
			pass


def _replace_file_atomically(filename, data):
	filename = str(filename or '')
	target = PROFILE_DIR + filename
	timestamp = str(int(time.time() * 1000))
	# Important sous Windows : ne pas préfixer les temporaires par un point.
	tmp = PROFILE_DIR + '__restore_tmp_%s_%s' % (timestamp, filename)
	is_database = filename.lower().endswith('.db')

	if not _write_binary(tmp, data):
		kodi_utils.logger('alkoPastes userdata restore temp write failed', filename)
		return False
	if _file_size(tmp) != len(data):
		kodi_utils.logger('alkoPastes userdata restore temp size mismatch', '%s | expected=%s | actual=%s' % (filename, len(data), _file_size(tmp)))
		try: kodi_utils.delete_file(tmp)
		except Exception: pass
		return False
	if is_database and not _validate_sqlite_file(tmp):
		kodi_utils.logger('alkoPastes userdata restore sqlite validation failed', filename)
		try: kodi_utils.delete_file(tmp)
		except Exception: pass
		return False

	# Ne jamais effacer le WAL ni le journal d'une base potentiellement ouverte.
	# Ancien helper conservé uniquement pour compatibilité ; A13 passe désormais
	# par l'API SQLite (_restore_database_from_file).
	if is_database and any(kodi_utils.path_exists(target + suffix) for suffix in EXCLUDED_SUFFIX):
		kodi_utils.logger('alkoPastes userdata restore blocked', '%s | journal SQLite présent' % filename)
		try: kodi_utils.delete_file(tmp)
		except Exception: pass
		return False

	# Remplacement atomique direct : aucune copie "old" n'est nécessaire.
	try:
		tmp_native = kodi_utils.translate_path(tmp)
		target_native = kodi_utils.translate_path(target)
		last_exc = None
		for _ in range(4):
			try:
				os.replace(tmp_native, target_native)
				last_exc = None
				break
			except OSError as exc:
				last_exc = exc
				time.sleep(0.12)
		if last_exc is not None: raise last_exc
		if kodi_utils.path_exists(target):
			_clear_windows_hidden_attribute(target)
			return True
	except Exception as exc:
		kodi_utils.logger('alkoPastes userdata restore target locked', '%s | %s: %s' % (filename, type(exc).__name__, exc))
	try:
		if kodi_utils.path_exists(tmp): kodi_utils.delete_file(tmp)
	except Exception:
		pass
	return False


def _database_basename(path):
	value = str(path or '')
	value = value.replace('\\', '/')
	return value.rsplit('/', 1)[-1].lower()


def _close_open_database_handles(database_names=None):
	# IMPORTANT : ne jamais faire getattr(obj, 'db_file') sur tous les objets de sys.modules.
	# Certains objets Python (notamment les chargeurs ctypes sous Windows) interprètent un attribut
	# inconnu comme le nom d'une DLL à charger. Demander « db_file » peut donc provoquer :
	# « Could not find module 'db_file' ». On limite volontairement la recherche aux modules cache
	# alkoFlix déjà chargés et on lit leur __dict__ sans déclencher de __getattr__ dynamique.
	target_names = set([i.lower() for i in (database_names if database_names is not None else PORTABLE_DATABASES)])
	closed = []
	seen = set()
	for module_name, module in list(sys.modules.items()):
		if module_name != 'caches' and not str(module_name).startswith('caches.'):
			continue
		try:
			values = list(vars(module).values())
		except Exception:
			continue
		for obj in values:
			marker = id(obj)
			if marker in seen:
				continue
			seen.add(marker)
			try:
				obj_dict = object.__getattribute__(obj, '__dict__')
			except Exception:
				continue
			# Une instance BaseCache possède dbcon/dbcur dans son __dict__. Les classes, fonctions,
			# modules et chargeurs divers sont donc ignorés sans interrogation dynamique.
			if not isinstance(obj_dict, dict) or 'dbcon' not in obj_dict:
				continue
			try:
				cls = object.__getattribute__(obj, '__class__')
				class_dict = vars(cls)
				db_file = obj_dict.get('db_file', class_dict.get('db_file', ''))
			except Exception:
				continue
			if not db_file or _database_basename(db_file) not in target_names:
				continue
			dbcur = obj_dict.get('dbcur')
			dbcon = obj_dict.get('dbcon')
			try:
				if dbcur: dbcur.close()
			except Exception:
				pass
			try:
				if dbcon: dbcon.close()
			except Exception:
				pass
			closed.append(obj)
	kodi_utils.logger('alkoPastes userdata restore db handles', 'closed=%s' % len(closed))
	return closed


def _reopen_database_handles(objects):
	reopened = 0
	for obj in objects or []:
		try:
			db_file = getattr(obj, 'db_file', '')
			if not db_file or db_file == ':memory:': continue
			obj.dbcon = kodi_utils.database_connect(db_file, isolation_level=None)
			obj.dbcur = obj.dbcon.cursor()
			if hasattr(obj, '_set_PRAGMAS'): obj._set_PRAGMAS()
			reopened += 1
		except Exception as exc:
			kodi_utils.logger('alkoPastes userdata restore db handle reopen failed', '%s: %s' % (type(exc).__name__, exc))
	kodi_utils.logger('alkoPastes userdata restore db handles', 'reopened=%s' % reopened)
	return reopened


def _sqlite_snapshot_bytes(path):
	"""Copie cohérente d'une base ouverte, WAL inclus, sans toucher à l'original.

	La sauvegarde SQLite traite les pages validées qui peuvent encore se trouver
	dans le WAL; lire le seul fichier .db avec xbmcvfs n'offre pas cette garantie.
	Un dossier temporaire privé est créé hors du profil Kodi, puis supprimé.
	"""
	source_path = kodi_utils.translate_path(path)
	if not os.path.isfile(source_path):
		raise IOError('Base locale absente ou inaccessible')
	# Le répertoire temporaire Kodi est accessible sur Windows et Android.
	try: temp_root = kodi_utils.translate_path('special://temp/')
	except Exception: temp_root = None
	if not temp_root or not os.path.isdir(temp_root): temp_root = None
	with tempfile.TemporaryDirectory(prefix='alkoflix_userdata_snapshot_', dir=temp_root) as temp_dir:
		snapshot_path = os.path.join(temp_dir, 'snapshot.db')
		source = destination = None
		try:
			source = sqlite3.connect(source_path, timeout=15)
			destination = sqlite3.connect(snapshot_path, timeout=15)
			# L'API SQLite Online Backup prend un snapshot transactionnel, y compris
			# lorsque les dernières transactions validées sont encore dans le WAL.
			deadline = time.monotonic() + 40.0
			def _check_snapshot_progress(status, remaining, total):
				if time.monotonic() > deadline:
					raise TimeoutError('La base reste occupée pendant la sauvegarde SQLite')
			source.backup(destination, pages=128, progress=_check_snapshot_progress, sleep=0.05)
			result = destination.execute('PRAGMA integrity_check').fetchone()
			if not result or str(result[0]).lower() != 'ok':
				raise IOError('La copie SQLite n’a pas passé la vérification d’intégrité')
		finally:
			if destination is not None: destination.close()
			if source is not None: source.close()
		with open(snapshot_path, 'rb') as reader:
			return reader.read()


def _collect_files(initial=False):
	if kodi_utils.get_property(RESTORE_IN_PROGRESS_PROPERTY) == 'true':
		raise IOError('Une restauration alkoFlix est en cours. Réessayez après sa fin.')
	_, files = kodi_utils.list_dirs(PROFILE_DIR)
	items, sanitized_settings = [], 0
	if 'settings.xml' not in files:
		if not initial or kodi_utils.path_exists(PROFILE_DIR + 'settings.xml'):
			raise IOError('Les réglages de cet appareil sont momentanément indisponibles.')
		# Une première installation peut ne pas avoir encore de fichier userdata.
		import xml.etree.ElementTree as ET
		from xbmcaddon import Addon
		get_value = Addon(id='plugin.video.alkoflix').getSetting
		root = ET.Element('settings', version='2')
		for key in _active_settings_defaults():
			ET.SubElement(root, 'setting', id=key).text = get_value(key)
		raw, sanitized_settings = _settings_snapshot_for_backup(ET.tostring(root, encoding='utf-8'))
		items.append({'name': 'settings.xml', 'size': len(raw), 'encoding': 'base64+gzip',
		              'data': base64.b64encode(gzip.compress(raw)).decode('ascii')})
	for filename in sorted(files):
		if not _should_collect_backup_file(filename): continue
		path = PROFILE_DIR + filename
		try:
			# Ne jamais envoyer une copie brute d'une base SQLite ouverte : la
			# transaction la plus récente peut se trouver uniquement dans son WAL.
			if filename.lower().endswith('.db'):
				data = _sqlite_snapshot_bytes(path)
			else:
				data = _read_binary(path)
			if filename.lower() == 'settings.xml':
				data, sanitized_settings = _settings_snapshot_for_backup(data)
		except Exception as exc:
			# Un export partiel écraserait une sauvegarde distante complète en
			# omettant silencieusement la base ou les réglages illisibles.
			kodi_utils.logger('alkoPastes userdata backup blocked', '%s | %s: %s' % (filename, type(exc).__name__, exc))
			raise IOError('Sauvegarde interrompue : fichier portable illisible (%s)' % filename) from exc
		items.append({
			'name': filename,
			'size': len(data),
			'encoding': 'base64+gzip',
			'data': base64.b64encode(gzip.compress(data)).decode('ascii')
		})
	kodi_utils.logger('alkoPastes userdata backup collect', 'portable_files=%s | sanitized_settings=%s | names=%s' % (len(items), sanitized_settings, ','.join([item.get('name', '') for item in items]) or 'none'))
	return items, sanitized_settings


def _settings_snapshot_for_backup(data):
	# Les comptes protégés sont neutralisés avant l’envoi sur alkoPaste.
	import xml.etree.ElementTree as ET
	from modules.account_settings import ACCOUNT_SETTINGS
	root = ET.fromstring(data)
	if root.tag != 'settings': raise ValueError('Réglages de sauvegarde invalides')
	for setting_id in sorted(ACCOUNT_SETTINGS - AUTH_SETTING_DEFAULTS.keys()):
		value = kodi_utils.get_setting(setting_id, '')
		item = next((node for node in root if node.get('id') == setting_id), None)
		if item is None: item = ET.SubElement(root, 'setting', {'id': setting_id})
		item.set('value', str(value or ''))
		item.text = None
	return _sanitize_settings_xml(ET.tostring(root, encoding='utf-8'))


def _build_backup_payload(initial=False):
	if any(kodi_utils.get_property(key) == 'true' for key in (RESTORE_IN_PROGRESS_PROPERTY, BACKUP_IN_PROGRESS_PROPERTY)):
		raise IOError('Une sauvegarde ou restauration alkoFlix est déjà en cours.')
	kodi_utils.set_property(BACKUP_IN_PROGRESS_PROPERTY, 'true')
	try:
		return _build_backup_payload_unlocked(initial)
	finally:
		kodi_utils.clear_property(BACKUP_IN_PROGRESS_PROPERTY)


def _build_backup_payload_unlocked(initial):
	files, sanitized_settings = _collect_files(initial)
	return {
		'type': BACKUP_TYPE,
		'version': BACKUP_VERSION,
		'portable': True,
		'addon': 'plugin.video.alkoflix',
		'addon_version': kodi_utils.get_addoninfo('version'),
		'created': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
		'created_utc': datetime.now(timezone.utc).isoformat(),
		'backup_scope': 'master',
		'installation_role': 'master',
		'master_device_hash': _current_master_device_hash(),
		'master_device_hash_version': 1,
		'sanitized_settings': sanitized_settings,
		'files': files
	}



def _require_owner(remote):
	if not _is_master_installation():
		raise ValueError('Seul l’appareil maître peut remplacer la sauvegarde.')
	if remote is None or remote.data.get('master_device_hash') != _current_master_device_hash():
		raise ValueError('Choisissez de nouveau « Ceci est mon appareil maître » pour rattacher cet appareil à la sauvegarde actuelle.')
	if remote.code != _bound_code() and remote.numeric_id != _bound_code():
		raise ValueError('La sauvegarde sélectionnée sur cet appareil a changé.')


def _replace_master(request, remote):
	_require_owner(remote)
	data = _build_backup_payload()
	data['backup_name'] = remote.name
	_validate_master_files(data)
	code = alkopastes_master.write(request, data, remote)
	kodi_utils.set_setting(BACKUP_NAME_SETTING, remote.name)
	kodi_utils.set_setting(BACKUP_SETTING_MULTI, code)
	return code


@_manual_action
def backup_alkoflix_userdata():
	if not _is_master_installation():
		raise ValueError('Seul l’appareil maître peut remplacer la sauvegarde.')
	if not _ensure_alkopastes_connected(): return
	request = _account_request()
	kodi_utils.show_busy_dialog()
	try: remote = _selected_snapshot(request)
	finally: kodi_utils.hide_busy_dialog()
	if remote is None or remote.data.get('master_device_hash') != _current_master_device_hash():
		raise ValueError('Choisissez « Ceci est mon appareil maître » pour créer ou reprendre la sauvegarde de ce compte.')
	text = ('Remplacer la sauvegarde maître [B]%s[/B] (code %s), enregistrée le %s, par les réglages et les menus de cet appareil ?[CR][CR]'
		'Les autres appareils pourront ensuite restaurer cette nouvelle copie. Les favoris et le suivi multi-appareil se synchronisent séparément.') % (remote.name, remote.code, remote.data.get('created') or 'date inconnue')
	if not kodi_utils.confirm_dialog(text=text, ok_label='Remplacer', cancel_label='Annuler', top_space=True): return
	kodi_utils.show_busy_dialog()
	try: code = _replace_master(request, remote)
	finally: kodi_utils.hide_busy_dialog()
	return kodi_utils.ok_dialog(text='Sauvegarde maître mise à jour.[CR][CR]Code : [B]%s[/B]' % code, top_space=True)


def automatic_alkoflix_userdata_backup(force=False):
	# Les sauvegardes de profil restent manuelles. Le service existant peut encore appeler ce point d’entrée.
	if not force: return 'disabled'
	if not _is_master_installation(): return 'not master'
	with _backup_operation():
		request = _account_request()
		_replace_master(request, _selected_snapshot(request))
	return 'success'


def automatic_alkoflix_userdata_restore(force=False):
	if not force: return 'disabled'
	if not _secondary_selected() or _master_selected(): return 'not secondary'
	with _backup_operation():
		remote = _selected_snapshot(_account_request())
		if remote is None: return 'no backup'
		kodi_utils.set_setting(BACKUP_SETTING_MULTI, remote.code)
		kodi_utils.set_setting(BACKUP_NAME_SETTING, remote.name)
		_restore_files(remote.data)
	return 'success'


def _validate_backup_header(data):
	if not isinstance(data, dict) or data.get('type') != BACKUP_TYPE:
		raise Exception('Le paste indiqué n’est pas une sauvegarde userdata alkoFlix valide.')
	if data.get('addon', 'plugin.video.alkoflix') != 'plugin.video.alkoflix':
		raise ValueError('La sauvegarde appartient à une autre extension.')
	try:
		version = int(data.get('version'))
	except (TypeError, ValueError):
		raise ValueError('Version du format de sauvegarde invalide.')
	if isinstance(data.get('version'), bool) or str(data.get('version')) != str(version) or not 1 <= version <= BACKUP_VERSION:
		raise ValueError('Version du format de sauvegarde non prise en charge.')
	if not isinstance(data.get('files'), list) or not data['files']:
		raise ValueError('La sauvegarde ne contient aucun fichier.')
	return data


# Budget défensif pour ne jamais décompresser sans limite une sauvegarde distante.
# Le contenu est une archive portable de réglages et de petites bases personnelles,
# et non un catalogue vidéo ou un cache téléchargé.
RESTORE_MAX_FILE_BYTES = 128 * 1024 * 1024
RESTORE_MAX_TOTAL_BYTES = 192 * 1024 * 1024
RESTORE_MAX_SETTINGS_BYTES = 4 * 1024 * 1024
RESTORE_DATABASE_COLUMNS = {
	'navigator.db': {'navigator': ('list_name', 'list_type', 'list_contents')},
	'watched.db': {
		'watched_status': ('db_type', 'media_id', 'season', 'episode', 'last_played', 'title'),
		'progress': ('db_type', 'media_id', 'season', 'episode', 'resume_point', 'curr_time', 'last_played', 'resume_id', 'title'),
	},
}


def _decode_restore_item(item, remaining_bytes):
	filename = str(item.get('name') or '')
	encoding = str(item.get('encoding') or '')
	if encoding not in ('base64', 'base64+gzip'):
		raise ValueError('Encodage de sauvegarde invalide (%s)' % filename)
	encoded = item.get('data')
	if not isinstance(encoded, str):
		raise ValueError('Données de sauvegarde absentes (%s)' % filename)
	limit = min(RESTORE_MAX_SETTINGS_BYTES if filename.lower() == 'settings.xml' else RESTORE_MAX_FILE_BYTES, remaining_bytes)
	if limit <= 0 or len(encoded) > ((limit * 4 // 3) + 4096):
		raise ValueError('Fichier de sauvegarde trop volumineux (%s)' % filename)
	try:
		compressed = base64.b64decode(encoded, validate=True)
		if encoding == 'base64+gzip':
			with gzip.GzipFile(fileobj=io.BytesIO(compressed), mode='rb') as reader:
				raw = reader.read(limit + 1)
		else:
			raw = compressed
	except (ValueError, OSError, EOFError) as exc:
		raise ValueError('Fichier de sauvegarde illisible (%s)' % filename) from exc
	if len(raw) > limit:
		raise ValueError('Fichier de sauvegarde trop volumineux (%s)' % filename)
	declared = item.get('size')
	if declared is not None:
		try:
			if int(declared) != len(raw): raise ValueError('Taille de sauvegarde incorrecte (%s)' % filename)
		except (TypeError, ValueError) as exc:
			raise ValueError('Taille de sauvegarde incorrecte (%s)' % filename) from exc
	return raw


def _validate_sqlite_bytes(raw, filename, recovery_dir):
	# La validation se fait dans un fichier provisoire indépendant, jamais en
	# ouvrant ou créant la base existante de l'utilisateur.
	path = os.path.join(recovery_dir, 'incoming_' + filename)
	with open(path, 'wb') as writer:
		writer.write(raw)
	if not raw.startswith(b'SQLite format 3\x00') or not _validate_sqlite_file(path):
		raise ValueError('Base SQLite sauvegardée invalide (%s)' % filename)
	name = filename[4:] if filename.startswith('old_') else filename
	connection = sqlite3.connect(path)
	try:
		for table, expected in RESTORE_DATABASE_COLUMNS.get(name, {}).items():
			actual = tuple(row[1] for row in connection.execute('PRAGMA table_info(%s)' % table))
			if actual != expected:
				raise ValueError('Structure de sauvegarde incompatible (%s / %s)' % (name, table))
	finally:
		connection.close()
	return path


def _navigator_memory_keys(path):
	connection = sqlite3.connect(path)
	try:
		return set(connection.execute('SELECT list_name, list_type FROM navigator'))
	finally:
		connection.close()


def _restore_database_from_file(filename, source_path):
	# L'API SQLite backup effectue une transaction cohérente dans la base cible.
	# Contrairement à os.replace, elle ne supprime ni les WAL, ni les SHM, ni les
	# journaux qui peuvent être utilisés par d'autres connexions Kodi.
	target = kodi_utils.translate_path(PROFILE_DIR + filename)
	was_present = os.path.exists(target)
	source = dest = None
	try:
		source = sqlite3.connect(source_path, timeout=10)
		dest = sqlite3.connect(target, timeout=10)
		deadline = time.monotonic() + 40.0
		def _check_progress(status, remaining, total):
			if time.monotonic() > deadline:
				raise TimeoutError('Restauration SQLite trop longue (%s)' % filename)
		source.backup(dest, pages=128, progress=_check_progress, sleep=0.05)
		result = dest.execute('PRAGMA integrity_check').fetchone()
		if not result or str(result[0]).lower() != 'ok':
			raise IOError('Intégrité de la base restaurée invalide (%s)' % filename)
	finally:
		if dest is not None: dest.close()
		if source is not None: source.close()
	if os.path.exists(target): _clear_windows_hidden_attribute(PROFILE_DIR + filename)
	return was_present


def _restore_files(data):
	_validate_backup_header(data)
	if kodi_utils.get_property(RESTORE_IN_PROGRESS_PROPERTY) == 'true':
		raise IOError('Une restauration alkoFlix est déjà en cours.')
	if kodi_utils.get_property(BACKUP_IN_PROGRESS_PROPERTY) == 'true':
		raise IOError('Une sauvegarde alkoFlix est déjà en cours.')
	if kodi_utils.get_property('alkoflix_preset_applying') == 'true':
		raise IOError('Un préréglage alkoFlix est en cours d’application.')
	kodi_utils.set_property(RESTORE_IN_PROGRESS_PROPERTY, 'true')
	try:
		return _restore_files_unlocked(data)
	finally:
		kodi_utils.clear_property('alkoflix_settings')
		kodi_utils.clear_property(RESTORE_IN_PROGRESS_PROPERTY)


def _restore_files_unlocked(data):
	# Etape 1 : préparer et vérifier TOUTES les pièces avant de toucher au profil.
	files = data.get('files')
	if not isinstance(files, list):
		raise ValueError('Liste de fichiers de sauvegarde invalide')
	if not kodi_utils.path_exists(PROFILE_DIR): kodi_utils.make_directorys(PROFILE_DIR)
	profile_native = kodi_utils.translate_path(PROFILE_DIR)
	if not os.path.isdir(profile_native):
		raise IOError('Dossier de profil inaccessible')
	preserve_values = _local_settings_values(LOCAL_SETTINGS_TO_PRESERVE)
	# Dossier privé de récupération DANS le même profil; si la restauration
	# échoue gravement, il est conservé pour permettre une récupération manuelle.
	recovery_dir = tempfile.mkdtemp(prefix='alkoflix_restore_recovery_', dir=profile_native)
	staged, skipped, sanitized = {}, 0, 0
	closed_handles = []
	changed_db = []
	old_settings = None
	rollback_complete = True
	navigator_memory_keys = set()
	try:
		remaining = RESTORE_MAX_TOTAL_BYTES
		for item in files:
			if not isinstance(item, dict):
				raise ValueError('Entrée de sauvegarde malformée')
			filename = item.get('name')
			if not _should_restore_backup_file(filename, data=data):
				skipped += 1
				continue
			filename = str(filename).lower()
			if filename in staged:
				raise ValueError('Fichier dupliqué dans la sauvegarde (%s)' % filename)
			raw = _decode_restore_item(item, remaining)
			remaining -= len(raw)
			if filename == 'settings.xml':
				raw, sanitized = _sanitize_settings_xml(raw, preserve_values=preserve_values)
				import xml.etree.ElementTree as ET
				try: valid_root = ET.fromstring(raw).tag == 'settings'
				except Exception: valid_root = False
				if not valid_root or _settings_values_from_xml(raw) is None or not _active_settings_defaults():
					raise ValueError('Réglages de sauvegarde invalides')
				staged[filename] = {'settings': raw}
			else:
				staged[filename] = {'db': _validate_sqlite_bytes(raw, filename, recovery_dir)}
		if not staged: raise ValueError('Aucun fichier portable alkoFlix à restaurer.')
		# Préparer également les copies de récupération AVANT toute modification.
		db_names = [name for name in staged if 'db' in staged[name]]
		for name in db_names:
			target = PROFILE_DIR + name
			if kodi_utils.path_exists(target):
				rollback_bytes = _sqlite_snapshot_bytes(target)
				staged[name]['old'] = _validate_sqlite_bytes(rollback_bytes, 'old_' + name, recovery_dir)
			else:
				staged[name]['old'] = None
			if name == 'navigator.db':
				navigator_memory_keys.update(_navigator_memory_keys(staged[name]['db']))
				if staged[name]['old']: navigator_memory_keys.update(_navigator_memory_keys(staged[name]['old']))
		if 'settings.xml' in staged:
			defaults = _active_settings_defaults()
			old_settings = {setting_id: str(kodi_utils.get_setting(setting_id, default) or '') for setting_id, default in defaults.items()}
		# Etape 2 : écriture transactionnelle SQLite, sans supprimer de caches,
		# favoris, journaux ni fichiers inconnus; les réglages sont appliqués en dernier.
		closed_handles = _close_open_database_handles(db_names)
		for name in db_names:
			# Marqué avant d'écrire : une exception en milieu de copie déclenche
			# la restauration de l'instantané d'origine.
			changed_db.append(name)
			_restore_database_from_file(name, staged[name]['db'])
			kodi_utils.logger('alkoPastes userdata restore write', 'OK | %s via SQLite backup' % name)
		if 'settings.xml' in staged:
			if not _restore_settings_via_kodi(staged['settings.xml']['settings'], preserve_values=preserve_values):
				raise IOError('Impossible d’appliquer tous les réglages Kodi')
			kodi_utils.logger('alkoPastes userdata restore write', 'OK | settings.xml via Kodi API')
		# Aucun nettoyage destructeur automatique. Les caches et autres DB
		# restent intacts et pourront être recalculés ultérieurement si nécessaire.
		count = len(staged)
		kodi_utils.logger('alkoPastes userdata restore write', 'DONE | restored=%s | received=%s | skipped_non_portable=%s | sanitized_settings=%s | cleanup=0' % (count, len(files), skipped, sanitized))
		return count, sanitized, 0, skipped
	except Exception as exc:
		# Retour arrière best-effort pour les bases déjà modifiées. Si une seule
		# récupération échoue, conserver les fichiers de secours sur disque.
		for name in reversed(changed_db):
			try:
				old = staged[name]['old']
				if old is None:
					# Base créée par CETTE restauration, elle n'existait pas avant.
					new_file = kodi_utils.translate_path(PROFILE_DIR + name)
					if os.path.exists(new_file): os.remove(new_file)
				else:
					_restore_database_from_file(name, old)
			except Exception as rollback_exc:
				rollback_complete = False
				kodi_utils.logger('alkoPastes userdata restore rollback failed', '%s | %s: %s' % (name, type(rollback_exc).__name__, rollback_exc))
		if old_settings is not None:
			try:
				for setting_id, old_value in old_settings.items():
					kodi_utils.set_setting(setting_id, old_value)
				kodi_utils.clear_property('alkoflix_settings')
			except Exception as rollback_exc:
				rollback_complete = False
				kodi_utils.logger('alkoPastes userdata restore settings rollback failed', '%s: %s' % (type(rollback_exc).__name__, rollback_exc))
		kodi_utils.logger('alkoPastes userdata restore blocked', '%s: %s | rollback_complete=%s' % (type(exc).__name__, exc, rollback_complete))
		if not rollback_complete:
			raise IOError('Restauration interrompue ; secours conservé dans %s' % recovery_dir) from exc
		raise
	finally:
		_reopen_database_handles(closed_handles)
		if 'navigator.db' in changed_db:
			# Invalider seulement les propriétés en mémoire. Les anciennes références
			# « default » sur disque restent nécessaires aux migrations des menus.
			for list_name, list_type in navigator_memory_keys:
				if list_type in ('default', 'edited', 'shortcut_folder', 'shortcut_folder_icon', 'removed_items'):
					try: kodi_utils.clear_property('alkoflix_%s_%s' % (list_name, list_type))
					except Exception as exc: kodi_utils.logger('alkoFlix restored menu cache skipped', type(exc).__name__)
			try: kodi_utils.set_property('alkoflix_kodi_menu_cache', 'false')
			except Exception as exc: kodi_utils.logger('alkoFlix restored menu flag skipped', type(exc).__name__)
		if rollback_complete:
			shutil.rmtree(recovery_dir, ignore_errors=True)



@_manual_action
def restore_alkoflix_userdata():
	if not _role_selected():
		raise ValueError('Choisissez d’abord le rôle de cet appareil dans Préréglages.')
	if not _ensure_alkopastes_connected(): return
	request = _account_request()
	code = _bound_code()
	if not code:
		entries = _choices(request)
		if not entries: raise ValueError('Aucune sauvegarde maître sur ce compte.')
		code = _choose_saved(entries)
		if not code: return
	kodi_utils.show_busy_dialog()
	try: remote = alkopastes_master.read(request, code, _validate_master)
	finally: kodi_utils.hide_busy_dialog()
	if not remote: raise ValueError('Cette sauvegarde est indisponible. Sélectionnez de nouveau le rôle de cet appareil pour en choisir une.')
	data = remote.data

	role_note = ''
	if _is_multi_device_mode() and not _is_master_installation():
		role_note = 'Cette installation est secondaire : elle récupère la sauvegarde, mais ne l’écrit pas automatiquement.[CR][CR]'
	elif _is_multi_device_mode():
		role_note = 'Cette installation est maître : elle sert de référence pour les autres appareils.[CR][CR]'
	text = ('Cette restauration alkoFlix remplacera les données alkoFlix par celles de la sauvegarde.[CR][CR]'
		'%s'
		'Sauvegarde : [B]%s[/B][CR]Code : [B]%s[/B][CR]'
		'Version d’alkoFlix à la création : [B]%s[/B][CR][CR]'
		'Les caches et bases non portables seront conservés. Les tokens et autorisations de comptes externes resteront propres à cet appareil.[CR][CR]'
		'Les statuts locaux de visionnement ne seront restaurés que si cet appareil utilise le fournisseur local alkoFlix. En mode Trakt/MDBList ou multi-appareil, ils sont ignorés afin d’éviter les conflits entre appareils.[CR][CR]'
		'Un redémarrage de Kodi est recommandé après la restauration.[CR][CR]'
		'Continuer ?') % (role_note, remote.name, remote.code, data.get('addon_version') or 'non précisée')
	if not kodi_utils.confirm_dialog(text=text, ok_label='Restaurer', cancel_label='Annuler', top_space=True): return

	kodi_utils.show_busy_dialog()
	try:
		count, sanitized, cleanup_count, skipped = _restore_files(data)
		kodi_utils.set_setting(BACKUP_SETTING_MULTI, remote.code)
		kodi_utils.set_setting(BACKUP_NAME_SETTING, remote.name)
		created = str(data.get('created') or '')
		if created: kodi_utils.set_setting(USERDATA_AUTO_RESTORE_LAST_CREATED_SETTING, created)
		kodi_utils.clear_property('alkoflix_settings')
		kodi_utils.hide_busy_dialog()
		message = ('Restauration alkoFlix terminée.[CR][CR]'
			'Fichiers restaurés : [B]%s[/B][CR]'
			'Réglages sensibles nettoyés : [B]%s[/B][CR]'
			'Données non portables ignorées : [B]%s[/B][CR]'
			'Caches locaux conservés : [B]oui[/B][CR][CR]'
			'Voulez-vous redémarrer Kodi maintenant ?') % (count, sanitized, skipped)
		if kodi_utils.confirm_dialog(text=message, ok_label='Redémarrer', cancel_label='Plus tard', top_space=True):
			kodi_utils.execute_builtin('RestartApp')
		return
	except Exception as exc:
		kodi_utils.hide_busy_dialog()
		kodi_utils.logger('alkoPastes userdata restore error', '%s: %s' % (type(exc).__name__, exc))
		return kodi_utils.ok_dialog(text='Erreur pendant la restauration alkoPastes.[CR][CR]%s' % exc, top_space=True)
