# -*- coding: utf-8 -*-
"""Fanarts AF3 calcules a partir des reponses de details TMDb deja disponibles.

Regles inspirees des classes ArtFanart / ArtExtraFanart de TMDb Helper :
  - backdrops sans langue (iso_639_1 null ou xx), notes decroissantes ;
  - la meilleure image est la toile de fond ; les suivantes sont fanart1..10 ;
  - landscape est une categorie distincte, pas une reserve de fanarts.
Les fonctions de ce module sont pures : aucun cache, fichier ou reseau.
"""

MAX_EXTRA_FANARTS = 10  # TMDb Helper : LIMIT 10 OFFSET 1
SELECTION_VERSION = 3
NEUTRAL_LANGUAGES = (None, 'xx')


def _art_id(url):
    """Identite TMDb stable meme lorsque la taille d'image differe."""
    if not isinstance(url, str) or not url.strip():
        return ''
    url = url.strip()
    if 'image.tmdb.org/t/p/' in url:
        try:
            return 'tmdb:' + url.split('/t/p/', 1)[1].split('/', 1)[1].split('?', 1)[0]
        except (IndexError, ValueError):
            pass
    return url


def _unique_urls(urls, limit=None):
    result, seen = [], set()
    for url in urls:
        identity = _art_id(url)
        if not identity or identity in seen:
            continue
        seen.add(identity)
        result.append(url.strip())
        if limit is not None and len(result) >= limit:
            break
    return result


def _landscape_ids(meta):
    """Exclut les miniatures de la rotation meme si leur resolution differe."""
    urls = [meta.get(k) for k in (
        'landscape_tmdb', 'landscape_tmdb_text', 'landscape',
        'landscape_text', 'tvshow.landscape', 'tvshow.landscape_text')]
    for key in ('season_landscapes', 'season_landscapes_text'):
        season_art = meta.get(key)
        if isinstance(season_art, dict):
            urls.extend(season_art.values())
    return {_art_id(url) for url in urls if _art_id(url)}


def _vote_score(image):
    try: rating = float(image.get('vote_average') or 0)
    except (TypeError, ValueError): rating = 0.0
    try: votes = int(image.get('vote_count') or 0)
    except (TypeError, ValueError): votes = 0
    return (-rating, -votes)


def tmdb_fanart_gallery(backdrops, resolution, image_base, exclude_landscapes=(), limit=MAX_EXTRA_FANARTS):
    """Retourne (fanart sans texte, [fanart1..10]) sans I/O.

    Reproduit la selection ArtFanart (premier) + ArtExtraFanart
    (suivants) de TMDb Helper. Les backdrops identifies par une langue
    ne sont JAMAIS utilises, meme pour completer artificiellement 10 images.
    Les backdrops sans iso_639_1 explicite ne sont pas consideres valides.
    """
    try: limit = min(MAX_EXTRA_FANARTS, max(1, int(limit)))
    except (TypeError, ValueError): limit = MAX_EXTRA_FANARTS

    neutrals = []
    for row in (backdrops or ()):
        if not isinstance(row, dict) or 'iso_639_1' not in row:
            continue
        if row['iso_639_1'] not in NEUTRAL_LANGUAGES:
            continue
        path = row.get('file_path')
        if not isinstance(path, str) or not path.startswith('/'):
            continue
        neutrals.append(row)
    neutrals.sort(key=_vote_score)

    ranked_urls = _unique_urls([image_base % (resolution, row['file_path']) for row in neutrals])
    if not ranked_urls:
        return '', []
    main = ranked_urls[0]
    # OFFSET 1 : pas d'injection du fanart principal dans fanart1.
    excluded = {_art_id(url) for url in exclude_landscapes if _art_id(url)}
    extras = [url for url in ranked_urls[1:] if _art_id(url) not in excluded]
    return main, extras[:limit]


def from_tmdb_images(backdrops, main_fanart, resolution, image_base,
                     image_language='fr', original_language='', limit=MAX_EXTRA_FANARTS,
                     exclude_landscapes=()):
    """Ancienne interface conservee pour compatibilite de code.

    Les langues et main_fanart ne doivent pas reintroduire des images titre.
    """
    return tmdb_fanart_gallery(backdrops, resolution, image_base,
                               exclude_landscapes=exclude_landscapes, limit=limit)[1]


def item_art(meta, primary_fanart='', tvshow=False):
    """Art pour menus et widgets ; zero reseau, zero I/O, zero refresh.

    Une ancienne galerie sans la version/provenance requise n'est pas fiable:
    ne pas la publier plutot que de recycler des images avec texte.
    """
    if not isinstance(meta, dict) or meta.get('extra_fanarts_selection_version') != SELECTION_VERSION:
        return {}
    main = meta.get('extra_fanart_primary')
    stored = meta.get('extra_fanarts')
    if not _art_id(main) or not isinstance(stored, (list, tuple)):
        return {}

    excluded = _landscape_ids(meta)
    excluded.add(_art_id(main))
    extras = _unique_urls([url for url in stored if _art_id(url) not in excluded], MAX_EXTRA_FANARTS)
    if not extras:
        return {}

    # AF3 utilise aussi le fond principal lorsqu'il alterne les images.
    # Un fanart Fanart.tv prioritaire mais titre pouvait donc s'infiltrer
    # dans la rotation : pour les fiches ayant une galerie fiable, le fond
    # choisi est la premiere image neutre TMDb, comme TMDb Helper.
    art = {'fanart': main}
    if tvshow:
        art['tvshow.fanart'] = main
    for n, url in enumerate(extras, 1):
        key = 'fanart%s' % n
        art[key] = url
        if tvshow:
            art['tvshow.' + key] = url
    return art
