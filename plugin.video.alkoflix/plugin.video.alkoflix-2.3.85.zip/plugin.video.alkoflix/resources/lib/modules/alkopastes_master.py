"""Recherche et écriture des sauvegardes maître privées du compte connecté."""
import json
import unicodedata
from datetime import datetime
from typing import NamedTuple

from modules.alkopastes_api import _summary_code, _paste_code

TITLE = 'Sauvegarde maître alkoFlix'


class Snapshot(NamedTuple):
    code: str
    title: str
    data: dict
    revision: object
    numeric_id: str

    @property
    def name(self):
        return str(self.data.get('backup_name') or 'Sauvegarde maître').strip() or 'Sauvegarde maître'


class Choice(NamedTuple):
    code: str
    name: str
    date: str
    order: tuple


def clean_name(value):
    name = ' '.join(unicodedata.normalize('NFC', value or '').split())
    if not name or len(name) > 80 or any(c in '[]' or unicodedata.category(c) == 'Cc' for c in name):
        raise ValueError('Utilisez un nom de 1 à 80 caractères, sans crochets.')
    return name


def summary(snapshot):
    data = snapshot.data
    date = str(data.get('created') or data.get('created_utc') or '')
    stamp = _date(data.get('created_utc') or date)
    if stamp is None:
        raise InvalidBackup('La date de cette sauvegarde maître est illisible.')
    ident = int(snapshot.numeric_id) if snapshot.numeric_id.isdigit() else 0
    return Choice(snapshot.code, snapshot.name, date, (stamp, ident, snapshot.code))


def _date(value):
    try:
        return datetime.fromisoformat(str(value).replace('Z', '+00:00')).timestamp()
    except (ValueError, OverflowError, OSError):
        return None


def _account_pastes(request):
    page, seen, expected_total = 1, set(), None
    while True:
        response = request('GET', 'list', params={'page': page, 'limit': 100})
        rows, pagination = response.get('pastes'), response.get('pagination')
        if not isinstance(rows, list) or not isinstance(pagination, dict):
            raise ValueError('Liste des pastes incomplète. Réessayez.')
        total, pages, limit = (int(pagination[k]) for k in ('total', 'pages', 'limit'))
        if (int(pagination['page']) != page or limit < 1 or total < 0
                or pages not in ({0, 1} if not total else {(total + limit - 1) // limit})
                or len(rows) != min(limit, max(0, total - (page - 1) * limit))
                or expected_total not in (None, total)):
            raise ValueError('La liste des pastes a changé ou est incomplète. Réessayez.')
        expected_total = total
        for row in rows:
            code = _summary_code(row) if isinstance(row, dict) else ''
            if not code or code in seen or not isinstance(row.get('title'), str) or not row.get('visibility'):
                raise ValueError('La liste des pastes contient une entrée manquante ou répétée.')
            seen.add(code)
            yield code, row
        if page >= pages:
            if len(seen) != total:
                raise ValueError('La liste des pastes est incomplète.')
            return
        page += 1


def read(request, code, validate):
    paste = request('GET', 'get', params={'id': code}).get('paste')
    if not isinstance(paste, dict) or 'content' not in paste or not _summary_code(paste):
        raise ValueError('Réponse alkoPaste incomplète pendant la lecture de la sauvegarde.')
    if code not in {_summary_code(paste), str(paste.get('id') or '')}:
        raise ValueError('Le code renvoyé par alkoPaste diffère du code demandé.')
    if paste.get('visibility') != 'private':
        raise ValueError('Cette sauvegarde doit être privée et appartenir au compte connecté.')
    data = paste['content']
    if isinstance(data, str):
        data = json.loads(data)
    if (not isinstance(data, dict) or data.get('backup_scope') != 'master'
            or data.get('installation_role', 'master') != 'master'
            or data.get('type') != 'alkoflix_userdata_backup'):
        return None
    validate(data)
    return Snapshot(_summary_code(paste), str(paste.get('title') or TITLE), data,
                    paste.get('revision'), str(paste.get('id') or ''))


def choices(request, validate, previous_code=''):
    records, unreadable = [], False
    prefix = TITLE.casefold().replace('î', 'i')
    for code, row in _account_pastes(request):
        title = row['title'].strip().casefold().replace('î', 'i')
        known = previous_code and previous_code in (code, str(row.get('id', '')))
        if row['visibility'] != 'private' or not (known or title == prefix or title.startswith(prefix + ' -')):
            continue
        try:
            snap = read(request, code, validate)
            if snap:
                records.append(summary(snap))
        except (json.JSONDecodeError, InvalidBackup):
            unreadable = True
    if not records and unreadable:
        raise ValueError('Une sauvegarde maître est illisible. Vérifiez-la avant de créer une nouvelle copie.')
    return sorted(records, key=lambda entry: entry.order, reverse=True)


class InvalidBackup(ValueError):
    """Les données reçues sont illisibles. Les erreurs de transport remontent séparément."""


def write(request, data, previous=None, keep_title=False):
    # Le contenu et la révision proviennent du même GET, y compris pour un transfert de rôle.
    title = previous.title if keep_title else TITLE + ' - ' + clean_name(data['backup_name'])
    payload = {'title': title, 'content': json.dumps(data, ensure_ascii=False, separators=(',', ':')),
               'syntax': 'json', 'visibility': 'private', 'expiry': 'NULL'}
    if previous is None:
        result = request('POST', 'paste', payload=payload)
        code = _paste_code(result)
    else:
        revision = str(previous.revision or '')
        if not revision.isdigit() or int(revision) < 1:
            # Des déploiements 1.1 fournissent la révision via status uniquement.
            status = request('GET', 'status', params={'id': previous.code}).get('paste') or {}
            revision = str(status.get('revision') or '')
            if (_summary_code(status) not in {previous.code, previous.numeric_id} or
                    not revision.isdigit() or int(revision) < 1):
                raise ValueError('alkoPaste doit confirmer la révision avant toute modification.')
            current = read(request, previous.code, lambda data: None)
            if not current or current.data != previous.data or current.title != previous.title:
                raise ValueError('La sauvegarde a changé. Relancez votre action.')
        payload['expected_revision'] = int(revision)
        result = request('POST', 'update', params={'id': previous.code}, payload=payload)
        reply = result.get('paste') or {}
        if reply and _summary_code(reply) not in (previous.numeric_id, previous.code):
            raise ValueError('Le code confirmé par alkoPaste a changé. Relancez la recherche.')
        code = previous.code
    if not code:
        raise ValueError('alkoPaste n’a pas confirmé le code de sauvegarde. Relancez la recherche.')
    return code
