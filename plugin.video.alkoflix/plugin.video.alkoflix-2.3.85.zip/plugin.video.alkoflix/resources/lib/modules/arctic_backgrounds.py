# -*- coding: utf-8 -*-
"""Fonds de dossiers Arctic Fuse 3 : correspondances FR/EN et identifiants TMDb.

Les packs resource.images.arctic.backgrounds.* ont une structure commune :
  resource://resource.images.arctic.backgrounds.<style>/genres/<slug>.jpg
  resource://resource.images.arctic.backgrounds.<style>/content/<slug>.jpg
Aucune requête réseau, aucune dépendance obligatoire, aucune modification d'images
pour les médias : uniquement les entrées de menu dont le sens est certain.
"""
import re
import unicodedata

# Genres fournis dans les six packs Arctic (27 fichiers identiques).
GENRE_FILES = frozenset((
    'action-adventure', 'action', 'adventure', 'animation', 'comedy', 'crime',
    'documentary', 'drama', 'family', 'fantasy', 'history', 'horror', 'kids',
    'music', 'mystery', 'news', 'reality', 'romance', 'sci-fi-fantasy',
    'science-fiction', 'soap', 'talk', 'thriller', 'tv-movie',
    'war-politics', 'war', 'western',
))

# Identifiants TMDb, pour ne jamais dépendre de la langue affichée.
GENRE_IDS = {
    '28': 'action', '12': 'adventure', '16': 'animation', '35': 'comedy',
    '80': 'crime', '99': 'documentary', '18': 'drama', '10751': 'family',
    '14': 'fantasy', '36': 'history', '27': 'horror', '10402': 'music',
    '9648': 'mystery', '10749': 'romance', '878': 'science-fiction',
    '53': 'thriller', '10770': 'tv-movie', '10752': 'war', '37': 'western',
    '10759': 'action-adventure', '10762': 'kids', '10763': 'news',
    '10764': 'reality', '10765': 'sci-fi-fantasy', '10766': 'soap',
    '10767': 'talk', '10768': 'war-politics',
}


def _key(value):
    text = unicodedata.normalize('NFKD', str(value or ''))
    text = ''.join(ch for ch in text if not unicodedata.combining(ch))
    text = text.lower().replace('&', ' et ').replace('+', ' et ')
    return re.sub(r'[^a-z0-9]+', ' ', text).strip()


_GENRE_ALIASES = {
    'action': ('action',),
    'adventure': ('adventure', 'aventure'),
    'action-adventure': ('action aventure', 'action et aventure', 'action et adventure', 'action and adventure'),
    'animation': ('animation', 'anime', 'animes', 'dessin anime', 'dessins animes'),
    'comedy': ('comedy', 'comedie'),
    'crime': ('crime', 'policier'),
    'documentary': ('documentary', 'documentaire'),
    'drama': ('drama', 'drame'),
    'family': ('family', 'famille', 'familial'),
    'fantasy': ('fantasy', 'fantastique'),
    'history': ('history', 'histoire', 'historique'),
    'horror': ('horror', 'horreur', 'epouvante'),
    'kids': ('kids', 'children', 'jeunesse', 'enfants'),
    'music': ('music', 'musique', 'musical'),
    'mystery': ('mystery', 'mystere'),
    'news': ('news', 'actualites', 'actualite'),
    'reality': ('reality', 'telerealite', 'tele realite'),
    'romance': ('romance', 'romantique'),
    'science-fiction': ('science fiction', 'sci fi'),
    'sci-fi-fantasy': ('sci fi fantasy', 'sci fi et fantasy', 'science fiction et fantastique',
                       'science fiction et fantasy', 'science fiction and fantasy'),
    'soap': ('soap', 'feuilleton'),
    'talk': ('talk', 'talk show', 'talk shows', 'emission debat'),
    'thriller': ('thriller',),
    'tv-movie': ('tv movie', 'telefilm', 'telefilms'),
    'war-politics': ('war politics', 'war et politics', 'war and politics', 'guerre et politique'),
    'war': ('war', 'guerre'),
    'western': ('western',),
}
ALIAS_TO_GENRE = { _key(alias): slug for slug, aliases in _GENRE_ALIASES.items() for alias in aliases }
for slug in GENRE_FILES:
    ALIAS_TO_GENRE[_key(slug)] = slug

# Les 41 illustrations de ``content/`` présentes dans les packs officiels.
# On ne mappe QUE des intitulés complets, sans chercher des sous-chaînes :
# « Films documentaires » ne devient donc jamais « Films », par exemple.
_CONTENT_NAMES = {
    'actors': ('acteurs', 'actrices', 'casting', 'actors'),
    'addons': ('extensions', 'extensions kodi', 'add-ons', 'addons'),
    'albums': ('albums',),
    'artists': ('artistes', 'artists'),
    'compilations': ('compilations',),
    'countries': ('pays', 'par pays', 'countries', 'country'),
    'directors': ('realisateurs', 'realisatrices', 'directors'),
    'episodes': ('episodes', 'par episode', 'episodes tv'),
    'files': ('fichiers', 'files'),
    'games': ('jeux', 'games'),
    'genres': ('genres', 'par genre', 'les genres', 'genres de films', 'genres de series'),
    'images': ('images', 'photos', 'pictures'),
    'inprogressmovies': ('films en cours', 'films en progression', 'in progress movies'),
    'inprogresstvshows': ('series en cours', 'series en progression', 'in progress tv shows'),
    'livetv': ('television en direct', 'tv en direct', 'live tv'),
    'mixed': ('mixte', 'melange', 'combined', 'combine', 'mixed'),
    'movies': ('films', 'film', 'movies', 'movie'),
    'music': ('musique', 'music'),
    'musicvideos': ('clips musicaux', 'videos musicales', 'music videos'),
    'playlists': ('listes thematiques', 'listes de lecture', 'playlists', 'playlist'),
    'plugins': ('plugins', 'greffons'),
    'recentlyaddedalbums': ('albums ajoutes recemment', 'nouveaux albums', 'recently added albums'),
    'recentlyaddedmovies': ('films ajoutes recemment', 'films recemment ajoutes', 'recently added movies'),
    'recentlyaddedtvshows': ('series ajoutees recemment', 'series recemment ajoutees', 'recently added tv shows'),
    'recentlyplayedalbums': ('albums recemment ecoutes', 'recently played albums'),
    'recordings': ('enregistrements', 'recordings'),
    'roles': ('roles', 'roles artistiques'),
    'seasons': ('saisons', 'seasons'),
    'sets': ('collections', 'sagas', 'saga', 'sets', 'coffrets'),
    'singles': ('singles', 'simples'),
    'songs': ('chansons', 'titres musicaux', 'songs'),
    'sources': ('sources', 'sources de medias'),
    'studios': ('studios', 'studio'),
    'tags': ('etiquettes', 'mots cles', 'tags'),
    'top100': ('top 100', 'top100'),
    'tvshows': ('series', 'serie', 'series tv', 'tv shows', 'tvshows'),
    'versions': ('versions', 'versions video'),
    'videoassets': ('ressources video', 'video assets'),
    'videoextras': ('bonus video', 'extras video', 'video extras'),
    'videos': ('videos', 'video'),
    'years': ('annees', 'par annee', 'years', 'year'),
}
CONTENT_FILES = frozenset(_CONTENT_NAMES)
ALIAS_TO_CONTENT = {_key(alias): slug for slug, aliases in _CONTENT_NAMES.items() for alias in aliases}
for _slug in CONTENT_FILES:
    ALIAS_TO_CONTENT[_key(_slug)] = _slug

# AF3 utilise directement ces découpes transparentes dans son interface Kodi
# (écrans de paramètres). Elles NE sont pas des fanarts 16:9 et ne doivent pas
# remplacer les visuels des catalogues de films, séries ou genres.
CUTOUT_FILES = frozenset((
    'addonbrowser', 'eventlog', 'filemanager', 'gamesettings', 'interfacesettings',
    'mediasettings', 'playersettings', 'profiles', 'pvrsettings', 'servicesettings',
    'settings', 'skinsettings', 'systeminfo', 'systemsettings'
))


def genre_slug(params, label=''):
    """Exige une route de genre pour éviter les faux positifs des listes nommées."""
    params = params or {}
    action = str(params.get('action') or '').lower()
    mode = str(params.get('mode') or '').lower()
    filt = str(params.get('catalogue_filter_type') or params.get('filter_type') or '').lower()
    is_genre = bool(params.get('genre_id')) or filt == 'genre' or mode.endswith('.genre_menu') or (
        'genre' in action and not 'multiselect' in action
    )
    if not is_genre: return ''
    for key in ('genre_id', 'catalogue_filter_value', 'filter_value'):
        value = str(params.get(key) or '').strip()
        if value and ',' not in value and value in GENRE_IDS:
            return GENRE_IDS[value]
    for key in ('genres', 'genre_label'):
        slug = ALIAS_TO_GENRE.get(_key(params.get(key)))
        if slug: return slug
    return ALIAS_TO_GENRE.get(_key(label), '')


def menu_background_file(params, label=''):
    """Retourne un chemin relatif valide ou '' ; ne touche pas aux médias."""
    params = params or {}
    if params.get('new_page') or _key(label).startswith('page suivante'):
        return ''
    # Éviter d'interpréter le titre d'une liste personnelle comme une catégorie.
    if str(params.get('mode') or '') in ('build_tmdb_list', 'build_trakt_list', 'build_mdb_list'):
        return ''
    slug = genre_slug(params, label)
    if slug in GENRE_FILES: return 'genres/%s.jpg' % slug
    content = ALIAS_TO_CONTENT.get(_key(label), '')
    if content: return 'content/%s.jpg' % content
    # Les entrées explicitement nommées par type de menu (indépendamment du FR).
    mode = str(params.get('mode') or '').lower()
    if mode.endswith(('.native_genres', '.family_genres', '.documentary_genres',
                      '.alkopaste_values', '.genres')) and (
        mode != 'catalogue.alkopaste_values' or params.get('catalogue_value_type') == 'genre'
    ):
        return 'content/genres.jpg'
    return ''


def active_style_path():
    """Renvoie la racine resource:// du style actif seulement pour AF3.

    Ne déclenche ni installation, ni accès HTTP. L'absence du pack conserve
    simplement l'apparence actuelle d'alkoFlix.
    """
    try:
        import xbmc
        skin = str(xbmc.getSkinDir() or '').strip().lower()
        if skin != 'skin.arctic.fuse.3': return ''
        style = str(xbmc.getInfoLabel('Skin.String(Background.Style)') or '').strip().lower()
        if style == 'simple': return ''
        if not style: style = 'surrealist'
        if not re.fullmatch(r'[a-z0-9_-]+', style): return ''
        addon_id = 'resource.images.arctic.backgrounds.%s' % style
        if not xbmc.getCondVisibility('System.HasAddon(%s)' % addon_id): return ''
        suffix = 'midnight_champagne/' if style == 'goldenage' else ''
        return 'resource://%s/%s' % (addon_id, suffix)
    except Exception:
        return ''


def styled_menu_art(params, label='', fanart='', landscape='', is_folder=True):
    """Fond et landscape cohérents ; évite la priorité AF3 au logo 1:1."""
    if not is_folder:
        return (fanart, landscape)
    relative = menu_background_file(params, label)
    if not relative: return (fanart, landscape)
    base = active_style_path()
    if not base: return (fanart, landscape)
    background = base + relative
    # Ne remplace pas les fanarts personnalisés des menus non-genre.
    if relative.startswith('content/') and fanart:
        return (fanart, landscape)
    return (background, background)
