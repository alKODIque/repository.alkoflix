# -*- coding: utf-8 -*-
"""Paginate visible media, with one real item of lookahead.

Source page numbers are opaque: a Kodi page may consume several source pages,
or only part of one. page_start is an inclusive source position, never an offset
in the filtered list (watching an item must not shift the next page).
"""
from contextvars import ContextVar
import random
import time

CURSOR_FIELDS = ('page_start', 'tmdb_full_skip', 'catalogue_full_skip')
MIXED_FIELDS = ('mixed_movie_pages', 'mixed_tv_pages')
random_seed = ContextVar('alkoflix_pagination_random_seed', default='')


def prepare_random_seed(params, action='', source_only=False):
    if action.endswith('_random') or any(str(params.get(key, '')).lower() == 'random'
                                         for key in ('list_sort', 'genre_sort', 'catalogue_sort')):
        first = str(params.get('new_page', '1')) == '1' and not params.get('page_start')
        if (first and not source_only) or not params.get('list_random_seed'):
            params['list_random_seed'] = str(time.time_ns())
    return params.get('list_random_seed', '')


def random_generator(salt=''):
    seed = random_seed.get()
    return random.Random('%s:%s' % (seed, salt)) if seed else random.SystemRandom()


class PageBatch:
    def __init__(self, entries=(), next_params=None, signature=None, render_entries=None):
        self.entries = list(entries)
        self.render_entries = render_entries
        self.next_params = next_params or {}
        self.signature = signature


class PaginationError(Exception):
    def __init__(self, message, items):
        super().__init__(message)
        self.items = items


def source_next_params(params, continuation):
    if not continuation:
        return {}
    result = dict(params)
    result.update(continuation)
    for key in CURSOR_FIELDS:
        result.pop(key, None)
    return result


def media_entries(items):
    for index, item in enumerate(items or [], 1):
        try: position = int(item[1].getProperty('alkoflix_sort_order'))
        except (ValueError, TypeError): position = index
        yield position, item


def collect_page(load_page, params, limit, abort=None, first_batch=None):
    """Return (items, confirmed_next_params). None limit keeps a full local list.

load_page must retain positions before watched/parental/availability filtering.
Empty filtered batches are traversed while the source declares a continuation.
No fixed 3/8-page cutoff: only exhaustion, lookahead or Kodi shutdown stops us.
"""
    current = dict(params)
    items, seen, visited = [], set(), set()
    previous_signature = None
    batch = first_batch
    while True:
        if abort and abort():
            return items, {}
        cursor = repr(sorted((str(k), str(v)) for k, v in current.items()))
        if cursor in visited:
            raise PaginationError('La source répète son curseur de pagination.', items)
        visited.add(cursor)
        try:
            batch = batch if batch is not None else load_page(current)
            if batch is None:
                raise ValueError('Réponse de pagination manquante.')
        except Exception as exc:
            raise PaginationError(str(exc), items) from exc
        if batch.signature and batch.signature == previous_signature:
            raise PaginationError('La source renvoie deux fois la même page.', items)
        previous_signature = batch.signature
        try: start = int(current.get('page_start', '0') or 0)
        except (TypeError, ValueError): start = 0
        try:
            needed = None if limit is None else limit - len(items) + 1
            entries = batch.render_entries(needed) if batch.render_entries else batch.entries
            for position, item in entries:
                key = item[0]
                if position < start:
                    seen.add(key)
                    continue
                if key in seen:
                    continue
                if limit is not None and len(items) >= limit:
                    continuation = dict(current)
                    continuation['page_start'] = str(position)
                    continuation.setdefault('new_page', '1')
                    return items, continuation
                seen.add(key)
                items.append(item)
        except Exception as exc:
            raise PaginationError(str(exc), items) from exc
        if not batch.next_params:
            return items, {}
        current = dict(batch.next_params)
        batch = None


def collect_kodi_page(load_page, params, limit, first_batch=None):
    from modules import kodi_utils
    monitor = kodi_utils.xbmc.Monitor()
    try:
        items, continuation = collect_page(load_page, params, limit, monitor.abortRequested, first_batch)
    except PaginationError as exc:
        kodi_utils.logger('pagination interrompue', str(exc))
        if not kodi_utils.external_browse():
            kodi_utils.notification('Chargement incomplet. Actualisez ce menu pour réessayer.', 5000)
        items, continuation = exc.items, {}
    # The source positions are already captured in the cursor. Expose one
    # continuous display order when several source pages contributed items.
    for index, item in enumerate(items, 1):
        item[1].setProperty('alkoflix_sort_order', str(index))
    return items, continuation


def _catalogue_widget_entries(menu, build_one, needed):
    ids = menu.list
    if needed is None or needed >= len(ids):
        yield from media_entries(menu.worker())
        return

    # Construire en parallèle la partie certaine de la page. Quand il reste
    # une seule place à confirmer, avancer par ID avec les filtres du worker.
    prefix = needed - 1
    if prefix:
        menu.list = ids[:prefix]
        try:
            ready = menu.worker()
        finally:
            menu.list = ids
        yield from media_entries(ready)

    from caches.meta_cache import MetaCache
    cache = MetaCache()
    try:
        for position in range(prefix + 1, len(ids) + 1):
            media_id = ids[position - 1]
            before = len(menu.items)
            if not menu._build_cached_item(position, media_id, cache):
                build_one(position, media_id)
            if len(menu.items) > before:
                yield menu.tmdb_sort_offset + position, menu.items[-1]
    finally:
        cache.dbcon.close()


def menu_page_batch(menu, builder, build_one):
    if menu.is_widget and menu.action in ('alkopaste_catalogue', 'alkopaste_catalogue_airing'):
        return PageBatch(next_params=source_next_params(menu.params, menu.new_page),
                         signature=repr(menu.list) if menu.list else None,
                         render_entries=lambda needed: _catalogue_widget_entries(menu, build_one, needed))
    return PageBatch(media_entries(builder()), source_next_params(menu.params, menu.new_page),
                     repr(menu.list) if menu.list else None)


def collect_menu_page(menu, first_batch):
    from modules import settings
    # « Paginer si possible » concerne les listes personnelles/locales.
    personal = menu.action in menu.personal_dict or any(
        menu.action in getattr(menu, name, ())
        for name in ('tmdb_personal', 'trakt_personal', 'mdblist_personal', 'imdb_personal'))
    limit = None if personal and not settings.paginate() else settings.page_limit()

    def load(params):
        child = type(menu)(dict(params))
        # Même état vu et même portée menu/widget pendant toute la collecte.
        for name in ('is_widget', 'widget_hide_watched', 'menu_hide_watched',
                     'discover_hide_watched', 'watched_info', 'watched_indicators'):
            setattr(child, name, getattr(menu, name))
        return child.run(_source_only=True)

    return collect_kodi_page(load, menu.params, limit, first_batch)


class MixedBuilder:
    """Keep the interleaved source positions, including items hidden by workers."""
    def __init__(self, params, id_key, type_key):
        self.params, self.id_key, self.type_key = params, id_key, type_key
        self.workers = {}

    def entries(self, rows):
        from urllib.parse import parse_qs, urlsplit
        from menus.movies import Movies
        from menus.tvshows import TVShows
        item_map = {}
        for kind, worker_class in (('movie', Movies), ('tvshow', TVShows)):
            ids = [str(row[self.id_key]) for row in rows
                   if row.get(self.id_key) and self._kind(row) == kind]
            if not ids:
                continue
            worker = self.workers.get(kind)
            if worker is None:
                worker = worker_class(dict(self.params, list=ids, id_type='tmdb_id'))
                self.workers[kind] = worker
            worker.list, worker.items = ids, []
            worker.append = worker.items.append
            for item in worker.worker() or []:
                ids_in_url = parse_qs(urlsplit(str(item[0])).query).get('tmdb_id') or []
                if ids_in_url: item_map[(kind, str(ids_in_url[0]))] = item
        for position, row in enumerate(rows, 1):
            item = item_map.get((self._kind(row), str(row.get(self.id_key) or '')))
            if item: yield position, item

    def _kind(self, row):
        kind = row.get(self.type_key)
        return 'tvshow' if kind == 'tv' else kind


def mixed_source_page(params, fetch_movie, fetch_tv, interleave):
    """Fetch each side only while it has pages. Each fetch returns rows, total."""
    page = max(1, int(params.get('new_page', '1') or 1))
    rows, totals = [], []
    for field, fetch in zip(MIXED_FIELDS, (fetch_movie, fetch_tv)):
        end = params.get(field)
        if end is not None and page > int(end):
            values, total = [], int(end)
        else:
            values, total = fetch(page)
        rows.append(values or [])
        totals.append(max(1, int(total or 1)))
    continuation = {}
    if page < max(totals):
        continuation = source_next_params(params, {'new_page': str(page + 1)})
        continuation.update({field: str(total) for field, total in zip(MIXED_FIELDS, totals)})
    return interleave(*rows), continuation
