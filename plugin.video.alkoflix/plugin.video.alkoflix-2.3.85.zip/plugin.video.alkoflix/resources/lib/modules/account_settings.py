"""État local des comptes gérés par les actions de connexion d’alkoFlix."""

import os
import sqlite3
from contextlib import closing
from pathlib import Path


ACCOUNT_SETTINGS = frozenset((
    'ad.token', 'ad.account_id',
    'rd.token', 'rd.refresh', 'rd.client_id', 'rd.secret', 'rd.username',
    'tb.token', 'tb.account_id',
    'trakt.token', 'trakt.refresh', 'trakt.expires', 'trakt_user', 'trakt_indicators_active',
    'mdblist.token', 'mdblist.auth_type', 'mdblist.access_token', 'mdblist.refresh_token',
    'mdblist.expires', 'mdblist.client_id', 'mdblist_user', 'mdbl_indicators_active',
    'tmdb.token', 'tmdb.account_id', 'tmdb.username', 'tmdb.session_id', 'tmdb.session_account_id',
    'alkopastes.api_key_user', 'alkopastes.api_mode',
))


def _connect(profile_directory):
    directory = Path(profile_directory)
    directory.mkdir(parents=True, exist_ok=True)
    path = directory / 'account_settings.db'
    os.close(os.open(path, os.O_CREAT | os.O_WRONLY, 0o600))
    return sqlite3.connect(path, timeout=10)


def _ensure_table(connection):
    connection.execute('CREATE TABLE IF NOT EXISTS account_settings (id TEXT PRIMARY KEY, value TEXT NOT NULL)')
    connection.execute('CREATE TABLE IF NOT EXISTS account_explicit_clears (id TEXT PRIMARY KEY)')


# Les noms et identifiants permettent de reconnaître un compte lors d'une mise
# à niveau. Seuls les jetons autorisent ensuite les actions du menu Gestion.
_TRACKING_ACCOUNTS = (
    ('trakt_user', ('trakt.token',), ('trakt.refresh', 'trakt.expires')),
    ('mdblist_user', ('mdblist.access_token', 'mdblist.token'),
     ('mdblist.auth_type', 'mdblist.refresh_token', 'mdblist.expires')),
    ('tmdb.account_id', ('tmdb.token',),
     ('tmdb.session_id', 'tmdb.session_account_id', 'tmdb.username')),
)
TRACKING_KEYS = frozenset(key for identity, tokens, extra in _TRACKING_ACCOUNTS
                           for key in (identity,) + tokens + extra)


def _tracking_updates(saved, legacy, native_get, explicit_clears):
    updates = {}
    for identity, tokens, extra in _TRACKING_ACCOUNTS:
        keys = (identity,) + tokens + extra
        stored_id = saved.get(identity)
        stored_token = any(saved.get(key) for key in tokens)
        if not stored_id and not stored_token and all(key in saved for key in (identity,) + tokens):
            # Une déconnexion enregistrée prime sur une ancienne copie du profil.
            continue
        source = {key: legacy[key] for key in keys if legacy.get(key)}
        if native_get and not (stored_id and stored_token) and not (
                source.get(identity) and any(source.get(key) for key in tokens)):
            try:
                native = {key: native_get(key) for key in keys}
            except (RuntimeError, ValueError):
                native = {}
            # Ne jamais composer un compte avec les jetons d'un autre profil.
            if not any(source.get(key) and native.get(key) and source[key] != native[key]
                       for key in (identity,) + tokens):
                source = {**{key: value for key, value in native.items() if value}, **source}
        matching_token = any(saved.get(key) and saved[key] == source.get(key) for key in tokens)
        if stored_id and source.get(identity) != stored_id and not matching_token:
            continue
        if stored_id and source.get(identity) and stored_id != source[identity]:
            continue
        if stored_token and not matching_token:
            continue
        for key, value in source.items():
            if key in explicit_clears:
                continue
            if key not in saved:
                updates[key] = value
            elif not saved[key]:
                # En 2.3.66 un champ importé vide pouvait masquer un jeton
                # encore valide. Exiger une preuve qu'il s'agit du même compte.
                if key in tokens and not stored_token and stored_id and stored_id == source.get(identity):
                    updates[key] = value
                elif key == identity and matching_token:
                    updates[key] = value
                elif key in ('tmdb.session_id', 'tmdb.session_account_id', 'tmdb.username') and matching_token:
                    updates[key] = value
    return updates


def read(profile_directory, legacy_settings=None, native_get=None):
    """Importe les autorisations récupérables sans réactiver un compte déconnecté."""
    with closing(_connect(profile_directory)) as connection, connection:
        _ensure_table(connection)
        saved = dict(connection.execute('SELECT id, value FROM account_settings'))
        if legacy_settings is None:
            return saved

        def pending(current):
            missing = (ACCOUNT_SETTINGS - TRACKING_KEYS) & (legacy_settings.keys() - current.keys())
            updates = {key: legacy_settings[key] for key in missing}
            clears = {row[0] for row in connection.execute('SELECT id FROM account_explicit_clears')}
            updates.update(_tracking_updates(current, legacy_settings, native_get, clears))
            return updates

        if pending(saved):
            # Un autre invocateur peut avoir connecté ou déconnecté le compte.
            connection.execute('BEGIN IMMEDIATE')
            saved = dict(connection.execute('SELECT id, value FROM account_settings'))
            updates = pending(saved)
            connection.executemany(
                'INSERT OR REPLACE INTO account_settings (id, value) VALUES (?, ?)', updates.items())
            saved.update(updates)
        return saved


def write(profile_directory, key, value):
    # Une valeur vide est enregistrée aussi : elle représente une déconnexion explicite.
    with closing(_connect(profile_directory)) as connection, connection:
        _ensure_table(connection)
        connection.execute('PRAGMA secure_delete = ON')
        connection.execute(
            'INSERT INTO account_settings (id, value) VALUES (?, ?) '
            'ON CONFLICT(id) DO UPDATE SET value = excluded.value WHERE value != excluded.value',
            (key, value),
        )
        if key in TRACKING_KEYS:
            if value:
                connection.execute('DELETE FROM account_explicit_clears WHERE id = ?', (key,))
            else:
                connection.execute('INSERT OR IGNORE INTO account_explicit_clears (id) VALUES (?)', (key,))
