# -*- coding: utf-8 -*-
"""Notation ponctuelle lors d'un relais Up Next (sans bloquer les caches 24 h).

Une note s'affiche avant l'ouverture du média suivant, uniquement après
franchissement du seuil de lecture. Les états ne contiennent aucune URL.
"""
import json
from time import time
from modules import kodi_utils, settings

_PENDING = 'alkoflix.rating.handoff_pending'
_CONSUMED = 'alkoflix.rating.handoff_consumed'
_TTL = 20 * 60  # Toujours lié à la séance en cours, jamais un vieux film.


def _key(media_type, tmdb_id, season='', episode=''):
    typ = 'movie' if media_type in ('movie', 'movies') else media_type
    if typ not in ('movie', 'episode') or not tmdb_id: return ''
    if typ == 'episode':
        if season in (None, '') or episode in (None, ''): return ''
        return 'episode:%s:%s:%s' % (tmdb_id, season, episode)
    return 'movie:%s' % tmdb_id


def _meta_key(meta):
    if not isinstance(meta, dict): return ''
    return _key(meta.get('media_type'), meta.get('tmdb_id'), meta.get('season'), meta.get('episode'))


def begin():
    """Chaque nouvelle vidéo rend caduc tout candidat précédent non consommé."""
    kodi_utils.clear_property(_PENDING)


def arm(meta):
    """Appelé une seule fois, quand le lecteur a réellement atteint le seuil vu."""
    try:
        if not isinstance(meta, dict): return False
        media_type = meta.get('media_type')
        if not settings.rating_after_playback_enabled(media_type): return False
        k = _meta_key(meta)
        if not k: return False
        params = {name: meta.get(name) for name in (
            'media_type', 'tmdb_id', 'imdb_id', 'tvdb_id', 'season', 'episode', 'title')}
        params['media_type'] = 'movie' if media_type == 'movies' else media_type
        kodi_utils.set_property(_PENDING, json.dumps({'key': k, 'at': time(), 'params': params}))
        return True
    except Exception:
        return False


def already_offered(meta):
    """Empêche un second popup après le relais, même si Kodi appelle Stop tard."""
    try:
        state = json.loads(kodi_utils.get_property(_CONSUMED) or '{}')
        return state.get('key') == _meta_key(meta) and 0 <= time() - float(state.get('at') or 0) <= _TTL
    except Exception:
        return False


def offer_for_handoff(expected_key):
    """Propose une note AVANT de rechercher les sources du film/épisode suivant.

    L'identité de l'ancien média doit correspondre strictement au relais Up Next.
    Une annulation de notation ne peut jamais empêcher la lecture suivante.
    """
    try:
        if not expected_key: return False
        state = json.loads(kodi_utils.get_property(_PENDING) or '{}')
        if not isinstance(state, dict) or state.get('key') != expected_key: return False
        age = time() - float(state.get('at') or 0)
        if not 0 <= age <= _TTL: return False
        params = state.get('params') or {}
        if not isinstance(params, dict) or _meta_key(params) != expected_key: return False
        if not settings.rating_after_playback_enabled(params.get('media_type')): return False
        # Écriture du reçu AVANT le dialogue pour éviter un double affichage si
        # onPlayBackStopped arrive pendant que la fenêtre est ouverte.
        kodi_utils.set_property(_CONSUMED, json.dumps({'key': expected_key, 'at': time()}))
        kodi_utils.clear_property(_PENDING)
        try:
            from modules import user_ratings
            if not user_ratings.rating_provider_ready(): return False
            from modules.dialogs import rating_choice
            kodi_utils.logger('Notation', 'Relais Up Next | média=%s | tmdb=%s' % (
                params.get('media_type'), params.get('tmdb_id')), level='info')
            rating_choice(params, after_playback=True)
            return True
        except Exception as exc:
            kodi_utils.logger('Notation', 'Relais ignoré | %s' % type(exc).__name__, level='warning')
            return False
    except Exception:
        return False


def offer_episode_handoff(handoff):
    """Réutilise l'identifiant d'épisode de l'actuel fournisseur Up Next."""
    if not handoff: return False
    return offer_for_handoff('episode:%s' % handoff)


def offer_saga_handoff(current_tmdb_id):
    if not current_tmdb_id: return False
    return offer_for_handoff('movie:%s' % current_tmdb_id)
