"""Sélection aléatoire des recommandations de « Vos suivis de lecture »."""

import random
from itertools import islice

from caches import watched_cache as wc
from modules import kodi_utils as ku, settings

LIMIT = 20


def _recent_seeds(kind, history, allowed, group):
    # La dernière activité d'une série peut être la relecture d'un ancien épisode.
    latest = {}
    for row in history or ():
        tmdb_id = str(row[0] or '')
        if not tmdb_id or (allowed is not None and tmdb_id not in allowed):
            continue
        played = str(row[-1] or '')
        if tmdb_id not in latest or played > latest[tmdb_id]:
            latest[tmdb_id] = played
    ids = sorted(latest, key=latest.get, reverse=True)
    if group in ('', 'all', 'global', 'combined'):
        return ids[:2]
    matches = []
    for start in range(0, len(ids), 8):
        matches.extend(wc._progress_filter_rows_by_meta(kind, ids[start:start + 8], group))
        if len(matches) >= 2:
            break
    return matches[:2]


def _candidate_ids(kind, section, seed):
    if section.startswith('qc_') and '|' not in section:
        from magneto.alkopaste import alkopaste_qc_recommendation_ids
        ids = alkopaste_qc_recommendation_ids('film' if kind == 'movie' else 'serie', section, seed)
        random.shuffle(ids)
        yield from ids
        return

    from indexers.tmdb_api import tmdb_movies_recommendations, tmdb_tv_recommendations
    getter = tmdb_movies_recommendations if kind == 'movie' else tmdb_tv_recommendations
    first = getter(seed, 1) or {}
    pages = list(range(1, min(500, int(first.get('total_pages') or 1)) + 1))
    random.shuffle(pages)
    for page in pages:
        data = first if page == 1 else getter(seed, page) or {}
        ids = [str(row['id']) for row in data.get('results') or () if isinstance(row, dict) and row.get('id')]
        random.shuffle(ids)
        yield from ids


def _eligible_items(worker, kind, section, seeds, allowed, batch_size):
    # Tirer un titre de départ. Le second peut compléter un résultat trop court.
    seeds = list(seeds)
    random.shuffle(seeds)
    seen = set(seeds)
    for seed in seeds:
        try:
            candidates = _candidate_ids(kind, section, seed)
            eligible = (i for i in candidates if i not in seen and (allowed is None or i in allowed))
            while True:
                # Inscrire chaque ID immédiatement, y compris les doublons d'une même page.
                batch = []
                for media_id in islice(eligible, batch_size):
                    seen.add(media_id)
                    batch.append(media_id)
                if not batch:
                    break
                worker.list = batch
                worker.items.clear()
                yield from worker.worker()
        except Exception as exc:
            ku.logger('recommandations de suivi', '%s | %s' % (kind, type(exc).__name__))


def render(params):
    from menus.movies import Movies
    from menus.tvshows import TVShows
    handle = params['handle']
    menu_type = params.get('menu_type', 'combined')
    kinds = ('movie', 'tvshow') if menu_type == 'combined' else (menu_type,)
    group = params.get('recommendation_group', 'all')
    name = params.get('name') or ku.local_string(33280)
    try:
        provider = int(params.get('watched_indicators', settings.watched_indicators()))
    except (TypeError, ValueError):
        provider = 0
    if provider not in (0, 1, 2):
        provider = 0

    streams = []
    for kind in kinds:
        if menu_type == 'combined':
            section_key = 'recommendation_movie_catalogue_section' if kind == 'movie' else 'recommendation_tv_catalogue_section'
        else:
            section_key = 'recommendation_catalogue_section'
        section = params.get(section_key, '')
        action = 'tmdb_movies_recommendations' if kind == 'movie' else 'tmdb_tv_recommendations'
        worker_params = dict(params, action=action, because_you_watched='true', discover_hide_watched='true',
                             watched_indicators=str(provider), catalogue_section=section if '|' not in section else '',
                             recommendation_catalogue_section=section)
        if section.startswith('qc_') and '|' not in section:
            worker_params.update(action='alkopaste_qc_recommendations', fav_type='movie_qc' if kind == 'movie' else 'tv_qc')
        worker = Movies(worker_params) if kind == 'movie' else TVShows(worker_params)
        if kind == 'movie' and worker.watched_indicators != provider:
            worker.watched_indicators = provider
            worker.watched_title = ('alkoFlix', 'Trakt', 'MDBList')[provider]
            worker.watched_info = wc.get_watched_info_movie(provider)
            worker.bookmarks = wc.get_bookmarks(provider, 'movie')
        allowed = wc._progress_catalogue_ids(kind, section)
        worker._recommendation_section_ids = allowed
        seeds = _recent_seeds(kind, worker.watched_info, allowed, group)
        if seeds:
            streams.append(_eligible_items(worker, kind, section, seeds, allowed, LIMIT // len(kinds)))

    items = []
    if not streams:
        ku.notification(ku.local_string(33281))
    # Partager les places entre les deux types, puis compléter avec le type restant.
    while streams and len(items) < LIMIT:
        for stream in list(streams):
            item = next(stream, None)
            if item is None:
                streams.remove(stream)
            else:
                items.append(item)
                if len(items) == LIMIT:
                    break
    random.shuffle(items)
    if items:
        ku.add_items(handle, items)
    content = 'movies' if menu_type == 'movie' else 'tvshows'
    ku.set_category(handle, name)
    ku.set_sort_method(handle, 'unsorted')
    ku.set_content(handle, content)
    ku.end_directory(handle, False)
    ku.set_view_mode('view.' + content, content)
