# -*- coding: utf-8 -*-
"""Affichage en liste des calendriers personnels Trakt et MDbList."""

from datetime import datetime, time, timedelta, timezone

from modules import kodi_utils, settings
from menus.following_calendar import _provider_air_date


def _boundary(today, setting, direction):
    try:
        days = max(0, int(kodi_utils.get_setting(setting, '7')))
        return today + timedelta(days=direction * days)
    except (ValueError, TypeError, OverflowError):
        return today + timedelta(days=direction * 7)


def _account_episodes(mode, first, last):
    # Les dates choisies sont locales. Une diffusion de fin de soirée peut
    # déjà appartenir au lendemain dans l'intervalle UTC demandé au service.
    start_utc = datetime.combine(first, time.min).astimezone(timezone.utc).date()
    end_utc = datetime.combine(last, time.max).astimezone(timezone.utc).date()
    if mode == 'build_mdbl_calendar':
        from indexers.mdblist_api import mdbl_calendar_episodes
        # MDbList renvoie aussi des dates sans heure : inclure les bornes locales.
        return mdbl_calendar_episodes(min(first, start_utc).isoformat(),
                                      max(last, end_utc).isoformat()) or []

    from indexers.trakt_api import trakt_calendar_episodes
    episodes = []
    while start_utc <= end_utc:
        days = min(33, (end_utc - start_utc).days + 1)
        episodes.extend(trakt_calendar_episodes(start_utc.isoformat(), str(days)) or [])
        start_utc += timedelta(days=days)
    return episodes


def _focus_today(items, today, mode):
    # Le dossier parent « .. » est optionnel selon la configuration Kodi.
    if not any(item.getProperty('alkoflix_first_aired') == today for _, item, _ in items):
        return
    for _ in range(10):
        kodi_utils.sleep(100)
        path = kodi_utils.get_infolabel('Container.FolderPath')
        if 'account_calendar=true' not in path or 'mode=' + mode not in path:
            continue
        count = kodi_utils.get_infolabel('Container.NumAllItems')
        if not count.isdigit() or int(count) == 0:
            continue
        for index in reversed(range(int(count))):
            shown = kodi_utils.get_infolabel('Container.ListItemAbsolute(%d).Property(alkoflix_first_aired)' % index)
            if shown == today:
                kodi_utils.focus_index(index, sleep_time=0)
                return
        return


def render_flat_calendar(menu, handle, category):
    today = menu.current_date
    first = _boundary(today, 'trakt.calendar_previous_days', -1)
    last = _boundary(today, 'trakt.calendar_future_days', 1)
    mode = menu.params['mode']
    try:
        episodes = _account_episodes(mode, first, last)
    except Exception as exc:
        kodi_utils.logger('calendrier de compte', '%s | %s' % (mode, type(exc).__name__))
        episodes = []

    first_iso, last_iso = first.isoformat(), last.isoformat()
    menu.list_type = 'flat_account_calendar'
    menu.date_format = settings.single_ep_format()
    menu.list = []
    for episode in episodes:
        air_date = _provider_air_date(episode.get('first_aired'))
        if not air_date or first_iso <= air_date <= last_iso:
            menu.list.append(dict(episode, account_air_date=air_date))
    menu.list.sort(key=lambda row: row.get('sort_title', ''))
    items = menu.worker() if menu.list else []
    # Quand le fournisseur omet la date, le moteur d'épisodes la complète via TMDb.
    items = [row for row in items if first_iso <= row[1].getProperty('alkoflix_first_aired') <= last_iso]
    descending = kodi_utils.get_setting('trakt.calendar_sort_order', '0') != '1'
    items.sort(key=lambda row: row[1].getProperty('alkoflix_first_aired'), reverse=descending)

    kodi_utils.add_items(handle, items)
    kodi_utils.set_category(handle, category)
    kodi_utils.set_sort_method(handle, 'unsorted')
    kodi_utils.set_menu_content(handle, default_content='episodes')
    kodi_utils.end_directory(handle, False)
    if kodi_utils.current_skin_id() != 'skin.arctic.fuse.3':
        kodi_utils.set_view_mode('view.episodes_lists', 'episodes')
    if kodi_utils.get_setting('trakt.calendar_focus_today', 'true') == 'true':
        _focus_today(items, today.isoformat(), mode)
