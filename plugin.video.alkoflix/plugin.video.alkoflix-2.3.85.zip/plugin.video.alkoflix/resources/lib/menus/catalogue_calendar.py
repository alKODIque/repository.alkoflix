"""Calendrier public TMDb, restreint au dossier catalogue affiché."""

from concurrent.futures import ThreadPoolExecutor
from urllib.parse import urlencode

from menus.following_calendar import _cached_tmdb_payload, REQUEST_WORKERS


TMDB_FILTERS = {
    'tv_root': {'without_genres': '16,99,10763,10764,10767'},
    'series_family': {'with_genres': '10751|10762'},
    'series_animation': {'with_genres': '16,10762|16,10751'},
    'anime_series': {'with_keywords': '210024'},
    'documentary_series_root': {'with_genres': '99|10763|10764|10767'},
    'series_documentary': {'with_genres': '99'},
    'series_reality': {'with_genres': '10764'},
    'series_talkshow': {'with_genres': '10767'},
    'series_news': {'with_genres': '10763'},
}


def _discover_day(day, filters, page):
    from indexers import tmdb_api
    query = dict(filters, sort_by='popularity.desc', include_adult='false', page=page)
    query.update({'air_date.gte': day, 'air_date.lte': day})
    key = 'catalogue_calendar_%s' % urlencode(sorted(query.items()))
    query['api_key'] = tmdb_api.tmdb_api_key()
    url = '%s/discover/tv?%s' % (tmdb_api.base_url, urlencode(query))
    payload = tmdb_api._tmdb_cached_secondary(key, url, expiration=4, label='catalogue calendar')
    return payload if isinstance(payload, dict) else {}


def _scope(params):
    from caches.watched_cache import _progress_catalogue_ids
    from modules import parental_control
    section = params.get('catalogue_section') or ''
    group = params.get('calendar_group') or ''
    actions = {'series_family': 'tmdb_tv_family_airing_this_week',
               'series_animation': 'tmdb_tv_family_animation_airing_this_week',
               'anime_series': 'tmdb_tvanime_airing_this_week'}
    action = 'alkopaste_catalogue' if section else actions.get(group, 'tmdb_tv_airing_this_week')
    parental_action = action if parental_control.applies_to_action(action, 'tvshow') else ''
    # Conserver aussi la branche d'origine pour les favoris et les actions Kodi.
    allowed = None
    if section:
        allowed = {}
        for child in section.split('|'):
            for media_id in _progress_catalogue_ids('tvshow', child) or ():
                allowed.setdefault(media_id, child)
    return group, allowed, parental_action


def _parental_allowed(tmdb_id, action):
    from indexers.metadata import tvshow_meta
    from modules import parental_control, settings
    from modules.utils import get_datetime
    try:
        meta = tvshow_meta('tmdb_id', tmdb_id, settings.metadata_user_info(), get_datetime())
        return meta and not meta.get('blank_entry') and parental_control.meta_allowed(meta, action, 'tvshow')
    except Exception:
        return False


def _candidates(day, group, allowed, parental_action):
    if allowed is not None and not allowed:
        return
    filters = TMDB_FILTERS.get(group, {}) if allowed is None else {}
    page = 1
    while page <= 500:
        payload = _discover_day(day, filters, page)
        for row in payload.get('results') or ():
            tmdb_id = str(row.get('id') or '')
            if not tmdb_id or (allowed is not None and tmdb_id not in allowed):
                continue
            if group == 'series_animation' and (row.get('original_language') == 'ja' or 'JP' in (row.get('origin_country') or ())):
                continue
            if not parental_action or _parental_allowed(tmdb_id, parental_action):
                yield row
        if page >= int(payload.get('total_pages') or 1):
            return
        page += 1


def _episodes_on_day(day, row):
    tmdb_id = row['id']
    details = _cached_tmdb_payload('show', tmdb_id)
    anchors = [details.get(key) or {} for key in ('last_episode_to_air', 'next_episode_to_air')]
    # Les deux épisodes repères et la saison en cours au jour demandé
    # couvrent aussi les saisons qui commencent ou se terminent cette semaine.
    seasons = {anchor.get('season_number') for anchor in anchors}
    started = [season for season in details.get('seasons', ())
               if season.get('air_date') and season['air_date'] <= day and season.get('season_number')]
    if started:
        seasons.add(max(started, key=lambda season: season['air_date'])['season_number'])
    for season in sorted(n for n in seasons if isinstance(n, int) and n > 0):
        season_data = _cached_tmdb_payload('season', tmdb_id, season)
        numbers = {ep.get('episode_number') for ep in season_data.get('episodes', ()) if ep.get('air_date') == day}
        numbers.update(ep.get('episode_number') for ep in anchors if ep.get('season_number') == season and ep.get('air_date') == day)
        for number in sorted(n for n in numbers if isinstance(n, int) and n > 0):
            yield {
                'media_ids': {'tmdb': tmdb_id}, 'season': season, 'episode': number, 'first_aired': day,
                'sort_title': '%s %04d %04d' % (row.get('name') or details.get('name') or '', season, number),
            }


def available_days(params, days):
    scope = _scope(params)

    def has_broadcast(day):
        return day if any(next(_episodes_on_day(day, row), None) for row in _candidates(day, *scope)) else None

    with ThreadPoolExecutor(max_workers=REQUEST_WORKERS) as pool:
        return {day for day in pool.map(has_broadcast, days) if day}


def catalogue_episodes(params, day):
    group, allowed, parental_action = _scope(params)
    candidates = {str(row['id']): row for row in _candidates(day, group, allowed, parental_action)}
    def episodes_for_show(row):
        section = allowed.get(str(row['id']), '') if allowed is not None else ''
        return [dict(episode, catalogue_section=section) for episode in _episodes_on_day(day, row)]
    with ThreadPoolExecutor(max_workers=REQUEST_WORKERS) as pool:
        return [episode for batch in pool.map(episodes_for_show, candidates.values()) for episode in batch]


def catalogue_day_items(params, day, series):
    from catalogue.catalogs import _alkopaste_fav_type
    from menus.episodes import Episodes
    from menus.following_calendar import _calendar_series_items

    episodes = sorted(catalogue_episodes(params, day), key=lambda row: row['sort_title'])
    by_section = {}
    for position, row in enumerate(episodes):
        row.update(sort=position, account_air_date=day)
        by_section.setdefault(row['catalogue_section'], []).append(row)

    items = []
    for section, rows in by_section.items():
        context = dict(params, catalogue_section=section, fav_type=_alkopaste_fav_type(section, 'serie'))
        if series:
            ids = list(dict.fromkeys(str(row['media_ids']['tmdb']) for row in rows))
            items.extend(_calendar_series_items(context, ids))
        else:
            worker = Episodes(dict(context, list=rows))
            worker.list_type = 'trakt_calendar'
            items.extend(worker.worker())
    if series:
        return sorted(items, key=lambda entry: (entry[1].getLabel() or '').casefold())
    return sorted(items, key=lambda entry: int(entry[1].getProperty('alkoflix_sort_order')))
