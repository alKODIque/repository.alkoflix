"""Langues des fiches, des visuels et du parcours Contenu QC."""
import sys
from functools import lru_cache
from urllib.parse import parse_qsl

LANGUAGES = (('Français (FR)', 'fr-FR'), ('Français (CA)', 'fr-CA'), ('Anglais (US)', 'en-US'))


def locale(value):
    code = str(value or '').strip().lower().replace('_', '-')
    if code == 'fr-ca':
        return 'fr-CA'
    if code.split('-')[0] == 'en':
        return 'en-US'
    return 'fr-FR'


def qc_params(params):
    if str(params.get('alkoflix_qc', '')).strip().lower() in ('1', 'true'):
        return True
    if params.get('mode') == 'navigator.favourites_qc':
        return True
    # Les favoris et les widgets Québec historiques n'ont pas forcément de
    # catalogue_section. Ne pas les laisser revenir aux langues globales.
    if str(params.get('fav_group') or '').lower() == 'qc':
        return True
    for key in ('fav_type', 'action'):
        value = str(params.get(key) or '').lower()
        if value in ('movie_qc', 'tv_qc', 'season_qc', 'episode_qc'):
            return True
        if key == 'action' and value.startswith('favourites_') and value.endswith('_qc'):
            return True
    # Les raccourcis de calendrier, de recommandations et de suivi peuvent
    # porter une ou plusieurs sections. Un mélange Québec / général n'est
    # PAS considéré comme un menu exclusivement Québec.
    for key, value in params.items():
        if key not in ('catalogue_folder', 'catalogue_section') and not key.endswith('_catalogue_section'):
            continue
        parts = [p.strip().lower() for p in str(value or '').split('|') if p.strip()]
        if parts and all(p == 'qc' or p.startswith('qc_') for p in parts):
            return True
    return False


@lru_cache(maxsize=32)
def _qc_query(query):
    return qc_params(dict(parse_qsl(query.lstrip('?'))))


def qc_request():
    return len(sys.argv) > 2 and isinstance(sys.argv[2], str) and _qc_query(sys.argv[2])


def translation_order(language):
    return {'fr-CA': ('fr-CA', 'fr-FR', 'en-US', 'en'),
            'fr-FR': ('fr-FR', 'fr', 'en-US', 'en'),
            'en-US': ('en-US', 'en')}[locale(language)]


def _tagline_text(value):
    return value.strip() if isinstance(value, str) else ''


def _localized_tagline(data, rows, language, fetch):
    primary = locale(language)
    by_locale = {}
    for row in rows:
        lang = str(row.get('iso_639_1') or '').lower()
        if not lang:
            continue
        country = str(row.get('iso_3166_1') or '').upper()
        tag = lang + '-' + country if country else lang
        fields = row.get('data')
        # None indique un champ omis. Une chaîne vide confirme l'absence de texte.
        by_locale.setdefault(tag, None)
        if isinstance(fields, dict) and 'tagline' in fields and not by_locale[tag]:
            by_locale[tag] = _tagline_text(fields['tagline'])

    order = []
    for tier in translation_order(language):
        if '-' in tier:
            if tier in by_locale or not by_locale:
                order.append(tier)
        else:
            order.extend(tag for tag in by_locale if tag.split('-')[0] == tier and tag not in order)

    observed = {}
    def detail_text(tag):
        if tag not in observed:
            value = data.get('tagline') if tag == primary else (fetch(tag) if fetch else None)
            observed[tag] = _tagline_text(value)
        return observed[tag]

    known = {text for text in by_locale.values() if text}
    for index, tag in enumerate(order):
        text = by_locale.get(tag)
        if text is None:
            text = detail_text(tag)
            if not text or text in known:
                continue
            # Une réponse non étiquetée peut reprendre une langue de repli.
            # Vérifier les rangs plus éloignés évite de sauter un rang intermédiaire.
            if any(detail_text(lower) == text for lower in order[index + 2:] if by_locale.get(lower) is None):
                continue
        if text:
            return text
    return ''


def translated_details(data, language, fields, fetch_tagline=None, title_fallbacks=None):
    """Résout chaque champ avec les traductions déjà jointes à la fiche."""
    if not isinstance(data, dict):
        return data
    translations = data.get('translations')
    rows = translations.get('translations') if isinstance(translations, dict) else None
    rows = [row for row in rows if isinstance(row, dict)] if isinstance(rows, list) else []
    choices = []
    primary = locale(language)
    for tag in translation_order(language):
        for row in rows:
            lang = str(row.get('iso_639_1') or '').lower()
            region = str(row.get('iso_3166_1') or '').upper()
            if tag in (lang, lang + '-' + region) and isinstance(row.get('data'), dict):
                choices.append(row['data'])
        if title_fallbacks and tag in title_fallbacks:
            choices.append(title_fallbacks[tag])
        if tag == primary and primary != 'fr-CA':
            # Le titre officiel pour la France peut être identique au titre original.
            choices.append(data)
    result = dict(data)
    for field in fields:
        if field == 'tagline':
            result[field] = _localized_tagline(data, rows, language, fetch_tagline)
            continue
        # TMDb peut placer le titre anglais dans la traduction fr-CA d'une
        # oeuvre originale québécoise francophone. Lorsque l'original français
        # est connu, ne pas laisser un alias anglais le remplacer.
        original_fr = ((title_fallbacks or {}).get('fr-CA') or {}).get(field, '') if primary == 'fr-CA' and field in ('title', 'name') else ''
        english = {
            str(row['data'].get(field) or '').strip().casefold()
            for row in rows if str(row.get('iso_639_1') or '').lower() == 'en'
            and isinstance(row.get('data'), dict) and row['data'].get(field)
        } if original_fr else set()
        for item in choices:
            value = item.get(field)
            if not isinstance(value, str) or not value.strip():
                continue
            if original_fr and value.strip().casefold() in english and value.strip().casefold() != original_fr.strip().casefold():
                continue
            result[field] = value
            break
    return result


def art_tag(item):
    raw = str(item.get('iso_639_1') or item.get('lang') or '').strip().lower().replace('_', '-')
    if raw in ('', '00', 'xx', 'null'):
        return ''
    lang, _, country = raw.partition('-')
    country = str(item.get('iso_3166_1') or country).strip().upper()
    if lang == 'en' and country == 'US':
        return 'en-US'
    if lang == 'fr' and country not in ('', '00', 'XX', 'NULL'):
        return lang + '-' + country
    return lang


def art_order(language, original='', prefer_neutral=False, allow_neutral=True, qc_poster=False, qc_logo=False, qc_landscape=False):
    preferred = locale(language)
    original = str(original or '').strip().lower().replace('_', '-').split('-')[0]
    if preferred == 'fr-CA' and (qc_logo or qc_landscape):
        # Clearlogos et vignettes Landscape QC : français avant anglais,
        # même avec le tag fr-FR. Les fonds neutres et les affiches QC
        # restent régis par leurs propres règles.
        langs = ('fr-CA', 'fr', 'fr-FR', 'en-US', 'en', original)
    elif preferred == 'fr-CA' and qc_poster:
        langs = ('fr-CA', 'fr', 'en-US', 'en', 'fr-FR', original)
    elif preferred == 'fr-CA':
        langs = ('fr-CA', 'en-US', 'en', 'fr-FR', 'fr', original)
    elif preferred == 'fr-FR':
        langs = ('fr-FR', 'en-US', 'en', original, 'fr')
    else:
        langs = ('en-US', 'en', 'fr-FR', 'fr', original)
    # La VO peut être française ou anglaise et occuper un rang déjà prévu.
    order = tuple(dict.fromkeys(lang for lang in langs if lang not in ('', 'xx', 'null', '00', 'und')))
    if not allow_neutral:
        return order
    if prefer_neutral and preferred == 'en-US':
        return ('',) + order
    return order + ('',)


def preferred_art(meta, keys, neutral_first=False, poster=False, logo=False, landscape=False):
    """La préférence de fournisseur départage les images de même priorité linguistique."""
    qc_priority = meta.get('qc_poster_priority', qc_request())
    order = art_order(meta.get('image_language'), meta.get('original_language'), neutral_first,
                      qc_poster=(poster and qc_priority), qc_logo=(logo and qc_priority),
                      qc_landscape=(landscape and qc_priority))
    tags = {**meta.get('tmdb_art_languages', {}), **meta.get('fanarttv_languages', {})}
    best, rank = '', len(order) + 2
    for key in keys:
        url = meta.get(key)
        if not url:
            continue
        tag = tags.get(url)
        if tag is not None and tag not in order:
            continue
        score = order.index(tag) if tag is not None else len(order) + 1
        if score < rank:
            best, rank = url, score
    return best
