# -*- coding: utf-8 -*-
"""Images choisies par l'utilisateur (films, séries, saisons, sagas).

Stockage portable indépendant des caches TMDb/Fanart.tv.  Le premier accès charge
la petite table SQLite en mémoire une seule fois par invocation Kodi. Les listes
et widgets ne font aucune requête réseau ni ouverture SQL par élément.
"""
import os
import sqlite3
from threading import Lock
from urllib.parse import urlsplit

DB_NAME = 'customart.db'
DB_PATH = 'special://profile/addon_data/plugin.video.alkoflix/' + DB_NAME
MEDIA_TYPES = ('movie', 'tvshow', 'season', 'collection')
ART_TYPES = ('poster', 'fanart', 'clearlogo', 'landscape')
_ROWS = None
_LOCK = Lock()


def _path():
    from modules import kodi_utils as ku
    return ku.translate_path(DB_PATH)


def _key(media_type, tmdb_id, season=-1):
    media_type = str(media_type or '').lower()
    if media_type in ('tv', 'series', 'show'): media_type = 'tvshow'
    if media_type in ('saga', 'set', 'sets'): media_type = 'collection'
    if media_type not in MEDIA_TYPES: return None
    try:
        tmdb_id = int(tmdb_id)
        season = int(season) if media_type == 'season' else -1
    except (TypeError, ValueError):
        return None
    if tmdb_id <= 0 or (media_type == 'season' and season < 0): return None
    return media_type, tmdb_id, season


def _valid_url(url):
    if not isinstance(url, str) or not (0 < len(url) <= 2048): return False
    try:
        parts = urlsplit(url)
        return parts.scheme in ('https', 'http') and bool(parts.netloc) and not parts.username and not parts.password
    except Exception:
        return False


def _load():
    global _ROWS
    if _ROWS is not None: return _ROWS
    with _LOCK:
        if _ROWS is not None: return _ROWS
        records = {}
        try:
            path = _path()
            if os.path.isfile(path):
                with sqlite3.connect(path, timeout=2) as con:
                    for kind, media_id, season, art_type, url in con.execute(
                        'SELECT media_type, tmdb_id, season, art_type, url FROM artwork'):
                        key = _key(kind, media_id, season)
                        if key and art_type in ART_TYPES and _valid_url(url):
                            records.setdefault(key, {})[art_type] = url
        except (OSError, sqlite3.Error):
            # Une ancienne base manquante/invalide ne doit jamais bloquer un widget.
            records = {}
        _ROWS = records
    return _ROWS


def get(media_type, tmdb_id, season=-1):
    key = _key(media_type, tmdb_id, season)
    if not key: return {}
    return _load().get(key, {})


def set_image(media_type, tmdb_id, art_type, url, season=-1):
    global _ROWS
    key = _key(media_type, tmdb_id, season)
    if key is None or art_type not in ART_TYPES or not _valid_url(url): return False
    try:
        path = _path()
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with _LOCK:
            with sqlite3.connect(path, timeout=8) as con:
                con.execute('PRAGMA journal_mode=DELETE')
                con.execute('PRAGMA synchronous=FULL')
                con.execute('''CREATE TABLE IF NOT EXISTS artwork (
                    media_type TEXT NOT NULL, tmdb_id INTEGER NOT NULL,
                    season INTEGER NOT NULL DEFAULT -1, art_type TEXT NOT NULL,
                    url TEXT NOT NULL,
                    PRIMARY KEY (media_type, tmdb_id, season, art_type)
                )''')
                con.execute('INSERT OR REPLACE INTO artwork VALUES (?, ?, ?, ?, ?)', (*key, art_type, url))
                con.commit()
            if _ROWS is not None: _ROWS.setdefault(key, {})[art_type] = url
        return True
    except (OSError, sqlite3.Error): return False


def remove(media_type, tmdb_id, art_type=None, season=-1):
    global _ROWS
    key = _key(media_type, tmdb_id, season)
    if key is None or (art_type is not None and art_type not in ART_TYPES): return False
    try:
        path = _path()
        with _LOCK:
            if os.path.exists(path):
                with sqlite3.connect(path, timeout=8) as con:
                    if art_type is None:
                        con.execute('DELETE FROM artwork WHERE media_type=? AND tmdb_id=? AND season=?', key)
                    else:
                        con.execute('DELETE FROM artwork WHERE media_type=? AND tmdb_id=? AND season=? AND art_type=?', (*key, art_type))
                    con.commit()
            if _ROWS is not None:
                if art_type is None: _ROWS.pop(key, None)
                elif key in _ROWS:
                    _ROWS[key].pop(art_type, None)
                    if not _ROWS[key]: del _ROWS[key]
        return True
    except (OSError, sqlite3.Error): return False


def invalidate():
    global _ROWS
    with _LOCK: _ROWS = None


def apply_meta(meta, media_type, season=-1):
    """Fiche éphémère : ne jamais écrire les choix personnalisés en meta-cache."""
    if not isinstance(meta, dict): return meta
    overrides = get(media_type, meta.get('tmdb_id'), season)
    if not overrides: return meta
    result = dict(meta)
    result['custom_artwork'] = dict(overrides)
    for kind, url in overrides.items():
        if kind == 'poster':
            result.update(poster=url, poster_text=url, poster2=url, poster2_text=url)
        elif kind == 'fanart':
            # Ne personnaliser QUE le fond principal. La galerie neutre
            # (extra_fanart_primary / extra_fanarts) reste intacte et cachee,
            # afin que AF3 puisse encore faire tourner fanart1..fanart10.
            result['fanart'] = url
        elif kind == 'clearlogo':
            result.update(clearlogo=url, tmdblogo=url)
        elif kind == 'landscape':
            result.update(landscape=url, landscape_text=url, landscape_tmdb=url, landscape_tmdb_text=url)
    return result


def apply_art(art, media_type, tmdb_id, season=-1):
    """Ajuste seulement l'art Kodi final (utile aussi aux recherches rapides)."""
    overrides = get(media_type, tmdb_id, season)
    if not overrides: return art
    output = dict(art or {})
    if 'poster' in overrides:
        output.update(poster=overrides['poster'], icon=overrides['poster'])
        if not output.get('landscape'): output['thumb'] = overrides['poster']
        if media_type == 'season': output['season.poster'] = overrides['poster']
        if media_type == 'tvshow': output['tvshow.poster'] = overrides['poster']
    if 'fanart' in overrides:
        # Appliquer seulement le fond principal, sans toucher aux entrees
        # fanart1..10 / tvshow.fanart1..10 (rotation Arctic Fuse 3).
        output['fanart'] = overrides['fanart']
        if media_type in ('tvshow', 'season'): output['tvshow.fanart'] = overrides['fanart']
    if 'clearlogo' in overrides:
        output['clearlogo'] = overrides['clearlogo']
        if media_type in ('tvshow', 'season'):
            output['tvshow.clearlogo'] = overrides['clearlogo']
    if 'landscape' in overrides:
        output.update(landscape=overrides['landscape'], thumb=overrides['landscape'])
        if media_type in ('tvshow', 'season'): output['tvshow.landscape'] = overrides['landscape']
    return output


def protected_image_urls():
    """URLs des images sélectionnées : exemption du nettoyage des miniatures.

    La liste n'est chargée que lors de l'exécution du nettoyeur, jamais en
    contexte de rendu d'une vue ou d'un widget.
    """
    return {url for choices in _load().values() for url in choices.values()}


def clear_all_user_choices():
    """Efface les choix enregistrés UNIQUEMENT sur demande explicite de l'utilisateur.

    Aucun nettoyage de cache, tâche planifiée ou migration ne doit appeler ceci.
    Conserver le fichier SQLite pour éviter de toucher aux journaux / sauvegardes
    lors d'une éventuelle synchronisation d'un autre processus Kodi.
    Retourne le nombre d'images supprimées, ou None en cas d'échec.
    """
    global _ROWS
    try:
        with _LOCK:
            path = _path()
            if not os.path.isfile(path):
                _ROWS = {}
                return 0
            with sqlite3.connect(path, timeout=8) as con:
                cursor = con.execute('DELETE FROM artwork')
                removed = max(0, cursor.rowcount)
                con.commit()
            _ROWS = {}
            return removed
    except (OSError, sqlite3.Error):
        return None


def confirm_clear_all_user_choices():
    """Action réservée aux réglages > Maintenance > Images personnalisées."""
    from modules import kodi_utils
    if not kodi_utils.confirm_dialog(
            text='Supprimer définitivement toutes les images choisies manuellement '
                 '(affiches, fanarts, clearlogos et paysages) sur cet appareil ?[CR][CR]'
                 'Cette opération n’est PAS un vidage de cache classique : '
                 'les choix personnels seront perdus. Seule une sauvegarde '
                 'alkoFlix antérieure pourra les restaurer.',
            top_space=True):
        return False
    removed = clear_all_user_choices()
    if removed is None:
        kodi_utils.notification('Impossible de supprimer les images personnalisées.', 3000)
        return False
    kodi_utils.notification('%s image(s) personnalisée(s) supprimée(s).' % removed, 2800)
    try: kodi_utils.container_refresh()
    except Exception: pass
    return True
