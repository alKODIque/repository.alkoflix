# -*- coding: utf-8 -*-
# plugin.video.alkoflix
# resources/lib/indexers/fanarttv_api.py
# © Les alKODIques

import requests
from modules.regional_language import art_order, art_tag, qc_request
from urllib.parse import urlsplit, urlunsplit, quote
# from modules.kodi_utils import logger

# Clé API publique offerte par Les alKODIques.
API_KEY = '30006d06f4d124007f5de4f568bd7bca'
base_url = 'https://webservice.fanart.tv/v3.2/%s/%s'
default_fanart_meta = {'poster2': '', 'poster2_text': '', 'fanart2': '', 'banner': '', 'clearart': '', 'clearlogo': '', 'landscape': '', 'landscape_text': '', 'discart': '', 'season_posters': {}, 'season_posters_text': {}, 'season_landscapes': {}, 'season_landscapes_text': {}, 'fanart_added': True}
default_fanart_nometa = {'poster2': '', 'poster2_text': '', 'fanart2': '', 'banner': '', 'clearart': '', 'clearlogo': '', 'landscape': '', 'landscape_text': '', 'discart': '', 'season_posters': {}, 'season_posters_text': {}, 'season_landscapes': {}, 'season_landscapes_text': {}, 'fanart_added': False}
# Actualise uniquement les sélections Fanart.tv existantes en cache.
FANARTTV_SELECTION_VERSION = 2
timeout = 3.05
session = requests.Session()
session.mount('https://webservice.fanart.tv', requests.adapters.HTTPAdapter(pool_maxsize=100))

# Nettoie et encode une URL d’image pour éviter les erreurs Kodi.
def clean_art_url(url):
	if not url or 'http' not in url:
		return ''
	try:
		parts = urlsplit(url)
		path = quote(parts.path, safe='/%._-~')
		query = quote(parts.query, safe='=&%._-~')
		return urlunsplit((parts.scheme, parts.netloc, path, query, parts.fragment))
	except:
		return url

# Récupère les visuels Fanart.tv d’un média selon la langue demandée.
def get(media_type, language, media_id, client_key, original_language='', any_language=False):
	if not media_id:
		return dict(default_fanart_meta, fanarttv_any_language=bool(any_language), fanarttv_selection_version=FANARTTV_SELECTION_VERSION)

	query = base_url % (media_type, media_id)

	headers = {'api-key': API_KEY}
	if client_key:
		headers['client-key'] = client_key

	try:
		response = session.get(query, headers=headers, timeout=timeout)
		response.raise_for_status()
		art = response.json()
	except:
		return dict(default_fanart_meta, fanarttv_any_language=bool(any_language), fanarttv_selection_version=FANARTTV_SELECTION_VERSION)

	if not isinstance(art, dict):
		return dict(default_fanart_meta, fanarttv_any_language=bool(any_language), fanarttv_selection_version=FANARTTV_SELECTION_VERSION)

	if art.get('status') == 'error' or 'error message' in art or 'error_message' in art:
		return dict(default_fanart_meta, fanarttv_any_language=bool(any_language), fanarttv_selection_version=FANARTTV_SELECTION_VERSION)

	art_get = art.get
	if media_type == 'movies':
		fanart_data = {
			'poster2': parse_art(art_get('movieposter'), language, original_language=original_language, poster=True, any_language=any_language),
			'poster2_text': parse_art(art_get('movieposter'), language, original_language=original_language, allow_neutral=False, poster=True, any_language=any_language),
			'fanart2': parse_art(art_get('moviebackground'), language, prefer_neutral=True, original_language=original_language, any_language=any_language),
			'banner': parse_art(art_get('moviebanner'), language, original_language=original_language, any_language=any_language),
			'clearart': parse_art(art_get('movieart', []) + art_get('hdmovieclearart', []), language, original_language=original_language, any_language=any_language),
			'clearlogo': parse_art(art_get('movielogo', []) + art_get('hdmovielogo', []), language, original_language=original_language, qc_logo=True, any_language=any_language),
			'landscape': parse_art(art_get('moviethumb'), language, original_language=original_language, qc_landscape=True, any_language=any_language),
			'landscape_text': parse_art(art_get('moviethumb'), language, original_language=original_language, allow_neutral=False, qc_landscape=True, any_language=any_language),
			'discart': parse_art(art_get('moviedisc'), language, original_language=original_language, any_language=any_language),
			'fanart_added': True
		}
	else:
		fanart_data = {
			'poster2': parse_art(art_get('tvposter'), language, original_language=original_language, poster=True, any_language=any_language),
			'poster2_text': parse_art(art_get('tvposter'), language, original_language=original_language, allow_neutral=False, poster=True, any_language=any_language),
			'fanart2': parse_art(art_get('showbackground'), language, prefer_neutral=True, original_language=original_language, any_language=any_language),
			'banner': parse_art(art_get('tvbanner'), language, original_language=original_language, any_language=any_language),
			'clearart': parse_art(art_get('clearart', []) + art_get('hdclearart', []), language, original_language=original_language, any_language=any_language),
			'clearlogo': parse_art(art_get('hdtvlogo', []) + art_get('clearlogo', []), language, original_language=original_language, qc_logo=True, any_language=any_language),
			'landscape': parse_art(art_get('tvthumb'), language, original_language=original_language, qc_landscape=True, any_language=any_language),
			'landscape_text': parse_art(art_get('tvthumb'), language, original_language=original_language, allow_neutral=False, qc_landscape=True, any_language=any_language),
			'season_posters': parse_season_art(art_get('seasonposter', []) + art_get('tvseasonposter', []), language, original_language=original_language, poster=True, any_language=any_language),
			'season_posters_text': parse_season_art(art_get('seasonposter', []) + art_get('tvseasonposter', []), language, original_language=original_language, allow_neutral=False, poster=True, any_language=any_language),
			'season_landscapes': parse_season_art(art_get('seasonthumb', []) + art_get('tvseasonthumb', []), language, original_language=original_language, qc_landscape=True, any_language=any_language),
			'season_landscapes_text': parse_season_art(art_get('seasonthumb', []) + art_get('tvseasonthumb', []), language, original_language=original_language, allow_neutral=False, qc_landscape=True, any_language=any_language),
			'discart': '',
			'fanart_added': True
		}
	fanart_data['fanarttv_any_language'] = bool(any_language)
	fanart_data['fanarttv_selection_version'] = FANARTTV_SELECTION_VERSION
	selected = set()
	for value in fanart_data.values():
		if isinstance(value, str) and value: selected.add(value)
		elif isinstance(value, dict): selected.update(value.values())
	fanart_data['fanarttv_languages'] = {
		url: art_tag(item) for rows in art.values() if isinstance(rows, list)
		for item in rows if isinstance(item, dict) and (url := clean_art_url(item.get('url'))) in selected
	}
	return fanart_data

# Sélectionne l’image la plus pertinente selon la langue prioritaire demandée.
def parse_art(art, language, prefer_neutral=False, original_language='', season=None, allow_neutral=True, poster=False, qc_logo=False, qc_landscape=False, any_language=False):
	if art is None:
		return ''

	try:
		if any_language:
			# Fanart.tv reste le fournisseur prioritaire, mais pas au prix d'une
			# affiche/paysage en langue étrangère : langue choisie, puis anglais.
			# En l'absence de ces langues, ne rien renvoyer afin que TMDb prenne
			# le relais dans les sélecteurs d'art existants (films et saisons).
			# Les fonds d'arrière-plan neutres conservent leur sélection à part.
			from modules.regional_language import locale
			preferred = locale(language)
			if preferred == 'fr-CA':
				allowed_order = ('fr-CA', 'fr', 'fr-FR', 'en-US', 'en')
			elif preferred == 'fr-FR':
				allowed_order = ('fr-FR', 'fr', 'en-US', 'en')
			else:
				allowed_order = ('en-US', 'en')
			if season is not None:
				art = [x for x in art if isinstance(x, dict) and str(x.get('season', '')) == str(season)]
			items = [x for x in art if isinstance(x, dict) and x.get('url')]
			if prefer_neutral and allow_neutral:
				neutral = [x for x in items if not art_tag(x)]
				if neutral: items = neutral
				else: items = [x for x in items if art_tag(x) in allowed_order]
			else:
				# Les variantes sans texte ne remplacent pas une vraie affiche :
				# lorsque FR/EN manquent, le fallback TMDb reste prioritaire.
				items = [x for x in items if art_tag(x) in allowed_order]
			if not items: return ''
			def likes(item):
				try: return int(item.get('likes') or 0)
				except (TypeError, ValueError): return 0
			# La langue est toujours départagée AVANT les votes.
			if prefer_neutral and allow_neutral and not art_tag(items[0]):
				return clean_art_url(max(items, key=likes)['url'])
			for lang in allowed_order:
				candidates = [x for x in items if art_tag(x) == lang]
				if candidates: return clean_art_url(max(candidates, key=likes)['url'])
			return ''
		lang_order = art_order(language, original_language, prefer_neutral, allow_neutral,
		                       qc_poster=poster and qc_request(), qc_logo=qc_logo and qc_request(),
		                       qc_landscape=qc_landscape and qc_request())
		if prefer_neutral and not poster and allow_neutral:
			# Les fonds doivent preferer explicitement la langue neutre,
			# meme quand la langue des affiches est FR (Fanart.tv prioritaire).
			lang_order = ('',) + tuple(tag for tag in lang_order if tag != '')
		result = []

		if season is not None:
			season = str(season)
			art = [x for x in art if str(x.get('season', '')) == season]

		for lang in lang_order:
			result = [(x['url'], x.get('likes', 0)) for x in art if art_tag(x) == lang]
			if result:
				break

		if result:
			result.sort(key=lambda x: int(x[1]), reverse=True)
			result = result[0][0]
		else:
			result = ''
	except:
		result = ''

	if 'http' not in result:
		result = ''

	return clean_art_url(result)


# Sélectionne les visuels Fanart.tv propres à chaque saison.
def parse_season_art(art, language, original_language='', allow_neutral=True, poster=False, qc_landscape=False, any_language=False):
	if not art:
		return {}
	result = {}
	try:
		seasons = []
		for item in art:
			season = item.get('season')
			if season is None or season == '':
				continue
			season = str(season)
			if season not in seasons:
				seasons.append(season)
		for season in seasons:
			url = parse_art(art, language, original_language=original_language, season=season, allow_neutral=allow_neutral, poster=poster, qc_landscape=qc_landscape, any_language=any_language)
			if url:
				result[season] = url
	except:
		result = {}
	return result

# Ajoute les visuels Fanart.tv aux métadonnées du média.
def add(media_type, language, media_id, client_key, meta, original_language='', any_language=False):
	if not media_id:
		meta.update(dict(default_fanart_meta, fanarttv_any_language=bool(any_language), fanarttv_selection_version=FANARTTV_SELECTION_VERSION))
	else:
		try:
			meta.update(get(media_type, language, media_id, client_key, original_language, any_language=any_language))
		except:
			meta.update(dict(default_fanart_meta, fanarttv_any_language=bool(any_language), fanarttv_selection_version=FANARTTV_SELECTION_VERSION))
	return meta
