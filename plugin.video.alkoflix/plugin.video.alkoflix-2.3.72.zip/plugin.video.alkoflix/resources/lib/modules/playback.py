# -*- coding: utf-8 -*-
"""Invocation-local Kodi playback contract (Omega 21 / Piers 22).

Native playable plugin calls must answer their own handle exactly once.
Commands and retries re-enter a small native resolver with a fresh handle.
Only an opaque token travels in the plugin URL; stream URLs and metadata stay
in a short-lived window property. No handle or stream URL is persisted.
"""
from contextlib import contextmanager
import json
from threading import local
from time import time
from urllib.parse import parse_qsl, urlencode, urlsplit
from uuid import uuid4

from modules import kodi_utils as ku

_STATE = local()
_RESOLVE_MODE = 'playback.resolve'
_PENDING_PROPERTY = 'alkoflix.native_resolution'
_PENDING_LIFETIME = 60
_CLOUD_MODES = frozenset(('alldebrid.resolve_ad', 'real_debrid.resolve_rd',
                          'torbox.resolve_tb', 'easynews.resolve_easynews'))


def is_playback(params):
    mode = params.get('mode')
    return (mode in ('play_media', 'tmdbh_play', 'tmdbh_select', 'media_play', _RESOLVE_MODE)
            or (mode in _CLOUD_MODES and params.get('play') == 'true'))


def _defer_widget_movie_resume(params, item):
    """Omega drops widget resume choices while rebuilding PlayMedia items.

    Keep the progress property for the skin, but offer the existing Kodi
    context dialog after source selection instead of asking on the tile.
    An explicit zero with a positive total also prevents Kodi from falling
    back to an old video-DB bookmark when processing the widget item.
    """
    if params.get('media_type') != 'movie':
        return False
    try:
        if ku.get_kodi_version() != 21 or not ku.external_browse():
            return False
        tag = item.getVideoInfoTag()
        tag.setResumePoint(0, max(1, int(tag.getDuration() or 0)))
        item.setProperty('alkoflix_resume_deferred', 'true')
        return True
    except Exception:
        return False


def mark_item(url, item, is_folder):
    """Mark only playable alkoFlix routes, never actions/info/folders/other add-ons."""
    if is_folder or not isinstance(url, str) or not url.startswith('plugin://plugin.video.alkoflix'):
        return url
    parsed = urlsplit(url)
    if parsed.scheme != 'plugin' or parsed.netloc != 'plugin.video.alkoflix':
        return url
    params = dict(parse_qsl(parsed.query, keep_blank_values=True))
    if not is_playback(params):
        return url
    item.setProperty('IsPlayable', 'true')
    item.setProperty('ForceResolvePlugin', 'true')
    item.setProperty('OverrideInfotag', 'true')
    # Widgets on Omega lose that native choice before the resolver starts.
    # Their fresh provider bookmark is selected after choosing a source.
    if params.get('mode') == 'play_media':
        params['_kodi_resume'] = 'deferred' if _defer_widget_movie_resume(params, item) else 'true'
        url = 'plugin://plugin.video.alkoflix/?' + urlencode(params)
    return url


class Request:
    def __init__(self, handle, params, resume=False):
        self.handle = handle
        self.params = params
        self.resume = resume
        self.completed = False
        self.no_playback_reason = None

    def resolve(self, item, success=True):
        if self.completed:
            raise RuntimeError('plugin handle already answered')
        self.completed = True
        ku.xbmcplugin.setResolvedUrl(self.handle, success, item)
        ku.logger('Résolution Kodi', 'handle=%s | %s' % (
            self.handle, 'URL remise à Kodi' if success else
            'Sans lecture (%s)' % (self.no_playback_reason or 'indéterminé')), level='info')


def note_no_playback(reason):
    """Distingue recherche vide / fermeture volontaire d'une vraie panne de flux.

    La lecture native reste sous le contrat setResolvedUrl, y compris sur
    Omega 21 et Piers 22 : ne jamais fabriquer de média pour masquer un échec.
    """
    request = current_request()
    if request is not None and not request.completed and reason in ('no_results', 'cancelled'):
        # Une recherche alternative d'anime peut ensuite réussir : resolve(True)
        # prévaut toujours et ne déclenche aucune fermeture de dialogue.
        request.no_playback_reason = reason


@contextmanager
def plugin_request(argv):
    previous = getattr(_STATE, 'request', None)
    request = None
    try:
        handle = int(argv[1])
        params = dict(parse_qsl(argv[2].lstrip('?'), keep_blank_values=True))
        if handle >= 0 and is_playback(params):
            request = Request(handle, params, len(argv) > 3 and argv[3] == 'resume:true')
    except (IndexError, TypeError, ValueError):
        pass
    _STATE.request = request
    try:
        yield request
    finally:
        try:
            if request is not None and not request.completed:
                reason = request.no_playback_reason
                request.resolve(ku.make_listitem(), False)
                if reason in ('no_results', 'cancelled'):
                    # Kodi peut ouvrir son dialogue générique « Échec de lecture »
                    # APRÈS setResolvedUrl(False). On ne ferme que son dialogue OK,
                    # dans une fenêtre de temps très courte; jamais tous les dialogues.
                    # C'est un contournement UI, pas une réussite de lecture fictive.
                    try:
                        if not ku.monitor.abortRequested():
                            ku.close_playback_error_dialog(attempts=8, delay=75)
                    except Exception:
                        pass
        finally:
            _STATE.request = previous


def current_request():
    return getattr(_STATE, 'request', None)


def native_resume_choice():
    request = current_request()
    if request is not None and not request.completed:
        if request.resume or request.params.get('_kodi_resume') == 'true':
            return request.resume
    return None


def prepare_upnext_handoff(params):
    """Finalize the old episode before resolving the queued next episode."""
    handoff = params.pop('nextep_handoff', '')
    if not handoff:
        return
    if ku.player.isPlayingVideo():
        ku.set_property('alkoflix_nextep_handoff', handoff)
        ku.sleep(1500)
    try:
        from modules.post_playback_ratings import offer_episode_handoff
        offer_episode_handoff(handoff)
    except Exception: pass
    ku.logger('UpNext', 'Relais natif Kodi | TMDb=%s S%sE%s' % (
        params.get('tmdb_id', ''), params.get('season', ''), params.get('episode', '')), level='info')


def open_native_episode(params):
    """Compatibility callback: re-enter Kodi's resolver, never play a raw stream."""
    data = dict(params, mode='play_media', media_type='episode')
    url = 'plugin://plugin.video.alkoflix/?' + urlencode(data)
    _open_native(url)


def _open_native(url):
    result = json.loads(ku.execJSONRPC(json.dumps({
        'jsonrpc': '2.0', 'id': 0, 'method': 'Player.Open',
        'params': {'item': {'file': url}}
    })))
    if result.get('result') != 'OK':
        raise RuntimeError('Kodi refused native playback')


def resolve_pending(token):
    """Answer only this native invocation, never an older or fabricated handle."""
    request = current_request()
    if request is None or request.completed:
        return False
    try:
        payload = json.loads(ku.get_property(_PENDING_PROPERTY) or '{}')
    except (TypeError, ValueError):
        return False
    if not isinstance(payload, dict) or not token or payload.get('token') != token:
        return False
    # One-shot consumption. A late invocation cannot replay the same stream.
    ku.clear_property(_PENDING_PROPERTY)
    created = payload.get('created')
    if not isinstance(created, (int, float)):
        return False
    age = time() - created
    url = payload.get('url')
    if not 0 <= age <= _PENDING_LIFETIME or not isinstance(url, str) or not url.strip():
        return False
    meta = payload.get('meta')
    if not isinstance(meta, dict):
        return False
    if meta:
        from modules.player import make_playback_item
        item = make_playback_item(meta)
    else:
        item = ku.make_listitem()
    item.setPath(url)
    item.setProperty('IsPlayable', 'true')
    item.setProperty('StartPercent', payload.get('start_percent', '0'))
    request.resolve(item)
    return True


def start(url, item, player=None):
    """Resolve once, or ask Kodi for a fresh native resolution for this item."""
    if not isinstance(url, str) or not url.strip():
        raise ValueError('empty playback URL')
    item.setPath(url)
    item.setProperty('IsPlayable', 'true')
    request = current_request()
    if request is not None and not request.completed:
        request.resolve(item)
        return 'resolved'
    token = uuid4().hex
    payload = {
        'token': token, 'created': time(), 'url': url,
        'meta': getattr(player, 'meta', None) or {},
        'start_percent': item.getProperty('StartPercent') or '0'
    }
    ku.set_property(_PENDING_PROPERTY, json.dumps(payload))
    native_params = {'mode': _RESOLVE_MODE, 'token': token}
    meta = payload['meta']
    if meta.get('media_type') in ('movie', 'episode') and meta.get('tmdb_id'):
        # Keep an ordinary, replayable media route in Kodi's playlist/history.
        # Once the temporary item is consumed, reopening this URL can resolve
        # the movie/episode normally instead of depending on an expired token.
        native_params = {
            'mode': 'play_media', '_native_token': token,
            'media_type': meta['media_type'], 'tmdb_id': str(meta['tmdb_id']),
            'autoplay': request.params.get('autoplay', 'true') if request else 'true',
            '_kodi_resume': 'true'
        }
        if meta['media_type'] == 'episode':
            native_params.update(season=meta.get('season', ''), episode=meta.get('episode', ''),
                                 tvshowtitle=meta.get('title', ''))
    native_url = 'plugin://plugin.video.alkoflix/?' + urlencode(native_params)
    try:
        _open_native(native_url)
    except Exception:
        discard_pending(token)
        raise
    reason = 'lien de secours' if request is not None else 'commande sans demande de résolution'
    ku.logger('Résolution Kodi', 'Nouvelle demande native | %s' % reason, level='info')
    return token


def discard_pending(token):
    """Clean up an unconsumed relay without touching a more recent command."""
    try:
        payload = json.loads(ku.get_property(_PENDING_PROPERTY) or '{}')
        if isinstance(payload, dict) and token and payload.get('token') == token:
            ku.clear_property(_PENDING_PROPERTY)
    except (TypeError, ValueError):
        pass


def play_url(url):
    """Cloud/direct files have no invented movie/episode scrobbling."""
    if not url:
        ku.logger('Résolution Kodi', 'URL absente : lecture non lancée', level='warning')
        return False
    start(url, ku.make_listitem())
    return True
