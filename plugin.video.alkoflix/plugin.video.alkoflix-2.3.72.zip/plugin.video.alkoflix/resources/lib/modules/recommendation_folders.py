# -*- coding: utf-8 -*-
"""Présentation des titres regardés, sans changer leur action de navigation.

La fiche est déjà chargée par Navigator. Ce module ne récupère aucune donnée :
il expose ses visuels et informations au skin, pour les menus et les widgets.
"""

from modules import kodi_utils, settings
from modules.extra_fanart import item_art as extra_fanart_art


def set_media_details(listitem, meta, media_type, title, poster, tmdb_id=None):
    meta = meta or {}
    _, _, fanart_main, fanart_backup = settings.get_art_provider()
    fanart = meta.get(fanart_main) or meta.get(fanart_backup) or ''
    landscape = settings.resolve_landscape_art(meta, fanart or poster)
    thumb = landscape or fanart or poster
    art = {
        'poster': poster, 'icon': poster, 'thumb': thumb, 'fanart': fanart,
        'landscape': landscape or thumb, 'banner': meta.get('banner'),
        'clearlogo': meta.get('clearlogo') or meta.get('tmdblogo'),
        'clearart': meta.get('clearart'), 'discart': meta.get('discart'),
    }
    if media_type == 'tvshow':
        for key in ('poster', 'thumb', 'fanart', 'landscape', 'banner', 'clearlogo', 'clearart'):
            art['tvshow.' + key] = art[key]
    art.update(extra_fanart_art(meta, fanart, tvshow=media_type == 'tvshow'))
    listitem.setArt(kodi_utils.clean_art(art))

    # Ne pas modifier la fiche partagée ni reprendre un éventuel état de lecture
    # ajouté par un autre constructeur : ces éléments ouvrent des recommandations.
    info = dict(meta, title=title, mediatype=media_type)
    info.pop('playcount', None)
    if media_type == 'tvshow': info['tvshowtitle'] = meta.get('tvshowtitle') or title
    kodi_utils.set_listitem_video_info(listitem, info)
    try: videoinfo = listitem.getVideoInfoTag(offscreen=True)
    except TypeError: videoinfo = listitem.getVideoInfoTag()
    videoinfo.setUniqueIDs(kodi_utils.clean_unique_ids({
        'tmdb': tmdb_id or meta.get('tmdb_id'),
        'imdb': meta.get('imdb_id'), 'tvdb': meta.get('tvdb_id'),
    }))
    videoinfo.setCast(kodi_utils.make_cast_list(meta.get('cast')))
    if media_type == 'tvshow':
        videoinfo.setTvShowStatus(kodi_utils.kodi_text(meta.get('status')))
        for key, value in (('totalseasons', meta.get('total_seasons')),
                           ('totalepisodes', meta.get('total_aired_eps'))):
            if value is not None: listitem.setProperty(key, str(value))
    listitem.setContentLookup(False)
    listitem.setProperty('IsPlayable', 'false')
