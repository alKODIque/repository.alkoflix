# -*- coding: utf-8 -*-
"""Read-only TheIntroDB v4 adapter. Up Next owns all playback decisions."""
import hashlib
import json
import math
from time import monotonic
from datetime import timedelta

API_URL = 'https://api.theintrodb.org/v4/media'


def _number(value):
    if isinstance(value, bool):
        raise ValueError('boolean timestamp')
    result = float(value)
    if not math.isfinite(result):
        raise ValueError('non-finite timestamp')
    return result


def query_for(meta, duration):
    """Use canonical TMDb aired coordinates, never custom display numbering."""
    try:
        duration = _number(duration)
        season, episode = int(meta['season']), int(meta['episode'])
        tmdb_id = int(meta['tmdb_id'])
        if duration <= 0 or season < 0 or episode < 1 or tmdb_id < 1:
            return None
        return {'tmdb_id': tmdb_id, 'season': season, 'episode': episode,
                'mapping': 'official', 'duration_ms': int(round(duration)) * 1000,
                'merge_unknown': 'false', 'details': 'true'}
    except (KeyError, TypeError, ValueError, OverflowError):
        return None


def to_upnext(data, duration):
    """Validate millisecond ranges and translate to Up Next's seconds."""
    result = {}
    if not isinstance(data, dict) or data.get('type') != 'tv':
        return result
    try:
        duration = _number(duration)
        group_duration = data.get('group_duration_ms')
        if group_duration is not None and abs(_number(group_duration) / 1000 - duration) > 5:
            return result
    except (TypeError, ValueError, OverflowError):
        return result
    segments = []
    for kind in ('intro', 'recap'):
        ranges = data.get(kind)
        if not isinstance(ranges, list):
            continue
        for item in ranges:
            try:
                if not isinstance(item, dict) or 'start_ms' not in item:
                    continue
                start = 0 if item['start_ms'] is None else _number(item['start_ms']) / 1000
                end = _number(item['end_ms']) / 1000
                if 0 <= start < end < duration:
                    segment = {'kind': kind, 'start': start, 'end': end}
                    if segment not in segments:
                        segments.append(segment)
            except (KeyError, TypeError, ValueError, OverflowError):
                continue
    if segments:
        result['skip_segments'] = sorted(segments, key=lambda item: item['start'])
    credits = []
    for item in data.get('credits', []) if isinstance(data.get('credits'), list) else []:
        try:
            start = _number(item['start_ms']) / 1000
            if 0 < start < duration:
                credits.append(start)
        except (KeyError, TypeError, ValueError, OverflowError):
            continue
    if credits:
        result['notification_offset'] = min(credits)
    return result


def log(meta, message, level='info'):
    # Only identifiers and outcomes: no stream URLs, credentials or raw replies.
    try:
        from modules import kodi_utils
        kodi_utils.logger('UpNext', 'TMDb=%s S%sE%s | %s' % (
            meta.get('tmdb_id', '?'), meta.get('season', '?'),
            meta.get('episode', '?'), message), level=level)
    except Exception:
        pass


def _summary(data, markers, duration):
    if markers:
        return '%s segment(s), générique=%s' % (
            len(markers.get('skip_segments', [])),
            'oui' if 'notification_offset' in markers else 'non')
    try:
        group_duration = data.get('group_duration_ms')
        if group_duration is not None and abs(_number(group_duration) / 1000 - duration) > 5:
            return 'repères rejetés : durée de version incompatible'
    except (TypeError, ValueError, OverflowError):
        return 'repères rejetés : durée de version invalide'
    if any(data.get(kind) for kind in ('intro', 'recap', 'credits')):
        return 'repères rejetés : format ou bornes invalides'
    return 'aucun repère disponible'


def fetch(meta, duration):
    """One bounded request, cached including missing data; called by a worker."""
    query = query_for(meta, duration)
    if query is None:
        log(meta, 'Recherche ignorée : identité, épisode ou durée invalide')
        return {}
    cache = None
    started = monotonic()
    key = 'upnext_segments_v4_' + hashlib.sha256(
        json.dumps(query, sort_keys=True).encode('utf-8')).hexdigest()
    try:
        from caches.main_cache import MainCache
        cache = MainCache()
        cached = cache.get(key)
        if isinstance(cached, dict):
            # Accept entries from the first test ZIP as well as labelled entries.
            data = cached.get('payload', cached)
            markers = to_upnext(data, duration)
            log(meta, 'Cache TheIntroDB (%s) : %s' % (
                cached.get('status', 'ancien résultat'), _summary(data, markers, duration)))
            return markers
        import requests
        with requests.get(API_URL, params=query, timeout=(2, 3),
                          headers={'User-Agent': 'alkoFlix/2.3.17'},
                          allow_redirects=False) as response:
            status = 'HTTP %s' % response.status_code
            if response.status_code == 404:
                data, expiration = {}, timedelta(hours=6)
            elif response.status_code == 200:
                data, expiration = response.json(), timedelta(days=7)
                if not isinstance(data, dict) or data.get('type') != 'tv':
                    log(meta, 'TheIntroDB HTTP 200 : réponse de format inattendu ; fonctionnement habituel conservé', 'warning')
                    cache.set(key, {'payload': {}, 'status': 'format invalide'},
                              expiration=timedelta(minutes=10))
                    return {}
            else:
                # Brief backoff for rate limits and unavailable upstream services.
                data, expiration = {}, timedelta(minutes=10)
        cache.set(key, {'payload': data, 'status': status}, expiration=expiration)
        markers = to_upnext(data, duration)
        elapsed = int((monotonic() - started) * 1000)
        if status not in ('HTTP 200', 'HTTP 404'):
            log(meta, 'TheIntroDB %s (%s ms) : recherche indisponible, nouvel essai après 10 min ; fonctionnement habituel conservé' % (status, elapsed), 'warning')
        else:
            log(meta, 'TheIntroDB %s (%s ms, fichier %s s) : %s' % (
                status, elapsed, query['duration_ms'] // 1000, _summary(data, markers, duration)))
        return markers
    except Exception as exc:
        # Exception class only; exception strings can contain URLs or proxy data.
        error = type(exc).__name__
        reason = 'délai réseau dépassé' if 'timeout' in error.lower() else 'erreur de récupération'
        log(meta, 'TheIntroDB : %s (%s, %s ms) ; fonctionnement habituel conservé' % (
            reason, error, int((monotonic() - started) * 1000)), 'warning')
        if cache is not None:
            try:
                cache.set(key, {'payload': {}, 'status': error}, expiration=timedelta(minutes=10))
            except Exception:
                pass
        return {}
    finally:
        if cache is not None:
            try:
                cache.dbcon.close()
            except Exception:
                pass
