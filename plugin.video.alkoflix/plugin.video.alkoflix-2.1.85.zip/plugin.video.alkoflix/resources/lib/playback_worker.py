# -*- coding: utf-8 -*-
# Detached playback monitor for native IsPlayable alkoFlix items.
# This module is invoked through the alkoFlix plugin route so Kodi keeps
# the correct addon context while the monitor follows the resolved stream.
import json

def main(session_id=''):
	try:
		session_id = str(session_id or '')
		if not session_id: return False
		from modules import kodi_utils
		from modules.player import AlkoFlixPlayer
		key = 'alkoflix.native_playback.%s' % session_id
		payload = kodi_utils.get_property(key)
		kodi_utils.clear_property(key)
		if not payload: return False
		meta = json.loads(payload)
		return AlkoFlixPlayer().monitor_resolved(meta)
	except Exception as e:
		try:
			from modules import kodi_utils
			kodi_utils.logger('alkoFlix Player', 'playback_worker impossible -> %s: %s' % (type(e).__name__, e))
		except: pass
		return False
