# -*- coding: utf-8 -*-
# plugin.video.alkoflix
# Synchronisation multi-appareils du fournisseur de visionnage Local via alkoPastes.

import hashlib
import json
import time
from datetime import datetime, timezone

from modules import kodi_utils, settings
from modules.alkopastes_backup import _request, _summary_code, _paste_code, _mask_code, _installation_device_id

get_setting, set_setting = kodi_utils.get_setting, kodi_utils.set_setting
logger = kodi_utils.logger
WATCHED_DB = kodi_utils.watched_db

BACKUP_SETTING = 'alkopastes.watched_backup_code'
MULTI_DEVICE_SETTING = 'alkopastes.watched_multi_device'
SYNC_SETTING = 'alkopastes.watched_sync_enabled'
AUTO_RESTORE_SETTING = 'alkopastes.watched_auto_restore_enabled'
AUTO_RESTORE_INTERVAL_SETTING = 'alkopastes.watched_auto_restore_interval'
AUTO_RESTORE_DUE_SETTING = 'alkopastes.watched_auto_restore_due'
SYNC_PENDING_SETTING = 'alkopastes.watched_sync_pending'
SYNC_PENDING_AT_SETTING = 'alkopastes.watched_sync_pending_at'
LAST_LOCAL_HASH_SETTING = 'alkopastes.watched_sync_last_local_hash'
LAST_REMOTE_HASH_SETTING = 'alkopastes.watched_auto_restore_last_hash'
BACKOFF_SETTING = 'alkopastes.watched_auto_restore_backoff_count'
BACKUP_TITLE = 'alkoFlix suivis de lecture - synchronisation'
BACKUP_VERSION = 1
SYNC_DEBOUNCE_SECONDS = 10
TOMBSTONE_RETENTION_SECONDS = 180 * 24 * 3600


def _setting_true(setting_id):
    try: return str(get_setting(setting_id, 'false')).strip().lower() == 'true'
    except Exception: return False


def _setting_int(setting_id, default=0):
    try: return int(float(str(get_setting(setting_id, str(default)) or default)))
    except Exception: return int(default or 0)


def _refresh_settings_cache():
    try: kodi_utils.clear_property('alkoflix_settings')
    except Exception: pass


def _set(setting_id, value):
    value = str(value)
    try:
        if str(get_setting(setting_id, '')) == value: return False
        set_setting(setting_id, value)
        _refresh_settings_cache()
        return True
    except Exception: return False


def has_user_api_key():
    try: return bool(str(get_setting('alkopastes.api_key_user', '')).strip())
    except Exception: return False


def multi_device_enabled(): return _setting_true(MULTI_DEVICE_SETTING)
def auto_send_enabled(): return multi_device_enabled()
def auto_restore_enabled(): return multi_device_enabled()


def _local_provider_selected():
    try: return int(settings.watched_indicators()) == 0
    except Exception: return False


def _device_hash():
    return hashlib.sha256(('alkoFlix watched:%s' % _installation_device_id()).encode('utf-8')).hexdigest()


def _db():
    con = kodi_utils.database_connect(WATCHED_DB, isolation_level=None)
    con.execute("""CREATE TABLE IF NOT EXISTS watched_status
                 (db_type text, media_id text, season integer, episode integer, last_played text, title text,
                  unique(db_type, media_id, season, episode))""")
    con.execute("""CREATE TABLE IF NOT EXISTS progress
                 (db_type text, media_id text, season integer, episode integer, resume_point text, curr_time text,
                  last_played text, resume_id integer, title text, unique(db_type, media_id, season, episode))""")
    con.execute("""CREATE TABLE IF NOT EXISTS dropped_status
                 (media_id text primary key, title text, dropped_at text)""")
    con.execute("""CREATE TABLE IF NOT EXISTS watchlist_status
                 (media_type text, media_id text, title text, added_at text, unique(media_type, media_id))""")
    con.execute("""CREATE TABLE IF NOT EXISTS watched_sync_state
                 (state_key text primary key, state_type text, payload text, updated_at integer,
                  deleted integer default 0, device_hash text)""")
    return con


def _to_epoch(value):
    raw = str(value or '').strip()
    if not raw: return 0
    try:
        if raw.isdigit(): return int(raw)
        iso = raw[:-1] + '+00:00' if raw.endswith('Z') else raw
        dt = datetime.fromisoformat(iso)
        if dt.tzinfo is None: dt = dt.astimezone()
        return int(dt.timestamp())
    except Exception: return 0


def _local_datetime(epoch):
    try: return datetime.fromtimestamp(int(epoch)).strftime('%Y-%m-%d %H:%M:%S')
    except Exception: return datetime.now().strftime('%Y-%m-%d %H:%M:%S')


def _key(*parts):
    return '|'.join(str(i if i not in (None, '') else '-') for i in parts)


def _payload_json(payload):
    return json.dumps(payload or {}, ensure_ascii=False, sort_keys=True, separators=(',', ':'))


def _read_actual_state(con):
    state = {}
    for db_type, media_id, season, episode, last_played, title in con.execute(
        "SELECT db_type, media_id, season, episode, last_played, title FROM watched_status").fetchall():
        k = _key('watched', db_type, media_id, season, episode)
        p = {'db_type': str(db_type or ''), 'media_id': str(media_id or ''), 'season': season, 'episode': episode,
             'last_played': str(last_played or ''), 'title': str(title or '')}
        state[k] = ('watched', p, _to_epoch(last_played))
    for db_type, media_id, season, episode, resume_point, curr_time, last_played, resume_id, title in con.execute(
        "SELECT db_type, media_id, season, episode, resume_point, curr_time, last_played, resume_id, title FROM progress").fetchall():
        k = _key('progress', db_type, media_id, season, episode)
        p = {'db_type': str(db_type or ''), 'media_id': str(media_id or ''), 'season': season, 'episode': episode,
             'resume_point': str(resume_point or ''), 'curr_time': str(curr_time or ''), 'last_played': str(last_played or ''),
             'resume_id': int(resume_id or 0), 'title': str(title or '')}
        state[k] = ('progress', p, _to_epoch(last_played))
    for media_id, title, dropped_at in con.execute(
        "SELECT media_id, title, dropped_at FROM dropped_status").fetchall():
        k = _key('dropped', 'tvshow', media_id)
        p = {'media_id': str(media_id or ''), 'title': str(title or ''), 'dropped_at': str(dropped_at or '')}
        state[k] = ('dropped', p, _to_epoch(dropped_at))
    for media_type, media_id, title, added_at in con.execute(
        "SELECT media_type, media_id, title, added_at FROM watchlist_status").fetchall():
        k = _key('watchlist', media_type, media_id)
        p = {'media_type': str(media_type or ''), 'media_id': str(media_id or ''), 'title': str(title or ''), 'added_at': str(added_at or '')}
        state[k] = ('watchlist', p, _to_epoch(added_at))
    return state


def capture_local_state(force_timestamp=False):
    """Capture l'état réel et transforme toute disparition en tombstone daté."""
    con = None
    try:
        con = _db()
        now = int(time.time())
        device = _device_hash()
        actual = _read_actual_state(con)
        old_rows = con.execute("SELECT state_key, state_type, payload, updated_at, deleted, device_hash FROM watched_sync_state").fetchall()
        old = {str(r[0]): r for r in old_rows}
        con.execute('BEGIN IMMEDIATE')
        for k, (state_type, payload, source_ts) in actual.items():
            encoded = _payload_json(payload)
            prev = old.get(k)
            if prev and int(prev[4] or 0) == 0 and str(prev[2] or '') == encoded and not force_timestamp:
                updated = max(int(prev[3] or 0), int(source_ts or 0))
                dev = str(prev[5] or device)
            else:
                updated = max(now, int(source_ts or 0)) if (prev or force_timestamp) else (int(source_ts or 0) or now)
                dev = device
            con.execute("""INSERT OR REPLACE INTO watched_sync_state
                         (state_key, state_type, payload, updated_at, deleted, device_hash)
                         VALUES (?, ?, ?, ?, 0, ?)""", (k, state_type, encoded, updated, dev))
        for k, row in old.items():
            if k in actual or int(row[4] or 0) == 1: continue
            con.execute("""UPDATE watched_sync_state SET deleted = 1, updated_at = ?, device_hash = ? WHERE state_key = ?""",
                        (now, device, k))
        con.commit()
        return True
    except Exception as exc:
        try:
            if con: con.rollback()
        except Exception: pass
        logger('alkoPastes watched capture failed', '%s: %s' % (type(exc).__name__, exc))
        return False
    finally:
        try:
            if con: con.close()
        except Exception: pass


def _state_items():
    capture_local_state()
    con = None
    try:
        con = _db()
        rows = con.execute("SELECT state_key, state_type, payload, updated_at, deleted, device_hash FROM watched_sync_state").fetchall()
        return [{'key': str(r[0]), 'type': str(r[1]), 'payload': json.loads(r[2] or '{}'), 'updated_at': int(r[3] or 0),
                 'deleted': bool(r[4]), 'device_hash': str(r[5] or '')} for r in rows]
    except Exception as exc:
        logger('alkoPastes watched state read failed', '%s: %s' % (type(exc).__name__, exc))
        return []
    finally:
        try:
            if con: con.close()
        except Exception: pass


def _state_newer(a, b):
    if b is None: return True
    ats, bts = int(a.get('updated_at') or 0), int(b.get('updated_at') or 0)
    if ats != bts: return ats > bts
    # À timestamp égal, une suppression gagne puis le hash appareil départage.
    if bool(a.get('deleted')) != bool(b.get('deleted')): return bool(a.get('deleted'))
    return str(a.get('device_hash') or '') > str(b.get('device_hash') or '')


def _merge(*groups):
    merged = {}
    for group in groups:
        for item in group or []:
            k = str(item.get('key') or '')
            if not k: continue
            if _state_newer(item, merged.get(k)): merged[k] = item
    return list(merged.values())


def _compact(items):
    cutoff = int(time.time()) - TOMBSTONE_RETENTION_SECONDS
    return [i for i in items or [] if not (i.get('deleted') and int(i.get('updated_at') or 0) < cutoff)]


def _content(items):
    payload = {'kind': 'alkoflix_watched_sync', 'version': BACKUP_VERSION, 'updated_at': int(time.time()), 'items': _compact(items)}
    return json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(',', ':'))


def _parse(content):
    try:
        data = json.loads(str(content or ''))
        if not isinstance(data, dict) or data.get('kind') != 'alkoflix_watched_sync': return []
        return [i for i in (data.get('items') or []) if isinstance(i, dict) and i.get('key')]
    except Exception: return []


def _backup_code(): return str(get_setting(BACKUP_SETTING, '') or '').strip()


def _set_backup_code(code):
    _set(BACKUP_SETTING, str(code or '').strip())
    return str(code or '').strip()


def _matches_title(paste):
    return str((paste or {}).get('title') or '').strip().startswith(BACKUP_TITLE)


def _find_backup_code():
    for page in range(1, 6):
        try: result = _request('GET', 'list', params={'page': page, 'limit': 100}, log_name='alkoPastes watched request')
        except Exception: break
        pastes = result.get('pastes') or []
        for paste in pastes:
            if _matches_title(paste):
                code = _summary_code(paste)
                if code: return _set_backup_code(code)
        pages = int((result.get('pagination') or {}).get('pages') or 0)
        if not pastes or (pages and page >= pages): break
    try:
        result = _request('GET', 'search', params={'q': BACKUP_TITLE, 'limit': 50}, log_name='alkoPastes watched request')
        for paste in result.get('pastes') or []:
            if _matches_title(paste):
                code = _summary_code(paste)
                if code: return _set_backup_code(code)
    except Exception: pass
    return ''


def _get_remote():
    code = _backup_code() or _find_backup_code()
    if not code: return '', [], ''
    result = _request('GET', 'get', params={'id': code}, log_name='alkoPastes watched request')
    paste = result.get('paste') or {}
    content = paste.get('content') or ''
    if isinstance(content, (dict, list)): content = json.dumps(content, ensure_ascii=False)
    return code, _parse(content), str(content)


def _save(items, code=''):
    code = code or _backup_code() or _find_backup_code()
    content = _content(items)
    payload = {'title': BACKUP_TITLE, 'content': content, 'syntax': 'text', 'visibility': 'private', 'expiry': 'NULL'}
    if code:
        try: result = _request('POST', 'update', payload=payload, params={'id': code}, log_name='alkoPastes watched request')
        except Exception:
            result = _request('POST', 'paste', payload=payload, log_name='alkoPastes watched request')
    else:
        result = _request('POST', 'paste', payload=payload, log_name='alkoPastes watched request')
    new_code = _paste_code(result, code)
    if new_code: _set_backup_code(new_code)
    return new_code, content


def _apply_item(con, item):
    t = str(item.get('type') or '')
    p = item.get('payload') or {}
    deleted = bool(item.get('deleted'))
    if t == 'watched':
        args = (str(p.get('db_type') or ''), str(p.get('media_id') or ''), p.get('season', ''), p.get('episode', ''))
        if deleted: con.execute("DELETE FROM watched_status WHERE db_type=? AND media_id=? AND season=? AND episode=?", args)
        else: con.execute("INSERT OR REPLACE INTO watched_status VALUES (?, ?, ?, ?, ?, ?)", args + (str(p.get('last_played') or _local_datetime(item.get('updated_at'))), str(p.get('title') or '')))
    elif t == 'progress':
        args = (str(p.get('db_type') or ''), str(p.get('media_id') or ''), p.get('season', ''), p.get('episode', ''))
        if deleted: con.execute("DELETE FROM progress WHERE db_type=? AND media_id=? AND season=? AND episode=?", args)
        else:
            con.execute("INSERT OR REPLACE INTO progress VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)", args + (
                str(p.get('resume_point') or ''), str(p.get('curr_time') or ''), str(p.get('last_played') or _local_datetime(item.get('updated_at'))),
                int(p.get('resume_id') or 0), str(p.get('title') or '')))
    elif t == 'dropped':
        media_id = str(p.get('media_id') or '')
        if deleted: con.execute("DELETE FROM dropped_status WHERE media_id=?", (media_id,))
        else: con.execute("INSERT OR REPLACE INTO dropped_status (media_id,title,dropped_at) VALUES (?,?,?)",
                          (media_id, str(p.get('title') or ''), str(p.get('dropped_at') or _local_datetime(item.get('updated_at')))))
    elif t == 'watchlist':
        media_type, media_id = str(p.get('media_type') or ''), str(p.get('media_id') or '')
        if deleted: con.execute("DELETE FROM watchlist_status WHERE media_type=? AND media_id=?", (media_type, media_id))
        else: con.execute("INSERT OR REPLACE INTO watchlist_status (media_type,media_id,title,added_at) VALUES (?,?,?,?)",
                          (media_type, media_id, str(p.get('title') or ''), str(p.get('added_at') or _local_datetime(item.get('updated_at')))))


def _apply_merged(items):
    con = None
    try:
        con = _db()
        con.execute('BEGIN IMMEDIATE')
        for item in items or []: _apply_item(con, item)
        con.execute('DELETE FROM watched_sync_state')
        for i in items or []:
            con.execute("INSERT OR REPLACE INTO watched_sync_state (state_key,state_type,payload,updated_at,deleted,device_hash) VALUES (?,?,?,?,?,?)",
                        (str(i.get('key') or ''), str(i.get('type') or ''), _payload_json(i.get('payload') or {}), int(i.get('updated_at') or 0), 1 if i.get('deleted') else 0, str(i.get('device_hash') or '')))
        con.commit()
        return True
    except Exception as exc:
        try:
            if con: con.rollback()
        except Exception: pass
        logger('alkoPastes watched apply failed', '%s: %s' % (type(exc).__name__, exc))
        return False
    finally:
        try:
            if con: con.close()
        except Exception: pass


def _state_hash(items=None):
    items = _state_items() if items is None else items
    normal = sorted((str(i.get('key')), int(i.get('updated_at') or 0), bool(i.get('deleted')), _payload_json(i.get('payload') or {})) for i in items)
    return hashlib.sha256(json.dumps(normal, ensure_ascii=False, separators=(',', ':')).encode('utf-8')).hexdigest()


def mark_sync_pending(reason=''):
    if not (has_user_api_key() and auto_send_enabled() and _local_provider_selected()): return False
    capture_local_state()
    _set(SYNC_PENDING_SETTING, 'true')
    _set(SYNC_PENDING_AT_SETTING, str(int(time.time())))
    logger('alkoPastes watched pending', 'QUEUED | %s' % (reason or 'local_change'))
    return True


def pending_sync_due():
    if not (has_user_api_key() and auto_send_enabled() and _local_provider_selected()): return False
    capture_local_state()
    current = _state_hash()
    previous = str(get_setting(LAST_LOCAL_HASH_SETTING, '') or '')
    pending = _setting_true(SYNC_PENDING_SETTING)
    if current != previous: pending = True
    if not pending: return False
    pending_at = _setting_int(SYNC_PENDING_AT_SETTING, 0)
    return pending_at <= 0 or int(time.time()) - pending_at >= SYNC_DEBOUNCE_SECONDS


def export_now(show_notification=False):
    if not multi_device_enabled():
        if show_notification: kodi_utils.notification('Activez d’abord la synchronisation multi-appareils des suivis', time=3000)
        return {'success': False, 'error': 'multi_device_disabled'}
    if not _local_provider_selected():
        if show_notification: kodi_utils.notification('Sélectionnez alkoFlix (Local) comme fournisseur de visionnage', time=3000)
        return {'success': False, 'error': 'local_provider_not_selected'}
    if not has_user_api_key():
        if show_notification: kodi_utils.notification('Connectez alkoPastes pour synchroniser les suivis', time=3000)
        return {'success': False, 'error': 'not_authorized'}
    try:
        local = _state_items()
        code, remote, _raw = _get_remote()
        merged = _merge(remote, local)
        # Appliquer aussi les éventuelles modifications distantes avant l'envoi :
        # une vraie fusion, jamais un écrasement aveugle.
        if not _apply_merged(merged): return {'success': False, 'error': 'apply_failed'}
        code, content = _save(merged, code)
        h = _state_hash(merged)
        _set(LAST_LOCAL_HASH_SETTING, h)
        _set(LAST_REMOTE_HASH_SETTING, hashlib.sha256(content.encode('utf-8')).hexdigest())
        _set(SYNC_PENDING_SETTING, 'false')
        _set(SYNC_PENDING_AT_SETTING, '0')
        logger('alkoPastes watched export', 'OK | code=%s | items=%s' % (_mask_code(code), len(merged)))
        if show_notification: kodi_utils.notification('Suivis de lecture synchronisés avec alkoPastes', time=3000)
        return {'success': True, 'count': len(merged), 'code': code}
    except Exception as exc:
        logger('alkoPastes watched export failed', '%s: %s' % (type(exc).__name__, exc))
        if show_notification: kodi_utils.notification('Synchronisation des suivis impossible', time=3000)
        return {'success': False, 'error': str(exc)}


def import_now(show_notification=False):
    if not multi_device_enabled():
        if show_notification: kodi_utils.notification('Activez d’abord la synchronisation multi-appareils des suivis', time=3000)
        return {'success': False, 'error': 'multi_device_disabled'}
    if not _local_provider_selected():
        if show_notification: kodi_utils.notification('Sélectionnez alkoFlix (Local) comme fournisseur de visionnage', time=3000)
        return {'success': False, 'error': 'local_provider_not_selected'}
    if not has_user_api_key():
        if show_notification: kodi_utils.notification('Connectez alkoPastes pour synchroniser les suivis', time=3000)
        return {'success': False, 'error': 'not_authorized'}
    try:
        code, remote, raw = _get_remote()
        if not code: return {'success': False, 'error': 'missing_backup'}
        local = _state_items()
        merged = _merge(local, remote)
        if not _apply_merged(merged): return {'success': False, 'error': 'apply_failed'}
        h = _state_hash(merged)
        _set(LAST_LOCAL_HASH_SETTING, h)
        _set(LAST_REMOTE_HASH_SETTING, hashlib.sha256(raw.encode('utf-8')).hexdigest())
        logger('alkoPastes watched import', 'OK | code=%s | items=%s' % (_mask_code(code), len(merged)))
        if show_notification:
            kodi_utils.notification('Suivis de lecture récupérés depuis alkoPastes', time=3000)
            kodi_utils.container_refresh()
        return {'success': True, 'count': len(merged), 'code': code}
    except Exception as exc:
        logger('alkoPastes watched import failed', '%s: %s' % (type(exc).__name__, exc))
        if show_notification: kodi_utils.notification('Récupération des suivis impossible', time=3000)
        return {'success': False, 'error': str(exc)}


def flush_pending_sync():
    if not pending_sync_due(): return {'success': True, 'skipped': True}
    return export_now(show_notification=False)


def _restore_interval_seconds():
    # La synchronisation des suivis est volontairement automatique :
    # récupération au démarrage puis vérification légère une fois par minute.
    return 60


def automatic_restore(startup=False, force=False):
    if not (has_user_api_key() and auto_restore_enabled() and _local_provider_selected()): return 'disabled'
    now = int(time.time())
    interval = _restore_interval_seconds()
    due = _setting_int(AUTO_RESTORE_DUE_SETTING, 0)
    if interval <= 0 and not (startup or force): return 'startup_only'
    if interval > 0 and not force and now < due: return 'not_needed'
    try:
        code, remote, raw = _get_remote()
        next_due = now + (interval if interval > 0 else 365*24*3600)
        _set(AUTO_RESTORE_DUE_SETTING, str(next_due))
        if not code: return 'missing_backup'
        remote_hash = hashlib.sha256(raw.encode('utf-8')).hexdigest()
        previous = str(get_setting(LAST_REMOTE_HASH_SETTING, '') or '')
        local = _state_items()
        merged = _merge(local, remote)
        if remote_hash == previous and _state_hash(merged) == _state_hash(local): return 'unchanged'
        if not _apply_merged(merged): return 'apply_failed'
        _set(LAST_LOCAL_HASH_SETTING, _state_hash(merged))
        _set(LAST_REMOTE_HASH_SETTING, remote_hash)
        # Si la fusion locale contient quelque chose de plus récent, l'envoi auto
        # le publiera ensuite ; sinon aucune écriture réseau supplémentaire.
        if auto_send_enabled() and _state_hash(merged) != _state_hash(remote):
            _set(SYNC_PENDING_SETTING, 'true')
            _set(SYNC_PENDING_AT_SETTING, str(now))
        logger('alkoPastes watched auto restore', 'OK | items=%s' % len(merged))
        return 'success'
    except Exception as exc:
        logger('alkoPastes watched auto restore failed', '%s: %s' % (type(exc).__name__, exc))
        _set(AUTO_RESTORE_DUE_SETTING, str(now + 3600))
        return 'failed'


def initialize_sync_state():
    try:
        capture_local_state()
        # Au premier démarrage de la synchro, un Local déjà rempli doit créer son
        # paste même si aucune nouvelle action n'a encore eu lieu.
        if auto_send_enabled() and not (_backup_code() or _find_backup_code()):
            _set(SYNC_PENDING_SETTING, 'true')
            _set(SYNC_PENDING_AT_SETTING, '0')
        elif not str(get_setting(LAST_LOCAL_HASH_SETTING, '') or ''):
            _set(LAST_LOCAL_HASH_SETTING, _state_hash())
        return True
    except Exception: return False
