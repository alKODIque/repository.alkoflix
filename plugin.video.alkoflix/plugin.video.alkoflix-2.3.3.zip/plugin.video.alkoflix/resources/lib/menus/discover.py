# -*- coding: utf-8 -*-
# plugin.video.alkoflix
# Discover TMDb 2.3.0
#
# Implémentation reconstruite sur le modèle du Discover TMDb de TMDb Helper :
# chaque filtre conserve son état indépendamment et la fenêtre modale ne sert
# qu'à configurer/sauvegarder la recherche. Les résultats sont des routes Kodi
# normales, ce qui garde une pile de navigation stable.

import sys
import json
import time
from datetime import timedelta
from urllib.parse import quote_plus, urlencode, parse_qs, urlsplit

from caches.main_cache import MainCache, cache_object
from indexers.tmdb_api import base_url, get_tmdb
from modules import kodi_utils, meta_lists, settings
from modules.settings import tmdb_api_key, get_language, certification_country

maincache_db = kodi_utils.maincache_db
build_url = kodi_utils.build_url
make_listitem = kodi_utils.make_listitem

ADVANCED_DISCOVER_ICON = kodi_utils.menu_icons_path('recherche-avancee.png')
TMDB_DISCOVER_STATE_PREFIX = 'alkoflix_tmdb_discover_230_state_'
TMDB_DISCOVER_SAVED_KEY = 'alkoflix_tmdb_discover_230_saved'

MOVIE_SORTS = (
	('Titre original (A-Z)', 'original_title.asc'),
	('Titre original (Z-A)', 'original_title.desc'),
	('Popularité (croissante)', 'popularity.asc'),
	('Popularité (décroissante)', 'popularity.desc'),
	('Recettes (croissantes)', 'revenue.asc'),
	('Recettes (décroissantes)', 'revenue.desc'),
	('Date de sortie (ancienne à récente)', 'primary_release_date.asc'),
	('Date de sortie (récente à ancienne)', 'primary_release_date.desc'),
	('Titre (A-Z)', 'title.asc'),
	('Titre (Z-A)', 'title.desc'),
	('Note (croissante)', 'vote_average.asc'),
	('Note (décroissante)', 'vote_average.desc'),
	('Votes (croissants)', 'vote_count.asc'),
	('Votes (décroissants)', 'vote_count.desc'),
)

TV_SORTS = (
	('Première diffusion (ancienne à récente)', 'first_air_date.asc'),
	('Première diffusion (récente à ancienne)', 'first_air_date.desc'),
	('Titre (A-Z)', 'name.asc'),
	('Titre (Z-A)', 'name.desc'),
	('Titre original (A-Z)', 'original_name.asc'),
	('Titre original (Z-A)', 'original_name.desc'),
	('Popularité (croissante)', 'popularity.asc'),
	('Popularité (décroissante)', 'popularity.desc'),
	('Note (croissante)', 'vote_average.asc'),
	('Note (décroissante)', 'vote_average.desc'),
	('Votes (croissants)', 'vote_count.asc'),
	('Votes (décroissants)', 'vote_count.desc'),
)

COMBINED_SORTS = (
	('Date (ancienne à récente)', {'movie': 'primary_release_date.asc', 'tv': 'first_air_date.asc'}),
	('Date (récente à ancienne)', {'movie': 'primary_release_date.desc', 'tv': 'first_air_date.desc'}),
	('Titre (A-Z)', {'movie': 'title.asc', 'tv': 'name.asc'}),
	('Titre (Z-A)', {'movie': 'title.desc', 'tv': 'name.desc'}),
	('Titre original (A-Z)', {'movie': 'original_title.asc', 'tv': 'original_name.asc'}),
	('Titre original (Z-A)', {'movie': 'original_title.desc', 'tv': 'original_name.desc'}),
	('Popularité (croissante)', {'movie': 'popularity.asc', 'tv': 'popularity.asc'}),
	('Popularité (décroissante)', {'movie': 'popularity.desc', 'tv': 'popularity.desc'}),
	('Note (croissante)', {'movie': 'vote_average.asc', 'tv': 'vote_average.asc'}),
	('Note (décroissante)', {'movie': 'vote_average.desc', 'tv': 'vote_average.desc'}),
	('Votes (croissants)', {'movie': 'vote_count.asc', 'tv': 'vote_count.asc'}),
	('Votes (décroissants)', {'movie': 'vote_count.desc', 'tv': 'vote_count.desc'}),
)

TV_TYPES = (
	('Documentaire', '0'), ('Actualités', '1'), ('Mini-série', '2'),
	('Télé-réalité', '3'), ('Scénarisée', '4'), ('Talk-show', '5'), ('Vidéo', '6')
)
TV_STATUS = (
	('En cours', '0'), ('Planifiée', '1'), ('En production', '2'),
	('Terminée', '3'), ('Annulée', '4'), ('Pilote', '5')
)
MOVIE_RELEASE_TYPES = (
	('Première', '1'), ('Cinéma (limité)', '2'), ('Cinéma', '3'),
	('Numérique', '4'), ('Physique', '5'), ('Télévision', '6')
)
MONETIZATION_TYPES = (
	('Abonnement', 'flatrate'), ('Gratuit', 'free'), ('Avec publicités', 'ads'),
	('Location', 'rent'), ('Achat', 'buy')
)


def _is_true(value):
	return str(value or '').strip().lower() in ('1', 'true', 'yes', 'on')


def _plain(value):
	return ' '.join(str(value or '').replace('[B]', '').replace('[/B]', '').split())


class Discover:
	def __init__(self, params):
		self.params = dict(params or {})
		self.params_get = self.params.get
		self.catalogue_only = _is_true(self.params_get('catalogue_only'))
		self.scope = 'alkopaste' if self.catalogue_only else 'tmdb'
		self.state_property = '%s%s' % (TMDB_DISCOVER_STATE_PREFIX, self.scope)
		self.handle = int(sys.argv[1]) if len(sys.argv) > 1 and str(sys.argv[1]).lstrip('-').isdigit() else -1
		self._discover_modal_active = False
		self._discover_dialog = None

	# -------------------------------------------------------------------------
	# Dossier Discover / recherches enregistrées
	# -------------------------------------------------------------------------
	def catalogue(self):
		self._add_dir(self._scope_params({'mode': 'discover.new', 'name': 'Nouveau...', 'list_name': 'Nouveau...'}),
			'Nouveau...', ADVANCED_DISCOVER_ICON, True)
		for row in self._saved_rows(self.scope):
			config = dict((row or {}).get('config') or {})
			name = _plain((row or {}).get('name') or self._default_name(config))
			result_params = self._result_params(config, name=name)
			saved_id = str((row or {}).get('id') or '')
			delete_url = build_url(self._scope_params({'mode': 'discover.delete_saved', 'saved_id': saved_id, 'name': name}))
			context = [('Supprimer cette recherche', 'RunPlugin(%s)' % delete_url)] if saved_id else []
			self._add_dir(result_params, name, self._saved_icon(config), True, context_items=context, editor_context=True)
		self._finish('Découvrir alkoPaste' if self.catalogue_only else 'Découvrir TMDb')

	def saved(self):
		# Compatibilité avec les raccourcis créés pendant les versions de test 2.2.x.
		return self.catalogue()

	def _saved_rows(self, scope=None):
		rows = MainCache().get(TMDB_DISCOVER_SAVED_KEY)
		rows = list(rows) if isinstance(rows, list) else []
		if scope is not None:
			rows = [i for i in rows if str((i or {}).get('scope') or 'tmdb') == str(scope)]
		return rows

	def _saved_set(self, rows):
		MainCache().set(TMDB_DISCOVER_SAVED_KEY, list(rows or []), expiration=timedelta(days=3650))

	def _saved_icon(self, config):
		media_type = str((config or {}).get('media_type') or 'movie')
		if media_type == 'movie': return kodi_utils.media_path('movies.png')
		if media_type == 'tv': return kodi_utils.media_path('tv.png')
		return kodi_utils.media_path('lists.png')

	def delete_saved(self):
		saved_id = str(self.params_get('saved_id') or '')
		all_rows = self._saved_rows()
		new_rows = [i for i in all_rows if str((i or {}).get('id') or '') != saved_id]
		if len(new_rows) != len(all_rows):
			self._saved_set(new_rows)
			kodi_utils.notification('Recherche supprimée')
		kodi_utils.container_refresh()

	# -------------------------------------------------------------------------
	# État / modal : modèle identique au Discover Trakt (stable dans Kodi)
	# -------------------------------------------------------------------------
	def _defaults(self):
		return {
			'media_type': 'movie',
			'hide_watched': False,
		}

	def _state_get(self):
		try:
			config = json.loads(kodi_utils.get_property(self.state_property) or '{}')
		except Exception:
			config = {}
		if not isinstance(config, dict): config = {}
		if not config:
			config = self._defaults()
			self._state_set(config)
		return config

	def _state_set(self, config):
		kodi_utils.set_property(self.state_property, json.dumps(dict(config or {}), ensure_ascii=False, sort_keys=True))

	def _state_reset(self):
		config = self._defaults()
		self._state_set(config)
		return config

	def _scope_params(self, params=None):
		params = dict(params or {})
		if self.catalogue_only: params['catalogue_only'] = 'true'
		else: params.pop('catalogue_only', None)
		return params

	def _run_dialog(self, reset=False):
		if reset: self._state_reset()
		try:
			from windows.tmdb_discover import TMDbDiscoverDialog
			dialog = TMDbDiscoverDialog('DialogSelect.xml', kodi_utils.get_addoninfo('path'), controller=self)
			self._discover_modal_active = True
			self._discover_dialog = dialog
			dialog.doModal()
			result = dialog.result
		except Exception as exc:
			kodi_utils.logger('TMDb Discover', 'modal failed: %s' % exc)
			result = None
		finally:
			self._discover_modal_active = False
			self._discover_dialog = None
			try: del dialog
			except Exception: pass
		return result

	def new(self):
		result = self._run_dialog(reset=True)
		if result:
			action, value = result
			if action == 'export' and value: self._export_current(value)
		# Important : exactement comme Discover Trakt, fermer le modal reconstruit
		# le dossier Discover courant. Aucun ActivateWindow/Container.Update ici.
		return self.catalogue()

	def editor(self):
		result = self._run_dialog(reset=False)
		if result:
			action, value = result
			if action == 'export' and value: self._export_current(value)
		return self.catalogue()

	def _refresh_modal(self, action=None):
		if self._discover_modal_active and self._discover_dialog is not None:
			try: return self._discover_dialog.refresh(select_action=action)
			except Exception as exc: kodi_utils.logger('TMDb Discover', 'refresh failed: %s' % exc)

	def discover_reset(self):
		self._state_reset()
		self._refresh_modal('media_type')

	def discover_save(self):
		config = self._state_get()
		default_name = self._default_name(config)
		name = kodi_utils.dialog.input('Nom de la recherche Discover', defaultt=default_name)
		if not name or not str(name).strip(): return False
		name = _plain(name)
		rows = self._saved_rows()
		saved_id = str(time.time_ns()) if hasattr(time, 'time_ns') else str(int(time.time() * 1000000))
		rows.insert(0, {'id': saved_id, 'scope': self.scope, 'name': name, 'config': config})
		self._saved_set(rows[:150])
		kodi_utils.notification('Recherche Discover enregistrée')
		return True

	def _export_current(self, target='menu'):
		config = self._state_get()
		item = self._result_params(config, name=self._default_name(config))
		name = item.get('name') or 'Discover TMDb'
		mode = 'menu_editor.shortcut_folder_add_item' if str(target) == 'folder' else 'menu_editor.add_external'
		url_params = {
			'mode': mode, 'name': name,
			'menu_item': json.dumps(item, ensure_ascii=False),
			'iconImage': ADVANCED_DISCOVER_ICON
		}
		kodi_utils.execute_builtin('RunPlugin(%s)' % build_url(url_params))
		return True

	# -------------------------------------------------------------------------
	# Lignes de la fenêtre : ordre calqué sur TMDb Helper
	# -------------------------------------------------------------------------
	def modal_rows(self):
		config = self._state_get()
		media_type = config.get('media_type', 'movie')
		rows = []
		add = rows.append
		type_icon = 'movies.png' if media_type == 'movie' else ('tv.png' if media_type == 'tv' else 'lists.png')
		add(self._row('media_type', 'Type', self._media_label(media_type), type_icon))
		add(self._row('sort_by', 'Tri', self._label(config, 'sort_by'), 'filter.png'))
		add(self._row('with_companies', 'Avec studios', self._label(config, 'with_companies'), 'filter.png'))
		if media_type == 'tv': add(self._row('with_networks', 'Avec diffuseurs', self._label(config, 'with_networks'), 'networks.png'))
		add(self._row('with_keywords', 'Avec mots-clés', self._label(config, 'with_keywords'), 'search.png'))
		add(self._row('without_keywords', 'Sans mots-clés', self._label(config, 'without_keywords'), 'search.png'))
		if media_type == 'movie':
			add(self._row('with_cast', 'Avec acteurs', self._label(config, 'with_cast'), 'people.png'))
			add(self._row('with_crew', 'Avec équipe technique', self._label(config, 'with_crew'), 'people.png'))
			add(self._row('with_people', 'Avec personnes', self._label(config, 'with_people'), 'people.png'))
		add(self._row('with_genres', 'Avec genres', self._label(config, 'with_genres'), 'genres.png'))
		add(self._row('without_genres', 'Sans genres', self._label(config, 'without_genres'), 'genres.png'))
		add(self._row('watch_region', 'Région de visionnage', self._label(config, 'watch_region'), 'world.png'))
		add(self._row('with_watch_providers', 'Avec fournisseur de visionnage', self._label(config, 'with_watch_providers'), 'justwatch.png'))
		add(self._row('with_watch_monetization_types', 'Type de disponibilité', self._label(config, 'with_watch_monetization_types'), 'justwatch.png'))
		if media_type == 'movie':
			add(self._row('region', 'Région de sortie', self._label(config, 'region'), 'world.png'))
			add(self._row('with_release_type', 'Type de sortie', self._label(config, 'with_release_type'), 'calendar.png'))
		elif media_type == 'tv':
			add(self._row('with_type', 'Type de série', self._label(config, 'with_type'), 'tv.png'))
			add(self._row('with_status', 'Statut', self._label(config, 'with_status'), 'tv.png'))
		add(self._row('year', 'Année de sortie principale' if media_type == 'movie' else ('Année de première diffusion' if media_type == 'tv' else 'Année'), self._label(config, 'year'), 'calender.png'))
		add(self._row('primary_date_gte', 'Date principale après', self._label(config, 'primary_date_gte'), 'calender.png'))
		add(self._row('primary_date_lte', 'Date principale avant', self._label(config, 'primary_date_lte'), 'calender.png'))
		add(self._row('release_date_gte', 'Date de sortie après' if media_type == 'movie' else ('Date de diffusion après' if media_type == 'tv' else 'Date après'), self._label(config, 'release_date_gte'), 'calender.png'))
		add(self._row('release_date_lte', 'Date de sortie avant' if media_type == 'movie' else ('Date de diffusion avant' if media_type == 'tv' else 'Date avant'), self._label(config, 'release_date_lte'), 'calender.png'))
		if media_type == 'tv': add(self._row('timezone', 'Fuseau horaire', self._label(config, 'timezone'), 'world.png'))
		add(self._row('with_origin_country', "Pays d'origine", self._label(config, 'with_origin_country'), 'world.png'))
		add(self._row('with_original_language', 'Avec langue originale', self._label(config, 'with_original_language'), 'languages.png'))
		if media_type == 'movie':
			add(self._row('certification_country', 'Pays de certification', self._label(config, 'certification_country'), 'filter.png'))
			add(self._row('certification', 'Certification', self._label(config, 'certification'), 'filter.png'))
			add(self._row('certification_gte', 'Certification minimum', self._label(config, 'certification_gte'), 'filter.png'))
			add(self._row('certification_lte', 'Certification maximum', self._label(config, 'certification_lte'), 'filter.png'))
		add(self._row('vote_average', 'Notes', self._label(config, 'vote_average'), 'star.png'))
		add(self._row('vote_count_gte', 'Nombre de votes minimum', self._label(config, 'vote_count_gte'), 'star.png'))
		add(self._row('vote_count_lte', 'Nombre de votes maximum', self._label(config, 'vote_count_lte'), 'star.png'))
		add(self._row('runtime', 'Durée', self._label(config, 'runtime'), 'calendar2.png'))
		add(self._row('hide_watched', 'Médias non vus seulement', 'Oui' if bool(config.get('hide_watched')) else 'Non', 'eye-slash.png'))
		# Extensions alkoFlix demandées : même accès que Discover Trakt.
		add(self._row('save', 'Enregistrer', '', 'favourites.png'))
		add(self._row('export_menu', 'Ajouter au menu', '', 'item_jump.png'))
		add(self._row('export_folder', 'Ajouter à un dossier personnel', '', 'folder.png'))
		return rows

	def _row(self, action, label, value='', icon=''):
		value = _plain(value)
		return {'action': action, 'label': '%s : %s' % (label, value) if value else label, 'icon': icon}

	def _label(self, config, key):
		return str(config.get('%s_label' % key) or '')

	def _media_label(self, media_type):
		return {'movie': 'Films', 'tv': 'Séries', 'combined': 'Combiné'}.get(str(media_type), 'Films')

	# -------------------------------------------------------------------------
	# Handlers des routes Discover
	# -------------------------------------------------------------------------
	def discover_media_type(self):
		config = self._state_get()
		values = ['movie', 'tv', 'combined']
		labels = ['Films', 'Séries', 'Combiné']
		try: preselect = values.index(config.get('media_type'))
		except Exception: preselect = 0
		choice = kodi_utils.dialog.select('Type', labels, preselect=preselect)
		if choice < 0: return
		config['media_type'] = values[choice]
		self._state_set(config)
		self._refresh_modal('media_type')

	def discover_sort_by(self):
		config = self._state_get(); media_type = config.get('media_type', 'movie')
		options = MOVIE_SORTS if media_type == 'movie' else TV_SORTS if media_type == 'tv' else COMBINED_SORTS
		self._select_route(config, 'sort_by', 'Tri', options)

	def discover_with_companies(self): return self._search_entity_route('with_companies', 'Studios', 'company')
	def discover_with_keywords(self): return self._search_entity_route('with_keywords', 'Mots-clés', 'keyword')
	def discover_without_keywords(self): return self._search_entity_route('without_keywords', 'Mots-clés exclus', 'keyword')
	def discover_with_cast(self): return self._search_entity_route('with_cast', 'Acteurs', 'person')
	def discover_with_crew(self): return self._search_entity_route('with_crew', 'Équipe technique', 'person')
	def discover_with_people(self): return self._search_entity_route('with_people', 'Personnes', 'person')

	def discover_with_networks(self):
		config = self._state_get()
		query = kodi_utils.dialog.input('Diffuseur', defaultt='')
		if query is None: return
		query = str(query or '').strip().lower()
		items = [i for i in meta_lists.networks if not query or query in str(i.get('name') or '').lower()]
		items = sorted(items, key=lambda x: str(x.get('name') or '').lower())
		options = [(str(i.get('name') or ''), str(i.get('id') or '')) for i in items if i.get('id')]
		self._multi_route(config, 'with_networks', 'Diffuseurs', options, default_separator='|')

	def discover_with_genres(self): return self._genre_route('with_genres', 'Genres à inclure')
	def discover_without_genres(self): return self._genre_route('without_genres', 'Genres à exclure')

	def discover_watch_region(self):
		config = self._state_get()
		regions = self._provider_regions()
		options = [(i['name'], i['code']) for i in regions]
		self._select_route(config, 'watch_region', 'Région de visionnage', options, default_value=certification_country() or 'FR')

	def _ensure_single_route(self, config, key, title, options, default_value=None):
		if config.get(key) not in ('', None): return True
		labels = [str(i[0]) for i in options]; values = [i[1] for i in options]
		preselect = 0
		if default_value not in ('', None):
			for idx, value in enumerate(values):
				if value == default_value: preselect = idx; break
		choice = kodi_utils.dialog.select(title, labels, preselect=preselect)
		if choice < 0: return False
		label, value = options[choice]
		config[key] = value; config['%s_label' % key] = str(label)
		self._state_set(config)
		return True

	def discover_with_watch_providers(self):
		config = self._state_get(); media_type = config.get('media_type', 'movie')
		if not self._ensure_single_route(config, 'watch_region', 'Région de visionnage', [(i['name'], i['code']) for i in self._provider_regions()], certification_country() or 'FR'): return
		config = self._state_get()
		region = str(config.get('watch_region') or certification_country() or 'FR').upper()
		providers = self._providers(media_type, region)
		if not providers:
			return kodi_utils.notification('Aucun fournisseur disponible pour cette région')
		labels, values, listitems = [], [], []
		for item in providers:
			name = str(item.get('provider_name') or '')
			pid = str(item.get('provider_id') or '')
			if not name or not pid: continue
			labels.append(name); values.append(pid)
			li = make_listitem(); li.setLabel(name); li.setLabel2('ID #%s' % pid)
			logo = str(item.get('logo_path') or '')
			if logo: li.setArt({'icon': 'https://image.tmdb.org/t/p/original%s' % logo, 'thumb': 'https://image.tmdb.org/t/p/original%s' % logo})
			listitems.append(li)
		current = self._selection_values(config, 'with_watch_providers')
		preselect = [idx for idx, value in enumerate(values) if value in current]
		choice = kodi_utils.dialog.multiselect('Fournisseurs de visionnage', listitems, preselect=preselect, useDetails=True)
		if choice is None: return
		if not choice:
			self._clear_route(config, 'with_watch_providers'); return
		selected_values = [values[i] for i in choice]
		selected_labels = [labels[i] for i in choice]
		separator = self._choose_separator(config, 'with_watch_providers', len(selected_values), default='|')
		if separator is None: return
		config['with_watch_providers'] = separator.join(selected_values)
		config['with_watch_providers_label'] = self._join_labels(selected_labels, separator)
		config['with_watch_providers_selection'] = selected_values
		self._state_set(config); self._refresh_modal('with_watch_providers')

	def discover_with_watch_monetization_types(self):
		config = self._state_get()
		if not self._ensure_single_route(config, 'watch_region', 'Région de visionnage', [(i['name'], i['code']) for i in self._provider_regions()], certification_country() or 'FR'): return
		config = self._state_get()
		self._multi_route(config, 'with_watch_monetization_types', 'Type de disponibilité', MONETIZATION_TYPES, default_separator='|')

	def discover_region(self):
		config = self._state_get(); options = [(i['name'], i['code']) for i in self._countries()]
		self._select_route(config, 'region', 'Région de sortie', options, default_value=certification_country() or 'FR')

	def discover_with_type(self):
		config = self._state_get(); self._multi_route(config, 'with_type', 'Type de série', TV_TYPES, default_separator='|')

	def discover_with_release_type(self):
		config = self._state_get()
		if not self._ensure_single_route(config, 'region', 'Région de sortie', [(i['name'], i['code']) for i in self._countries()], certification_country() or 'FR'): return
		config = self._state_get()
		self._multi_route(config, 'with_release_type', 'Type de sortie', MOVIE_RELEASE_TYPES, default_separator='|')

	def discover_with_status(self):
		config = self._state_get(); self._multi_route(config, 'with_status', 'Statut', TV_STATUS, default_separator='|')

	def discover_year(self):
		config = self._state_get()
		years = [str(i) for i in meta_lists.years()]
		options = [(i, i) for i in years]
		self._select_route(config, 'year', 'Année', options)

	def discover_primary_date_gte(self): return self._date_route('primary_date_gte', 'Date principale après')
	def discover_primary_date_lte(self): return self._date_route('primary_date_lte', 'Date principale avant')
	def discover_release_date_gte(self): return self._date_route('release_date_gte', 'Date après')
	def discover_release_date_lte(self): return self._date_route('release_date_lte', 'Date avant')

	def discover_timezone(self):
		config = self._state_get()
		zones = self._timezones()
		countries = sorted(zones.keys(), key=lambda x: x[1].lower())
		country_labels = ['%s (%s)' % (name, code) for code, name in countries]
		choice = kodi_utils.dialog.select('Pays', country_labels)
		if choice < 0: return
		country_code, _ = countries[choice]
		zone_values = zones.get((country_code, countries[choice][1])) or []
		choice2 = kodi_utils.dialog.select('Fuseau horaire', zone_values)
		if choice2 < 0: return
		value = zone_values[choice2]
		config['timezone'] = value; config['timezone_label'] = value
		self._state_set(config); self._refresh_modal('timezone')

	def discover_with_origin_country(self):
		config = self._state_get(); options = [(i['name'], i['code']) for i in self._countries()]
		self._select_route(config, 'with_origin_country', "Pays d'origine", options)

	def discover_with_original_language(self):
		config = self._state_get(); options = [(i['name'], i['code']) for i in self._languages()]
		self._multi_route(config, 'with_original_language', 'Langue originale', options, default_separator='|')

	def discover_certification_country(self):
		config = self._state_get()
		countries = self._certification_countries()
		options = [(name, code) for code, name in countries]
		old = str(config.get('certification_country') or '')
		self._select_route(config, 'certification_country', 'Pays de certification', options, default_value=certification_country() or 'FR')
		config = self._state_get()
		if str(config.get('certification_country') or '') != old:
			for key in ('certification', 'certification_gte', 'certification_lte'):
				self._clear_route(config, key, refresh=False)
			self._state_set(config); self._refresh_modal('certification_country')

	def discover_certification(self): return self._certification_route('certification', 'Certification', clear_keys=('certification_gte', 'certification_lte'))
	def discover_certification_gte(self): return self._certification_route('certification_gte', 'Certification minimum', clear_keys=('certification',))
	def discover_certification_lte(self): return self._certification_route('certification_lte', 'Certification maximum', clear_keys=('certification',))

	def discover_vote_average(self):
		config = self._state_get()
		values = [x / 2.0 for x in range(0, 21)]
		labels = [('%g' % v) for v in values]
		current_min = str(config.get('vote_average_gte') or '')
		current_max = str(config.get('vote_average_lte') or '')
		result = self._select_range('Notes', [str(v) for v in values], labels, current_min, current_max)
		if result is None: return
		minimum, maximum = result
		for key in ('vote_average_gte', 'vote_average_lte', 'vote_average_label'):
			config.pop(key, None)
		if minimum:
			config['vote_average_gte'] = minimum
			if maximum: config['vote_average_lte'] = maximum
			config['vote_average_label'] = '%s à %s' % (minimum, maximum) if maximum else '%s et +' % minimum
		self._state_set(config); self._refresh_modal('vote_average')

	def discover_vote_count_gte(self): return self._numeric_route('vote_count_gte', 'Votes minimum')
	def discover_vote_count_lte(self): return self._numeric_route('vote_count_lte', 'Votes maximum')

	def discover_runtime(self):
		config = self._state_get()
		values = [str(i) for i in range(0, 361, 5)]
		labels = [self._runtime_label(int(i)) for i in values]
		result = self._select_range('Durée', values, labels, str(config.get('runtime_gte') or ''), str(config.get('runtime_lte') or ''))
		if result is None: return
		minimum, maximum = result
		for key in ('runtime_gte', 'runtime_lte', 'runtime_label'): config.pop(key, None)
		if minimum:
			config['runtime_gte'] = minimum
			if maximum: config['runtime_lte'] = maximum
			min_label = self._runtime_label(int(float(minimum)))
			max_label = self._runtime_label(int(float(maximum))) if maximum else ''
			config['runtime_label'] = '%s à %s' % (min_label, max_label) if max_label else '%s et +' % min_label
		self._state_set(config); self._refresh_modal('runtime')

	def discover_hide_watched(self):
		config = self._state_get(); config['hide_watched'] = not bool(config.get('hide_watched', False))
		self._state_set(config); self._refresh_modal('hide_watched')

	# -------------------------------------------------------------------------
	# Helpers UI / données de configuration TMDb
	# -------------------------------------------------------------------------
	def _select_route(self, config, key, title, options, default_value=None):
		labels = ['Aucun filtre'] + [str(i[0]) for i in options]
		values = [i[1] for i in options]
		current = config.get(key) if config.get(key) not in ('', None) else default_value
		preselect = 0
		for idx, value in enumerate(values):
			if value == current:
				preselect = idx + 1; break
		choice = kodi_utils.dialog.select(title, labels, preselect=preselect)
		if choice < 0: return
		if choice == 0:
			self._clear_route(config, key); return
		label, value = options[choice - 1]
		config[key] = value; config['%s_label' % key] = str(label)
		self._state_set(config); self._refresh_modal(key)

	def _multi_route(self, config, key, title, options, default_separator='|'):
		labels = [str(i[0]) for i in options]; values = [str(i[1]) for i in options]
		current = self._selection_values(config, key)
		preselect = [idx for idx, value in enumerate(values) if value in current]
		choice = kodi_utils.dialog.multiselect(title, labels, preselect=preselect)
		if choice is None: return
		if not choice:
			self._clear_route(config, key); return
		selected_values = [values[i] for i in choice]
		selected_labels = [labels[i] for i in choice]
		separator = self._choose_separator(config, key, len(selected_values), default=default_separator)
		if separator is None: return
		config[key] = separator.join(selected_values)
		config['%s_label' % key] = self._join_labels(selected_labels, separator)
		config['%s_selection' % key] = selected_values
		self._state_set(config); self._refresh_modal(key)

	def _selection_values(self, config, key):
		selection = config.get('%s_selection' % key)
		if isinstance(selection, list): return [str(i) for i in selection]
		value = config.get(key)
		if isinstance(value, dict):
			value = value.get('movie') or value.get('tv') or ''
		return [i for i in str(value or '').replace('%2C', ',').replace('%7C', '|').replace(',', '|').split('|') if i]

	def _choose_separator(self, config, key, count, default='|'):
		if count < 2: return default
		current = str(config.get(key) or '')
		preselect = 0 if ',' in current else 1
		choice = kodi_utils.dialog.select('Combinaison', ['Tous (ET)', 'Au moins un (OU)'], preselect=preselect)
		if choice < 0: return None
		return ',' if choice == 0 else '|'

	def _join_labels(self, labels, separator):
		return (' ET ' if separator == ',' else ' OU ').join(labels)

	def _clear_route(self, config, key, refresh=True):
		for suffix in ('', '_label', '_selection'):
			config.pop('%s%s' % (key, suffix), None)
		if refresh:
			self._state_set(config); self._refresh_modal(key)

	def _date_route(self, key, title):
		config = self._state_get()
		value = kodi_utils.dialog.input('%s (AAAA-MM-JJ)' % title, defaultt=str(config.get(key) or ''))
		if value is None: return
		value = str(value or '').strip()
		if value:
			config[key] = value; config['%s_label' % key] = value
		else:
			self._clear_route(config, key, refresh=False)
		self._state_set(config); self._refresh_modal(key)

	def _numeric_route(self, key, title):
		config = self._state_get()
		value = kodi_utils.dialog.input(title, defaultt=str(config.get(key) or ''), type=kodi_utils.xbmcgui.INPUT_NUMERIC)
		if value is None: return
		value = str(value or '').strip()
		if value:
			config[key] = value; config['%s_label' % key] = value
		else:
			self._clear_route(config, key, refresh=False)
		self._state_set(config); self._refresh_modal(key)

	def _select_range(self, title, values, labels, current_min='', current_max=''):
		options = ['Aucun filtre'] + list(labels)
		try: pre_min = list(values).index(str(current_min)) + 1 if current_min else 0
		except Exception: pre_min = 0
		choice = kodi_utils.dialog.select('%s - minimum' % title, options, preselect=pre_min)
		if choice < 0: return None
		if choice == 0: return ('', '')
		minimum = str(values[choice - 1])
		try: min_num = float(minimum)
		except Exception: min_num = None
		valid = []
		for value, label in zip(values, labels):
			try:
				if min_num is not None and float(value) < min_num: continue
			except Exception: pass
			valid.append((str(value), str(label)))
		max_values = [i[0] for i in valid]
		max_labels = ['Sans maximum'] + [i[1] for i in valid]
		try: pre_max = max_values.index(str(current_max)) + 1 if current_max else 0
		except Exception: pre_max = 0
		choice2 = kodi_utils.dialog.select('%s - maximum' % title, max_labels, preselect=pre_max)
		if choice2 < 0: return None
		maximum = max_values[choice2 - 1] if choice2 > 0 else ''
		return minimum, maximum

	def _runtime_label(self, minutes):
		hours, mins = divmod(int(minutes), 60)
		return '%dh %02d min' % (hours, mins)

	def _genre_route(self, key, title):
		config = self._state_get(); media_type = config.get('media_type', 'movie')
		movie = self._genres('movie'); tv = self._genres('tv')
		if media_type == 'movie':
			options = [(i['name'], str(i['id'])) for i in movie]
			return self._multi_route(config, key, title, options, default_separator='|')
		if media_type == 'tv':
			options = [(i['name'], str(i['id'])) for i in tv]
			return self._multi_route(config, key, title, options, default_separator='|')
		# Combiné : seuls les genres ayant le même ID des deux côtés sont proposés.
		movie_by_id = {str(i['id']): i['name'] for i in movie}
		tv_by_id = {str(i['id']): i['name'] for i in tv}
		common_ids = sorted(set(movie_by_id).intersection(tv_by_id), key=lambda x: movie_by_id[x].lower())
		options = [(movie_by_id[i], i) for i in common_ids]
		return self._multi_route(config, key, title, options, default_separator='|')

	def _search_entity_route(self, key, title, entity_type):
		config = self._state_get()
		# Si le filtre existe, l'utilisateur peut l'effacer sans devoir réinitialiser tout Discover.
		if config.get(key):
			choice = kodi_utils.dialog.select(title, ['Ajouter / modifier', 'Effacer le filtre'])
			if choice < 0: return
			if choice == 1:
				self._clear_route(config, key); return
		query = kodi_utils.dialog.input(title)
		if not query: return
		results = self._search_entities(entity_type, query)
		if not results:
			return kodi_utils.notification('Aucun résultat')
		labels = [i['name'] for i in results]
		values = [str(i['id']) for i in results]
		choice = kodi_utils.dialog.multiselect(title, labels)
		if choice is None or not choice: return
		new_values = [values[i] for i in choice]
		new_labels = [labels[i] for i in choice]
		old_values = self._selection_values(config, key)
		old_labels = self._label(config, key)
		for value in new_values:
			if value not in old_values: old_values.append(value)
		label_parts = [i.strip() for i in str(old_labels or '').replace(' ET ', '|').replace(' OU ', '|').split('|') if i.strip()]
		for label in new_labels:
			if label not in label_parts: label_parts.append(label)
		separator = self._choose_separator(config, key, len(old_values), default='|')
		if separator is None: return
		config[key] = separator.join(old_values)
		config['%s_selection' % key] = old_values
		config['%s_label' % key] = self._join_labels(label_parts, separator)
		self._state_set(config); self._refresh_modal(key)

	def _certification_route(self, key, title, clear_keys=()):
		config = self._state_get()
		if not self._ensure_single_route(config, 'certification_country', 'Pays de certification', [(name, code) for code, name in self._certification_countries()], certification_country() or 'FR'): return
		config = self._state_get()
		country = str(config.get('certification_country') or certification_country() or 'FR').upper()
		certs = self._certifications().get(country) or []
		options = [(str(i.get('certification') or ''), str(i.get('certification') or '')) for i in certs if i.get('certification')]
		self._select_route(config, key, title, options)
		config = self._state_get()
		if config.get(key):
			for other in clear_keys: self._clear_route(config, other, refresh=False)
			self._state_set(config); self._refresh_modal(key)

	def _support(self, cache_key, path, expiration=168):
		url = '%s%s%sapi_key=%s' % (base_url, path, '&' if '?' in path else '?', tmdb_api_key())
		return cache_object(get_tmdb, 'tmdb_discover230_%s' % cache_key, url, expiration=expiration) or {}

	def _genres(self, media_type):
		language = get_language() or 'fr-FR'
		data = self._support('genres_%s_%s' % (media_type, language), '/genre/%s/list?language=%s' % (media_type, language), 168)
		return sorted(list(data.get('genres') or []), key=lambda x: str(x.get('name') or '').lower()) if isinstance(data, dict) else []

	def _countries(self):
		language = get_language() or 'fr-FR'
		data = self._support('countries_%s' % language, '/configuration/countries?language=%s' % language, 672)
		rows = data if isinstance(data, list) else []
		result = []
		for item in rows:
			code = str(item.get('iso_3166_1') or '').upper(); name = str(item.get('native_name') or item.get('english_name') or code)
			if code: result.append({'code': code, 'name': name})
		if not result: result = [{'code': i['code'], 'name': i['name']} for i in meta_lists.regions]
		return sorted(result, key=lambda x: x['name'].lower())

	def _languages(self):
		data = self._support('languages', '/configuration/languages', 672)
		rows = data if isinstance(data, list) else []
		result = []
		for item in rows:
			code = str(item.get('iso_639_1') or '').lower(); name = str(item.get('name') or item.get('english_name') or code)
			if code: result.append({'code': code, 'name': name})
		if not result: result = [{'code': i[1], 'name': i[0]} for i in meta_lists.languages]
		return sorted(result, key=lambda x: x['name'].lower())

	def _provider_regions(self):
		data = self._support('provider_regions', '/watch/providers/regions', 672)
		rows = data.get('results') or [] if isinstance(data, dict) else []
		result = []
		for item in rows:
			code = str(item.get('iso_3166_1') or '').upper(); name = str(item.get('native_name') or item.get('english_name') or code)
			if code: result.append({'code': code, 'name': name})
		if not result: return self._countries()
		return sorted(result, key=lambda x: x['name'].lower())

	def _providers(self, media_type, region):
		region = str(region or 'FR').upper()
		def one(kind):
			data = self._support('providers_%s' % kind, '/watch/providers/%s' % kind, 168)
			rows = data.get('results') or [] if isinstance(data, dict) else []
			rows = [i for i in rows if region in (i.get('display_priorities') or {})]
			return rows
		if media_type == 'movie': rows = one('movie')
		elif media_type == 'tv': rows = one('tv')
		else:
			movie = {str(i.get('provider_id')): i for i in one('movie')}
			tv = {str(i.get('provider_id')): i for i in one('tv')}
			rows = [movie[i] for i in set(movie).intersection(tv)]
		return sorted(rows, key=lambda i: ((i.get('display_priorities') or {}).get(region, 99999), str(i.get('provider_name') or '').lower()))

	def _timezones(self):
		data = self._support('timezones', '/configuration/timezones', 672)
		rows = data if isinstance(data, list) else []
		country_names = {i['code']: i['name'] for i in self._countries()}
		result = {}
		for item in rows:
			code = str(item.get('iso_3166_1') or '').upper(); zones = list(item.get('zones') or [])
			if code and zones: result[(code, country_names.get(code, code))] = zones
		return result

	def _certifications(self):
		data = self._support('movie_certifications', '/certification/movie/list', 672)
		return data.get('certifications') or {} if isinstance(data, dict) else {}

	def _certification_countries(self):
		certs = self._certifications(); names = {i['code']: i['name'] for i in self._countries()}
		return sorted([(code, names.get(code, code)) for code in certs.keys()], key=lambda x: x[1].lower())

	def _search_entities(self, entity_type, query):
		url = '%s/search/%s?api_key=%s&query=%s&language=%s&page=1' % (base_url, entity_type, tmdb_api_key(), quote_plus(str(query)), get_language() or 'fr-FR')
		try: data = get_tmdb(url) or {}
		except Exception: data = {}
		rows = data.get('results') or [] if isinstance(data, dict) else []
		result = []
		for item in rows[:40]:
			name = str(item.get('name') or item.get('title') or '').strip(); iid = item.get('id')
			if name and iid is not None: result.append({'name': name, 'id': iid})
		return result

	# -------------------------------------------------------------------------
	# Construction des routes résultats
	# -------------------------------------------------------------------------
	def _default_name(self, config):
		return 'Discover TMDb - %s' % self._media_label((config or {}).get('media_type', 'movie'))

	def _value_for_media(self, value, media_type):
		if isinstance(value, dict): return value.get(media_type) or ''
		return value

	def _resolve_date_value(self, value):
		value = str(value or '').strip()
		if len(value) >= 3 and value[:1].lower() == 't' and value[1:2] in ('+', '-'):
			try:
				from datetime import datetime, timedelta
				days = int(value[2:]); days = -abs(days) if value[1] == '-' else abs(days)
				return (datetime.now() + timedelta(days=days)).strftime('%Y-%m-%d')
			except Exception: pass
		return value

	def _query_params(self, config, media_type):
		params = {'api_key': tmdb_api_key(), 'language': get_language() or 'fr-FR'}
		# Filtres communs
		for key in ('with_companies', 'with_keywords', 'without_keywords', 'watch_region', 'with_watch_providers',
			'with_watch_monetization_types', 'with_origin_country', 'with_original_language'):
			value = self._value_for_media(config.get(key), media_type)
			if value not in ('', None): params[key] = value
		for key in ('with_genres', 'without_genres'):
			value = self._value_for_media(config.get(key), media_type)
			if value not in ('', None): params[key] = value

		# Tri
		sort_value = self._value_for_media(config.get('sort_by'), media_type)
		if sort_value: params['sort_by'] = sort_value

		# Année et dates : les noms de paramètres diffèrent entre Films et Séries.
		year = config.get('year')
		if year: params['primary_release_year' if media_type == 'movie' else 'first_air_date_year'] = year
		primary_gte = config.get('primary_date_gte'); primary_lte = config.get('primary_date_lte')
		release_gte = config.get('release_date_gte'); release_lte = config.get('release_date_lte')
		if primary_gte: params['primary_release_date.gte' if media_type == 'movie' else 'first_air_date.gte'] = self._resolve_date_value(primary_gte)
		if primary_lte: params['primary_release_date.lte' if media_type == 'movie' else 'first_air_date.lte'] = self._resolve_date_value(primary_lte)
		if release_gte: params['release_date.gte' if media_type == 'movie' else 'air_date.gte'] = self._resolve_date_value(release_gte)
		if release_lte: params['release_date.lte' if media_type == 'movie' else 'air_date.lte'] = self._resolve_date_value(release_lte)

		# Notes / votes / durée
		if config.get('vote_average_gte'): params['vote_average.gte'] = config['vote_average_gte']
		if config.get('vote_average_lte'): params['vote_average.lte'] = config['vote_average_lte']
		if config.get('vote_count_gte'): params['vote_count.gte'] = config['vote_count_gte']
		if config.get('vote_count_lte'): params['vote_count.lte'] = config['vote_count_lte']
		if config.get('runtime_gte'): params['with_runtime.gte'] = config['runtime_gte']
		if config.get('runtime_lte'): params['with_runtime.lte'] = config['runtime_lte']

		if media_type == 'movie':
			for key in ('region', 'with_release_type', 'certification_country', 'certification'):
				if config.get(key): params[key] = config[key]
			if config.get('certification_gte'): params['certification.gte'] = config['certification_gte']
			if config.get('certification_lte'): params['certification.lte'] = config['certification_lte']
			for key in ('with_cast', 'with_crew', 'with_people'):
				if config.get(key): params[key] = config[key]
		else:
			for key in ('with_networks', 'with_type', 'with_status', 'timezone'):
				if config.get(key): params[key] = config[key]
		return params

	def _build_query(self, config, media_type):
		params = self._query_params(config, media_type)
		query = urlencode(params, doseq=False, safe=',|')
		return '%s/discover/%s?%s&page=%%s' % (base_url, media_type, query)

	def _result_params(self, config, name=None):
		config = dict(config or {})
		media_type = str(config.get('media_type') or 'movie')
		name = _plain(name or self._default_name(config))
		if media_type == 'movie':
			params = {'mode': 'build_movie_list', 'action': 'tmdb_movies_discover', 'query': self._build_query(config, 'movie')}
		elif media_type == 'tv':
			params = {'mode': 'build_tvshow_list', 'action': 'tmdb_tv_discover', 'query': self._build_query(config, 'tv')}
		else:
			params = {
				'mode': 'discover.combined_results',
				'movie_query': self._build_query(config, 'movie'),
				'tv_query': self._build_query(config, 'tv')
			}
		params.update({'name': name, 'iconImage': ADVANCED_DISCOVER_ICON})
		if bool(config.get('hide_watched')): params['discover_hide_watched'] = 'true'
		if self.catalogue_only: params['catalogue_only'] = 'true'
		return params

	# -------------------------------------------------------------------------
	# Résultats Combiné Films + Séries
	# -------------------------------------------------------------------------
	@staticmethod
	def _combined_interleave(movie_rows, tv_rows):
		result = []
		max_len = max(len(movie_rows or []), len(tv_rows or []))
		for idx in range(max_len):
			if idx < len(movie_rows or []):
				row = dict(movie_rows[idx] or {}); row['_discover_media_type'] = 'movie'; result.append(row)
			if idx < len(tv_rows or []):
				row = dict(tv_rows[idx] or {}); row['_discover_media_type'] = 'tvshow'; result.append(row)
		return result

	@staticmethod
	def _combined_item_tmdb_id(item):
		try:
			values = parse_qs(urlsplit(str(item[0])).query).get('tmdb_id') or []
			return str(values[0]) if values else ''
		except Exception: return ''

	def combined_results(self):
		from indexers.tmdb_api import tmdb_movies_discover, tmdb_tv_discover
		movie_query = str(self.params_get('movie_query') or '')
		tv_query = str(self.params_get('tv_query') or '')
		if not movie_query or not tv_query:
			return self.catalogue()
		try: page_no = max(1, int(self.params_get('new_page', '1') or 1))
		except Exception: page_no = 1
		try: page_size = max(1, int(settings.page_limit())) if settings.paginate() else 100
		except Exception: page_size = 20
		target_end = page_no * page_size
		pool, seen = [], set()
		source_page, movie_pages, tv_pages = 1, 1, 1
		movie_allowed = tv_allowed = None
		if self.catalogue_only:
			try:
				from magneto.alkopaste import alkopaste_catalogue_all_id_set
				movie_allowed = alkopaste_catalogue_all_id_set('film')
				tv_allowed = alkopaste_catalogue_all_id_set('serie')
			except Exception: pass
		while len(pool) <= target_end and source_page <= max(movie_pages, tv_pages, 1):
			movie_data = tmdb_movies_discover(movie_query, source_page) or {}
			tv_data = tmdb_tv_discover(tv_query, source_page) or {}
			try: movie_pages = max(movie_pages, int(movie_data.get('total_pages') or 1))
			except Exception: pass
			try: tv_pages = max(tv_pages, int(tv_data.get('total_pages') or 1))
			except Exception: pass
			movie_rows = list(movie_data.get('results') or []) if isinstance(movie_data, dict) else []
			tv_rows = list(tv_data.get('results') or []) if isinstance(tv_data, dict) else []
			if movie_allowed is not None: movie_rows = [i for i in movie_rows if str(i.get('id') or '') in movie_allowed]
			if tv_allowed is not None: tv_rows = [i for i in tv_rows if str(i.get('id') or '') in tv_allowed]
			for row in self._combined_interleave(movie_rows, tv_rows):
				key = (row.get('_discover_media_type'), str(row.get('id') or ''))
				if not key[1] or key in seen: continue
				seen.add(key); pool.append(row)
			source_page += 1
			if source_page > max(movie_pages, tv_pages): break
		start = (page_no - 1) * page_size
		page_data = pool[start:start + page_size]
		movie_ids = [str(i.get('id')) for i in page_data if i.get('_discover_media_type') == 'movie' and i.get('id')]
		tv_ids = [str(i.get('id')) for i in page_data if i.get('_discover_media_type') == 'tvshow' and i.get('id')]
		movie_items, tv_items = [], []
		common = {'name': self.params_get('name') or 'Discover TMDb - Combiné'}
		if self.params_get('discover_hide_watched') == 'true': common['discover_hide_watched'] = 'true'
		if self.catalogue_only: common['catalogue_only'] = 'true'
		try:
			if movie_ids:
				from menus.movies import Movies
				movie_items = Movies(dict(common, list=movie_ids, id_type='tmdb_id', action='tmdb_discover_combined_worker')).worker()
		except Exception as exc: kodi_utils.logger('Discover TMDb combiné films', str(exc))
		try:
			if tv_ids:
				from menus.tvshows import TVShows
				tv_items = TVShows(dict(common, list=tv_ids, id_type='tmdb_id', action='tmdb_discover_combined_worker')).worker()
		except Exception as exc: kodi_utils.logger('Discover TMDb combiné séries', str(exc))
		item_map = {}
		for item in movie_items or []:
			tmdb_id = self._combined_item_tmdb_id(item)
			if tmdb_id: item_map[('movie', tmdb_id)] = item
		for item in tv_items or []:
			tmdb_id = self._combined_item_tmdb_id(item)
			if tmdb_id: item_map[('tvshow', tmdb_id)] = item
		combined_items = []
		for row in page_data:
			item = item_map.get((row.get('_discover_media_type'), str(row.get('id') or '')))
			if item: combined_items.append(item)
		if combined_items: kodi_utils.add_items(self.handle, combined_items)
		has_more = len(pool) > target_end or source_page <= max(movie_pages, tv_pages)
		if has_more:
			next_params = dict(self.params); next_params['new_page'] = str(page_no + 1); next_params['mode'] = 'discover.combined_results'
			for key in ('handle', 'iconImage', 'isFolder'): next_params.pop(key, None)
			kodi_utils.add_dir(self.handle, next_params, kodi_utils.local_string(32799), iconImage=kodi_utils.media_path('item_next.png'))
		kodi_utils.set_category(self.handle, self.params_get('name') or 'Discover TMDb - Combiné')
		kodi_utils.set_sort_method(self.handle, 'tvshows'); kodi_utils.set_content(self.handle, 'tvshows')
		kodi_utils.end_directory(self.handle, False if kodi_utils.external_browse() else None)
		kodi_utils.set_view_mode('view.tvshows', 'tvshows')

	# -------------------------------------------------------------------------
	# Kodi directory helpers
	# -------------------------------------------------------------------------
	def _add_dir(self, params, label, icon, is_folder=True, context_items=None, editor_context=False):
		params = self._scope_params(params)
		icon = kodi_utils.resolve_icon_path(icon or ADVANCED_DISCOVER_ICON)
		url = build_url(params)
		li = make_listitem(); li.setLabel(str(label or ''))
		li.setArt({'icon': icon, 'poster': icon, 'thumb': icon, 'banner': icon})
		try:
			cm = []
			if editor_context: cm.extend(kodi_utils.menu_editor_context(params, label, icon, is_folder))
			if context_items: cm.extend(list(context_items))
			if cm: li.addContextMenuItems(cm, replaceItems=False)
		except Exception: pass
		kodi_utils.add_item(self.handle, url, li, is_folder)

	def _finish(self, category='Discover TMDb'):
		kodi_utils.set_category(self.handle, category)
		kodi_utils.set_content(self.handle, '')
		kodi_utils.end_directory(self.handle, cacheToDisc=False)
		kodi_utils.set_view_mode('view.main', '')


# -----------------------------------------------------------------------------
# Historique Discover historique utilisé par les builders Films/Séries.
# Conservé pour compatibilité interne, mais la nouvelle interface 2.3.0 utilise
# son propre stockage de recherches enregistrées.
# -----------------------------------------------------------------------------
def get_history(media_type):
	string = 'alkoflix_discover_%s_%%' % media_type
	dbcon = kodi_utils.database_connect(maincache_db)
	dbcur = dbcon.cursor()
	dbcur.execute("""SELECT id, data FROM maincache WHERE id LIKE ? ORDER BY rowid DESC""", (string,))
	history = dbcur.fetchall(); dbcon.close()
	return history


def set_history(media_type, name, query):
	string = 'alkoflix_discover_%s_%s' % (media_type, query)
	maincache = MainCache()
	if maincache.get(string): return
	if media_type == 'movie': mode, action = 'build_movie_list', 'tmdb_movies_discover'
	else: mode, action = 'build_tvshow_list', 'tmdb_tv_discover'
	maincache.set(string, {'mode': mode, 'action': action, 'name': name, 'query': query}, expiration=timedelta(days=7))


def remove_from_history(params):
	dbcon = kodi_utils.database_connect(maincache_db, isolation_level=None)
	dbcur = dbcon.cursor(); dbcur.execute("""PRAGMA synchronous = OFF"""); dbcur.execute("""PRAGMA journal_mode = OFF""")
	dbcur.execute("""DELETE FROM maincache WHERE id = ?""", (params['data_id'],)); dbcon.close()
	kodi_utils.clear_property(params['data_id']); kodi_utils.container_refresh()
	if not params.get('silent'): kodi_utils.notification(32576)


def remove_all_history(params):
	media_type = params['media_type']
	if not kodi_utils.confirm_dialog(): return
	for item in (i[0] for i in get_history(media_type)):
		remove_from_history({'data_id': item, 'silent': True})
	kodi_utils.notification(32576)
