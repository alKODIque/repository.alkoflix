# -*- coding: utf-8 -*-
# plugin.video.alkoflix
# resources/lib/menus/tvshows.py

import sys
import time
import re
try:
	from urllib.parse import parse_qs, urlsplit
except ImportError:
	from urlparse import parse_qs, urlsplit
from threading import Thread
from indexers.trakt_api import trakt_get_hidden_items
from indexers.metadata import tvshow_meta, cached_tvshow_meta, rpdb_get, tmdb_image_base
from caches.watched_cache import get_watched_info_tv, get_watched_status_tvshow, get_effective_total_aired_eps, get_watched_status_tvshow_provider, get_provider_tv_progress
from caches.meta_cache import MetaCache
from caches.favourites_cache import favourites_context_label, favourite_type_from_context
from modules import kodi_utils, settings, user_ratings, parental_control
#from modules.utils import manual_function_import, get_datetime, make_thread_list_enumerate
from modules.utils import manual_function_import, get_datetime, TaskPool, chunks
# logger = kodi_utils.logger

# Alias locaux pour éviter les accès répétés aux modules pendant la construction des listes.
tv_meta_function, cached_tv_meta_function, get_datetime_function = tvshow_meta, cached_tvshow_meta, get_datetime
get_watched_function, get_watched_info_function = get_watched_status_tvshow, get_watched_info_tv
KODI_VERSION, make_cast_list = kodi_utils.get_kodi_version(), kodi_utils.make_cast_list
string, ls, build_url, get_infolabel = str, kodi_utils.local_string, kodi_utils.build_url, kodi_utils.get_infolabel
remove_meta_keys, dict_removals = kodi_utils.remove_meta_keys, kodi_utils.tvshow_dict_removals
run_plugin, container_refresh, container_update = 'RunPlugin(%s)', 'Container.Refresh(%s)', 'Container.Update(%s)'
fanart_empty = ''
poster_empty = kodi_utils.media_path('box_office.png')
item_jump = kodi_utils.media_path('item_jump.png')
item_next = kodi_utils.media_path('item_next.png')
watched_str, unwatched_str, traktmanager_str, tmdbmanager_str, mdblmanager_str = ls(32642), ls(32643), ls(32198), 'Gestion TMDb', ls(32200)
favmanager_str, extras_str, options_str, recomm_str = 'Favoris (alkoFlix)', 'Info & Extra', 'Options (alkoFlix)', '%s...' % ls(32503)
trailer_str = 'Bande annonce'
random_str, browse_str = ls(32611), ls(32652)
nextpage_str, switchjump_str, jumpto_str = ls(32799), ls(32784), ls(32964)

ANIMATION_GENRE_NAMES = ('animation', 'dessin animé', 'dessins animés')
DEFAULT_TV_EXCLUDED_GENRE_IDS = {'16', '99', '10763', '10764', '10767'}
DEFAULT_TV_EXCLUDED_GENRE_NAMES = {
	'animation', 'anime', 'animé', 'dessin animé', 'dessins animés',
	'documentary', 'documentaire',
	'news', 'actualité', 'actualités',
	'reality', 'téléréalité', 'telerealite', 'télé-réalité',
	'talk', 'talk show', 'talk-show', 'talkshow'
}

def _normal_genre_ids(values):
	try:
		if isinstance(values, (list, tuple, set)): source = values
		else: source = str(values or '').replace('|', ',').split(',')
		return {str(item or '').strip() for item in source if str(item or '').strip()}
	except: return set()

def _normal_genre_names(values):
	try:
		if isinstance(values, (list, tuple, set)): source = values
		else: source = str(values or '').split(',')
		return {str(item or '').strip().lower() for item in source if str(item or '').strip()}
	except: return set()

def _meta_has_animation_genre(genre):
	return bool(_normal_genre_names(genre).intersection(ANIMATION_GENRE_NAMES))

def _row_has_excluded_default_tv_genre(row):
	try: return bool(_normal_genre_ids((row or {}).get('genre_ids')).intersection(DEFAULT_TV_EXCLUDED_GENRE_IDS))
	except: return False

def _meta_has_excluded_default_tv_genre(meta):
	try:
		genre_ids = _normal_genre_ids((meta or {}).get('genre_ids'))
		genre_names = _normal_genre_names((meta or {}).get('genre'))
		return bool(genre_ids.intersection(DEFAULT_TV_EXCLUDED_GENRE_IDS) or genre_names.intersection(DEFAULT_TV_EXCLUDED_GENRE_NAMES))
	except: return False

def _exclude_animation_for_action(action, params):
	action = str(action or '')
	# « Parce que vous avez regardé... » est une recommandation personnelle :
	# elle ne doit pas être vidée par les exclusions du tiroir Séries général.
	if str((params or {}).get('because_you_watched', '')).lower() == 'true': return False
	if action.startswith('favourites_'): return False
	if str(params.get('exclude_animation', '')).lower() == 'true': return True
	# Les listes issues du menu Famille / Chaînes jeunesse doivent conserver
	# l'animation. Ces entrées utilisent parfois l'action générique
	# tmdb_tv_networks, donc se fier seulement au préfixe de l'action viderait
	# des réseaux comme Cartoon Network.
	family_type = str(params.get('family_type', '') or '').lower()
	fav_type = str(params.get('fav_type', '') or '').lower()
	if family_type in ('series_family', 'series_family_kids', 'series_animation') or fav_type in ('tv_family', 'tv_animation'):
		return False
	action = str(action or '')
	if not action: return False
	if action.startswith(('tmdb_tvanime_', 'trakt_tvanime_', 'tmdb_tv_family_', 'tmdb_tv_documentary_', 'tmdb_tv_reality_', 'tmdb_tv_talkshow_', 'tmdb_tv_news_')): return False
	if action in ('tmdb_tv_search', 'tmdb_tv_discover', 'tmdb_tv_keyword'): return False
	if action.startswith(('tmdb_tv_', 'trakt_tv_')): return True
	return False

def _exclude_default_tv_genres_for_action(action, params):
	# Une recommandation « Parce que vous avez regardé... » doit rester fidèle
	# au contenu regardé (documentaire, réalité, talk-show, etc.) au lieu d'être
	# recoupée par les exclusions structurelles du tiroir Séries général.
	if str((params or {}).get('because_you_watched', '')).lower() == 'true': return False
	# Menu Séries natif : les documentaires, animés, actualités, télé-réalités
	# et talk-shows doivent rester dans leurs sections dédiées.
	action = str(action or '')
	if action.startswith('favourites_'): return False
	if str(params.get('exclude_default_tv_genres', '')).lower() == 'true': return True
	if _catalogue_only_enabled(params): return False
	fav_type = str(params.get('fav_type', '') or '').lower()
	native_type = str(params.get('native_type', '') or '').lower()
	family_type = str(params.get('family_type', '') or '').lower()
	documentary_type = str(params.get('documentary_type', '') or '').lower()
	if native_type in ('anime_series',) or family_type or documentary_type: return False
	if fav_type in ('tv_family', 'tv_animation', 'anime_tv', 'tv_documentary', 'tv_reality', 'tv_talkshow', 'tv_news'): return False
	action = str(action or '')
	if not action: return False
	if action.startswith(('tmdb_tvanime_', 'trakt_tvanime_', 'tmdb_tv_family_', 'tmdb_tv_documentary_', 'tmdb_tv_reality_', 'tmdb_tv_talkshow_', 'tmdb_tv_news_')): return False
	if action in ('tmdb_tv_search', 'tmdb_tv_discover', 'tmdb_tv_keyword'): return False
	# Seulement les listes générales du tiroir Séries doivent être nettoyées pour
	# éviter les doublons avec Anime / Animation / Docus & Télé. Les listes
	# personnelles et de suivi (Trakt, MDBList, TMDb, IMDb, En cours, Vu récemment,
	# Favoris) doivent afficher exactement ce que l'utilisateur suit ou a regardé.
	if action.startswith(('tmdb_tv_', 'trakt_tv_')): return True
	return False


def _ignore_menu_hide_watched_for_action(action):
	# Les recherches et Discover doivent rester indépendants du réglage global
	# « Masquer les éléments vus dans les menus ». Le flag est aussi propagé
	# vers les saisons/épisodes afin qu'un résultat ouvert depuis une recherche
	# ne soit pas filtré ensuite par erreur.
	action = str(action or '')
	return action in (
		'watched_tvshows',
		'tmdb_tv_search',
		'tmdb_tv_keyword',
		'tmdb_tv_discover'
	)


def _ignore_unreleased_filter_for_action(action):
	# Les recherches manuelles et le menu À venir doivent rester accessibles
	# même si l'utilisateur masque les séries qui ne sont pas encore sorties.
	action = str(action or '')
	return action in (
		'tmdb_tv_search',
		'tmdb_tv_keyword',
		'tmdb_tv_upcoming'
	)


def _tvshow_date_is_future(first_air_date, current_date_text):
	try:
		first_air_date = str(first_air_date or '')[:10]
		if len(first_air_date) != 10: return False
		return first_air_date > current_date_text
	except: return False



def _catalogue_only_enabled(params):
	return str((params or {}).get('catalogue_only', '') or '').strip().lower() in ('1', 'true', 'yes', 'on')


def _favourite_type_for_action(action, params, meta=None):
	# Contexte du menu d'abord, puis fallback genres TMDb pour les widgets de skin.
	return favourite_type_from_context('tvshow', params, action, meta)


# Appelle les endpoints TMDb avec un tri contextuel optionnel, tout en gardant
# les signatures existantes intactes pour les dossiers qui ne supportent pas encore
# ce mode. Le fallback évite de casser un menu entier si une fonction n'a pas été
# prévue pour le tri régional strict.
def _tmdb_context_filter_page(data, context_sort=''):
	if not context_sort: return data
	try:
		from indexers.tmdb_api import _tmdb_filter_context_results, _tmdb_context_sort_results
		data = _tmdb_filter_context_results(data or {}, 'tv', context_sort)
		if isinstance(data, dict):
			data = dict(data)
			data['results'] = _tmdb_context_sort_results(data.get('results', []) or [], context_sort, 'tv')
		return data
	except: return data


def _call_tmdb_page_function(function, page_no, context_sort=''):
	if context_sort:
		try: return function(page_no, context_sort)
		except TypeError: pass
	return _tmdb_context_filter_page(function(page_no), context_sort)


def _call_tmdb_special_function(function, function_var, page_no, context_sort='', provider_region=None, is_provider=False):
	# Les fonctions de plateformes/diffuseurs qui acceptent une région ont la
	# signature (id, page, region, tri). Même si region est vide, il faut passer
	# le 4e argument, sinon le tri se retrouve accidentellement dans region.
	if context_sort:
		if is_provider:
			try: return function(function_var, page_no, provider_region, context_sort) or {}
			except TypeError: pass
		try: return function(function_var, page_no, context_sort) or {}
		except TypeError: pass
	if is_provider and provider_region not in ('', None):
		try: return _tmdb_context_filter_page(function(function_var, page_no, provider_region) or {}, context_sort)
		except TypeError: pass
	return _tmdb_context_filter_page(function(function_var, page_no) or {}, context_sort)


def _default_tmdb_special_context_sort(action, params_get):
	# Les dossiers de plateformes/diffuseurs doivent ouvrir sur les nouveautés,
	# comme les genres. Le choix contextuel reste prioritaire si l'utilisateur
	# sélectionne Popularité / Mieux notés / Aléatoire.
	explicit = params_get('genre_sort', '')
	if explicit: return explicit
	action = str(action or '')
	if action.endswith('_watch_provider') or action.endswith('_networks') or action in ('tmdb_tv_networks',):
		return 'date'
	return ''


TMDB_SOURCE_PAGE_SIZE = 20
TMDB_FULL_MAX_PAGES = 3
ALKOPASTE_CATALOGUE_PAGE_SIZE = 20
ALKOPASTE_CATALOGUE_FULL_MAX_PAGES = 8

def _safe_int(value, default=1):
	try: return int(value)
	except: return default

def _tmdb_result_rows(data):
	try:
		return [i for i in (data.get('results', []) or []) if isinstance(i, dict) and i.get('id')]
	except: return []


def _tmdb_result_ids(data):
	try:
		return [i.get('id') for i in _tmdb_result_rows(data)]
	except: return []

def _tmdb_page_number(data, fallback=1):
	try: return max(1, int((data or {}).get('page') or fallback or 1))
	except: return max(1, _safe_int(fallback, 1))

def _tmdb_total_pages(data, fallback=1):
	try: return max(1, int((data or {}).get('total_pages') or fallback or 1))
	except: return max(1, _safe_int(fallback, 1))

def _alkopaste_catalogue_offset_to_page_skip(offset):
	offset = max(0, _safe_int(offset, 0))
	return (offset // ALKOPASTE_CATALOGUE_PAGE_SIZE) + 1, offset % ALKOPASTE_CATALOGUE_PAGE_SIZE

def _tmdb_full_page_limit():
	# Les menus publics TMDb/Discover ne suivent pas le réglage des listes
	# personnelles. TMDb travaille par pages de 20 éléments : on garde cette
	# taille fixe pour éviter les comportements variables entre menus.
	return TMDB_SOURCE_PAGE_SIZE


def _normal_text(value):
	try:
		return str(value or '').strip().lower()
	except:
		return ''


def _query_param_value(query, key):
	try:
		parsed = parse_qs(urlsplit(str(query or '')).query, keep_blank_values=True)
		value = parsed.get(key, [''])[0]
		return str(value or '').strip()
	except:
		return ''

def _strip_tv_discover_certification(query):
	# Les certifications ne sont pas prises en charge proprement par Discover TV.
	# On nettoie aussi les anciennes URL exportées/cachées pour éviter des menus séries vides.
	query = str(query or '')
	query = re.sub(r'&certification_country=[^&]*', '', query)
	query = re.sub(r'&certification=[^&]*', '', query)
	return query


def _normalize_favourites_action(action, params):
	# Filet de sécurité pour les anciennes URL Kodi/cache : si une entrée de
	# favoris séries transporte un contexte spécialisé mais appelle encore
	# l'action globale, on force l'action spécialisée avant le routage.
	# Sans cela, favourites_tvshows/favourites_tvshows_all lit le panier tvshow.
	action = _normal_text(action)
	if action not in ('favourites_tvshows', 'favourites_tvshows_all'):
		return action
	params = params or {}
	fav_type = _normal_text(params.get('fav_type') or params.get('favourite_type') or params.get('favorite_type') or params.get('parent_fav_type') or params.get('series_fav_type') or params.get('tv_fav_type'))
	family_type = _normal_text(params.get('family_type'))
	documentary_type = _normal_text(params.get('documentary_type'))
	native_type = _normal_text(params.get('native_type'))
	fav_group = _normal_text(params.get('fav_group') or params.get('group'))
	if fav_type == 'tv_family' or family_type in ('series_family', 'series_family_kids') or fav_group in ('family', 'series_family'):
		return 'favourites_tv_family'
	if fav_type == 'tv_animation' or family_type == 'series_animation' or fav_group in ('animation', 'series_animation'):
		return 'favourites_tv_animation'
	if fav_type == 'anime_tv' or native_type in ('anime_series', 'anime_tv') or fav_group in ('anime', 'series_anime'):
		return 'favourites_anime_tv'
	if fav_type in ('tv_documentary', 'tv_reality', 'tv_talkshow', 'tv_news') or documentary_type.startswith(('series', 'tv')) or fav_group in ('documentary', 'series_documentary'):
		return 'favourites_tv_documentary'
	if fav_type == 'tv_qc' or params.get('catalogue_section') == 'qc_series' or fav_group in ('qc', 'series_qc'):
		return 'favourites_tv_qc'
	if fav_type == 'tv_replay' or params.get('catalogue_section') == 'replay' or fav_group in ('replay', 'series_replay'):
		return 'favourites_tv_replay'
	return action

class TVShows:
	def __init__(self, params):
		self.params = params
		self.items, self.new_page, self.total_pages = [], {}, None
		self.id_type, self.list, self.action, self.exit_list_params = (
			self.params.get('id_type', 'tmdb_id'),
			self.params.get('list', []),
			self.params.get('action'),
			self.params.get('exit_list_params')
		)
		self.action = _normalize_favourites_action(self.action, self.params)
		self.params['action'] = self.action
		self.append = self.items.append
		self.current_date = get_datetime_function()
		self.current_date_text = get_datetime_function(string=True)
		# Paramètres utilisés pour récupérer les métadonnées et les images selon la configuration utilisateur.
		self.meta_user_info = settings.metadata_user_info()
		try: self.watched_indicators = int(self.params.get('watched_indicators', settings.watched_indicators()))
		except: self.watched_indicators = settings.watched_indicators()
		self.watched_info = get_watched_info_function(self.watched_indicators)
		self.provider_tv_progress = get_provider_tv_progress(self.watched_indicators) if self.watched_indicators in (1, 2) else {}
		self.all_episodes = settings.default_all_episodes()
		self.include_year_in_title = settings.include_year_in_title('tvshow')
		# Si demandé, le clic sur une pochette de série ouvre la fenêtre d'information.
		self.media_click_opens_info = settings.media_click_opens_info()
		# Info & Extra utilise la fenêtre d'information native du skin.
		self.open_extras = False
		# Menu contextuel natif : ordre fixe, entrées externes selon services autorisés.
		self.cm_sort = settings.context_menu_sort()
		self.cm_services = settings.context_menu_services()
		self.is_folder = True
		self.rpdb_enabled = self.meta_user_info['extra_rpdb_series']
		# Conserve l'identifiant brut du catalogue Stremio pendant la navigation.
		# Sans cela, les épisodes repassent par TMDb/IMDb et certains manifests
		# (French Stream -> Baguettio/AIOStreams) ne retrouvent plus leurs liens.
		self.catalogue_id = self.params.get('catalogue_id') or self.params.get('catalog_id') or ''
		self.fanart_enabled = self.meta_user_info['extra_fanart_enabled']
		self.is_widget = kodi_utils.external_browse()
		self.widget_hide_watched = self.is_widget and self.meta_user_info['widget_hide_watched']
		self.discover_hide_watched = self.params.get('discover_hide_watched', 'false') == 'true'
		self.menu_hide_watched = (not self.is_widget) and self.meta_user_info.get('menu_hide_watched', False) and not _ignore_menu_hide_watched_for_action(self.action)
		self.ignore_menu_hide_watched = _ignore_menu_hide_watched_for_action(self.action)
		self.hide_watched_items = self.params.get('hide_watched_items', 'false') == 'true'
		self.hide_unreleased_tvshows = settings.hide_unreleased_tvshows() and not _ignore_unreleased_filter_for_action(self.action)
		if not self.exit_list_params: self.exit_list_params = get_infolabel('Container.FolderPath')
		self.watched_title = ('alkoFlix', 'Trakt', 'MDBList')[self.watched_indicators]
		self.poster_main, self.poster_backup, self.fanart_main, self.fanart_backup = settings.get_art_provider()
		self.user_ratings = user_ratings.get_active_ratings_index()
		self.parental_blocked = False
		self.exclude_animation_content = _exclude_animation_for_action(self.action, self.params)
		self.exclude_default_tv_genres = _exclude_default_tv_genres_for_action(self.action, self.params)
		self.tmdb_sort_offset = 0
		self._tmdb_full_fetcher = None
		self._tmdb_full_start_page = 1
		self._tmdb_full_start_skip = 0
		self._tmdb_full_total_pages = 1
		self._tmdb_full_next_source_page = 2
		self._tmdb_full_raw_count = 0
		self._tmdb_full_raw_rows = []
		self.catalogue_only = _catalogue_only_enabled(self.params)
		self._catalogue_only_ids = None
		self._recommendation_section_ids = None


	def _catalogue_only_allowed(self, tmdb_id):
		if not self.catalogue_only:
			return True
		try:
			if self._catalogue_only_ids is None:
				from magneto.alkopaste import alkopaste_catalogue_all_id_set
				self._catalogue_only_ids = alkopaste_catalogue_all_id_set('serie')
			return str(tmdb_id or '').strip() in self._catalogue_only_ids
		except Exception as e:
			kodi_utils.logger('catalogue-only tv filter skipped', str(e))
			return True

	def _fast_tmdb_search(self):
		# Les résultats de recherche doivent être affichés rapidement à partir de
		# la réponse TMDb brute. Les détails complets seront récupérés seulement
		# quand l'utilisateur ouvrira l'item.
		return self.action in ('tmdb_tv_search', 'tmdb_tv_keyword')

	def _set_tmdb_source(self, data, page_no, fetcher=None):
		# Prépare une page TMDb paginée. Si l'option « pages complètes » est active,
		# on conserve assez d'information pour compléter la page Kodi sans doublons.
		current_page = _tmdb_page_number(data, page_no)
		total_pages = _tmdb_total_pages(data, current_page)
		start_skip = max(0, _safe_int(self.params.get('tmdb_full_skip', '0'), 0))
		rows = _tmdb_result_rows(data)
		if start_skip:
			rows = rows[start_skip:] if start_skip < len(rows) else []
		if self.hide_unreleased_tvshows:
			rows = [i for i in rows if not _tvshow_date_is_future(i.get('first_air_date'), self.current_date_text)]
		if self.exclude_default_tv_genres:
			rows = [i for i in rows if not _row_has_excluded_default_tv_genre(i)]
		ids = [i.get('id') for i in rows if i.get('id')]
		self.tmdb_sort_offset = start_skip
		self.list = ids
		self._tmdb_full_raw_rows = rows
		self._tmdb_full_fetcher = fetcher if settings.tmdb_try_full_pages() and not self._fast_tmdb_search() else None
		self._tmdb_full_start_page = current_page
		self._tmdb_full_start_skip = start_skip
		self._tmdb_full_total_pages = total_pages
		self._tmdb_full_next_source_page = current_page + 1
		self._tmdb_full_raw_count = len(ids)
		return current_page, total_pages

	def _update_tmdb_full_next_page(self, displayed_items, display_limit):
		# Calcule la prochaine page TMDb réelle à ouvrir. Si on a seulement consommé
		# une partie d'une page source, on reprend cette même page avec un décalage
		# interne pour éviter de sauter des éléments valides.
		# Important : certains menus n'ont aucun paramètre à transporter à part
		# new_page. Il faut donc mémoriser l'existence du lien avant de retirer
		# new_page, sinon les menus TMDb simples perdent leur pagination.
		base_next = dict(self.new_page or {})
		had_next_page = 'new_page' in base_next
		base_next.pop('new_page', None)
		base_next.pop('tmdb_full_skip', None)
		total_pages = max(1, int(self._tmdb_full_total_pages or 1))
		self.new_page = {}
		if not had_next_page:
			return
		if len(displayed_items) < display_limit and self._tmdb_full_next_source_page > total_pages:
			return
		if displayed_items and len(displayed_items) >= display_limit:
			try: consumed_offset = max(0, int(displayed_items[-1][1].getProperty('alkoflix_sort_order')) + 1)
			except: consumed_offset = self._tmdb_full_start_skip + self._tmdb_full_raw_count
		else:
			consumed_offset = self._tmdb_full_start_skip + self._tmdb_full_raw_count
		next_page = self._tmdb_full_start_page + (consumed_offset // TMDB_SOURCE_PAGE_SIZE)
		next_skip = consumed_offset % TMDB_SOURCE_PAGE_SIZE
		if next_page > total_pages:
			return
		base_next['new_page'] = string(next_page)
		if next_skip: base_next['tmdb_full_skip'] = string(next_skip)
		self.new_page = base_next

	def _dedupe_tmdb_items(self, items):
		seen, deduped = set(), []
		for item in items or []:
			try: key = item[0]
			except: key = None
			if key in seen: continue
			if key is not None: seen.add(key)
			deduped.append(item)
		return deduped

	def _complete_tmdb_items(self, items):
		if not self._tmdb_full_fetcher:
			return items
		display_limit = _tmdb_full_page_limit()
		try: items.sort(key=lambda k: int(k[1].getProperty('alkoflix_sort_order')))
		except: pass
		attempts = 1
		max_attempts = TMDB_FULL_MAX_PAGES
		while len(items) < display_limit and attempts < max_attempts:
			next_source_page = self._tmdb_full_next_source_page
			if next_source_page > self._tmdb_full_total_pages: break
			data = self._tmdb_full_fetcher(next_source_page) or {}
			if not isinstance(data, dict): break
			self._tmdb_full_total_pages = max(self._tmdb_full_total_pages, _tmdb_total_pages(data, self._tmdb_full_total_pages))
			rows = _tmdb_result_rows(data)
			if not rows: break
			ids = [i.get('id') for i in rows if i.get('id')]
			if not ids: break
			self.tmdb_sort_offset = self._tmdb_full_start_skip + self._tmdb_full_raw_count
			self._tmdb_full_raw_count += len(rows)
			self._tmdb_full_next_source_page = next_source_page + 1
			self._tmdb_full_raw_rows = rows
			self.list = ids
			items = self.worker()
			try: items.sort(key=lambda k: int(k[1].getProperty('alkoflix_sort_order')))
			except: pass
			attempts += 1
		items = self._dedupe_tmdb_items(items)
		displayed = items[:display_limit]
		self._update_tmdb_full_next_page(displayed, display_limit)
		self.items = displayed
		self.list = []
		self.tmdb_sort_offset = 0
		return displayed

	def _update_alkopaste_catalogue_next_page(self, displayed_items, display_limit):
		base_next = dict(self.new_page or {})
		base_next.pop('new_page', None)
		base_next.pop('catalogue_full_skip', None)
		total_pages = max(1, _safe_int(getattr(self, '_alkopaste_full_total_pages', 1), 1))
		self.new_page = {}
		if displayed_items and len(displayed_items) >= display_limit:
			try: consumed_offset = max(0, int(displayed_items[-1][1].getProperty('alkoflix_sort_order')) + 1)
			except: consumed_offset = _safe_int(getattr(self, '_alkopaste_full_next_offset', 0), 0)
		else:
			consumed_offset = _safe_int(getattr(self, '_alkopaste_full_next_offset', 0), 0)
		next_page, next_skip = _alkopaste_catalogue_offset_to_page_skip(consumed_offset)
		if next_page > total_pages:
			return
		base_next['new_page'] = string(next_page)
		if next_skip: base_next['catalogue_full_skip'] = string(next_skip)
		self.new_page = base_next

	def _complete_alkopaste_catalogue_items(self, items):
		if self.action not in ('alkopaste_catalogue', 'alkopaste_catalogue_airing'):
			return items
		display_limit = ALKOPASTE_CATALOGUE_PAGE_SIZE
		try: items.sort(key=lambda k: int(k[1].getProperty('alkoflix_sort_order')))
		except: pass
		attempts = 1
		while len(self._dedupe_tmdb_items(items)) < display_limit and attempts < ALKOPASTE_CATALOGUE_FULL_MAX_PAGES:
			cursor_offset = _safe_int(getattr(self, '_alkopaste_full_next_offset', 0), 0)
			next_page, next_skip = _alkopaste_catalogue_offset_to_page_skip(cursor_offset)
			if next_page > max(1, _safe_int(getattr(self, '_alkopaste_full_total_pages', 1), 1)):
				break
			try:
				request_params = dict(self.params)
				request_params['new_page'] = string(next_page)
				if next_skip: request_params['catalogue_full_skip'] = string(next_skip)
				else: request_params.pop('catalogue_full_skip', None)
				from magneto.alkopaste import alkopaste_catalogue_ids
				if self.action == 'alkopaste_catalogue_airing':
					# Compatibilité avec un ancien cache/menu : on redirige vers la
					# liste locale « Séries en diffusion » préparée par le builder.
					request_params['catalogue_sort'] = 'tmdb_order'
					request_params['catalogue_group1'] = '__any__'
					request_params['catalogue_group2'] = 'Séries en diffusion'
				ids, total_pages = alkopaste_catalogue_ids('serie', request_params.get, next_page)
			except Exception as e:
				kodi_utils.logger('alkopaste catalogue full page error', str(e))
				break
			self._alkopaste_full_total_pages = max(_safe_int(getattr(self, '_alkopaste_full_total_pages', 1), 1), _safe_int(total_pages, next_page))
			if not ids:
				break
			self.tmdb_sort_offset = cursor_offset
			self._alkopaste_full_next_offset = cursor_offset + len(ids)
			self.list = ids
			items = self.builder() if hasattr(self, 'builder') else self.worker()
			try: items.sort(key=lambda k: int(k[1].getProperty('alkoflix_sort_order')))
			except: pass
			attempts += 1
		items = self._dedupe_tmdb_items(items)
		displayed = items[:display_limit]
		self._update_alkopaste_catalogue_next_page(displayed, display_limit)
		self.items = displayed
		self.list = []
		self.tmdb_sort_offset = 0
		return displayed

	def _carry_context_to_next_page(self, params_get):
		# Les dossiers thématiques (Famille, Docus, Animation, Anime, Sagas)
		# doivent garder leur contexte quand Kodi ajoute « Page suivante ».
		# Sans ces clés, les favoris ajoutés depuis une page suivante peuvent
		# retomber dans les favoris globaux movie/tvshow.
		for key in ('fav_type', 'family_type', 'documentary_type', 'native_type', 'saga_type', 'catalogue_id', 'catalog_id', 'catalogue_section', 'catalogue_media_type', 'catalogue_sort', 'catalogue_filter_type', 'catalogue_filter_value', 'catalogue_group1', 'catalogue_group2', 'catalogue_full_skip', 'alkopaste_airing_kind', 'exclude_animation', 'provider_region', 'hide_watched_items', 'discover_hide_watched', 'watched_indicators', 'genre_sort', 'list_sort', 'list_random_seed', 'catalogue_only', 'because_you_watched', 'recommendation_group', 'recommendation_catalogue_section', 'progress_group', 'progress_catalogue_section'):
			value = params_get(key)
			if value not in ('', None) and key not in self.new_page:
				self.new_page[key] = value

	def build_tvshow_search_content(self, _position, item):
		try:
			# Variante légère pour les recherches : aucune récupération meta complète,
			# aucun appel Fanart.tv/RPDb. On utilise directement la réponse TMDb.
			image_resolution = settings.get_resolution()
			tmdb_id = item.get('id')
			if not tmdb_id: return
			title = item.get('name') or item.get('title') or item.get('original_name') or ''
			if not title: return
			year = str(item.get('first_air_date') or '')[:4]
			label = '%s (%s)' % (title, year) if self.include_year_in_title and year else title
			poster_path, backdrop_path = item.get('poster_path'), item.get('backdrop_path')
			poster = tmdb_image_base % (image_resolution['poster'], poster_path) if poster_path else poster_empty
			fanart = tmdb_image_base % (image_resolution['fanart'], backdrop_path) if backdrop_path else fanart_empty
			thumb = fanart or poster
			playcount, overlay, total_watched, total_unwatched = get_watched_function(self.watched_info, string(tmdb_id), 0)
			sort = _position + getattr(self, 'tmdb_sort_offset', 0)
			props = {'alkoflix_sort_order': string(sort), 'watchedepisodes': string(total_watched), 'unwatchedepisodes': string(total_unwatched), 'totalepisodes': '0', 'totalseasons': '0'}
			url_data = {'mode': 'build_season_list', 'tmdb_id': tmdb_id, 'ignore_menu_hide_watched': 'true'}
			if self.catalogue_id: url_data['catalogue_id'] = self.catalogue_id
			fav_type = _favourite_type_for_action(self.action, self.params, None)
			if fav_type: url_data['parent_fav_type'] = fav_type
			if 'anime' in str(fav_type or '').lower(): url_data['anime_context'] = 'true'
			url_params = build_url(url_data)
			options_params = build_url({'mode': 'options_menu_choice', 'content': 'tvshow', 'tmdb_id': tmdb_id, 'is_widget': self.is_widget})
			info_extra_params = build_url({'mode': 'info_extra_choice', 'media_type': 'tvshow', 'tmdb_id': tmdb_id, 'is_widget': string(self.is_widget).lower()})
			trailer_params = build_url({'mode': 'play_trailer_choice', 'media_type': 'tvshow', 'tmdb_id': tmdb_id})
			trakt_manager_params = build_url({'mode': 'trakt_manager_choice', 'tmdb_id': tmdb_id, 'imdb_id': 'None', 'tvdb_id': 'None', 'media_type': 'tvshow'})
			tmdb_manager_params = build_url({'mode': 'tmdb_manager_choice', 'tmdb_id': tmdb_id, 'imdb_id': 'None', 'tvdb_id': 'None', 'media_type': 'tvshow'})
			mdbl_manager_params = build_url({'mode': 'mdbl_manager_choice', 'tmdb_id': tmdb_id, 'imdb_id': 'None', 'tvdb_id': 'None', 'media_type': 'tvshow'})
			rating_params = build_url({'mode': 'rating_choice', 'media_type': 'tvshow', 'tmdb_id': tmdb_id, 'imdb_id': 'None', 'tvdb_id': 'None', 'title': title})
			fav_manager_label = favourites_context_label(fav_type, tmdb_id)
			fav_manager_params = build_url({'mode': 'favourites_choice', 'media_type': 'tvshow', 'tmdb_id': tmdb_id, 'imdb_id': 'None', 'tvdb_id': 'None', 'title': title, 'fav_type': fav_type, 'action': self.action})
			cm = []
			cm_append = cm.append
			cm_append((self.cm_sort['options'], options_str, run_plugin % options_params))
			cm_append((self.cm_sort['options'], trailer_str, run_plugin % trailer_params))
			cm_append((self.cm_sort['extras'], extras_str, run_plugin % info_extra_params))
			if self.cm_services['trakt']: cm_append((self.cm_sort['trakt'], traktmanager_str, run_plugin % trakt_manager_params))
			if self.cm_services['mdblist']: cm_append((self.cm_sort['mdblist'], mdblmanager_str, run_plugin % mdbl_manager_params))
			if self.cm_services['tmdblist']: cm_append((self.cm_sort['tmdblist'], tmdbmanager_str, run_plugin % tmdb_manager_params))
			if settings.context_rating_enabled('tvshow'): cm_append((self.cm_sort['rating'], ls(33136), run_plugin % rating_params))
			if settings.context_favourites_enabled(): cm_append((self.cm_sort['favourites'], fav_manager_label, run_plugin % fav_manager_params))
			cm_append((self.cm_sort['mark'], watched_str % self.watched_title, run_plugin % build_url({'mode': 'mark_as_watched_unwatched_tvshow', 'action': 'mark_as_watched', 'year': year, 'tmdb_id': tmdb_id, 'imdb_id': 'None', 'tvdb_id': 'None', 'title': title})))
			if self.watched_indicators == 0:
				from caches.watched_cache import local_watchlist_contains
				local_wl_label = 'Retirer de la Watchlist (alkoFlix)' if local_watchlist_contains('tvshow', tmdb_id) else 'Ajouter à la Watchlist (alkoFlix)'
				cm_append((self.cm_sort['mark'], local_wl_label, run_plugin % build_url({'mode': 'toggle_local_watchlist', 'media_type': 'tvshow', 'tmdb_id': tmdb_id, 'title': title})))
			if self.watched_indicators == 0:
				cm_append((self.cm_sort['mark'], 'Basculer l’état « Abandonné » (alkoFlix)...', run_plugin % build_url({'mode': 'toggle_local_dropped', 'media_type': 'tvshow', 'tmdb_id': tmdb_id, 'title': title})))
			cm.sort(key=lambda k: k[0])
			cm = [v for k, *v in cm if k]
			listitem = kodi_utils.make_listitem()
			listitem.addContextMenuItems(cm)
			listitem.setProperties(props)
			listitem.setLabel(label)
			listitem.setArt(kodi_utils.clean_art({'poster': poster, 'fanart': fanart, 'icon': poster, 'thumb': thumb, 'landscape': thumb, 'tvshow.poster': poster, 'tvshow.thumb': thumb, 'tvshow.landscape': thumb}))
			info = {'mediatype': 'tvshow', 'title': label, 'tvshowtitle': title, 'plot': item.get('overview', ''), 'year': year, 'premiered': item.get('first_air_date', ''), 'rating': item.get('vote_average', 0), 'votes': item.get('vote_count', 0), 'playcount': playcount}
			kodi_utils.set_listitem_video_info(listitem, info)
			try: listitem.getVideoInfoTag(offscreen=True).setUniqueIDs({'tmdb': string(tmdb_id)})
			except: pass
			item_is_folder = self.is_folder
			if self.media_click_opens_info:
				url_params = info_extra_params
				item_is_folder = False
			self.append((url_params, listitem, item_is_folder))
		except Exception as e:
			kodi_utils.logger('quick tv search item error', str(e))

	def fast_search_worker(self):
		rows = self._tmdb_full_raw_rows or [{'id': i} for i in self.list]
		if not rows: return []
		for position, item in enumerate(rows):
			self.build_tvshow_search_content(position, item)
		try: self.items.sort(key=lambda k: int(k[1].getProperty('alkoflix_sort_order')))
		except: pass
		return self.items

	def build_tvshow_content(self, _position, _id, _cached_meta=None):
		try:
			# Si worker() a déjà validé la fiche en cache, on la réutilise directement.
			meta = _cached_meta if _cached_meta is not None else tv_meta_function(self.id_type, _id, self.meta_user_info, self.current_date)
			meta_get = meta.get
			if not meta or meta_get('blank_entry', False): return
			# Même cloisonnement que les suivis : recommandations TMDb filtrées selon
			# le tiroir courant et, dans alkoPaste, strictement selon les IDs présents
			# dans la section de catalogue ouverte.
			if str(self.params.get('because_you_watched', '')).lower() == 'true':
				recommendation_section = self.params.get('recommendation_catalogue_section', '')
				if recommendation_section:
					try:
						if self._recommendation_section_ids is None:
							from caches.watched_cache import _progress_catalogue_ids
							self._recommendation_section_ids = _progress_catalogue_ids('tvshow', recommendation_section)
						if self._recommendation_section_ids is not None and str(meta_get('tmdb_id')) not in self._recommendation_section_ids: return
					except Exception: pass
				recommendation_group = self.params.get('recommendation_group', '')
				if recommendation_group not in ('', 'all', 'global', 'combined'):
					try:
						from caches.watched_cache import _progress_matches_context
						if not _progress_matches_context('tvshow', meta, recommendation_group): return
					except Exception: pass
			# Les listes « Séries abandonnées » utilisent la même fiche TMDb que
			# l'item final pour vérifier le tiroir éditorial. Ne pas les pré-filtrer
			# dans Menu.run : avec MDBList cela pouvait éliminer tous les IDs avant
			# même que la série soit construite. Le filtre alkoPaste par section/IDs
			# reste, lui, appliqué en amont.
			if self.action in ('trakt_droplist', 'mdblist_droplist', 'local_droplist'):
				progress_group = self.params.get('progress_group', '')
				if progress_group:
					try:
						from caches.watched_cache import _progress_matches_context
						if not _progress_matches_context('tvshow', meta, progress_group): return
					except Exception: pass
			if not self._catalogue_only_allowed(meta_get('tmdb_id')): return
			if self.hide_unreleased_tvshows and _tvshow_date_is_future(meta_get('premiered'), self.current_date_text): return
			if self.exclude_default_tv_genres and _meta_has_excluded_default_tv_genre(meta): return
			if self.exclude_animation_content and _meta_has_animation_genre(meta_get('genre')): return
			if not parental_control.meta_allowed(meta, self.action, 'tvshow'):
				self.parental_blocked = True
				return
			effective_aired_eps = get_effective_total_aired_eps(meta['tmdb_id'], meta.get('total_aired_eps'))
			playcount, overlay, total_watched, total_unwatched, effective_aired_eps = get_watched_status_tvshow_provider(
				self.watched_indicators, self.watched_info, string(meta['tmdb_id']), effective_aired_eps, self.provider_tv_progress
			)
			# Dans les widgets ou les menus, on peut masquer les séries déjà vues selon le réglage utilisateur.
			if (self.widget_hide_watched or self.menu_hide_watched or self.discover_hide_watched) and playcount: return
			meta.update({'playcount': playcount, 'overlay': overlay})
			sort = _id.get('sort', _position) if self.id_type == 'trakt_dict' else _position + getattr(self, 'tmdb_sort_offset', 0)
			props = {'alkoflix_sort_order': string(sort)}
			cm = []
			cm_append = cm.append
			rootname, title, year = meta_get('rootname'), meta_get('title'), meta_get('year')
			tmdb_id, tvdb_id, imdb_id = meta_get('tmdb_id'), meta_get('tvdb_id'), meta_get('imdb_id')
			user_rating = user_ratings.get_user_rating(self.user_ratings, 'tvshow', tmdb_id=tmdb_id, imdb_id=imdb_id, tvdb_id=tvdb_id)
			if user_rating: meta['userrating'] = user_rating
			total_seasons, total_aired_eps = meta_get('total_seasons'), effective_aired_eps
			tmdb_poster = meta_get('poster') or poster_empty
			poster = settings.resolve_poster_art(meta, tmdb_poster)
			media_fanart = meta_get(self.fanart_main) or meta_get(self.fanart_backup)
			fanart = media_fanart or fanart_empty
			clearlogo = meta_get('clearlogo') or meta_get('tmdblogo') or ''
			if self.rpdb_enabled:
				rpdb_data = rpdb_get('series', imdb_id or str(tmdb_id), self.meta_user_info['rpdb_api_key'])
				poster = rpdb_data.get('rpdb') or poster
			# Les images supplémentaires Fanart.tv restent optionnelles, mais l'image
			# landscape doit toujours respecter le choix de langue TMDb quand disponible.
			if self.fanart_enabled:
				banner, clearart = meta_get('banner'), meta_get('clearart')
				landscape = settings.resolve_landscape_art(meta, media_fanart or tmdb_poster)
			else:
				banner, clearart = '', ''
				landscape = meta_get('landscape_tmdb') or media_fanart or tmdb_poster
			if self.hide_watched_items:
				url_data = {'mode': 'build_episode_list', 'tmdb_id': tmdb_id, 'season': 'all', 'hide_watched_items': 'true', 'watched_indicators': string(self.watched_indicators)}
			elif self.all_episodes:
				if self.all_episodes == 1 and total_seasons > 1:
					url_data = {'mode': 'build_season_list', 'tmdb_id': tmdb_id}
				else:
					url_data = {'mode': 'build_episode_list', 'tmdb_id': tmdb_id, 'season': 'all'}
			else:
				url_data = {'mode': 'build_season_list', 'tmdb_id': tmdb_id}
			if self.catalogue_id: url_data['catalogue_id'] = self.catalogue_id
			if self.ignore_menu_hide_watched: url_data['ignore_menu_hide_watched'] = 'true'
			fav_type = _favourite_type_for_action(self.action, self.params, meta)
			if fav_type: url_data['parent_fav_type'] = fav_type
			if 'anime' in str(fav_type or '').lower(): url_data['anime_context'] = 'true'
			url_params = build_url(url_data)
			options_params = build_url({'mode': 'options_menu_choice', 'content': 'tvshow', 'tmdb_id': tmdb_id, 'is_widget': self.is_widget})
			recommended_params = build_url({'mode': 'build_tvshow_list', 'action': 'tmdb_tv_recommendations', 'tmdb_id': tmdb_id})
			trakt_manager_params = build_url({'mode': 'trakt_manager_choice', 'tmdb_id': tmdb_id, 'imdb_id': imdb_id, 'tvdb_id': tvdb_id, 'media_type': 'tvshow'})
			tmdb_manager_params = build_url({'mode': 'tmdb_manager_choice', 'tmdb_id': tmdb_id, 'imdb_id': imdb_id, 'tvdb_id': tvdb_id, 'media_type': 'tvshow'})
			mdbl_manager_params = build_url({'mode': 'mdbl_manager_choice', 'tmdb_id': tmdb_id, 'imdb_id': imdb_id, 'tvdb_id': tvdb_id, 'media_type': 'tvshow'})
			rating_params = build_url({'mode': 'rating_choice', 'media_type': 'tvshow', 'tmdb_id': tmdb_id, 'imdb_id': imdb_id, 'tvdb_id': tvdb_id, 'title': title})
			fav_manager_label = favourites_context_label(fav_type, tmdb_id)
			fav_payload = {'mode': 'favourites_choice', 'media_type': 'tvshow', 'tmdb_id': tmdb_id, 'imdb_id': imdb_id, 'tvdb_id': tvdb_id, 'title': title, 'fav_type': fav_type, 'action': self.action}
			# Conserve le contexte du menu d'origine dans l'action Favoris.
			# C'est indispensable pour les séries Famille : si l'item est ouvert depuis
			# une liste ou un cache sans fav_type fiable, favourites_choice peut alors
			# reconstruire le panier spécialisé (tv_family) au lieu de retomber sur tvshow.
			for ctx_key in ('family_type', 'documentary_type', 'native_type', 'fav_group', 'group', 'parent_fav_type', 'catalogue_section', 'catalogue_sort', 'catalogue_filter_type', 'catalogue_filter_value', 'catalogue_group1', 'catalogue_group2'):
				ctx_value = self.params.get(ctx_key)
				if ctx_value not in ('', None): fav_payload[ctx_key] = ctx_value
			fav_manager_params = build_url(fav_payload)
			trailer_params = build_url({'mode': 'play_trailer_choice', 'media_type': 'tvshow', 'tmdb_id': tmdb_id})
			info_extra_params = build_url({'mode': 'info_extra_choice', 'media_type': 'tvshow', 'tmdb_id': tmdb_id, 'is_widget': string(self.is_widget).lower()})
			if self.media_click_opens_info:
				url_params = info_extra_params
				item_is_folder = False
			else:
				item_is_folder = self.is_folder
			# Menu contextuel natif : Info & Extra ouvre la fiche info du skin.
			cm_append((self.cm_sort['options'], options_str, run_plugin % options_params))
			cm_append((self.cm_sort['options'], trailer_str, run_plugin % trailer_params))
			cm_append((self.cm_sort['extras'], extras_str, run_plugin % info_extra_params))
			if self.cm_services['trakt']: cm_append((self.cm_sort['trakt'], traktmanager_str, run_plugin % trakt_manager_params))
			if self.cm_services['mdblist']: cm_append((self.cm_sort['mdblist'], mdblmanager_str, run_plugin % mdbl_manager_params))
			if self.cm_services['tmdblist']: cm_append((self.cm_sort['tmdblist'], tmdbmanager_str, run_plugin % tmdb_manager_params))
			if settings.context_rating_enabled('tvshow'): cm_append((self.cm_sort['rating'], ls(33136), run_plugin % rating_params))
			if settings.context_favourites_enabled(): cm_append((self.cm_sort['favourites'], fav_manager_label, run_plugin % fav_manager_params))
			if not playcount: cm_append((self.cm_sort['mark'], watched_str % self.watched_title, run_plugin % build_url({
				'mode': 'mark_as_watched_unwatched_tvshow', 'action': 'mark_as_watched', 'year': year,
				'tmdb_id': tmdb_id, 'imdb_id': imdb_id, 'tvdb_id': tvdb_id, 'title': title
			})))
			if total_watched: cm_append((self.cm_sort['mark'], unwatched_str % self.watched_title, run_plugin % build_url({
				'mode': 'mark_as_watched_unwatched_tvshow', 'action': 'mark_as_unwatched', 'year': year,
				'tmdb_id': tmdb_id, 'imdb_id': imdb_id, 'tvdb_id': tvdb_id, 'title': title
			})))
			if self.watched_indicators == 0:
				from caches.watched_cache import local_watchlist_contains
				local_wl_label = 'Retirer de la Watchlist (alkoFlix)' if local_watchlist_contains('tvshow', tmdb_id) else 'Ajouter à la Watchlist (alkoFlix)'
				cm_append((self.cm_sort['mark'], local_wl_label, run_plugin % build_url({'mode': 'toggle_local_watchlist', 'media_type': 'tvshow', 'tmdb_id': tmdb_id, 'title': title})))
			if self.watched_indicators == 0:
				cm_append((self.cm_sort['mark'], 'Basculer l’état « Abandonné » (alkoFlix)...', run_plugin % build_url({
					'mode': 'toggle_local_dropped', 'media_type': 'tvshow', 'tmdb_id': tmdb_id, 'title': title
				})))
			# Trie les entrées du menu contextuel selon l'ordre automatique.
			cm.sort(key=lambda k: k[0])
			cm = [v for k, *v in cm if k]
			props['unwatchedepisodes'] = string(total_unwatched)
			props['totalepisodes'] = string(total_aired_eps)
			props['totalseasons'] = string(total_seasons)
			listitem = kodi_utils.make_listitem()
			listitem.addContextMenuItems(cm)
			listitem.setProperties(props)
			listitem.setLabel(rootname if self.include_year_in_title else title)
#			listitem.setContentLookup(False)
			# Les vues horizontales de certains skins utilisent thumb/tvshow.thumb
			# en priorité. On fournit donc un fallback explicite pour éviter les
			# tuiles grises lorsque landscape ou thumb n'est pas encore résolu.
			thumb = landscape or fanart or tmdb_poster
			listitem.setArt(kodi_utils.clean_art({'poster': poster, 'fanart': fanart, 'icon': poster, 'thumb': thumb, 'banner': banner, 'clearart': clearart, 'clearlogo': clearlogo, 'landscape': landscape or thumb,
							'tvshow.poster': poster, 'tvshow.thumb': thumb, 'tvshow.clearart': clearart, 'tvshow.clearlogo': clearlogo, 'tvshow.landscape': landscape or thumb, 'tvshow.banner': banner}))
			if KODI_VERSION < 20:
				listitem.setCast(meta_get('cast', []))
				listitem.setUniqueIDs({'imdb': imdb_id, 'tmdb': string(tmdb_id), 'tvdb': string(tvdb_id)})
				listitem.setInfo('video', remove_meta_keys(meta, dict_removals))
				listitem.setProperty('watchedepisodes', string(total_watched))
			else:
				if total_watched > 0: listitem.setProperty('watchedepisodes', string(total_watched))
				if total_aired_eps > 0: listitem.setProperty('watchedprogress', string(min(100, int(total_watched / total_aired_eps * 100))))
				videoinfo = listitem.getVideoInfoTag(offscreen=True)
				videoinfo.setCast(make_cast_list(meta_get('cast', [])))
				videoinfo.setUniqueIDs({'imdb': imdb_id, 'tmdb': string(tmdb_id), 'tvdb': string(tvdb_id)})
				videoinfo.setCountries(meta_get('country'))
				videoinfo.setDirectors(meta_get('director').split(', '))
				videoinfo.setDuration(meta_get('duration'))
				videoinfo.setGenres(meta_get('genre').split(', '))
				videoinfo.setIMDBNumber(imdb_id)
				videoinfo.setMediaType('tvshow')
				videoinfo.setMpaa(meta_get('mpaa'))
				videoinfo.setPlaycount(playcount)
				videoinfo.setPlot(meta_get('plot'))
				videoinfo.setPremiered(meta_get('premiered'))
				videoinfo.setRating(meta_get('rating'))
				user_ratings.apply_user_rating_to_listitem(listitem, user_rating, videoinfo)
				videoinfo.setStudios((meta_get('studio'),))
				videoinfo.setTagLine(meta_get('tagline'))
				videoinfo.setTitle(rootname if self.include_year_in_title else title)
				videoinfo.setTrailer(meta_get('trailer'))
				videoinfo.setTvShowStatus(meta_get('status'))
				videoinfo.setTvShowTitle(title)
				videoinfo.setVotes(meta_get('votes'))
				videoinfo.setWriters(meta_get('writer').split(', '))
				videoinfo.setYear(int(year))
			self.append((url_params, listitem, item_is_folder))
		except: pass

	def worker(self):
		if not self.list: return []
		if self._fast_tmdb_search(): return self.fast_search_worker()
		# Cache-first : les séries déjà présentes dans MetaCache sont construites
		# directement ; seuls les cache misses passent dans TaskPool.
		cache = MetaCache()
		misses = []
		for position, media_id in enumerate(self.list, 1):
			meta = cached_tv_meta_function(self.id_type, media_id, self.meta_user_info, cache)
			if meta is None: misses.append((position, media_id))
			else: self.build_tvshow_content(position, media_id, meta)
		kodi_utils.xbmc.log('>> alkoFlix cache-first <<: Séries | total=%s | hits=%s | misses=%s' % (len(self.list), len(self.list) - len(misses), len(misses)), kodi_utils.xbmc.LOGDEBUG)
		try: cache.dbcon.close()
		except: pass
		for i in TaskPool().tasks(self.build_tvshow_content, misses, Thread): i.join()
		self.items.sort(key=lambda k: int(k[1].getProperty('alkoflix_sort_order')))
		return self.items

class Menu(TVShows):
	tmdb_main, trakt_main, tmdb_special_key_dict = (
		'tmdb_tv_popular', 'tmdb_tv_trending', 'tmdb_tv_random', 'tmdb_tv_top_rated', 'tmdb_tv_airing_today', 'tmdb_tv_on_the_air', 'tmdb_tv_airing_this_week', 'tmdb_tv_premieres', 'tmdb_tv_upcoming',
		'tmdb_tvanime_popular', 'tmdb_tvanime_random', 'tmdb_tvanime_premieres', 'tmdb_tvanime_airing_this_week',
		'tmdb_tv_family_popular', 'tmdb_tv_family_random', 'tmdb_tv_family_airing_this_week',
		'tmdb_tv_family_animation_popular', 'tmdb_tv_family_animation_random', 'tmdb_tv_family_animation_airing_this_week',
		'tmdb_tv_documentary_popular', 'tmdb_tv_documentary_random', 'tmdb_tv_documentary_trending', 'tmdb_tv_documentary_airing_this_week', 'tmdb_tv_documentary_premieres',
		'tmdb_tv_reality_popular', 'tmdb_tv_reality_random', 'tmdb_tv_reality_trending', 'tmdb_tv_reality_airing_this_week', 'tmdb_tv_reality_premieres',
		'tmdb_tv_talkshow_popular', 'tmdb_tv_talkshow_random', 'tmdb_tv_talkshow_trending', 'tmdb_tv_talkshow_airing_this_week', 'tmdb_tv_talkshow_premieres',
		'tmdb_tv_news_popular', 'tmdb_tv_news_random', 'tmdb_tv_news_trending', 'tmdb_tv_news_airing_this_week', 'tmdb_tv_news_premieres'
	), (
		'trakt_tv_trending', 'trakt_tv_trending_recent', 'trakt_tv_most_watched',
		'trakt_tvanime_trending', 'trakt_tvanime_most_watched'
	), {
		'tmdb_tv_networks': 'network_id', 'tmdb_tv_year': 'year', 'tmdb_tvanime_year': 'year',
		'tmdb_tv_language': 'language_code', 'tmdb_tv_watch_provider': 'provider_id',
		'tmdb_tvanime_language': 'language_code', 'tmdb_tvanime_watch_provider': 'provider_id',
		'tmdb_tv_family_year': 'year', 'tmdb_tv_family_watch_provider': 'provider_id', 'tmdb_tv_family_kids_watch_provider': 'provider_id', 'tmdb_tv_family_genres': 'genre_id',
		'tmdb_tv_family_animation_year': 'year', 'tmdb_tv_family_animation_watch_provider': 'provider_id', 'tmdb_tv_family_animation_genres': 'genre_id',
		'tmdb_tv_documentary_year': 'year', 'tmdb_tv_documentary_language': 'language_code', 'tmdb_tv_documentary_watch_provider': 'provider_id', 'tmdb_tv_documentary_networks': 'network_id', 'tmdb_tv_documentary_genres': 'genre_id',
		'tmdb_tv_reality_year': 'year', 'tmdb_tv_reality_language': 'language_code', 'tmdb_tv_reality_watch_provider': 'provider_id', 'tmdb_tv_reality_networks': 'network_id', 'tmdb_tv_reality_genres': 'genre_id',
		'tmdb_tv_talkshow_year': 'year', 'tmdb_tv_talkshow_language': 'language_code', 'tmdb_tv_talkshow_watch_provider': 'provider_id', 'tmdb_tv_talkshow_networks': 'network_id', 'tmdb_tv_talkshow_genres': 'genre_id',
		'tmdb_tv_news_year': 'year', 'tmdb_tv_news_language': 'language_code', 'tmdb_tv_news_watch_provider': 'provider_id', 'tmdb_tv_news_networks': 'network_id', 'tmdb_tv_news_genres': 'genre_id',
		'tmdb_tv_keyword': 'keyword_id'
	}
	tmdb_personal = ('tmdb_watchlist', 'tmdb_favorite', 'tmdb_recommendations')
	trakt_personal = ('trakt_collection', 'trakt_watchlist', 'trakt_favorites', 'trakt_collection_lists', 'trakt_droplist')
	mdblist_personal = ('mdblist_collection', 'mdblist_watchlist', 'mdblist_favorites', 'mdblist_droplist')
	imdb_personal = ('imdb_watchlist', 'imdb_user_list_contents')
	similar = ('tmdb_tv_similar', 'tmdb_tv_recommendations')
	personal_dict = {
		'in_progress_tvshows': ('caches.watched_cache', 'get_in_progress_tvshows'),
		'trakt_in_progress_tvshows': ('caches.watched_cache', 'get_in_progress_unwatched_tvshows'),
		'local_droplist': ('caches.watched_cache', 'get_local_dropped_tvshows'),
		'active_watchlist_tvshows': ('caches.watched_cache', 'get_active_watchlist_items'),
		'favourites_tvshows': ('caches.favourites_cache', 'get_favourites'),
		'favourites_tvshows_all': ('caches.favourites_cache', 'get_favourites_tvshows_all'),
		'favourites_tv_family': ('caches.favourites_cache', 'get_favourites_tv_family'),
		'favourites_tv_animation': ('caches.favourites_cache', 'get_favourites_tv_animation'),
		'favourites_anime_tv': ('caches.favourites_cache', 'get_favourites_anime_tv'),
		'favourites_tv_documentary': ('caches.favourites_cache', 'get_favourites_tv_documentary'),
		'favourites_tv_reality': ('caches.favourites_cache', 'get_favourites_tv_reality'),
		'favourites_tv_talkshow': ('caches.favourites_cache', 'get_favourites_tv_talkshow'),
		'favourites_tv_news': ('caches.favourites_cache', 'get_favourites_tv_news'),
		'favourites_tv_qc': ('caches.favourites_cache', 'get_favourites_tv_qc'),
		'favourites_tv_replay': ('caches.favourites_cache', 'get_favourites_tv_replay'),
		'favourites_custom_tvshows': ('caches.favourites_cache', 'get_favourites_custom'),
		'watched_tvshows': ('caches.watched_cache', 'get_watched_items')
	}

	def run(self):
		try:
			params_get = self.params.get
			self.handle = int(sys.argv[1])
			view_type, content_type = 'view.tvshows', 'tvshows'
			mode = params_get('mode')
			try: page_no = int(params_get('new_page', '1'))
			except ValueError: page_no = params_get('new_page')
			letter = params_get('new_letter', 'None')

			# Watchlist/Favoris en mode Aléatoire : même logique que les catalogues
			# « Aléatoire ». On crée le tirage au niveau du menu AVANT toute pagination,
			# puis on transporte la même graine vers les pages suivantes. Un nouvel appel
			# de la page 1 (y compris depuis un widget) reçoit donc un nouveau tirage.
			personal_sort_kind = ''
			if self.action in ('active_watchlist_tvshows', 'trakt_watchlist', 'mdblist_watchlist', 'tmdb_watchlist'):
				personal_sort_kind = 'watchlist'
			elif self.action.startswith('favourites_') or self.action in ('trakt_favorites', 'mdblist_favorites', 'tmdb_favorite'):
				personal_sort_kind = 'favorites'
			if personal_sort_kind:
				effective_personal_sort = params_get('list_sort', '') or settings.default_list_sort(personal_sort_kind)
				if str(effective_personal_sort or '').strip().lower() == 'random':
					self.params['list_sort'] = 'random'
					if page_no == 1:
						try: self.params['list_random_seed'] = str(time.time_ns())
						except: self.params['list_random_seed'] = '%.6f' % time.time()
					elif not params_get('list_random_seed', ''):
						self.params['list_random_seed'] = kodi_utils.ensure_random_seed('%s_%s' % (personal_sort_kind, self.action), page_no)
					params_get = self.params.get
					# Les favoris locaux sont triés dans leur cache : on lui transmet la même
					# graine active afin que l'agrégat complet soit mélangé avant pagination.
					if self.action.startswith('favourites_'):
						kodi_utils.ensure_random_seed('favorites_local', page_no, params_get('list_random_seed', ''))
			if self.action in Menu.personal_dict: var_module, import_function = Menu.personal_dict[self.action]
			else: var_module, import_function = 'indexers.%s_api' % self.action.split('_')[0], self.action
			try: function = manual_function_import(var_module, import_function)
			except: pass
			if self.action == 'alkopaste_catalogue':
				if page_no == 1 and (str(params_get('catalogue_sort', '') or '').strip().lower() == 'random' or str(params_get('list_sort', '') or '').strip().lower() == 'random'):
					# Le catalogue doit vraiment changer à chaque ouverture en mode Aléatoire,
					# que l'aléatoire vienne du dossier dédié ou du menu contextuel Trier par...
					# Le seed est transporté ensuite vers Page suivante pour garder une
					# pagination cohérente dans le même tirage.
					try: self.params['list_random_seed'] = str(time.time_ns())
					except: self.params['list_random_seed'] = '%.6f' % time.time()
					params_get = self.params.get
				from magneto.alkopaste import alkopaste_catalogue_ids
				self.list, total_pages = alkopaste_catalogue_ids('serie', params_get, page_no)
				try: catalogue_full_skip = max(0, int(params_get('catalogue_full_skip', '0') or 0))
				except: catalogue_full_skip = 0
				self.tmdb_sort_offset = ((page_no - 1) * ALKOPASTE_CATALOGUE_PAGE_SIZE) + catalogue_full_skip
				self._alkopaste_full_next_offset = self.tmdb_sort_offset + len(self.list)
				self._alkopaste_full_total_pages = total_pages
				self.total_pages = total_pages
				if total_pages > page_no:
					self.new_page = {'new_page': string(page_no + 1)}
					for key in ('catalogue_section', 'catalogue_sort', 'catalogue_filter_type', 'catalogue_filter_value', 'catalogue_group1', 'catalogue_group2', 'catalogue_full_skip', 'fav_type', 'list_sort', 'list_random_seed', 'catalogue_only'):
						if params_get(key) not in (None, ''): self.new_page[key] = params_get(key)
			elif self.action == 'alkopaste_catalogue_airing':
				# Compatibilité avec un ancien cache/menu : ne plus appeler TMDb ici.
				# On utilise la liste locale On The Air déjà préparée dans le catalogue.
				from magneto.alkopaste import alkopaste_catalogue_ids
				request_params = dict(self.params)
				request_params['catalogue_sort'] = 'tmdb_order'
				request_params['catalogue_group1'] = '__any__'
				request_params['catalogue_group2'] = 'Séries en diffusion'
				request_params['catalogue_media_type'] = 'serie'
				req_get = request_params.get
				self.list, total_pages = alkopaste_catalogue_ids('serie', req_get, page_no)
				try: catalogue_full_skip = max(0, int(req_get('catalogue_full_skip', '0') or 0))
				except: catalogue_full_skip = 0
				self.tmdb_sort_offset = ((page_no - 1) * ALKOPASTE_CATALOGUE_PAGE_SIZE) + catalogue_full_skip
				self._alkopaste_full_next_offset = self.tmdb_sort_offset + len(self.list)
				self._alkopaste_full_total_pages = total_pages
				self.total_pages = total_pages
				if total_pages > page_no:
					self.new_page = {'new_page': string(page_no + 1)}
					for key in ('catalogue_section', 'catalogue_sort', 'catalogue_filter_type', 'catalogue_filter_value', 'catalogue_group1', 'catalogue_group2', 'catalogue_full_skip', 'fav_type', 'list_sort', 'list_random_seed', 'catalogue_only'):
						if req_get(key) not in (None, ''): self.new_page[key] = req_get(key)
			elif self.action in Menu.tmdb_main:
				context_sort = params_get('genre_sort', '')
				data = _call_tmdb_page_function(function, page_no, context_sort) or {}
				current_page, total_pages = self._set_tmdb_source(data, page_no, lambda source_page: _call_tmdb_page_function(function, source_page, context_sort))
				if context_sort:
					try: total_pages = min(int(total_pages), 4)
					except: total_pages = 4
					self._tmdb_full_total_pages = total_pages
				if total_pages > page_no:
					self.new_page = {'new_page': string(current_page + 1)}
					if context_sort: self.new_page['genre_sort'] = context_sort
			elif self.action == 'trakt_catalogue_tv':
				# Catalogue Trakt public / Discover : Trakt fournit uniquement les IDs et
				# l'ordre; le pipeline de métadonnées alkoFlix reste inchangé.
				self.id_type = 'trakt_dict'
				self.list, total_pages = function(self.params, page_no)
				list_sort, list_random_seed = params_get('list_sort', ''), params_get('list_random_seed', '')
				if list_sort:
					try:
						trakt_kind = str(params_get('trakt_list_type', '') or '').strip().lower()
						# En restriction alkoPaste, trakt_api a déjà fait le tri GLOBAL avant
						# pagination. Ne surtout pas retrier chaque page ici.
						if not (settings.trakt_catalogue_alkopaste_only() and trakt_kind != 'anticipated'):
							from modules.list_sorting import apply_context_id_sort
							self.list = apply_context_id_sort(self.list, 'tv', {'list_sort': list_sort, 'list_random_seed': list_random_seed})
					except Exception as e:
						kodi_utils.logger('Catalogue Trakt tri local ignoré', str(e))
				try: self.total_pages = max(1, int(total_pages or 1))
				except: self.total_pages = 1
				if self.total_pages > page_no:
					self.new_page = {'new_page': string(page_no + 1)}
					for key in ('trakt_list_type', 'query', 'genres', 'years', 'languages', 'countries', 'runtimes', 'studio_ids', 'certifications', 'watchnow', 'network_ids', 'status', 'ratings', 'votes', 'tmdb_ratings', 'tmdb_votes', 'imdb_ratings', 'imdb_votes', 'rt_meters', 'rt_user_meters', 'metascores', 'trakt_catalogue', 'list_sort', 'list_random_seed'):
						if params_get(key) not in (None, ''): self.new_page[key] = params_get(key)
			elif self.action in Menu.trakt_main:
				self.id_type = 'trakt_dict'
				data = function(page_no)
				list_sort, list_random_seed = params_get('list_sort', ''), params_get('list_random_seed', '')
				if list_sort:
					try:
						from modules.list_sorting import apply_context_list_sort
						data = apply_context_list_sort(data, 'trakt', {'list_sort': list_sort, 'list_random_seed': list_random_seed})
					except Exception as e:
						kodi_utils.logger('trakt anime tv sort skipped', str(e))
				self.list = [i['show']['ids'] for i in data]
				self.new_page = {'new_page': string(page_no + 1)}
				if list_sort: self.new_page['list_sort'] = list_sort
				if list_random_seed: self.new_page['list_random_seed'] = list_random_seed
			elif self.action in Menu.tmdb_personal:
				list_sort, list_random_seed = params_get('list_sort', ''), params_get('list_random_seed', '')
				if self.action in ('tmdb_watchlist', 'tmdb_favorite'):
					data, total_pages = function('tv', page_no, letter, list_random_seed)
				else:
					data, total_pages = function('tv', page_no, letter)
				self.list = [i['id'] for i in data]
				if total_pages > page_no:
					self.new_page = {'new_page': string(page_no + 1), 'new_letter': letter}
					if list_sort: self.new_page['list_sort'] = list_sort
					if list_random_seed: self.new_page['list_random_seed'] = list_random_seed
			elif self.action in Menu.trakt_personal:
				self.id_type = 'trakt_dict'
				list_sort, list_random_seed = params_get('list_sort', ''), params_get('list_random_seed', '')
				if self.action in ('trakt_collection', 'trakt_watchlist', 'trakt_favorites'):
					data, total_pages = function('shows', page_no, letter, list_sort, list_random_seed)
				else:
					data, total_pages = function('shows', page_no, letter)
				self.list = [i['media_ids'] for i in data]
				if self.action == 'trakt_droplist' and params_get('progress_catalogue_section', ''):
					try:
						from caches.watched_cache import _progress_catalogue_ids
						allowed_ids = _progress_catalogue_ids('tvshow', params_get('progress_catalogue_section', ''))
						if allowed_ids is not None: self.list = [i for i in self.list if str((i or {}).get('tmdb') or '') in allowed_ids]
					except: pass
				if total_pages > 2: self.total_pages = total_pages
				try:
					if total_pages > page_no:
						self.new_page = {'new_page': string(page_no + 1), 'new_letter': letter}
						if list_sort: self.new_page['list_sort'] = list_sort
						if list_random_seed: self.new_page['list_random_seed'] = list_random_seed
				except: pass
			elif self.action in Menu.mdblist_personal:
				self.id_type = 'trakt_dict'
				list_sort, list_random_seed = params_get('list_sort', ''), params_get('list_random_seed', '')
				if self.action in ('mdblist_watchlist', 'mdblist_favorites'):
					data, total_pages = function('shows', page_no, letter, list_sort, list_random_seed)
				else:
					data, total_pages = function('shows', page_no, letter)
				self.list = [{'imdb': i['imdb_id'], 'tmdb': i['id']} for i in data]
				if self.action == 'mdblist_droplist' and params_get('progress_catalogue_section', ''):
					try:
						from caches.watched_cache import _progress_catalogue_ids
						allowed_ids = _progress_catalogue_ids('tvshow', params_get('progress_catalogue_section', ''))
						if allowed_ids is not None: self.list = [i for i in self.list if str((i or {}).get('tmdb') or '') in allowed_ids]
					except: pass
				if total_pages > 2: self.total_pages = total_pages
				try:
					if total_pages > page_no:
						self.new_page = {'new_page': string(page_no + 1), 'new_letter': letter}
						if list_sort: self.new_page['list_sort'] = list_sort
						if list_random_seed: self.new_page['list_random_seed'] = list_random_seed
				except: pass
			elif self.action in Menu.imdb_personal:
				self.id_type = 'imdb_id'
				list_id = params_get('list_id')
				data, next_page = function('tvshow', list_id, page_no)
				self.list = [i['imdb_id'] for i in data]
				if next_page: self.new_page = {'list_id': list_id, 'new_page': string(page_no + 1), 'new_letter': letter}
			elif self.action in Menu.personal_dict:
				forced_watched_indicators = params_get('watched_indicators')
				list_sort, list_random_seed = params_get('list_sort', ''), params_get('list_random_seed', '')
				# Sans indicateur forcé, les dossiers de suivi utilisent le choix actif de l'utilisateur :
				# alkoFlix local, Trakt ou MDBList. Dans les sous-dossiers Trakt/MDBList,
				# l'indicateur est forcé par le navigateur du service concerné.
				favourite_query_type = params_get('fav_type') if self.action == 'favourites_custom_tvshows' else 'tvshow'
				if self.action == 'active_watchlist_tvshows':
					watchlist_kwargs = {'list_sort': list_sort, 'list_random_seed': list_random_seed, 'progress_group': params_get('progress_group', ''), 'catalogue_section': params_get('progress_catalogue_section', '')}
					if forced_watched_indicators not in (None, ''): watchlist_kwargs['watched_indicators'] = int(forced_watched_indicators)
					data, total_pages = function(favourite_query_type, page_no, letter, **watchlist_kwargs)
				elif self.action == 'trakt_in_progress_tvshows':
					progress_kwargs = {'list_sort': list_sort, 'list_random_seed': list_random_seed, 'progress_group': params_get('progress_group', ''), 'catalogue_section': params_get('progress_catalogue_section', ''), 'continue_watching': self.hide_watched_items}
					if forced_watched_indicators not in (None, ''): progress_kwargs['watched_indicators'] = int(forced_watched_indicators)
					data, total_pages = function(favourite_query_type, page_no, letter, **progress_kwargs)
				elif self.action in ('in_progress_tvshows', 'watched_tvshows'):
					personal_kwargs = {'list_sort': list_sort, 'list_random_seed': list_random_seed}
					if self.action == 'watched_tvshows':
						personal_kwargs['catalogue_section'] = params_get('progress_catalogue_section', '')
						personal_kwargs['progress_group'] = params_get('progress_group', '')
					if forced_watched_indicators not in (None, ''): personal_kwargs['watched_indicators'] = int(forced_watched_indicators)
					data, total_pages = function(favourite_query_type, page_no, letter, **personal_kwargs)
				else:
					data, total_pages = function(favourite_query_type, page_no, letter)
				self.list = [i['media_id'] for i in data]
				if self.action == 'local_droplist' and params_get('progress_catalogue_section', ''):
					try:
						from caches.watched_cache import _progress_catalogue_ids
						allowed_ids = _progress_catalogue_ids('tvshow', params_get('progress_catalogue_section', ''))
						if allowed_ids is not None: self.list = [i for i in self.list if str(i) in allowed_ids]
					except: pass
				if total_pages > 2: self.total_pages = total_pages
				if total_pages > page_no:
					self.new_page = {'new_page': string(page_no + 1), 'new_letter': letter}
					if list_sort: self.new_page['list_sort'] = list_sort
					if list_random_seed: self.new_page['list_random_seed'] = list_random_seed
				if self.watched_indicators == 1:
					try:
						hidden_data = trakt_get_hidden_items('dropped')
						self.list = [i for i in self.list if not int(i) in hidden_data]
					except: pass
			elif self.action in Menu.similar:
				tmdb_id = self.params['tmdb_id']
				data = function(tmdb_id, page_no)
				current_page, total_pages = self._set_tmdb_source(data, page_no, lambda source_page: function(tmdb_id, source_page))
				if current_page < total_pages: self.new_page = {'new_page': string(current_page + 1), 'tmdb_id': tmdb_id}
			elif self.action in Menu.tmdb_special_key_dict:
				key = Menu.tmdb_special_key_dict[self.action]
				function_var = params_get(key)
				if not function_var: return
				provider_region = params_get('provider_region')
				context_sort = _default_tmdb_special_context_sort(self.action, params_get)
				if key == 'language_code' and str(function_var).lower() not in ('fr', 'en') and self.action not in ('tmdb_tvanime_language',):
					context_sort = ''
				data = _call_tmdb_special_function(function, function_var, page_no, context_sort, provider_region if self.action.endswith('_watch_provider') else None, self.action.endswith('_watch_provider'))
				results = data.get('results', []) if isinstance(data, dict) else []
				current_page, total_pages = self._set_tmdb_source(data, page_no, lambda source_page: _call_tmdb_special_function(function, function_var, source_page, context_sort, provider_region if self.action.endswith('_watch_provider') else None, self.action.endswith('_watch_provider')))
				if self.action.endswith('_watch_provider') and not self.list:
					kodi_utils.logger('catalogue provider empty', '%s | provider_id=%s | region=%s | page=%s' % (self.action, function_var, provider_region or 'settings', page_no))
				if isinstance(data, dict):
					current_page = current_page
					total_pages = total_pages
					if context_sort:
						try: total_pages = min(int(total_pages), 4)
						except: total_pages = 4
						self._tmdb_full_total_pages = total_pages
					if current_page < total_pages:
						self.new_page = {'new_page': string(current_page + 1), key: function_var}
						if provider_region: self.new_page['provider_region'] = provider_region
						if context_sort: self.new_page['genre_sort'] = context_sort
			elif self.action == 'tmdb_person_tvshows':
				from menus.people import person_credit_ids, _person_credits_debug
				actor_id = params_get('actor_id')
				credit_ids = person_credit_ids(actor_id, 'tvshow')
				credit_pages = list(chunks(credit_ids, 40))
				try: self.list = credit_pages[page_no - 1]
				except: self.list = []
				_person_credits_debug('menu page build', actor_id, 'tvshow', len(self.list), 'page=%s/%s | prepared=%s | prepared_count=%s' % (page_no, len(credit_pages), params_get('person_credit_prepared', 'false'), params_get('person_credit_count', 'N/A')))
				if len(credit_pages) > page_no:
					self.new_page = {'actor_id': actor_id, 'new_page': string(page_no + 1), 'person_credit_prepared': params_get('person_credit_prepared', 'false'), 'person_credit_type': 'tvshow'}
			elif self.action == 'tmdb_tv_discover':
				from menus.discover import set_history
				name = self.params['name']
				query = _strip_tv_discover_certification(self.params['query'])
				if page_no == 1: set_history('tvshow', name, query)
				data = function(query, page_no)
				current_page, total_pages = self._set_tmdb_source(data, page_no, lambda source_page: function(query, source_page))
				if current_page < total_pages:
					self.new_page = {'query': query, 'name': name, 'new_page': string(current_page + 1)}
					if self.discover_hide_watched: self.new_page['discover_hide_watched'] = 'true'
			elif self.action in ('tmdb_tv_genres', 'tmdb_tvanime_genres'):
				genre_id = self.params['genre_id']
				genre_sort = params_get('genre_sort', '')
				if not genre_id: return
				data = function(genre_id, page_no, genre_sort) if genre_sort else function(genre_id, page_no)
				data = data or {}
				results = data.get('results', []) if isinstance(data, dict) else []
				current_page, total_pages = self._set_tmdb_source(data, page_no, lambda source_page: function(genre_id, source_page, genre_sort) if genre_sort else function(genre_id, source_page))
				if isinstance(data, dict):
					current_page = current_page
					total_pages = total_pages
					if genre_sort:
						try: total_pages = min(int(total_pages), 4)
						except: total_pages = 4
						self._tmdb_full_total_pages = total_pages
					if current_page < total_pages:
						self.new_page = {'new_page': string(current_page + 1), 'genre_id': genre_id}
						if genre_sort: self.new_page['genre_sort'] = genre_sort
			elif self.action == 'tmdb_tv_id':
				query = self.params.get('query', '')
				data = function(query, page_no)
				self._set_tmdb_source(data, page_no, lambda source_page: function(query, source_page))
			elif self.action == 'tmdb_tv_search':
				query = self.params['query']
				data = function(query, page_no)
				current_page, total_pages = self._set_tmdb_source(data, page_no, lambda source_page: function(query, source_page))
				if total_pages > current_page: self.new_page = {'new_page': string(current_page + 1), 'query': query}
			elif self.action == 'trakt_tv_certifications':
				self.id_type = 'trakt_dict'
				data = function(self.params['certification'], page_no)
				self.list = [i['show']['ids'] for i in data]
				self.new_page = {'new_page': string(page_no + 1), 'certification': self.params['certification']}
			elif self.action == 'trakt_recommendations':
				self.id_type = 'trakt_dict'
				data = function('shows')
				self.list = [i['ids'] for i in data]
			# Ajoute l'entrée de navigation rapide seulement dans les listes complètes, pas dans les widgets.
			if self.total_pages and not self.is_widget and settings.nav_jump_use_alphabet():
				url_params = {
					'mode': 'build_navigate_to_page', 'current_page': page_no, 'total_pages': self.total_pages,
					'query': params_get('search_name', ''), 'actor_id': params_get('actor_id', ''),
					'transfer_mode': mode, 'transfer_action': self.action, 'media_type': 'Séries'
				}
				for key in ('list_sort', 'list_random_seed', 'genre_sort', 'provider_region', 'genre_id', 'provider_id', 'company_id', 'company', 'network_id', 'year', 'language_code', 'keyword_id'):
					if params_get(key): url_params[key] = params_get(key)
				kodi_utils.add_dir(self.handle, url_params, jumpto_str, item_jump, isFolder=False)
			kodi_utils.add_items(self.handle, self._complete_alkopaste_catalogue_items(self._complete_tmdb_items(self.worker())))
			if self.new_page:
				self._carry_context_to_next_page(params_get)
				self.new_page.update({'mode': mode, 'action': self.action, 'exit_list_params': self.exit_list_params, 'name': ls(params_get('name'))})
				kodi_utils.add_dir(self.handle, self.new_page, nextpage_str, item_next)
		except: pass
		kodi_utils.set_category(self.handle, ls(params_get('name')))
		kodi_utils.set_sort_method(self.handle, content_type)
		kodi_utils.set_content(self.handle, content_type)
		kodi_utils.end_directory(self.handle, False if self.is_widget else None)
		kodi_utils.set_view_mode(view_type, content_type)

