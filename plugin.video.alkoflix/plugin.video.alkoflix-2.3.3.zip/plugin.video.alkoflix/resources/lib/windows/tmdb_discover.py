# -*- coding: utf-8 -*-
# plugin.video.alkoflix
# Fenêtre Discover TMDb 2.3.0 : même cycle de vie que Discover Trakt.

from modules import kodi_utils


class TMDbDiscoverDialog(kodi_utils.window_xml_dialog):
	LIST_ID = 3
	SAVE_ID = 5
	UNUSED_ID = 6
	CLOSE_ID = 7
	RESET_ID = 8

	def __init__(self, *args, **kwargs):
		self.controller = kwargs.get('controller')
		self.result = None
		self._closed = False

	def onInit(self):
		try: self.getControl(1).setLabel('TMDb Discover')
		except Exception: pass
		try: self.getControl(self.SAVE_ID).setLabel('Enregistrer')
		except Exception: pass
		try: self.getControl(self.UNUSED_ID).setVisible(False)
		except Exception: pass
		try: self.getControl(self.CLOSE_ID).setLabel('Fermer')
		except Exception: pass
		try: self.getControl(self.RESET_ID).setLabel('Réinitialiser')
		except Exception: pass
		self.build_menu()

	def _item(self, row):
		li = kodi_utils.make_listitem(); li.setLabel(str(row.get('label') or ''))
		li.setProperty('alkoflix.tmdbdiscover.action', str(row.get('action') or ''))
		icon = str(row.get('icon') or '')
		if icon:
			try:
				icon_path = kodi_utils.media_path(icon)
				li.setArt({'icon': icon_path, 'thumb': icon_path})
			except Exception: pass
		return li

	def build_menu(self, select_action=None):
		if self._closed or not self.controller: return
		try:
			rows = self.controller.modal_rows(); items = [self._item(row) for row in rows]
			control = self.getControl(self.LIST_ID)
			try: current = control.getSelectedPosition()
			except Exception: current = -1
			control.reset(); control.addItems(items)
			# Même stratégie que Discover Trakt; on évite de forcer le focus si le
			# skin ne rend pas encore le contrôle focalisable (AF3 le signale parfois).
			try:
				if self.getFocusId() != self.LIST_ID: self.setFocus(control)
			except Exception: pass
			if select_action:
				for idx, row in enumerate(rows):
					if str(row.get('action') or '') == str(select_action):
						control.selectItem(idx); break
			elif current >= 0 and current < len(items): control.selectItem(current)
		except Exception as exc:
			kodi_utils.logger('TMDb Discover dialog', 'build_menu failed: %s' % exc)

	def refresh(self, select_action=None):
		self.build_menu(select_action=select_action)

	def _selected(self):
		try: return self.getControl(self.LIST_ID).getSelectedItem()
		except Exception: return None

	def _run_selected(self):
		item = self._selected()
		if not item or not self.controller: return
		action = str(item.getProperty('alkoflix.tmdbdiscover.action') or '')
		if action == 'save': return self._save()
		if action == 'export_menu':
			self.result = ('export', 'menu'); return self.close()
		if action == 'export_folder':
			self.result = ('export', 'folder'); return self.close()
		method = getattr(self.controller, 'discover_%s' % action, None)
		if callable(method): return method()

	def _save(self):
		if self.controller and self.controller.discover_save():
			self.result = ('saved', None); return self.close()

	def _reset(self):
		if self.controller: return self.controller.discover_reset()

	def onAction(self, action):
		try: action_id = action.getId()
		except Exception: action_id = int(action)
		if action_id in kodi_utils.window_xml_closing_actions: return self.close()
		if action_id not in kodi_utils.window_xml_selection_actions: return
		try: focus_id = self.getFocusId()
		except Exception: focus_id = 0
		if focus_id == self.LIST_ID: return self._run_selected()
		if focus_id == self.SAVE_ID: return self._save()
		if focus_id == self.RESET_ID: return self._reset()
		if focus_id == self.CLOSE_ID: return self.close()

	def close(self):
		self._closed = True
		try: return kodi_utils.window_xml_dialog.close(self)
		except Exception: pass
