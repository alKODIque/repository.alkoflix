# -*- coding: utf-8 -*-
# plugin.video.alkoflix
# resources/lib/magneto/draupnirr.py

from modules.private_torznab import PrivateTorznabSource


class source(PrivateTorznabSource):
	provider_key = 'draupnirr'
	provider_name = 'DRAUPNIRR'
	api_setting = 'private.draupnirr.api_key'
	base_url = 'https://draupnirr.xyz/torznab/api'
	response_mode = 'xml'

	# DRAUPNIRR expose une API Torznab directe. La passkey personnelle sert
	# d'apikey et n'est envoyée qu'au tracker dans la query string.
	auth_mode = 'query_apikey'
	auth_modes = ('query_apikey',)
	try_next_auth_on_empty = False

	# La documentation Torznab DRAUPNIRR expose surtout la recherche texte (q).
	# On privilégie donc les titres alkoFlix (Titre + année / SxxExx) plutôt que
	# d'envoyer des paramètres d'identifiants non documentés.
	prefer_query_search = True

	# Catégories Torznab : 2000 Films, 5000 Séries.
	movie_categories = '2000'
	episode_categories = '5000'
	season_categories = '5000'
	show_categories = '5000'

	# Source privée stricte : alkoFlix n'utilise jamais le lien .torrent
	# personnalisé. Seuls l'infohash et le magnet propre issus de Torznab sont
	# conservés pour la résolution côté débrideur.
	trust_api_results = False
	allow_loose_private_match = False
	max_requests_per_minute = 120
	timeout = 8
	priority = 5
