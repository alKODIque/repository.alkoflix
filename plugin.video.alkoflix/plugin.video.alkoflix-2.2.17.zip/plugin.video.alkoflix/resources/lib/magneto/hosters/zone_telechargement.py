# -*- coding: utf-8 -*-
# plugin.video.alkoflix
# resources/lib/magneto/hosters/zone_telechargement.py

import re
from concurrent.futures import ThreadPoolExecutor, as_completed
from threading import local
from html import unescape
from urllib.parse import parse_qs, urljoin, urlparse

import requests
from bs4 import BeautifulSoup, Tag

from magneto.hosters.common import (
	BaseHosterSource, abs_url, clean_text, language_code, normalize_quality,
	normalize_text, title_variants
)


def _host_without_www(value):
	value = str(value or '').lower()
	return value[4:] if value.startswith('www.') else value


def _www_variant(url):
	try:
		p = urlparse(str(url or ''))
		if not p.scheme or not p.netloc: return ''
		host = p.hostname or ''
		if not host: return ''
		alt_host = host[4:] if host.lower().startswith('www.') else 'www.' + host
		netloc = alt_host
		try:
			if p.port is not None: netloc += ':%s' % p.port
		except Exception:
			pass
		return p._replace(netloc=netloc).geturl()
	except Exception:
		return ''


class source(BaseHosterSource):
	"""Zone-Telechargement scraper adapted from Wastream's provider.

	The source validates the title/year on the content page, crawls alternate
	quality/season pages and resolves Zoneurs intermediary links before returning
	the actual hoster URL to alkoFlix.
	"""

	provider_key = 'zone_telechargement'
	provider_name = 'Zone-Telechargement'
	base_setting = 'hoster.zone_telechargement.url'
	default_base_url = ''  # supplied by the alkoPastes dynamic URL feed
	priority = 7
	MAX_SEARCH_PAGES = 3
	MAX_RELATED_PAGES = 30
	MAX_RESOLVE_WORKERS = 16
	MAX_VERIFY_WORKERS = 8
	MAX_PAGE_WORKERS = 10
	CONTENT_TIMEOUT = 5.0
	ZONEURS_TIMEOUT = 2.5
	HOST_ALIASES = {
		'trbt.cc': 'turbobit.net',
		'turbobit.cc': 'turbobit.net',
		'trbbt.net': 'turbobit.net',
		'turb.cc': 'turbobit.net',
		'turb.pw': 'turbobit.net',
		'rg.to': 'rapidgator.net'
	}

	def __init__(self, *args, **kwargs):
		try: super().__init__(*args, **kwargs)
		except TypeError: pass
		self._base_override = ''
		self._domain_refresh_attempted = False
		self._page_cache = {}
		self._thread_http = local()

	def base_url(self):
		if self._base_override: return self._base_override.rstrip('/')
		return super().base_url()

	def _refresh_dynamic_base(self):
		if self._domain_refresh_attempted: return ''
		self._domain_refresh_attempted = True
		try:
			from magneto.hosters.alkopaste_urls import get_hoster_url
			url = get_hoster_url(self.provider_key, force=True)
			if url:
				self._base_override = url.rstrip('/')
				return self._base_override
		except Exception:
			pass
		return ''

	def _headers(self, ajax=False):
		base = self.base_url()
		headers = {
			'User-Agent': (
				'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
				'AppleWebKit/537.36 (KHTML, like Gecko) '
				'Chrome/152.0.0.0 Safari/537.36 Edg/152.0.0.0'
			),
			'Accept': 'text/html,application/xhtml+xml,application/json;q=0.9,*/*;q=0.8',
			'Accept-Language': 'fr-FR,fr;q=0.9,en;q=0.7',
			'Referer': '%s/' % base if base else ''
		}
		if ajax: headers['X-Requested-With'] = 'XMLHttpRequest'
		return headers

	def _session(self):
		"""Une session HTTP par thread : connexions persistantes sans partage non sûr."""
		try:
			session = getattr(self._thread_http, 'session', None)
			if session is None:
				session = requests.Session()
				self._thread_http.session = session
			return session
		except Exception:
			return requests

	def _request_text(self, url, params=None, ajax=False, timeout=None):
		try:
			response = self._session().get(
				url, params=params, headers=self._headers(ajax=ajax),
				timeout=timeout or self.CONTENT_TIMEOUT, allow_redirects=True
			)
			if response.status_code != 200: return ''
			text = response.text or ''
			# Ne jamais parser une page de challenge comme une fiche ZT.
			if re.search(r'(?:just\s+a\s+moment|verify\s+you\s+are\s+human|cf[-_ ]?challenge|access\s+denied)', text[:20000], re.I):
				return ''
			return text
		except Exception:
			return ''

	def _get(self, url, params=None, ajax=False, retry_domain=True):
		old_base = self.base_url()
		html = self._request_text(url, params=params, ajax=ajax)
		if html or not retry_domain: return html

		alt_url = _www_variant(url)
		if alt_url and alt_url != url:
			html = self._request_text(alt_url, params=params, ajax=ajax)
			if html:
				try:
					p = urlparse(alt_url)
					self._base_override = '%s://%s' % (p.scheme or 'https', p.netloc)
				except Exception:
					pass
				return html

		# Comme Movix, Zone-Telechargement peut changer de domaine sans prévenir.
		# On force une seule actualisation du flux alkoPastes par recherche, puis on
		# réécrit l'URL demandée vers le nouveau domaine si nécessaire.
		new_base = self._refresh_dynamic_base()
		if not new_base or new_base.rstrip('/') == (old_base or '').rstrip('/'):
			return ''
		try:
			old = urlparse(old_base or '')
			current = urlparse(url or '')
			new = urlparse(new_base)
			if current.hostname and old.hostname and _host_without_www(current.hostname) == _host_without_www(old.hostname):
				netloc = new.netloc
				url = current._replace(scheme=new.scheme or current.scheme, netloc=netloc).geturl()
		except Exception:
			pass
		return self._request_text(url, params=params, ajax=ajax)

	def _soup(self, html):
		try: return BeautifulSoup(html or '', 'html.parser')
		except Exception: return None

	def _fetch_page(self, url, retry_domain=False):
		"""Fetch and cache a normal ZT content page for the duration of one search."""
		if not url: return ''
		try:
			if url in self._page_cache: return self._page_cache[url]
		except Exception:
			pass
		html = self._get(url, retry_domain=retry_domain)
		try: self._page_cache[url] = html or ''
		except Exception: pass
		return html or ''

	def _fetch_pages_parallel(self, urls, supplied=None):
		"""Fetch static content pages concurrently while preserving the input order."""
		ordered = []
		seen = set()
		for url in urls or []:
			if url and url not in seen:
				seen.add(url); ordered.append(url)
		if not ordered: return {}
		result = dict(supplied or {})
		for url, html in list(result.items()):
			if html:
				try: self._page_cache[url] = html
				except Exception: pass
		pending = [u for u in ordered if not result.get(u)]
		if not pending: return result
		workers = max(1, min(self.MAX_PAGE_WORKERS, len(pending)))
		try:
			with ThreadPoolExecutor(max_workers=workers) as pool:
				futures = {pool.submit(self._fetch_page, url, False): url for url in pending}
				for future in as_completed(futures):
					url = futures[future]
					try: result[url] = future.result() or ''
					except Exception: result[url] = ''
		except Exception:
			for url in pending: result[url] = self._fetch_page(url, False)
		return result

	def _content_type(self, data):
		if data.get('anime_context'): return 'anime'
		return 'series' if data.get('tvshowtitle') else 'films'

	def _internal_url(self, href, page_url):
		try:
			if not href: return ''
			href = unescape(str(href)).strip()
			if href.startswith('//'): href = 'https:' + href
			full = urljoin(page_url, href)
			p = urlparse(full); page = urlparse(page_url); base = urlparse(self.base_url())
			if p.scheme not in ('http', 'https'): return ''
			host = _host_without_www(p.hostname)
			page_host = _host_without_www(page.hostname)
			base_host = _host_without_www(base.hostname)
			if host not in (page_host, base_host): return ''
			return full
		except Exception:
			return ''

	def _run_filter(self, query, content_type, page):
		base = self.base_url()
		category = {'films': '2', 'movies': '2', 'series': '15', 'anime': '32'}.get(content_type)
		if not base or not category: return []
		params = {
			'mod': 'filter', 'catid': '0', 'q': query, 'categorie[]': category,
			'art': '0', 'AiffchageMode': '0', 'inputTirePar': '0', 'cstart': str(page)
		}
		html = self._get('%s/engine/ajax/controller.php' % base, params=params, ajax=True)
		if not html: return []
		soup = self._soup(html)
		if not soup: return []
		urls, seen = [], set()
		for node in soup.select('a[href]'):
			full = self._internal_url(node.get('href') or '', base)
			if not full: continue
			if not re.search(r'/\d+-[^/]+\.html$', urlparse(full).path, re.I): continue
			if full in seen: continue
			seen.add(full); urls.append(full)
		return urls

	def _extract_identity(self, html, content_type):
		soup = self._soup(html)
		if not soup: return None
		page_title = ''
		for node in soup.select('div[style]'):
			style = re.sub(r'\s+', '', str(node.get('style') or '').lower())
			if 'font-size:24px' in style:
				page_title = clean_text(node.get_text(' ', strip=True))
				if page_title: break
		if not page_title:
			node = soup.select_one('[data-title]')
			if node: page_title = clean_text(node.get('data-title') or '')
		if not page_title: return None
		title = normalize_text(page_title)
		if content_type != 'films':
			title = re.sub(r'\s+saison\s+\d+\b.*$', '', title, flags=re.I).strip()
		text = clean_text(soup.get_text(' ', strip=True))
		m = re.search(r'Date de sortie\s*:?\s*(\d{4})-\d{2}-\d{2}', text, re.I)
		return {'title': title, 'year': m.group(1) if m else ''}

	def _verify_candidate_urls(self, urls, content_type, targets, year):
		if not urls: return (None, None)
		workers = max(1, min(self.MAX_VERIFY_WORKERS, len(urls)))
		html_by_url = {}
		try:
			with ThreadPoolExecutor(max_workers=workers) as pool:
				futures = {pool.submit(self._fetch_page, url, False): url for url in urls}
				for future in as_completed(futures):
					url = futures[future]
					try: html_by_url[url] = future.result() or ''
					except Exception: html_by_url[url] = ''
		except Exception:
			for url in urls: html_by_url[url] = self._fetch_page(url, False)

		fallback = None
		for url in urls:  # ordre ZT conservé malgré le chargement parallèle
			html = html_by_url.get(url) or ''
			if not html: continue
			identity = self._extract_identity(html, content_type)
			if not identity or identity.get('title') not in targets: continue
			entry = {'link': url, 'html': html}
			entry_year = str(identity.get('year') or '').strip()
			if year and entry_year == year: return entry, fallback
			if not year: return entry, fallback
			if fallback is None: fallback = entry
		return None, fallback

	def _search_content(self, data):
		base = self.base_url()
		if not base: return None
		content_type = self._content_type(data)
		year = str(data.get('year') or '').strip()
		variants = title_variants(data, limit=6)
		targets = [normalize_text(i) for i in variants if i]
		fallback = None
		# Comme Wastream : page 0 d'abord. On ne parcourt les pages suivantes que si
		# aucun candidat valable n'a été trouvé, ce qui évite des GET inutiles.
		for title in variants:
			for page in range(0, self.MAX_SEARCH_PAGES):
				urls = self._run_filter(title, content_type, page)
				if not urls: continue
				match, page_fallback = self._verify_candidate_urls(urls, content_type, targets, year)
				if match: return match
				if fallback is None and page_fallback is not None: fallback = page_fallback
		# Identique à Wastream : titre strict comme dernier repli si l'année est absente.
		return fallback

	def _quality_pages(self, anchor, initial_html=''):
		pages, seen = [], set()
		def add(url):
			if url and url not in seen:
				seen.add(url); pages.append(url)
		add(anchor)
		html = initial_html or self._get(anchor)
		soup = self._soup(html)
		if not soup: return pages
		for span in soup.select('span.otherquality'):
			parent = span.parent if isinstance(span.parent, Tag) else None
			if not parent or parent.name != 'a': continue
			add(self._internal_url(parent.get('href') or '', anchor))
		return pages

	def _related_pages(self, anchor, initial_html=''):
		seen, ordered = set(), []
		frontier = [anchor] if anchor else []
		if initial_html and anchor:
			self._page_cache[anchor] = initial_html
		while frontier and len(ordered) < self.MAX_RELATED_PAGES:
			current = []
			for url in frontier:
				if url and url not in seen and url not in current:
					current.append(url)
			if not current: break
			current = current[:max(0, self.MAX_RELATED_PAGES - len(ordered))]
			htmls = self._fetch_pages_parallel(current, {anchor: initial_html} if initial_html else None)
			frontier = []
			for page_url in current:
				if page_url in seen: continue
				seen.add(page_url); ordered.append(page_url)
				soup = self._soup(htmls.get(page_url) or '')
				if not soup: continue
				for span in soup.select('span.otherquality'):
					parent = span.parent if isinstance(span.parent, Tag) else None
					if not parent or parent.name != 'a': continue
					full = self._internal_url(parent.get('href') or '', page_url)
					if full and full not in seen and full not in frontier:
						frontier.append(full)
		return ordered

	def _release_info(self, raw, page_url, content_title=''):
		size_pattern = r'(?:\(\s*)?~?\s*([\d.,]+\s*[KMGT]o)(?:\s*par\s+[eé]pisode)?\s*\)?'
		m = re.search(size_pattern, raw or '', re.I)
		size = clean_text(m.group(1)) if m else ''
		name = re.sub(size_pattern, '', raw or '', flags=re.I).strip(' -~')
		technical = name
		if content_title:
			normalized_title = normalize_text(content_title)
			normalized_name = normalize_text(name)
			if normalized_name.startswith(normalized_title):
				# Keep the original string for display, but quality/language detection can
				# safely inspect the full release label too.
				technical = name
		quality = normalize_quality('%s %s' % (technical, page_url))
		language = language_code(technical)
		return {'name': name, 'quality': quality, 'language': language, 'raw_language': name, 'size': size}

	def _ignored_release(self, value):
		return normalize_text(value).rstrip(':').strip() in ('lien premium', 'liens premium', 'lien premiums', 'liens premiums')

	def _markers(self, block, series=False):
		markers = []
		for node in block.descendants:
			if not isinstance(node, Tag): continue
			name = (node.name or '').lower()
			if name == 'font' and str(node.get('color') or '').strip().lower() == 'red':
				text = clean_text(node.get_text(' ', strip=True))
				if text and not self._ignored_release(text): markers.append(('release', text))
				continue
			if name == 'img':
				path = urlparse(node.get('src') or '').path
				image = path.rsplit('/', 1)[-1]
				if path.lower().startswith('/img/') and image.lower().endswith('.png'):
					host = image[:-4].strip().lower()
					if host: markers.append(('host', host))
				continue
			if name == 'div':
				style = ''.join(str(node.get('style') or '').lower().split())
				if 'color:#1e88e5' in style:
					host = clean_text(node.get_text(' ', strip=True)).lower()
					if host: markers.append(('host', host))
				continue
			if name != 'a': continue
			classes = [str(i).lower() for i in (node.get('class') or [])]
			href = unescape(node.get('href') or '')
			parsed = urlparse(href)
			if 'btntolink' not in classes or not parsed.netloc: continue
			if 'url' not in parse_qs(parsed.query, keep_blank_values=True): continue
			label = clean_text(node.get_text(' ', strip=True))
			if not series:
				markers.append(('link', (href, label)))
			else:
				m = re.search(r'\b[EÉeé]pisode\s*(\d+)\b', label, re.I)
				if m: markers.append(('link', (href, m.group(1))))
		return markers

	def _collect_movie_pairs(self, html, page_url):
		soup = self._soup(html)
		if not soup: return []
		identity = self._extract_identity(html, 'films') or {}
		title = identity.get('title') or ''
		pairs = []
		for block in soup.select('div.postinfo'):
			release = None; host = ''
			for kind, value in self._markers(block, series=False):
				if kind == 'release': release = self._release_info(value, page_url, title); host = ''; continue
				if kind == 'host': host = value; continue
				if not release or not host: continue
				link, label = value
				if 'partie' in label.lower(): continue
				pairs.append(dict(release, hoster=host, _link=link))
		return pairs

	def _page_season(self, page_url, html=''):
		for text in (page_url, clean_text(html)[:1000]):
			m = re.search(r'saison[ _-]*(\d+)', text or '', re.I)
			if m:
				try: return int(m.group(1))
				except Exception: pass
		return 1

	def _collect_series_pairs(self, html, page_url, data):
		requested_season = int(data.get('season') or 0)
		requested_episode = int(data.get('episode') or 0)
		season = self._page_season(page_url, html)
		if requested_season and season != requested_season: return []
		soup = self._soup(html)
		if not soup: return []
		identity = self._extract_identity(html, 'series') or {}
		title = data.get('tvshowtitle') or identity.get('title') or ''
		pairs = []
		for block in soup.select('div.postinfo'):
			release = None; host = ''
			for kind, value in self._markers(block, series=True):
				if kind == 'release': release = self._release_info(value, page_url, identity.get('title') or title); host = ''; continue
				if kind == 'host': host = value; continue
				if not release or not host: continue
				link, ep = value
				try: epnum = int(ep)
				except Exception: continue
				if requested_episode and epnum != requested_episode: continue
				item = dict(release, hoster=host, _link=link)
				item['display_name'] = '%s S%02dE%02d %s' % (title, season, epnum, release.get('name') or '')
				pairs.append(item)
		return pairs

	def _canonicalize_hoster_url(self, url):
		try:
			parsed = urlparse(str(url or ''))
			host = (parsed.hostname or '').lower().rstrip('.')
			canonical = self.HOST_ALIASES.get(host)
			if not canonical: return str(url or '')
			netloc = canonical
			if parsed.port is not None: netloc += ':%s' % parsed.port
			return parsed._replace(netloc=netloc).geturl()
		except Exception:
			return str(url or '')

	def _host_matches(self, url, expected_host):
		try:
			hostname = (urlparse(url).hostname or '').lower()
			wanted = re.sub(r'[^a-z0-9]', '', str(expected_host or '').lower())
			domain = re.sub(r'[^a-z0-9]', '', hostname)
			return bool(wanted and wanted in domain)
		except Exception:
			return False

	def _resolve_zoneurs(self, link_url, expected_host):
		if not link_url: return ''
		if link_url.startswith('//'): link_url = 'https:' + link_url
		# 1) Certains boutons ZT contiennent déjà l'URL finale dans ?url=. Dans ce
		# cas, appeler Zoneurs ne sert à rien : on gagne une redirection HTTP entière.
		try:
			parsed = urlparse(link_url)
			query = parse_qs(parsed.query, keep_blank_values=False)
			for key in ('url', 'link', 'target'):
				for candidate in query.get(key, []) or []:
					candidate = unescape(str(candidate or '')).strip()
					if candidate.startswith('//'): candidate = 'https:' + candidate
					if not candidate.startswith(('http://', 'https://')): continue
					candidate = self._canonicalize_hoster_url(candidate)
					if self._host_matches(candidate, expected_host): return candidate
		except Exception:
			pass

		# 2) Un lien hébergeur direct a évidemment priorité lui aussi.
		link_url = self._canonicalize_hoster_url(link_url)
		if self._host_matches(link_url, expected_host): return link_url
		try:
			# Zoneurs est une étape auxiliaire : un miroir lent ne doit jamais retenir
			# tout le sélecteur 8 secondes. Les résolutions s'effectuent déjà en parallèle.
			response = self._session().get(link_url, headers=self._headers(), timeout=self.ZONEURS_TIMEOUT, allow_redirects=True)
			if response.status_code != 200: return ''
			final_url = self._canonicalize_hoster_url(str(response.url or ''))
			if final_url and self._host_matches(final_url, expected_host): return final_url
			soup = self._soup(response.text)
			if not soup: return ''
			for selector in ('a.btn-success[href]', 'a.btn-action[href]'):
				node = soup.select_one(selector)
				if node:
					href = unescape(node.get('href') or '')
					if href.startswith('http') and not re.search(r'(zoneurs|/assets/)', href, re.I): return self._canonicalize_hoster_url(href)
			for node in soup.select('a[href]'):
				href = unescape(node.get('href') or '')
				if href.startswith('http'):
					href = self._canonicalize_hoster_url(href)
					if self._host_matches(href, expected_host): return href
		except Exception:
			return ''
		return ''

	def _resolve_pairs(self, pairs):
		if not pairs: return []
		# Une même URL Zoneurs peut être répétée dans plusieurs blocs/qualités. On la
		# résout une seule fois, ce qui évite des allers-retours HTTP redondants.
		unique = {}
		for index, item in enumerate(pairs):
			key = (str(item.get('_link') or ''), str(item.get('hoster') or '').lower())
			unique.setdefault(key, []).append(index)
		workers = max(1, min(self.MAX_RESOLVE_WORKERS, len(unique)))
		resolved_by_key = {}
		try:
			with ThreadPoolExecutor(max_workers=workers) as pool:
				futures = {pool.submit(self._resolve_zoneurs, key[0], key[1]): key for key in unique}
				for future in as_completed(futures):
					key = futures[future]
					try: resolved_by_key[key] = future.result() or ''
					except Exception: resolved_by_key[key] = ''
		except Exception:
			for key in unique:
				resolved_by_key[key] = self._resolve_zoneurs(key[0], key[1])

		results, seen = [], set()
		for index, item in enumerate(pairs):
			key = (str(item.get('_link') or ''), str(item.get('hoster') or '').lower())
			url = resolved_by_key.get(key) or ''
			if not url or url in seen: continue
			seen.add(url)
			raw = {key: value for key, value in item.items() if key != '_link'}
			raw['link'] = url
			raw.setdefault('display_name', raw.get('name') or '')
			results.append(raw)
		return results

	def search(self, data):
		self._domain_refresh_attempted = False
		self._page_cache = {}
		content = self._search_content(data)
		if not content: return []
		anchor = content.get('link') or ''
		initial_html = content.get('html') or ''
		if not anchor: return []
		if initial_html: self._page_cache[anchor] = initial_html
		pairs = []
		if data.get('tvshowtitle'):
			pages = self._related_pages(anchor, initial_html)
			htmls = self._fetch_pages_parallel(pages, {anchor: initial_html} if initial_html else None)
			for page in pages:
				html = htmls.get(page) or ''
				if html: pairs.extend(self._collect_series_pairs(html, page, data))
		else:
			pages = self._quality_pages(anchor, initial_html)
			htmls = self._fetch_pages_parallel(pages, {anchor: initial_html} if initial_html else None)
			for page in pages:
				html = htmls.get(page) or ''
				if html: pairs.extend(self._collect_movie_pairs(html, page))
		return self._resolve_pairs(pairs)

