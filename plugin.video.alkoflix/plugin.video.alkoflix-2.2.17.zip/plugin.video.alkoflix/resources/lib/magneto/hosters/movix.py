# -*- coding: utf-8 -*-
# plugin.video.alkoflix
# resources/lib/magneto/hosters/movix.py
#
# Le nom/provider historique « Movix » est volontairement conservé dans
# alkoFlix. Depuis v2.1.96, son moteur de récupération lit le catalogue Idrix
# (Rentry/TextUp/PrivateBin), suivant la structure utilisée par Wastream.

import base64
import html
import json
import re
import threading
import time
import zlib
from concurrent.futures import ThreadPoolExecutor, as_completed
from urllib.parse import urljoin, urlparse, urlsplit, urlunsplit

import requests

from magneto.hosters.common import BaseHosterSource, clean_text, normalize_quality, normalize_text, title_variants


RENTRY_HOSTS = ('rentry.co', 'www.rentry.co', 'rentry.org', 'www.rentry.org')
TEXTUP_HOSTS = ('textup.fr', 'www.textup.fr')
PRIVATEBIN_HOSTS = ('bin.idrix.fr', 'www.bin.idrix.fr')
SUPPORTED_PAGE_HOSTS = RENTRY_HOSTS + TEXTUP_HOSTS + PRIVATEBIN_HOSTS

ONEFICHIER_RE = re.compile(r'https?://(?:[a-z0-9.-]+\.)?1fichier\.com/[^\s"<>]+', re.I)
EPISODE_RE = re.compile(r'\bS(\d{1,2})\s*E(\d{1,3})\b', re.I)
YEAR_RE = re.compile(r'(?<!\d)(19\d{2}|20\d{2})(?!\d)')
SIZE_RE = re.compile(r'~?\s*([\d.,]+)\s*(Ko|Mo|Go|To|KB|MB|GB|TB)(?:\s+par\s+[eé]pisode)?', re.I)
FILE_EXTENSION_RE = re.compile(r'\.(?:mkv|mka|mp4|avi|m4v|mov|ts|webm)\b', re.I)
NAV_BLOCK_RE = re.compile(
    r'\b(?:streaming|musique|music|filmographies?|signaler|rapport|telegram|vpn|concerts?|clips?)\b',
    re.I,
)
CLOUDFLARE_RE = re.compile(
    r'(?:<title>\s*just\s+a\s+moment|cf-chl-|challenge-platform|cf-turnstile|checking\s+your\s+browser)',
    re.I,
)

_PAGE_CACHE = {}
_PAGE_CACHE_LOCK = threading.Lock()
_PAGE_CACHE_TTL = 10 * 60


def _host(url):
    try:
        return (urlsplit(str(url or '')).hostname or '').lower().rstrip('.')
    except Exception:
        return ''


def _clean_release_text(value):
    value = html.unescape(str(value or ''))
    value = FILE_EXTENSION_RE.sub(' ', value)
    value = re.sub(r'@@[^@]*@@', ' ', value)
    value = re.sub(r'\s+', ' ', value)
    return value.strip(' -.:')


def _anchor_to_text(match):
    href = html.unescape(match.group(2) or '')
    inner = re.sub(r'<[^>]+>', ' ', match.group(3) or '')
    inner = html.unescape(re.sub(r'\s+', ' ', inner)).strip()
    if '1fichier.com' in href.lower():
        return ' %s ' % href
    return ' %s ' % inner


def _html_to_text(content):
    """Convertit une page Idrix en lignes exploitables, comme Wastream."""
    content = str(content or '')
    if not re.search(r'<[^>]+>', content):
        return html.unescape(content)

    preserved = {}

    def preserve_block(match):
        key = '__ALKOF_IDRIX_BLOCK_%d__' % len(preserved)
        block = match.group(1) or ''
        block = re.sub(r'<br\s*/?>', '\n', block, flags=re.I)
        block = re.sub(r'<[^>]+>', ' ', block)
        preserved[key] = html.unescape(block)
        return '\n%s\n' % key

    content = re.sub(
        r'<(?:textarea|pre)\b[^>]*>(.*?)</(?:textarea|pre)>',
        preserve_block,
        content,
        flags=re.I | re.S,
    )
    content = re.sub(
        r'<a\b[^>]*\bhref\s*=\s*([\'\"])(.*?)\1[^>]*>(.*?)</a>',
        _anchor_to_text,
        content,
        flags=re.I | re.S,
    )
    content = re.sub(r'<script\b[^>]*>.*?</script>', ' ', content, flags=re.I | re.S)
    content = re.sub(r'<style\b[^>]*>.*?</style>', ' ', content, flags=re.I | re.S)
    content = re.sub(r'<br\s*/?>', '\n', content, flags=re.I)
    content = re.sub(r'</(?:p|div|li|tr|article|section|h[1-6])\s*>', '\n', content, flags=re.I)
    content = re.sub(r'<[^>]+>', ' ', content)
    content = html.unescape(content)
    for key, block in preserved.items():
        content = content.replace(key, block)

    lines = []
    for raw_line in content.splitlines():
        line = re.sub(r'[ \t\f\r]+', ' ', raw_line).strip()
        if line:
            lines.append(line)
    return '\n'.join(lines)


def _extract_links(content, base_url):
    links = []
    seen = set()
    try:
        for match in re.finditer(r'<a\b([^>]*)>(.*?)</a>', str(content or ''), re.I | re.S):
            attrs, inner = match.group(1), match.group(2)
            href_match = re.search(r'href\s*=\s*([\'\"])(.*?)\1', attrs, re.I | re.S)
            if not href_match:
                continue
            href = html.unescape(href_match.group(2) or '').strip()
            if not href:
                continue
            url = urljoin(base_url, href)
            parsed = urlsplit(url)
            if parsed.scheme.lower() not in ('http', 'https') or not parsed.hostname:
                continue
            label = clean_text(inner)
            key = (url, normalize_text(label))
            if key in seen:
                continue
            seen.add(key)
            links.append((url, label))
    except Exception:
        pass
    return links


def _normalize_page_url(url):
    try:
        parsed = urlsplit(str(url or '').strip())
        if parsed.scheme.lower() not in ('http', 'https') or not parsed.hostname:
            return ''
        host = (parsed.hostname or '').lower().rstrip('.')
        if host not in SUPPORTED_PAGE_HOSTS:
            return ''
        # Les fragments ne servent qu'à la clé PrivateBin.
        fragment = parsed.fragment if host in PRIVATEBIN_HOSTS else ''
        query = '' if host in RENTRY_HOSTS else parsed.query
        return urlunsplit((parsed.scheme, parsed.netloc, parsed.path, query, fragment))
    except Exception:
        return ''


def _base58_decode(value):
    alphabet = '123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz'
    number = 0
    for char in str(value or ''):
        if char not in alphabet:
            raise ValueError('invalid PrivateBin key')
        number = number * 58 + alphabet.index(char)
    raw = number.to_bytes((number.bit_length() + 7) // 8, 'big') if number else b''
    leading_zeroes = len(value) - len(value.lstrip('1'))
    return b'\x00' * leading_zeroes + raw


def _base64_decode(value):
    value = str(value or '').strip()
    value += '=' * (-len(value) % 4)
    return base64.b64decode(value)


def _decrypt_privatebin(payload, fragment_key):
    """Déchiffrement optionnel : si PyCryptodome n'est pas disponible, on ignore la page."""
    try:
        from Crypto.Cipher import AES
        from Crypto.Hash import SHA256
        from Crypto.Protocol.KDF import PBKDF2
    except Exception:
        return ''
    try:
        data = json.loads(payload)
        if not isinstance(data, dict) or data.get('status', 0) not in (0, '0', None):
            return ''
        adata = data.get('adata')
        ciphertext_value = data.get('ct')
        spec = adata[0] if isinstance(adata, list) else adata
        if not isinstance(spec, (list, tuple)) or len(spec) < 5 or not ciphertext_value:
            return ''
        iv = _base64_decode(spec[0])
        salt = _base64_decode(spec[1])
        iterations = int(spec[2])
        key_size = int(spec[3])
        tag_size = int(spec[4])
        ciphertext = _base64_decode(ciphertext_value)
        derived_key = PBKDF2(
            _base58_decode(fragment_key), salt, dkLen=key_size // 8,
            count=iterations, hmac_hash_module=SHA256,
        )
        cipher = AES.new(derived_key, AES.MODE_GCM, nonce=iv, mac_len=tag_size // 8)
        cipher.update(json.dumps(adata, separators=(',', ':')).encode())
        tag_length = tag_size // 8
        plaintext = cipher.decrypt_and_verify(ciphertext[:-tag_length], ciphertext[-tag_length:])
        try:
            plaintext = zlib.decompress(plaintext, -15)
        except zlib.error:
            pass
        decoded = plaintext.decode('utf-8', 'replace')
        if decoded.lstrip().startswith('{'):
            nested = json.loads(decoded)
            if isinstance(nested, dict) and isinstance(nested.get('paste'), str):
                decoded = nested['paste']
        return decoded
    except Exception:
        return ''


class source(BaseHosterSource):
    # Le provider reste volontairement « Movix » dans les réglages, tris, sélecteur
    # et logs. Seul le moteur de récupération est remplacé par Idrix.
    provider_key = 'movix'
    provider_name = 'Movix'
    base_setting = 'hoster.movix.url'
    default_base_url = 'https://rentry.co/zsmwc7gc'
    priority = 5

    MAX_CHILD_WORKERS = 4
    MAX_DETAIL_PAGES = 12
    MAX_DEPTH = 3
    REQUEST_TIMEOUT = 8

    def __init__(self, *args, **kwargs):
        try:
            super().__init__(*args, **kwargs)
        except TypeError:
            pass
        self._base_override = ''

    def base_url(self):
        if self._base_override:
            return self._base_override.rstrip('/')
        value = super().base_url()
        # Après le remplacement de l'URL Movix dans le paste officiel, un ancien
        # domaine Movix peut encore vivre 12 h dans le cache local. S'il ne s'agit
        # pas d'une URL Idrix supportée, on force UNE lecture fraîche du paste.
        if value and _host(value) not in SUPPORTED_PAGE_HOSTS:
            try:
                from magneto.hosters.alkopaste_urls import get_hoster_url
                fresh = get_hoster_url(self.provider_key, force=True)
                if fresh and _host(fresh) in SUPPORTED_PAGE_HOSTS:
                    self._base_override = fresh.rstrip('/')
                    return self._base_override
            except Exception:
                pass
        return value.rstrip('/') if value else self.default_base_url.rstrip('/')

    def headers(self):
        return {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
                          '(KHTML, like Gecko) Chrome/131.0 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/json;q=0.9,*/*;q=0.8',
            'Accept-Language': 'fr-FR,fr;q=0.9,en;q=0.6',
            'Cache-Control': 'no-cache',
        }

    def _cache_get(self, url):
        now = time.time()
        with _PAGE_CACHE_LOCK:
            entry = _PAGE_CACHE.get(url)
            if entry and now - entry[0] < _PAGE_CACHE_TTL:
                return entry[1]
        return None

    def _cache_put(self, url, content):
        if not content:
            return
        with _PAGE_CACHE_LOCK:
            _PAGE_CACHE[url] = (time.time(), content)
            # petit garde-fou pour un service Kodi vivant longtemps
            if len(_PAGE_CACHE) > 80:
                oldest = sorted(_PAGE_CACHE.items(), key=lambda item: item[1][0])[:20]
                for key, _value in oldest:
                    _PAGE_CACHE.pop(key, None)

    def _request_page_once(self, url):
        normalized = _normalize_page_url(url)
        if not normalized:
            return ''
        cached = self._cache_get(normalized)
        if cached is not None:
            return cached

        parsed = urlsplit(normalized)
        fetch_url = urlunsplit((parsed.scheme, parsed.netloc, parsed.path, parsed.query, ''))
        headers = self.headers()
        if _host(normalized) in PRIVATEBIN_HOSTS and parsed.fragment:
            headers['X-Requested-With'] = 'JSONHttpRequest'
        try:
            response = requests.get(fetch_url, headers=headers, timeout=self.REQUEST_TIMEOUT)
            if response.status_code != 200:
                return ''
            text = response.text or ''
            if CLOUDFLARE_RE.search(text[:200000]):
                return ''
            if _host(normalized) in PRIVATEBIN_HOSTS and parsed.fragment:
                text = _decrypt_privatebin(text, parsed.fragment)
            if text:
                self._cache_put(normalized, text)
            return text
        except Exception:
            return ''

    def _request_page(self, url):
        content = self._request_page_once(url)
        if content:
            return content
        # Rentry publie rentry.org comme miroir officiel : une panne/filtrage du
        # .co ne doit pas rendre la source entière muette.
        try:
            parsed = urlsplit(url)
            host = (parsed.hostname or '').lower()
            if host in ('rentry.co', 'www.rentry.co'):
                mirror = urlunsplit((parsed.scheme or 'https', 'rentry.org', parsed.path, parsed.query, parsed.fragment))
                return self._request_page_once(mirror)
            if host in ('rentry.org', 'www.rentry.org'):
                mirror = urlunsplit((parsed.scheme or 'https', 'rentry.co', parsed.path, parsed.query, parsed.fragment))
                return self._request_page_once(mirror)
        except Exception:
            pass
        return ''

    def _title_targets(self, data):
        values = title_variants(data, limit=10)
        for key in ('original_title', 'original_name', 'tvshowtitle', 'title'):
            value = clean_text(data.get(key))
            if value and value.casefold() not in [str(v).casefold() for v in values]:
                values.append(value)
        return [normalize_text(value) for value in values if normalize_text(value)]

    def _catalog_link(self, content, base_url, is_series):
        # L'URL fournie dans le paste peut être la page SERIES. Pour un film on
        # suit simplement « FILMS CLIQUEZ ICI » ; aucune seconde URL à maintenir.
        wanted = 'series' if is_series else 'films'
        for url, label in _extract_links(content, base_url):
            label_norm = normalize_text(label)
            if wanted in label_norm and 'cliquez ici' in label_norm and 'streaming' not in label_norm:
                if _host(url) in RENTRY_HOSTS:
                    return _normalize_page_url(url)
        return base_url

    def _candidate_score(self, label, targets, year=''):
        label_clean = clean_text(label)
        label_norm = normalize_text(label_clean)
        if not label_norm or NAV_BLOCK_RE.search(label_clean):
            return -999
        if 'cliquez ici' in label_norm:
            return -999

        # variantes sans année / sans parenthèses pour les libellés du type
        # « À découvert (Shelter) » ou « Doctor Who (2024) ».
        no_year = normalize_text(YEAR_RE.sub(' ', label_clean))
        no_paren = normalize_text(re.sub(r'\([^)]*\)', ' ', label_clean))
        score = -999
        for target in targets:
            if label_norm == target:
                score = max(score, 120)
            if no_year == target or no_paren == target:
                score = max(score, 112)
            if len(target) >= 4 and (label_norm.startswith(target + ' ') or label_norm.endswith(' ' + target)):
                score = max(score, 98)
            if len(target) >= 5 and (' ' + target + ' ') in (' ' + label_norm + ' '):
                score = max(score, 92)
            if len(label_norm) >= 5 and label_norm in target:
                score = max(score, 86)

        requested_year = str(year or '').strip()
        years = YEAR_RE.findall(label_clean)
        if score > 0 and requested_year and years:
            score += 8 if requested_year in years else -20
        return score

    def _find_media_page(self, content, catalog_url, data):
        targets = self._title_targets(data)
        if not targets:
            return ''
        best = None
        for url, label in _extract_links(content, catalog_url):
            if _host(url) not in SUPPORTED_PAGE_HOSTS:
                continue
            score = self._candidate_score(label, targets, data.get('year'))
            if best is None or score > best[0]:
                best = (score, _normalize_page_url(url), label)
        if best and best[0] >= 86:
            return best[1]
        return ''

    def _extract_release_rows(self, content, data):
        text = _html_to_text(content)
        is_series = bool(data.get('tvshowtitle'))
        wanted_season = int(data.get('season') or 0)
        wanted_episode = int(data.get('episode') or 0)
        results = []
        seen = set()
        pending = ''

        for raw_line in text.splitlines():
            line = raw_line.strip()
            if pending:
                line = ('%s %s' % (pending, line)).strip()
                pending = ''
            if '1fichier.com' not in line.lower():
                if line.endswith('-'):
                    pending = line
                continue

            match = ONEFICHIER_RE.search(line)
            if not match:
                continue
            url = html.unescape(match.group(0)).rstrip('.,;:)]}')
            if not url or url in seen:
                continue

            before = _clean_release_text(line[:match.start()])
            episode_match = EPISODE_RE.search(before)
            if is_series:
                if not episode_match:
                    # pas de packs complets dans la recherche d'un épisode précis
                    continue
                if int(episode_match.group(1)) != wanted_season or int(episode_match.group(2)) != wanted_episode:
                    continue
            elif episode_match:
                continue

            size = ''
            size_matches = list(SIZE_RE.finditer(before))
            if size_matches:
                size_match = size_matches[-1]
                size = '%s %s' % (size_match.group(1), size_match.group(2))

            raw_name = before
            title = clean_text(data.get('tvshowtitle') or data.get('title'))
            if title and normalize_text(title) not in normalize_text(raw_name):
                if is_series:
                    raw_name = '%s S%02dE%02d %s' % (title, wanted_season, wanted_episode, raw_name)
                else:
                    raw_name = '%s %s %s' % (title, data.get('year') or '', raw_name)
            raw_name = clean_text(raw_name)
            seen.add(url)
            results.append({
                'link': url,
                'hoster': '1fichier',
                'quality': normalize_quality(raw_name),
                'language': raw_name,
                'raw_language': raw_name,
                'size': size,
                'display_name': raw_name,
            })
        return results

    def _child_priority(self, label, data):
        label_norm = normalize_text(label)
        if NAV_BLOCK_RE.search(label or '') or 'cliquez ici' in label_norm:
            return -1000
        if data.get('tvshowtitle'):
            season = int(data.get('season') or 0)
            episode = int(data.get('episode') or 0)
            wanted = ('s%02d' % season, 'saison %d' % season, 's%02de%02d' % (season, episode))
            compact = label_norm.replace(' ', '')
            if wanted[2] in compact:
                return 100
            if wanted[0] in compact or wanted[1] in label_norm:
                return 80
        return 10

    def _supported_children(self, content, base_url, data, visited):
        children = []
        seen = set()
        for url, label in _extract_links(content, base_url):
            normalized = _normalize_page_url(url)
            if not normalized or normalized in visited or normalized in seen:
                continue
            if _host(normalized) not in SUPPORTED_PAGE_HOSTS:
                continue
            priority = self._child_priority(label, data)
            if priority < 0:
                continue
            seen.add(normalized)
            children.append((priority, normalized))
        children.sort(key=lambda item: item[0], reverse=True)
        return [url for _priority, url in children]

    def _collect_from_media_page(self, media_url, data):
        root = self._request_page(media_url)
        if not root:
            return []

        direct = self._extract_release_rows(root, data)
        if direct:
            return direct

        visited = set([_normalize_page_url(media_url) or media_url])
        frontier = [(media_url, root, 0)]
        pages_seen = 1

        while frontier and pages_seen < self.MAX_DETAIL_PAGES:
            next_urls = []
            next_depth = None
            for page_url, content, depth in frontier:
                if depth >= self.MAX_DEPTH:
                    continue
                for child in self._supported_children(content, page_url, data, visited):
                    if child not in next_urls:
                        next_urls.append(child)
                        next_depth = depth + 1
                    if pages_seen + len(next_urls) >= self.MAX_DETAIL_PAGES:
                        break
                if pages_seen + len(next_urls) >= self.MAX_DETAIL_PAGES:
                    break
            if not next_urls:
                break

            batch = next_urls[:max(0, self.MAX_DETAIL_PAGES - pages_seen)]
            found = []
            fetched = []
            workers = max(1, min(self.MAX_CHILD_WORKERS, len(batch)))
            with ThreadPoolExecutor(max_workers=workers) as pool:
                futures = dict((pool.submit(self._request_page, url), url) for url in batch)
                for future in as_completed(futures):
                    url = futures[future]
                    visited.add(url)
                    try:
                        content = future.result() or ''
                    except Exception:
                        content = ''
                    if not content:
                        continue
                    pages_seen += 1
                    rows = self._extract_release_rows(content, data)
                    if rows:
                        found.extend(rows)
                    fetched.append((url, content, next_depth or 1))
            if found:
                # Toutes les pages du batch ont déjà été traitées en parallèle :
                # on conserve donc toutes les qualités/hébergeurs trouvés ensemble.
                unique = []
                seen_urls = set()
                for item in found:
                    if item.get('link') in seen_urls:
                        continue
                    seen_urls.add(item.get('link'))
                    unique.append(item)
                return unique
            frontier = fetched
        return []

    def search(self, data):
        base = _normalize_page_url(self.base_url())
        if not base:
            return []
        start_content = self._request_page(base)
        if not start_content:
            return []

        is_series = bool(data.get('tvshowtitle'))
        catalog_url = self._catalog_link(start_content, base, is_series)
        if catalog_url == base:
            catalog_content = start_content
        else:
            catalog_content = self._request_page(catalog_url)
        if not catalog_content:
            return []

        media_url = self._find_media_page(catalog_content, catalog_url, data)
        if not media_url:
            return []
        return self._collect_from_media_page(media_url, data)
