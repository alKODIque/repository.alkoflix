# -*- coding: utf-8 -*-
# plugin.video.alkoflix
# resources/lib/magneto/hosters/alkopaste_urls.py

import json
import re
import time
import unicodedata
from urllib.parse import urlparse

import requests


API_URL = 'https://paste.lesalkodiques.com/api.php'
HOSTER_URLS_PASTE_CODE = 'qm9EYvrP'
# Clé publique intégrée de l'addon alkoFlix/alKoPastes.
# Important : ne pas utiliser la clé API personnelle de l'utilisateur pour ce paste officiel.
ALKOPASTES_ADDON_API_KEY = '135e78a79a84713d11e4c0fa269097fa99e46b5ffb3eab9a6982f1005e0e972d'
CACHE_FILE = 'special://profile/addon_data/plugin.video.alkoflix/hoster_urls_cache.json'
REFRESH_SECONDS = 12 * 3600
FAILED_RETRY_SECONDS = 10 * 60
DEFAULT_TIMEOUT = 8.0

_MEMORY = {'loaded_at': 0.0, 'urls': None}


ALIASES = {
	'movix': 'movix',
	'moxix': 'movix',
	'free telecharger': 'free_telecharger',
	'free-telecharger': 'free_telecharger',
	'freetelecharger': 'free_telecharger',
	'free telechargement': 'free_telecharger',
	'free-telechargement': 'free_telecharger',
	'wawacity': 'wawacity',
	'zone telechargement': 'zone_telechargement',
	'zone-telechargement': 'zone_telechargement',
	'zonetelechargement': 'zone_telechargement',
	'zt': 'zone_telechargement'
}


def _logger(heading, message):
	try:
		from modules import kodi_utils
		kodi_utils.logger(heading, message)
	except Exception:
		pass


def _addon_version():
	try:
		from modules import kodi_utils
		return kodi_utils.get_addoninfo('version') or '2.0'
	except Exception:
		return '2.0'


def _translate_path(path):
	try:
		from modules import kodi_utils
		return kodi_utils.translate_path(path)
	except Exception:
		return path


def _make_parent_dirs(path):
	try:
		from modules import kodi_utils
		translated = kodi_utils.translate_path(path)
		parent = translated.rsplit('/', 1)[0] if '/' in translated else translated.rsplit('\\', 1)[0]
		if parent: kodi_utils.make_directorys(parent)
	except Exception:
		pass


def _strip_accents(value):
	try:
		return ''.join(c for c in unicodedata.normalize('NFKD', value) if not unicodedata.combining(c))
	except Exception:
		return value


def _clean_label(value):
	value = _strip_accents(str(value or '')).lower()
	value = re.sub(r'[^a-z0-9]+', ' ', value).strip()
	return value


def _canonical_key(value):
	label = _clean_label(value)
	if not label: return ''
	if label in ALIASES: return ALIASES[label]
	compact = label.replace(' ', '')
	return ALIASES.get(compact, '')


def _valid_url(value):
	try:
		url = str(value or '').strip().strip('"\'<>')
		if not url or not re.match(r'^https?://', url, re.I): return ''
		parsed = urlparse(url)
		if not parsed.netloc: return ''
		return url.rstrip('/')
	except Exception:
		return ''


def _key_from_url(url):
	try:
		host = (urlparse(url).netloc or '').lower()
		if host.startswith('www.'): host = host[4:]
		if 'movix' in host: return 'movix'
		if 'free-telecharger' in host or 'freetelecharger' in host: return 'free_telecharger'
		if 'wawacity' in host: return 'wawacity'
		if 'zone-telechargement' in host or 'zonetelechargement' in host: return 'zone_telechargement'
	except Exception:
		pass
	return ''


def parse_hoster_urls(content):
	urls = {}
	current_key = ''
	for raw_line in str(content or '').splitlines():
		line = raw_line.strip()
		if not line: continue

		if line.startswith('#'):
			current_key = _canonical_key(line.lstrip('#').strip())
			continue

		url_match = re.search(r'https?://[^\s<>"\']+', line, re.I)
		if not url_match: continue
		url = _valid_url(url_match.group(0))
		if not url: continue

		key = ''
		prefix = line[:url_match.start()].strip(' :=\t-')
		if prefix: key = _canonical_key(prefix)
		if not key: key = current_key
		if not key: key = _key_from_url(url)
		if key and key not in urls:
			urls[key] = url
	return urls


def _headers():
	return {
		'X-API-Key': ALKOPASTES_ADDON_API_KEY,
		'Content-Type': 'application/json',
		'User-Agent': 'alkoFlix/%s' % _addon_version()
	}


def _fetch_paste_content():
	last_error = ''
	# Selon la version de l'API, le code peut être accepté sous id, p_code ou slug.
	# On reste toujours sur l'API alkoPastes officielle, jamais sur /raw/ ni sur la clé utilisateur.
	for param_name in ('id', 'p_code', 'slug'):
		try:
			response = requests.get(API_URL, params={'action': 'get', param_name: HOSTER_URLS_PASTE_CODE}, headers=_headers(), timeout=DEFAULT_TIMEOUT)
			try:
				data = response.json()
			except Exception:
				data = {'success': False, 'error': response.text[:200] if hasattr(response, 'text') else 'Réponse invalide'}
			if response.status_code in (200, 201) and data.get('success'):
				paste = data.get('paste') or {}
				content = paste.get('content') or ''
				if isinstance(content, (dict, list)):
					content = json.dumps(content, ensure_ascii=False)
				return str(content or '')
			last_error = data.get('error') or data.get('message') or 'HTTP %s' % response.status_code
		except Exception as exc:
			last_error = '%s: %s' % (type(exc).__name__, exc)
	_logger('alkoPastes hoster URLs', 'FAIL | code=%s | %s' % (HOSTER_URLS_PASTE_CODE, last_error))
	return ''


def _read_cache():
	try:
		path = _translate_path(CACHE_FILE)
		with open(path, 'r', encoding='utf-8') as f:
			data = json.load(f)
		urls = data.get('urls') or {}
		if not isinstance(urls, dict): urls = {}
		return {'fetched_at': float(data.get('fetched_at') or 0), 'urls': urls}
	except Exception:
		return {'fetched_at': 0.0, 'urls': {}}


def _write_cache(urls):
	try:
		_make_parent_dirs(CACHE_FILE)
		path = _translate_path(CACHE_FILE)
		with open(path, 'w', encoding='utf-8') as f:
			json.dump({'fetched_at': time.time(), 'urls': urls or {}}, f, ensure_ascii=False, indent=2, sort_keys=True)
	except Exception:
		pass


def _load_urls(force=False):
	now = time.time()
	memory_urls = _MEMORY.get('urls')
	memory_age = now - float(_MEMORY.get('loaded_at') or 0)
	if not force and memory_urls is not None and memory_age < REFRESH_SECONDS:
		return memory_urls

	cache = _read_cache()
	cache_urls = cache.get('urls') or {}
	cache_age = now - float(cache.get('fetched_at') or 0)
	if not force and cache_urls and cache_age < REFRESH_SECONDS:
		_MEMORY['loaded_at'] = now
		_MEMORY['urls'] = cache_urls
		return cache_urls

	# Si le dernier essai vient tout juste d'échouer, on évite de retaper l'API à chaque recherche.
	if not force and memory_urls is not None and memory_age < FAILED_RETRY_SECONDS:
		return memory_urls

	content = _fetch_paste_content()
	urls = parse_hoster_urls(content)
	if urls:
		_write_cache(urls)
		_MEMORY['loaded_at'] = now
		_MEMORY['urls'] = urls
		_logger('alkoPastes hoster URLs', 'OK | keys=%s' % ','.join(sorted(urls.keys())))
		return urls

	# En cas de panne API, une ancienne URL de cache vaut mieux qu'un domaine codé en dur devenu mort.
	if cache_urls:
		_MEMORY['loaded_at'] = now
		_MEMORY['urls'] = cache_urls
		_logger('alkoPastes hoster URLs', 'STALE_CACHE | keys=%s' % ','.join(sorted(cache_urls.keys())))
		return cache_urls

	_MEMORY['loaded_at'] = now
	_MEMORY['urls'] = {}
	return {}


def get_hoster_url(provider_key, force=False):
	try:
		key = _canonical_key(provider_key) or str(provider_key or '').strip().lower()
		if key == 'free-telecharger': key = 'free_telecharger'
		url = (_load_urls(force=force) or {}).get(key) or ''
		return _valid_url(url)
	except Exception:
		return ''
