# -*- coding: utf-8 -*-
# plugin.video.alkoflix
# resources/lib/magneto/hosters/wawacity.py

import base64
import re
from urllib.parse import parse_qs, quote_plus, unquote, urlparse

from bs4 import BeautifulSoup

from magneto.hosters.common import (
	BaseHosterSource, abs_url, clean_text, normalize_text, normalize_quality,
	language_code, request_text, title_variants
)


class source(BaseHosterSource):
	"""Wawacity direct scraper, adapted from the Wacustom search/extraction model.

	The public site is searched directly, then alkoFlix keeps the protected
	dl-protect link. AllDebrid resolves that protection through its redirector
	endpoint at playback time (handled centrally by alldebrid_api.py).
	"""

	provider_key = 'wawacity'
	provider_name = 'Wawacity'
	base_setting = 'hoster.wawacity.url'
	default_base_url = ''  # domain is supplied by the existing alkoPastes URL feed
	priority = 6
	MAX_SEARCH_PAGES = 3
	MAX_SERIES_PAGES = 24
	SEARCH_MAX_LENGTH = 31
	# Seuls ces hosters sont utiles dans le flux Wawacity alkoFlix : ils sont
	# pris en charge par AllDebrid. Les autres liens (DailyUploads, Uploady, etc.)
	# sont écartés dès le scraping pour ne jamais encombrer le sélecteur.
	ALLDEBRID_HOSTERS = ('1fichier', 'turbobit', 'rapidgator', 'vidoza')


	def _get(self, url):
		return request_text(url, headers={'User-Agent': 'Mozilla/5.0 (Kodi; alkoFlix/2.1.31)'}, timeout=self.timeout)

	def _soup(self, html):
		try: return BeautifulSoup(html or '', 'html.parser')
		except: return None

	def _content_kind(self, data):
		if data.get('anime_context'): return 'mangas'
		return 'series' if data.get('tvshowtitle') else 'films'

	def _search_selector(self, kind):
		if kind == 'series': return 'a[href^="?p=serie&id="]'
		if kind == 'mangas': return 'a[href^="?p=manga&id="]'
		return 'a[href^="?p=film&id="]'

	def _extract_search_entry(self, node):
		try:
			href = node.get('href') or ''
			if not href: return None
			full_text = clean_text(node.get_text(' ', strip=True))
			title = full_text.split('[')[0].strip() if '[' in full_text else full_text
			if not title: return None

			parent = node
			while parent and parent.name:
				classes = parent.get('class') or []
				if 'wa-post-detail-item' in classes: break
				parent = parent.parent

			year = ''
			if parent and getattr(parent, 'name', None):
				for li in parent.find_all('li'):
					span = li.find('span')
					if span and 'annee' in normalize_text(span.get_text(' ', strip=True)):
						value = li.find('a') or li.find('b')
						if value: year = clean_text(value.get_text(' ', strip=True))
						break
			return {'link': href, 'title': title, 'year': year}
		except:
			return None

	def _search_content(self, data):
		base = self.base_url()
		if not base: return None
		kind = self._content_kind(data)
		year = str(data.get('year') or '').strip()
		target_titles = [normalize_text(i) for i in title_variants(data, limit=6) if i]
		if not target_titles: return None

		# Wacustom retries title variants and, if needed, repeats the search without
		# the year while still validating the year found on the Wawacity result.
		for search_year in ([year, ''] if year else ['']):
			for title in title_variants(data, limit=5):
				title = clean_text(title)[:self.SEARCH_MAX_LENGTH]
				if not title: continue
				for page in range(1, self.MAX_SEARCH_PAGES + 1):
					params = 'p=%s&search=%s' % (kind, quote_plus(title))
					if page > 1: params += '&page=%s' % page
					if search_year: params += '&year=%s' % quote_plus(search_year)
					html = self._get('%s/?%s' % (base, params))
					if not html: continue
					soup = self._soup(html)
					if not soup: continue
					for node in soup.select(self._search_selector(kind)):
						entry = self._extract_search_entry(node)
						if not entry: continue
						candidate_title = normalize_text(entry.get('title'))
						if 'saison' in candidate_title:
							candidate_title = re.sub(r'(\s*-\s*)?saison.*$', '', candidate_title, flags=re.I).strip()
						if candidate_title not in target_titles: continue
						# Follow Wacustom's strict title/year validation when a TMDb year exists.
						if year:
							entry_year = str(entry.get('year') or '').strip()
							if not entry_year or entry_year != year: continue
						return entry
		return None

	def _quality_pages_movie(self, first_link):
		base = self.base_url()
		pages, seen = [], set()
		def add(href):
			if href and href not in seen:
				seen.add(href); pages.append(href)
		add(first_link)
		html = self._get(abs_url(first_link, base))
		soup = self._soup(html)
		if not soup: return pages
		for node in soup.select('a[href^="?p=film&id="]'):
			if node.find('button'):
				add(node.get('href') or '')
		return pages

	def _series_pages(self, first_link, requested_season):
		base = self.base_url()
		queue, visited = [first_link], []
		seen = set()
		season_token = 'saison%s' % int(requested_season or 0) if requested_season else ''

		while queue and len(visited) < self.MAX_SERIES_PAGES:
			page = queue.pop(0)
			if not page or page in seen: continue
			seen.add(page); visited.append(page)
			html = self._get(abs_url(page, base))
			soup = self._soup(html)
			if not soup: continue

			for node in soup.select('ul.wa-post-list-ofLinks a[href^="?p=serie&id="], ul.wa-post-list-ofLinks a[href^="?p=manga&id="]'):
				href = node.get('href') or ''
				if not href or href in seen or href in queue: continue
				low = href.lower()
				# Other-season links: only crawl the requested season. Quality links on
				# the current season do not always contain "saison", so keep those too.
				if 'saison' in low and season_token and season_token not in low:
					continue
				if node.find('button') or 'saison' in low:
					queue.append(href)
		return visited

	def _decode_filename(self, url):
		try:
			query = parse_qs(urlparse(url).query or '')
			encoded = (query.get('fn') or [None])[0]
			if not encoded: return ''
			raw = unquote(encoded)
			# Add missing padding defensively; dl-protect usually uses standard base64.
			raw += '=' * (-len(raw) % 4)
			return base64.b64decode(raw).decode('utf-8', 'replace').strip()
		except:
			return ''

	def _season_episode_from_name(self, name, page_path='', requested_season=None):
		text = clean_text(name)
		patterns = (
			r'\bS(\d{1,2})[ ._-]*E(?:P)?(\d{1,3})\b',
			r'\bSaison\s*(\d{1,2})\s*(?:Episode|Ep|Épisode)\s*(\d{1,3})\b',
			r'\b(\d{1,2})x(\d{1,3})\b'
		)
		for pattern in patterns:
			m = re.search(pattern, text, re.I)
			if m:
				try: return int(m.group(1)), int(m.group(2))
				except: pass
		# Wawacity sometimes encodes only "Episode N" in fn; recover season from URL.
		ep = re.search(r'\b(?:Episode|Ep|Épisode)\s*(\d{1,3})\b', text, re.I)
		season = None
		m = re.search(r'saison(\d+)', str(page_path or ''), re.I)
		if m:
			try: season = int(m.group(1))
			except: season = None
		if season is None and requested_season not in ('', None):
			try: season = int(requested_season)
			except: season = None
		if ep and season is not None:
			try: return season, int(ep.group(1))
			except: pass
		return None, None

	def _supported_hoster(self, value):
		"""Return the canonical AllDebrid-supported Wawacity hoster or ''.

		Wawacity can list many mirrors for the same file. alkoFlix only keeps
		the four services explicitly supported in this source's AllDebrid flow.
		The comparison is deliberately tolerant of labels such as
		"1Fichier.com" or "Rapidgator.net".
		"""
		compact = re.sub(r'[^a-z0-9]+', '', normalize_text(value))
		compact = compact.replace('onefichier', '1fichier')
		for hoster in self.ALLDEBRID_HOSTERS:
			if hoster in compact:
				return hoster
		return ''

	def _rows(self, soup):
		rows = []
		try:
			rows.extend(soup.select('#DDLLinks tr.link-row'))
			rows.extend(soup.select('#streamLinks tr.link-row'))
		except:
			pass
		return rows

	def _extract_links_from_page(self, page_path, data):
		base = self.base_url()
		html = self._get(abs_url(page_path, base))
		if not html: return []
		soup = self._soup(html)
		if not soup: return []
		is_series = bool(data.get('tvshowtitle'))
		requested_season = int(data.get('season') or 0) if is_series else None
		requested_episode = int(data.get('episode') or 0) if is_series else None
		results = []

		for row in self._rows(soup):
			try:
				link_node = row.select_one('a.link[href*="dl-protect."], a[href*="dl-protect."]')
				if not link_node: continue
				url = abs_url(link_node.get('href') or '', base)
				if not url: continue
				filename = self._decode_filename(url)
				link_text = clean_text(link_node.get_text(' ', strip=True))
				if not filename:
					filename = link_text.split(':', 1)[-1].strip() if ':' in link_text else link_text
				if not filename: continue

				if is_series:
					season, episode = self._season_episode_from_name(filename, page_path, requested_season)
					if season is None or episode is None: continue
					if season != requested_season or episode != requested_episode: continue

				hoster = ''
				hoster_cell = row.select_one('td[width="120px"].text-center') or row.select_one('td[width="120px"]')
				if hoster_cell: hoster = clean_text(hoster_cell.get_text(' ', strip=True))
				# Ne jamais proposer les miroirs inutilisables avec AllDebrid.
				# En particulier DailyUploads et Uploady sont volontairement ignorés.
				canonical_hoster = self._supported_hoster(hoster)
				if not canonical_hoster: continue
				hoster = canonical_hoster
				size = ''
				size_cell = row.select_one('td[width="80px"].text-center') or row.select_one('td[width="80px"]')
				if size_cell: size = clean_text(size_cell.get_text(' ', strip=True))

				quality = normalize_quality(filename)
				language = language_code(filename)
				results.append({
					'link': url, 'hoster': hoster, 'quality': quality,
					'language': language, 'raw_language': filename,
					'size': size, 'display_name': filename
				})
			except:
				continue
		return results

	def search(self, data):
		content = self._search_content(data)
		if not content: return []
		results = []
		if data.get('tvshowtitle'):
			pages = self._series_pages(content.get('link'), data.get('season'))
		else:
			pages = self._quality_pages_movie(content.get('link'))
		for page in pages:
			results.extend(self._extract_links_from_page(page, data))

		# Protected URL is stable per file; deduplicate quality/season pages.
		seen, unique = set(), []
		for item in results:
			key = item.get('link') or ''
			if not key or key in seen: continue
			seen.add(key); unique.append(item)
		return unique
