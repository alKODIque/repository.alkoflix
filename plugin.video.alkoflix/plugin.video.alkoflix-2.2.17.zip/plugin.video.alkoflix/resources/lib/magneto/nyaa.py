# -*- coding: utf-8 -*-
# plugin.video.alkoflix
# resources/lib/magneto/nyaa.py

import re
import xml.etree.ElementTree as ET
from urllib.parse import quote, urlencode

from alko import client
from alko import log_utils
from alko import source_utils
from modules import anime_episode_map


class source:
	timeout = 10
	priority = 5
	pack_capable = False
	hasMovies = True
	hasEpisodes = True

	NYAA_NS = 'https://nyaa.si/xmlns/nyaa'
	MAX_RESULTS = 50
	MAX_QUERIES = 4

	def __init__(self):
		self.language = ['en', 'fr']
		# Recherche directe sur le RSS officiel de Nyaa.
		# Aucun intermédiaire TorrentsDB : le flux fournit déjà infoHash, taille et seeders.
		self.base_link = 'https://nyaa.si'
		self.category = '1_0'
		self.min_seeders = 0

	def _valid_text(self, value):
		try:
			value = str(value or '').strip()
			return '' if value.lower() in ('', 'none', 'null', 'false') else value
		except:
			return ''

	def _normalize_size(self, raw):
		try:
			if not raw: return ''
			match = re.search(r'([\d.]+)\s*(GiB|MiB|KiB|GB|MB|KB)', str(raw), re.I)
			if not match: return ''
			value, unit = match.group(1), match.group(2).upper().replace('IB', 'B')
			return '%s %s' % (value, unit)
		except:
			return ''

	def _rss_value(self, item, name):
		try:
			node = item.find('{%s}%s' % (self.NYAA_NS, name))
			return (node.text or '').strip() if node is not None else ''
		except:
			return ''

	def _rss_items(self, query):
		try:
			params = {'page': 'rss', 'q': query, 'c': self.category, 'f': '0'}
			url = '%s/?%s' % (self.base_link, urlencode(params))
			log_utils.log('NYAA RSS direct request -> q=%s' % query, caller='nyaa')
			result = client.request(url, timeout=self.timeout, headers={'Accept': 'application/rss+xml, application/xml, text/xml;q=0.9, */*;q=0.8'})
			if not result: return []
			root = ET.fromstring(result)
			items = root.findall('.//item')[:self.MAX_RESULTS]
			log_utils.log('NYAA RSS direct request OK -> q=%s | results=%s' % (query, len(items)), caller='nyaa')
			return items
		except:
			source_utils.scraper_error('NYAA')
			return []

	def _query_candidates(self, data, title, year, season=None, episode=None):
		queries = []
		def add(value):
			value = re.sub(r'\s+', ' ', str(value or '')).strip()
			if value and value.lower() not in [i.lower() for i in queries]: queries.append(value)

		if season is not None and episode is not None:
			canonical = 'S%02dE%02d' % (int(season), int(episode))
			add('%s %s' % (title, canonical))
			if data.get('anime_context'):
				# Les animés sont souvent numérotés autrement sur Nyaa : groupe TMDb alternatif
				# ou numéro absolu (ex. S02E01 publié comme épisode 13).
				mapping = data.get('anime_episode_map') or {}
				for cand in mapping.get('candidates') or []:
					try:
						s, e = int(cand.get('season') or 0), int(cand.get('episode') or 0)
						if s and e and (s != int(season) or e != int(episode)):
							add('%s S%02dE%02d' % (title, s, e))
					except:
						pass
				absolute = 0
				try: absolute = int(mapping.get('absolute_episode') or data.get('absolute_episode') or 0)
				except: absolute = 0
				if absolute: add('%s %02d' % (title, absolute))
			# Dernier filet : recherche par titre seul pour les noms de releases atypiques
			# et pour permettre aux packs de saison/série de remonter.
			add(title)
		else:
			add('%s %s' % (title, year))
			add(title)
		return queries[:self.MAX_QUERIES]

	def _raw_results(self, data, title, year, season=None, episode=None):
		results, seen = [], set()
		for query in self._query_candidates(data, title, year, season, episode):
			for item in self._rss_items(query):
				try:
					title_node = item.find('title')
					release_title = (title_node.text or '').strip() if title_node is not None else ''
					info_hash = self._rss_value(item, 'infoHash').lower()
					if not release_title or not re.fullmatch(r'[a-f0-9]{40}', info_hash or ''): continue
					if info_hash in seen: continue
					seen.add(info_hash)
					seeders = 0
					try: seeders = int(self._rss_value(item, 'seeders') or 0)
					except: seeders = 0
					results.append({
						'name': release_title, 'hash': info_hash, 'seeders': seeders,
						'size_text': self._normalize_size(self._rss_value(item, 'size'))
					})
				except:
					source_utils.scraper_error('NYAA')
		log_utils.log('NYAA RSS direct aggregate -> results=%s' % len(results), caller='nyaa')
		return results

	def _episode_hdlr_match(self, title, aliases, name, year, data, default_hdlr):
		try:
			hdlrs = anime_episode_map.hdlrs(data) if data.get('anime_context') else [default_hdlr]
			for hdlr in hdlrs or [default_hdlr]:
				if source_utils.check_title(title, aliases, name, hdlr, year): return hdlr
			if data.get('anime_context') and anime_episode_map.release_matches_episode(name, data.get('season'), data.get('episode'), data):
				# Normalement couvert par hdlrs(); ce fallback protège les formats "Episode 13"
				# ou groupes alternatifs que check_title ne découperait pas correctement.
				for hdlr in anime_episode_map.hdlrs(data):
					if re.search(re.escape(str(hdlr)), name, re.I): return hdlr
		except:
			pass
		return ''

	def _is_vostfr(self, text):
		try:
			return bool(re.search(r'(?<![a-z0-9])vo[ ._-]?stfr(?![a-z0-9])|(?<![a-z0-9])vostfr(?![a-z0-9])|(?<![a-z0-9])subfrench(?![a-z0-9])|(?<![a-z0-9])french[ ._-]?sub(?![a-z0-9])|(?<![a-z0-9])fr[ ._-]?sub(?![a-z0-9])', text, re.I))
		except:
			return False

	def _is_multi(self, text):
		try:
			return bool(re.search(r'(?<![a-z0-9])multi(?![a-z0-9])|(?<![a-z0-9])multi[ ._-]', text, re.I))
		except:
			return False

	def _is_explicit_fr_audio(self, text):
		try:
			# Même famille de tags FR que les autres sources, avec quelques variantes
			# typiques des releases anime.
			return bool(re.search(r'(?<![a-z0-9])(?:true[ ._-]?french|french|vf[ ._-]?fr|vf[ ._-]?fq|vf[ ._-]?i|vfi|vff|vfq|vf2|vof|vf|fr|fra|fre|frn)(?![a-z0-9])', text, re.I))
		except:
			return False

	def _is_english(self, text):
		try:
			return bool(re.search(r'(?<![a-z0-9])(?:english|eng|en|vosta|eng[ ._-]?sub|en[ ._-]?sub)(?![a-z0-9])', text, re.I))
		except:
			return False

	def _language_rank_from_text(self, text):
		try:
			# Pour Nyaa/anime, MULTI peut contenir une piste FR et doit rester avec
			# les résultats prioritaires. VOSTFR reste juste après.
			if self._is_explicit_fr_audio(text) or self._is_multi(text): return 0
			if self._is_vostfr(text): return 1
		except:
			pass
		return 2

	def _fr_rank(self, item):
		try:
			text = '%s %s %s' % (item.get('name', ''), item.get('name_info', ''), item.get('info', ''))
			return self._language_rank_from_text(text)
		except:
			return 3

	def _language_tags_from_text(self, text):
		tags = []
		try:
			# Tags FR repris dans l'esprit de source_utils.FRENCH_CHECK, mais avec
			# des regex à frontières propres pour éviter les faux positifs.
			checks = (
				('TRUEFRENCH', r'(?<![a-z0-9])true[ ._-]?french(?![a-z0-9])'),
				('VF-FR', r'(?<![a-z0-9])vf[ ._-]?fr(?![a-z0-9])'),
				('VF-FQ', r'(?<![a-z0-9])vf[ ._-]?fq(?![a-z0-9])'),
				('VFI', r'(?<![a-z0-9])vfi(?![a-z0-9])|(?<![a-z0-9])vf[ ._-]?i(?![a-z0-9])'),
				('VFF', r'(?<![a-z0-9])vff(?![a-z0-9])'),
				('VFQ', r'(?<![a-z0-9])vfq(?![a-z0-9])'),
				('VF2', r'(?<![a-z0-9])vf2(?![a-z0-9])'),
				('VOF', r'(?<![a-z0-9])vof(?![a-z0-9])'),
				('VF', r'(?<![a-z0-9])vf(?![a-z0-9])'),
				('FRENCH', r'(?<![a-z0-9])french(?![a-z0-9])'),
				('FR', r'(?<![a-z0-9])(?:fr|fra|fre|frn)(?![a-z0-9])'),
				('VOSTFR', r'(?<![a-z0-9])vo[ ._-]?stfr(?![a-z0-9])|(?<![a-z0-9])vostfr(?![a-z0-9])|(?<![a-z0-9])subfrench(?![a-z0-9])|(?<![a-z0-9])french[ ._-]?sub(?![a-z0-9])|(?<![a-z0-9])fr[ ._-]?sub(?![a-z0-9])'),
				('VOSTA', r'(?<![a-z0-9])vosta(?![a-z0-9])'),
				('ENG-SUB', r'(?<![a-z0-9])eng[ ._-]?sub(?:s|titles?)?(?![a-z0-9])|(?<![a-z0-9])en[ ._-]?sub(?:s|titles?)?(?![a-z0-9])'),
				('ENG', r'(?<![a-z0-9])(?:english|eng|en)(?![a-z0-9])')
			)
			for label, pattern in checks:
				if label in tags: continue
				if label == 'FR' and any(tag in tags for tag in ('TRUEFRENCH', 'VF-FR', 'VF-FQ', 'VFI', 'VFF', 'VFQ', 'VF2', 'VOF', 'VF', 'FRENCH', 'VOSTFR')): continue
				if label == 'ENG' and any(tag in tags for tag in ('ENG-SUB', 'VOSTA')): continue
				if re.search(pattern, text, re.I): tags.append(label)
			if self._is_multi(text) and 'MULTI' not in tags: tags.append('MULTI')
		except:
			pass
		return tags

	def _add_fr_info(self, info, name_info, stream_text):
		try:
			text = '%s %s' % (name_info, stream_text)
			existing = [str(i).upper() for i in info]
			for tag in reversed(self._language_tags_from_text(text)):
				if tag not in existing:
					info.insert(0, tag)
					existing.append(tag)
		except:
			pass
		return info

	def sources(self, data, hostDict):
		sources = []
		if not data: return sources
		sources_append = sources.append
		try:
			search_title = data['tvshowtitle'] if 'tvshowtitle' in data else data['title']
			search_title = str(search_title or '').replace('/', ' ').strip()
			title = search_title.replace('&', 'and').replace('Special Victims Unit', 'SVU')
			aliases = data.get('aliases', [])
			episode_title = data['title'] if 'tvshowtitle' in data else None
			total_seasons = data.get('total_seasons') if 'tvshowtitle' in data else None
			year = str(data.get('year') or '')
			imdb = self._valid_text(data.get('imdb'))
			if 'tvshowtitle' in data:
				season, episode = data['season'], data['episode']
				hdlr = 'S%02dE%02d' % (int(season), int(episode))
			else:
				season = episode = None
				hdlr = year
			if 'timeout' in data: self.timeout = max(10, int(data['timeout']))
			raw_results = self._raw_results(data, search_title, year, season, episode)
		except:
			source_utils.scraper_error('NYAA')
			return sources

		seen = set()
		for raw in raw_results:
			try:
				release_title = raw.get('name') or ''
				display_title = source_utils.clean_display_name(release_title)
				name = source_utils.clean_name(release_title)
				info_hash = raw.get('hash')
				if not name or not info_hash or info_hash in seen: continue

				package, episode_start, episode_end, last_season = None, 0, 0, None
				matched_hdlr = hdlr
				match_variant = None
				if 'tvshowtitle' in data:
					matched_hdlr = self._episode_hdlr_match(title, aliases, name, year, data, hdlr)
					if matched_hdlr:
						if data.get('anime_context'):
							match_variant = anime_episode_map.candidate_for_release(name, data) or None
					else:
						if total_seasons is not None:
							valid, last_season = source_utils.filter_show_pack(title, aliases, imdb, year, season, name, total_seasons)
							if valid: package = 'show'
						if not package:
							variants = anime_episode_map.season_data_variants(data) if data.get('anime_context') else [data]
							for variant in variants:
								valid, episode_start, episode_end = source_utils.filter_season_pack(title, aliases, year, variant.get('season') or season, name)
								if valid:
									package = 'season'
									match_variant = variant
									break
						if not package: continue
				else:
					if not source_utils.check_title(title, aliases, name, hdlr, year): continue

				seen.add(info_hash)
				seeders = int(raw.get('seeders', 0) or 0)
				if self.min_seeders > seeders: continue
				final_url = 'magnet:?xt=urn:btih:%s&dn=%s' % (info_hash, quote(name))
				name_info = source_utils.info_from_name(name, title, year, matched_hdlr or hdlr, episode_title, season=str(season or ''), pack=package)
				language_text = '%s %s' % (name_info, release_title)
				language = 'fr' if self._language_rank_from_text(language_text) in (0, 1) else 'en'
				quality, info = source_utils.get_release_quality(name_info, final_url)
				info = self._add_fr_info(info, name_info, release_title)
				dsize = 0
				try:
					size_text = raw.get('size_text') or ''
					if size_text:
						dsize, isize = source_utils._size(size_text)
						if isize: info.insert(0, isize)
				except:
					dsize = 0
				info = ' | '.join(info)

				item = {
					'provider': 'nyaa', 'provider_name': 'Nyaa', 'source': 'torrent',
					'seeders': seeders, 'hash': info_hash, 'name': name, 'display_title': display_title, 'name_info': name_info,
					'quality': quality, 'language': language, 'url': final_url, 'info': info,
					'direct': False, 'debridonly': True, 'size': dsize, 'true_size': bool(dsize), 'bypass_filter': True
				}
				if package: item.update({'package': package, 'true_size': True})
				if package == 'show': item.update({'last_season': last_season})
				if package == 'season' and episode_start: item.update({'episode_start': episode_start, 'episode_end': episode_end})
				if match_variant:
					try:
						item['anime_match_season'] = int(match_variant.get('season') or season or 0)
						item['anime_match_episode'] = int(match_variant.get('episode') or episode or 0)
					except:
						pass
				sources_append(item)
			except:
				source_utils.scraper_error('NYAA')
		try:
			sources.sort(key=lambda i: (self._fr_rank(i), -int(i.get('seeders', 0) or 0), -float(i.get('size', 0) or 0)))
		except:
			pass
		return sources
