import sys
import re
import unicodedata
from queue import SimpleQueue, Empty
from threading import Thread
from indexers import mdblist_api
from menus.movies import Movies
from menus.tvshows import TVShows
from modules import kodi_utils
from menus import list_search_history
from modules.utils import paginate_list, paginate_directory_items, next_page_params, TaskPool, get_max_threads
from modules.list_sorting import apply_context_list_sort
from modules.settings import paginate, page_limit, nav_jump_use_alphabet
# logger = kodi_utils.logger

KODI_VERSION, ls = kodi_utils.get_kodi_version(), kodi_utils.local_string
build_url, make_listitem = kodi_utils.build_url, kodi_utils.make_listitem
fanart = ''
default_icon = kodi_utils.media_path('mdblist.png')
item_jump = kodi_utils.media_path('item_jump.png')
copy2str = ls(33147)


def _normalize_mdbl_label(value):
	try:
		text = str(value or '').strip().lower()
		text = unicodedata.normalize('NFKD', text)
		text = ''.join(ch for ch in text if not unicodedata.combining(ch))
		return re.sub(r'[^a-z0-9]+', '', text)
	except Exception:
		return str(value or '').strip().lower()


def _mdbl_menu_icon(name, fallback='mdblist.png'):
	key = _normalize_mdbl_label(name)
	if 'justwatch' in key:
		return 'justwatch.png'
	if 'moviemeter' in key:
		return 'chart-simple.png'
	if ('plusregarde' in key or 'mostwatched' in key or 'mostviewed' in key):
		if 'semaine' in key or 'week' in key:
			return 'eye2.png'
		if 'annee' in key or 'year' in key:
			return 'calendar2.png'
	if ('pluspopulaire' in key or 'mostpopular' in key or 'popular' in key) and 'listespopulaires' not in key:
		return 'thumbs-up.png'
	if 'tendance' in key or 'trending' in key:
		return 'rocket.png'
	return fallback
likelist_str, unlikelist_str = ls(32776), ls(32783)

# Export vers TMDb seulement si le compte TMDb est autorisé dans alkoFlix.
def tmdb_export_available():
	return kodi_utils.get_setting('tmdb.account_id') not in ('', None)
nextpage_str, jump2_str, mdblist_str = ls(32799), ls(32964), 'MDBList'
def _list_favourite_context(url_params, name):
	fav_params = dict(url_params or {})
	fav_params['target_mode'] = fav_params.get('mode')
	fav_params.update({'mode': 'favourites_choice', 'media_type': 'list', 'fav_type': 'list', 'list_service': 'mdblist', 'title': name, 'name': name})
	return ('Favoris (alkoFlix)', 'RunPlugin(%s)' % build_url(fav_params))

def _catalogue_filter_mdbl_items(results, media_filter):
	try:
		from magneto.alkopaste import alkopaste_catalogue_all_id_set
		movie_ids = alkopaste_catalogue_all_id_set('film') if media_filter in ('', None, 'movie') else set()
		tv_ids = alkopaste_catalogue_all_id_set('serie') if media_filter in ('', None, 'tvshow') else set()
		filtered = []
		for item in results or []:
			mtype = item.get('mediatype')
			tmdb_id = str(item.get('id') or '').strip()
			if mtype == 'movie' and tmdb_id in movie_ids:
				filtered.append(item)
			elif mtype == 'show' and tmdb_id in tv_ids:
				filtered.append(item)
		return filtered
	except Exception as e:
		kodi_utils.logger('mdblist catalogue-only list filter skipped', str(e))
		return results or []


def _mdbl_list_plot(item, fallback=''):
	description = str((item or {}).get('description') or '').strip()
	return description or fallback


def _catalogue_list_visible(item, media_filter, catalogue_only):
	"""Masque les listes MDBList vides pour la branche Films/Séries demandée.

	Le type est contrôlé dans les deux catalogues. En mode alkoPaste, les items
	doivent en plus exister dans la base alkoPaste.
	"""
	if media_filter not in ('movie', 'tvshow'):
		return True
	item = item or {}
	key = 'movies' if media_filter == 'movie' else 'shows'
	count = item.get(key)
	if count is not None:
		try:
			if int(count) <= 0:
				return False
		except: pass
	mediatype = str(item.get('mediatype') or '').lower()
	expected_type = 'movie' if media_filter == 'movie' else 'show'
	if mediatype in ('movie', 'show') and mediatype != expected_type:
		return False
	# Si MDBList fournit déjà un compteur ventilé et qu'on est dans le Catalogue
	# TMDb, aucune requête supplémentaire n'est nécessaire.
	if not catalogue_only and count is not None:
		try:
			return int(count) > 0
		except: pass
	try:
		list_id = item.get('id')
		if not list_id:
			return True
		list_type = 'external' if 'source' in item else 'user_lists'
		results = mdblist_api.mdbl_list_items(list_id, list_type)
		if results is None:
			return True
		results = [i for i in results if i.get('mediatype') == expected_type]
		if not results:
			return False
		if not catalogue_only:
			return True
		return bool(_catalogue_filter_mdbl_items(results, media_filter))
	except Exception as e:
		kodi_utils.logger('mdblist list visibility skipped', str(e))
		return True


def search_mdbl_lists(params):
	def _process():
		for item in lists:
			try:
				cm = []
				cm_append = cm.append
				media_filter = params.get('media_filter')
				if not _catalogue_list_visible(item, media_filter, params.get('catalogue_only')): continue
				name, user, slug, list_id = item['name'], item['user_name'], item['slug'], item['id']
				likes, item_count = item['likes'] or 0, item.get('items', '?')
				display = '%s (x%s) - %s' % (name, str(item_count), user)
				plot = _mdbl_list_plot(item, 'Likes: %s' % likes)
				url_params = {'mode': 'build_mdb_list', 'user': user, 'slug': slug, 'list_id': list_id, 'name': name}
				if media_filter: url_params['media_filter'] = media_filter
				if params.get('catalogue_only'): url_params['catalogue_only'] = params.get('catalogue_only')
				url = build_url(url_params)
				cm[:0] = kodi_utils.menu_editor_context(url_params, name, default_icon) + kodi_utils.list_sort_context(url_params, name, default_icon)
				cm_append(_list_favourite_context(url_params, name))
				cm_append((likelist_str, 'RunPlugin(%s)' % build_url({'mode': 'mdblist.mdbl_like_a_list', 'list_id': list_id})))
				cm_append((unlikelist_str, 'RunPlugin(%s)' % build_url({'mode': 'mdblist.mdbl_unlike_a_list', 'list_id': list_id})))
				tmdb_export_available() and cm_append((copy2str, 'RunPlugin(%s)' % build_url({'mode': 'tmdb_manager_choice', 'mdbl_list_id': list_id, 'mdbl_list_name': name, 'user': user, 'list_slug': slug})))
				listitem = make_listitem()
				listitem.setLabel(display)
				menu_icon = kodi_utils.media_path(_mdbl_menu_icon(name))
				listitem.setArt({'icon': menu_icon, 'poster': menu_icon, 'thumb': menu_icon, 'fanart': fanart, 'banner': menu_icon})
				listitem.setInfo('video', {'plot': plot}) if KODI_VERSION < 20 else listitem.getVideoInfoTag().setPlot(plot)
				listitem.addContextMenuItems(cm)
				yield (url, listitem, True)
			except: pass
	page = params.get('new_page', '1')
	search_title = params.get('search_title')
	if not search_title:
		if params.get('new_search') == 'true':
			return list_search_history.prompt_and_update(params, 'build_mdb_list.search_mdbl_lists', 'mdblist_list_queries')
		return list_search_history.show_history(params, 'build_mdb_list.search_mdbl_lists', 'mdblist_list_queries', params.get('name') or 'Recherche de listes', default_icon)
	search_title = str(search_title).strip()
	if str(page) in ('', '1'):
		list_search_history.add_to_history(search_title, 'mdblist_list_queries')
	if search_title: lists, pages = mdblist_api.mdbl_searchlists(search_title), '1'
	else: lists, pages = [], page
	if not lists: lists = []
	__handle__ = int(sys.argv[1])
	items, local_total_pages, current_page = paginate_directory_items(list(_process()), params)
	kodi_utils.add_items(__handle__, items)
	if local_total_pages > current_page:
		kodi_utils.add_dir(__handle__, next_page_params(params, current_page), nextpage_str, special_sort='bottom')
	elif int(pages) > int(page):
		url = {'mode': 'build_mdb_list.search_mdbl_lists', 'search_title': search_title, 'new_page': int(page) + 1}
		if params.get('media_filter'): url['media_filter'] = params.get('media_filter')
		if params.get('catalogue_only'): url['catalogue_only'] = params.get('catalogue_only')
		kodi_utils.add_dir(__handle__, url, nextpage_str, special_sort='bottom')
	kodi_utils.set_category(__handle__, search_title)
	kodi_utils.set_content(__handle__, 'files')
	kodi_utils.end_directory(__handle__)
	kodi_utils.set_view_mode('view.main')

def get_mdbl_lists(params):
	def _process():
		for item in lists:
			try:
				cm = []
				cm_append = cm.append
				list_type = 'external' if 'source' in item else 'user_lists'
				media_filter = params.get('media_filter')
				if not _catalogue_list_visible(item, media_filter, params.get('catalogue_only')): continue
				name, user, list_id = item['name'], item['user_name'], item['id']
				slug, likes, item_count = item.get('slug', ''), item.get('likes', 0), item.get('items', '?')
				display = '%s (x%s)' % (name, item_count) if item_count else name
				plot = _mdbl_list_plot(item, 'Likes: %s' % likes if likes else '')
				url_params = {'mode': 'build_mdb_list', 'user': user, 'slug': slug, 'list_id': list_id, 'list_type': list_type, 'name': name}
				if media_filter: url_params['media_filter'] = media_filter
				if params.get('catalogue_only'): url_params['catalogue_only'] = params.get('catalogue_only')
				url = build_url(url_params)
				cm[:0] = kodi_utils.menu_editor_context(url_params, name, default_icon) + kodi_utils.list_sort_context(url_params, name, default_icon)
				cm_append(_list_favourite_context(url_params, name))
				if requested_type == 'liked_lists':
					cm_append((unlikelist_str, 'RunPlugin(%s)' % build_url({'mode': 'mdblist.mdbl_unlike_a_list', 'list_id': list_id})))
				tmdb_export_available() and cm_append((copy2str, 'RunPlugin(%s)' % build_url({'mode': 'tmdb_manager_choice', 'mdbl_list_id': list_id, 'mdbl_list_name': name, 'user': user, 'list_slug': slug})))
				listitem = make_listitem()
				listitem.setLabel(display)
				menu_icon = kodi_utils.media_path(_mdbl_menu_icon(name))
				listitem.setArt({'icon': menu_icon, 'poster': menu_icon, 'thumb': menu_icon, 'fanart': fanart, 'banner': menu_icon})
				listitem.setInfo('video', {'plot': plot}) if KODI_VERSION < 20 else listitem.getVideoInfoTag().setPlot(plot)
				listitem.addContextMenuItems(cm, replaceItems=False)
				yield (url, listitem, True)
			except: pass
	requested_type = params.get('list_type')
	if requested_type == 'liked_lists':
		lists = mdblist_api.mdbl_likedlists() or []
	else:
		# Conserver le comportement historique de « Mes listes » : listes
		# personnelles + listes externes enregistrées par l'utilisateur.
		lists = []
		lists += mdblist_api.mdbl_userlists() or []
		lists += mdblist_api.mdbl_externallists() or []
	__handle__ = int(sys.argv[1])
	# Le filtrage Films/Séries (et alkoPaste si demandé) est terminé avant de
	# paginer : chaque page respecte donc la limite choisie par l'utilisateur.
	items, total_pages, current_page = paginate_directory_items(list(_process()), params)
	kodi_utils.add_items(__handle__, items)
	if total_pages > current_page:
		kodi_utils.add_dir(__handle__, next_page_params(params, current_page), nextpage_str, special_sort='bottom')
	kodi_utils.set_category(__handle__, params.get('name'))
	kodi_utils.set_sort_method(__handle__, 'label')
	kodi_utils.set_content(__handle__, 'files')
	kodi_utils.end_directory(__handle__)
	kodi_utils.set_view_mode('view.main')

def get_mdbl_toplists(params):
	def _process():
		for item in lists:
			try:
				cm = []
				cm_append = cm.append
				media_filter = params.get('media_filter')
				if not _catalogue_list_visible(item, media_filter, params.get('catalogue_only')): continue
				name, user, slug, list_id = item['name'], item['user_name'], item['slug'], item['id']
				likes, item_count = item['likes'], item.get('items', '?')
				display = '%s (x%s) - %s' % (name, item_count, user)
				plot = _mdbl_list_plot(item, 'Likes: %s' % likes)
				url_params = {'mode': 'build_mdb_list', 'user': user, 'slug': slug, 'list_id': list_id, 'name': name}
				if media_filter: url_params['media_filter'] = media_filter
				if params.get('catalogue_only'): url_params['catalogue_only'] = params.get('catalogue_only')
				url = build_url(url_params)
				cm[:0] = kodi_utils.menu_editor_context(url_params, name, default_icon) + kodi_utils.list_sort_context(url_params, name, default_icon)
				cm_append(_list_favourite_context(url_params, name))
				cm_append((likelist_str, 'RunPlugin(%s)' % build_url({'mode': 'mdblist.mdbl_like_a_list', 'list_id': list_id})))
				cm_append((unlikelist_str, 'RunPlugin(%s)' % build_url({'mode': 'mdblist.mdbl_unlike_a_list', 'list_id': list_id})))
				tmdb_export_available() and cm_append((copy2str, 'RunPlugin(%s)' % build_url({'mode': 'tmdb_manager_choice', 'mdbl_list_id': list_id, 'mdbl_list_name': name, 'user': user, 'list_slug': slug})))
				listitem = make_listitem()
				listitem.setLabel(display)
				menu_icon = kodi_utils.media_path(_mdbl_menu_icon(name))
				listitem.setArt({'icon': menu_icon, 'poster': menu_icon, 'thumb': menu_icon, 'fanart': fanart, 'banner': menu_icon})
				listitem.setInfo('video', {'plot': plot}) if KODI_VERSION < 20 else listitem.getVideoInfoTag().setPlot(plot)
				listitem.addContextMenuItems(cm)
				yield (url, listitem, True)
			except: pass
	lists = mdblist_api.mdbl_toplists()
	__handle__ = int(sys.argv[1])
	# Même séquence pour les listes populaires : filtre d'abord, pagination ensuite.
	items, total_pages, current_page = paginate_directory_items(list(_process()), params)
	kodi_utils.add_items(__handle__, items)
	if total_pages > current_page:
		kodi_utils.add_dir(__handle__, next_page_params(params, current_page), nextpage_str, special_sort='bottom')
	kodi_utils.set_category(__handle__, params.get('name'))
	kodi_utils.set_content(__handle__, 'files')
	kodi_utils.end_directory(__handle__)
	kodi_utils.set_view_mode('view.main')

def build_mdb_list(params):
	def _thread_target(q):
		while True:
			try: target, *args = q.get_nowait()
			except Empty: break
			except Exception: continue
			else: target(*args)
	__handle__, _queue, is_widget = int(sys.argv[1]), SimpleQueue(), kodi_utils.external_browse()
	max_threads = get_max_threads()
	use_alphabet = nav_jump_use_alphabet() > 0
	user, slug, name = params.get('user'), params.get('slug'), params.get('name')
	list_type, list_id = params.get('list_type'), params.get('list_id')
	letter, page = params.get('new_letter', 'None'), int(params.get('new_page', '1'))
	results = mdblist_api.mdbl_list_items(list_id, list_type) or []
	media_filter = params.get('media_filter')
	if media_filter == 'movie': results = [i for i in results if i.get('mediatype') == 'movie']
	elif media_filter == 'tvshow': results = [i for i in results if i.get('mediatype') == 'show']
	if params.get('catalogue_only'):
		results = _catalogue_filter_mdbl_items(results, media_filter)
	results = apply_context_list_sort(results, 'mdblist', params)
	if paginate() and results: process_list, total_pages = paginate_list(results, page, letter, page_limit())
	else: process_list, total_pages = results, 1
	# Une liste personnelle doit respecter ses items, sans recoupe animation/dossier.
	exclude_animation = 'false'
	base_builder_params = {'id_type': 'trakt_dict', 'exclude_animation': exclude_animation}
	if params.get('catalogue_only'): base_builder_params['catalogue_only'] = params.get('catalogue_only')
	movies, tvshows = Movies(dict(base_builder_params)), TVShows(dict(base_builder_params))
	for idx, tag in enumerate(process_list, 1):
		mtype = tag['mediatype']
		if   mtype == 'movie':
			_queue.put((movies.build_movie_content, idx, {'imdb': tag['imdb_id'], 'tmdb': tag['id']}))
		elif mtype == 'show':
			_queue.put((tvshows.build_tvshow_content, idx, {'imdb': tag['imdb_id'], 'tmdb': tag['id']}))
	max_threads = min(_queue.qsize(), max_threads)
	threads = (Thread(target=_thread_target, args=(_queue,)) for i in range(max_threads))
	threads = list(TaskPool.process(threads))
	[i.join() for i in threads]
	items = movies.items + tvshows.items
	items.sort(key=lambda k: int(k[1].getProperty('alkoflix_sort_order')))
	if media_filter == 'movie':
		content = 'movies'
	elif media_filter == 'tvshow':
		content = 'tvshows'
	else:
		content, total = max(
			('movies', movies), ('tvshows', tvshows), key=lambda k: len(k[1].items)
		)
	if total_pages > 2 and not is_widget and use_alphabet:
		url = {'mode': 'build_navigate_to_page', 'current_page': page, 'total_pages': total_pages,
				'user': user, 'slug': slug, 'name': name, 'list_id': list_id, 'list_type': list_type,
				'transfer_mode': 'build_mdb_list', 'media_type': 'Media', 'media_filter': media_filter}
		if params.get('list_sort'): url['list_sort'] = params.get('list_sort')
		if params.get('list_random_seed'): url['list_random_seed'] = params.get('list_random_seed')
		if params.get('regional_filter'): url['regional_filter'] = params.get('regional_filter')
		if params.get('catalogue_only'): url['catalogue_only'] = params.get('catalogue_only')
		kodi_utils.add_dir(__handle__, url, jump2_str, iconImage=item_jump, isFolder=False)
	kodi_utils.add_items(__handle__, items)
	if total_pages > page:
		url = {'mode': 'build_mdb_list', 'new_page': page + 1, 'new_letter': letter,
				'user': user, 'slug': slug, 'name': name, 'list_id': list_id, 'list_type': list_type}
		if media_filter: url['media_filter'] = media_filter
		if params.get('list_sort'): url['list_sort'] = params.get('list_sort')
		if params.get('list_random_seed'): url['list_random_seed'] = params.get('list_random_seed')
		if params.get('regional_filter'): url['regional_filter'] = params.get('regional_filter')
		if params.get('catalogue_only'): url['catalogue_only'] = params.get('catalogue_only')
		kodi_utils.add_dir(__handle__, url, nextpage_str, special_sort='bottom')
	kodi_utils.set_category(__handle__, name)
	kodi_utils.set_content(__handle__, content)
	kodi_utils.end_directory(__handle__, False if is_widget else None)
	kodi_utils.set_view_mode('view.%s' % content, content)

def mdbl_account_info():
	try:
		kodi_utils.show_busy_dialog()
		account_info = mdblist_api.call_mdblist('user')
		api_requests = account_info['api_requests']
		remaining = api_requests - account_info['api_requests_count']
		body = []
		append = body.append
		append('Username: %s' % account_info['username'])
		append('Supporter: %s' % account_info['is_supporter'])
		append('API Request Limit: %s' % api_requests)
		append('API Request Remaining: %s' % remaining)
		kodi_utils.hide_busy_dialog()
		return kodi_utils.show_text(mdblist_str.upper(), '\n\n'.join(body), font_size='large')
	except: kodi_utils.hide_busy_dialog()

