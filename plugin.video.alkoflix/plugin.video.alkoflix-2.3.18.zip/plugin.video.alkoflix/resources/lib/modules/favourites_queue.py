# -*- coding: utf-8 -*-
"""File persistante des favoris externes (A04).

SQLite arbitre les interpreteurs Kodi independants. Aucun verrou ni transaction ne
reste ouvert pendant un appel reseau. On confirme uniquement l'identifiant de la
tache reservee : un ajout effectue entre-temps ne peut pas etre ecrase.
"""

import json
from contextlib import closing
import os
import sqlite3
import time
import uuid


class FavouritesQueue:
	LEASE_SECONDS = 900  # Recuperation apres fermeture brutale.
	RETRY_MAX_SECONDS = 300

	@classmethod
	def _retry_delay(cls, attempts):
		# 10, 20, 40, 80, 160, 300 s; calcul sans debordement pour vieilles files.
		return min(cls.RETRY_MAX_SECONDS, 10 * (2 ** min(max(0, int(attempts) - 1), 5))) if attempts else 0

	def __init__(self, database_path, legacy_file=None, read_legacy=None, legacy_exists=None):
		self.database_path = database_path
		self.legacy_file = legacy_file
		self.read_legacy = read_legacy
		self.legacy_exists = legacy_exists

	def _connect(self):
		parent = os.path.dirname(self.database_path)
		if parent and not os.path.isdir(parent): os.makedirs(parent, exist_ok=True)
		connection = sqlite3.connect(self.database_path, timeout=10, isolation_level=None)
		try:
			# DELETE/FULL convient aux donnees durables sur profil local. Ne pas activer WAL
			# tant que sauvegardes / restauration ne sont pas coordonnees (A13).
			connection.execute('PRAGMA journal_mode=DELETE')
			connection.execute('PRAGMA synchronous=FULL')
			connection.execute('PRAGMA busy_timeout=10000')
			connection.execute('''CREATE TABLE IF NOT EXISTS jobs (
				id INTEGER PRIMARY KEY AUTOINCREMENT,
				item_key TEXT NOT NULL,
				kind TEXT NOT NULL,
				payload TEXT NOT NULL,
				status TEXT NOT NULL DEFAULT 'pending',
				attempts INTEGER NOT NULL DEFAULT 0,
				locked_until INTEGER NOT NULL DEFAULT 0,
				lock_token TEXT,
				last_attempt_at INTEGER NOT NULL DEFAULT 0
			)''')
			connection.execute('CREATE INDEX IF NOT EXISTS jobs_state_idx ON jobs (status, id)')
			connection.execute('CREATE TABLE IF NOT EXISTS queue_meta (key TEXT PRIMARY KEY, value TEXT NOT NULL)')
			self._import_legacy(connection)
			return connection
		except Exception:
			connection.close()
			raise

	def _import_legacy(self, connection):
		if not self.legacy_file or self.read_legacy is None: return
		connection.execute('BEGIN IMMEDIATE')
		try:
			if not connection.execute("SELECT 1 FROM queue_meta WHERE key='legacy_imported'").fetchone():
				items = self.read_legacy() if self.legacy_exists(self.legacy_file) else []
				if not isinstance(items, list): raise ValueError('Legacy favourites queue is not a list')
				for item in items:
					if not isinstance(item, dict): raise ValueError('Invalid legacy queue item')
					self._insert(connection, item, self._key(item))
				connection.execute("INSERT INTO queue_meta(key,value) VALUES ('legacy_imported','1')")
			connection.execute('COMMIT')
		except Exception:
			connection.execute('ROLLBACK')
			raise

	@staticmethod
	def _key(item):
		if item.get('kind') == 'bulk_clear':
			return 'bulk|%s|%s' % (item.get('provider', ''), item.get('queued_at', ''))
		return '|'.join(str(item.get(k) or '') for k in (
			'provider', 'media_type', 'tmdb_id', 'imdb_id', 'tvdb_id', 'season', 'episode'))

	@staticmethod
	def _insert(connection, item, item_key):
		connection.execute('''INSERT INTO jobs(item_key,kind,payload,attempts)
			VALUES (?,?,?,?)''', (item_key, item.get('kind') or 'item',
			json.dumps(item, ensure_ascii=False, separators=(',', ':')),
			max(0, int(item.get('attempts') or 0))))

	def enqueue(self, items):
		if not items: return False
		with closing(self._connect()) as connection:
			connection.execute('BEGIN IMMEDIATE')
			try:
				for item in items:
					key = self._key(item)
					if item.get('kind') == 'item':
						# Une intention deja en cours d'envoi doit finir; seule la
						# derniere intention encore EN ATTENTE peut etre remplacee.
						connection.execute("DELETE FROM jobs WHERE status='pending' AND kind='item' AND item_key=?", (key,))
					self._insert(connection, item, key)
				connection.execute('COMMIT')
				return True
			except Exception:
				connection.execute('ROLLBACK')
				raise

	def _recover_expired(self, connection, now):
		connection.execute("UPDATE jobs SET status='pending', lock_token=NULL, locked_until=0 WHERE status='running' AND locked_until<=?", (now,))

	def claim(self, skip_ids=()):
		with closing(self._connect()) as connection:
			connection.execute('BEGIN IMMEDIATE')
			try:
				now = int(time.time())
				self._recover_expired(connection, now)
				# Un seul envoi a la fois, meme avec plusieurs interpreteurs Kodi.
				# Preservons l'ordre ajout/retrait et bulk_clear par fournisseur.
				if connection.execute("SELECT 1 FROM jobs WHERE status='running' LIMIT 1").fetchone():
					connection.execute('COMMIT')
					return None
				q = "SELECT id, payload, attempts, last_attempt_at FROM jobs WHERE status='pending'"
				args = []
				if skip_ids:
					q += ' AND id NOT IN (%s)' % ','.join('?' for _ in skip_ids)
					args.extend(skip_ids)
				q += ' ORDER BY id'
				# FIFO par fournisseur. Un Trakt limite ne doit pas bloquer TMDb.
				blocked_providers = set()
				row = None
				for candidate in connection.execute(q, args):
					item = json.loads(candidate[1])
					provider = str(item.get('provider') or '')
					if provider in blocked_providers: continue
					if candidate[2] and now < int(candidate[3] or 0) + self._retry_delay(candidate[2]):
						blocked_providers.add(provider)
						continue
					row = candidate
					break
				if row is None:
					connection.execute('COMMIT')
					return None
				token = uuid.uuid4().hex
				connection.execute("UPDATE jobs SET status='running', locked_until=?, lock_token=? WHERE id=?", (now + self.LEASE_SECONDS, token, row[0]))
				connection.execute('COMMIT')
				return row[0], token, json.loads(row[1])
			except Exception:
				connection.execute('ROLLBACK')
				raise

	def finish(self, task_id, token, succeeded):
		with closing(self._connect()) as connection:
			connection.execute('BEGIN IMMEDIATE')
			try:
				if succeeded:
					cursor = connection.execute("DELETE FROM jobs WHERE id=? AND status='running' AND lock_token=?", (task_id, token))
				else:
					# Une panne reseau ne doit pas effacer silencieusement une intention.
					# A09 affinera la politique de reprise et les diagnostics.
					cursor = connection.execute("""UPDATE jobs SET status='pending', attempts=attempts+1,
						last_attempt_at=?, locked_until=0, lock_token=NULL
						WHERE id=? AND status='running' AND lock_token=?""", (int(time.time()), task_id, token))
				connection.execute('COMMIT')
				return cursor.rowcount == 1
			except Exception:
				connection.execute('ROLLBACK')
				raise

	def count(self):
		with closing(self._connect()) as connection:
			return connection.execute('SELECT COUNT(*) FROM jobs').fetchone()[0]

	def next_retry_seconds(self):
		"""Retourne le delai restant du premier job, 0 si disponible."""
		with closing(self._connect()) as connection:
			now = int(time.time())
			running = connection.execute("SELECT locked_until FROM jobs WHERE status='running' LIMIT 1").fetchone()
			if running: return max(1, int(running[0] or 0) - now)
			blocked_providers = set()
			delays = []
			for payload, attempts, last_attempt_at in connection.execute(
				"SELECT payload, attempts, last_attempt_at FROM jobs WHERE status='pending' ORDER BY id"):
				provider = str(json.loads(payload).get('provider') or '')
				if provider in blocked_providers: continue
				delay = max(0, int(last_attempt_at or 0) + self._retry_delay(attempts) - now) if attempts else 0
				if not delay: return 0
				blocked_providers.add(provider)
				delays.append(delay)
			return min(delays) if delays else 0

	def snapshot(self):
		with closing(self._connect()) as connection:
			return [json.loads(row[0]) for row in connection.execute('SELECT payload FROM jobs ORDER BY id')]
