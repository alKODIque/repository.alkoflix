# -*- coding: utf-8 -*-
# plugin.video.alkoflix
# resources/lib/modules/thumbnails.py

import sqlite3 as database
import json
from pathlib import Path
from datetime import datetime, timedelta
import xbmc, xbmcaddon, xbmcgui, xbmcvfs
from modules import kodi_utils


def ls(string):
	try: return xbmcaddon.Addon().getLocalizedString(int(string))
	except: return str(string)


def logger(heading, function):
	try:
		if xbmcaddon.Addon().getSetting('debug.enabled') != 'true': return
		xbmc.log('>> %s <<: %s' % (heading, function), xbmc.LOGDEBUG)
	except: pass


def notification(line1, time=3000, sound=False):
	addon_info = xbmcaddon.Addon().getAddonInfo
	xbmcgui.Dialog().notification(addon_info('name'), line1, addon_info('icon'), time, sound)


def _delete_path(path):
	files_deleted, dirs_deleted = 0, 0
	try:
		if not path.exists(): return files_deleted, dirs_deleted
		if path.is_dir():
			for child in path.iterdir():
				child_files, child_dirs = _delete_path(child)
				files_deleted += child_files
				dirs_deleted += child_dirs
			try:
				path.rmdir()
				dirs_deleted += 1
			except Exception as e:
				logger('clear kodi thumbnails rmdir skipped', '%s | %s' % (path, e))
		else:
			try:
				path.unlink(missing_ok=True)
				files_deleted += 1
			except Exception as e:
				logger('clear kodi thumbnails file skipped', '%s | %s' % (path, e))
	except Exception as e:
		logger('clear kodi thumbnails path skipped', '%s | %s' % (path, e))
	return files_deleted, dirs_deleted


def _delete_folder_contents(folder):
	files_deleted, dirs_deleted = 0, 0
	try:
		if not folder.exists(): return files_deleted, dirs_deleted
		for child in folder.iterdir():
			child_files, child_dirs = _delete_path(child)
			files_deleted += child_files
			dirs_deleted += child_dirs
	except Exception as e:
		logger('clear kodi thumbnails folder skipped', '%s | %s' % (folder, e))
	return files_deleted, dirs_deleted


# A15 : la base TexturesXX appartient a Kodi. Ne jamais changer ses PRAGMA,
# ne jamais supprimer son journal WAL/SHM ni la base alors que Kodi tourne.
# Pour une suppression selective, utiliser exclusivement Textures.RemoveTexture.


def _textures_database_candidates():
	# Utilise la base de textures de la version Kodi réellement exécutée.
	# On conserve les deux chemins historiques car, selon la plateforme,
	# special://database et special://profile/Database peuvent être des alias.
	try:
		resolved = kodi_utils.get_texture_database_path()
		db_name = str(resolved).replace('\\', '/').rsplit('/', 1)[-1]
	except:
		db_name = 'Textures14.db' if _kodi_major_version() >= 22 else 'Textures13.db'
	candidates, seen = [], set()
	for special_path in ('special://database', 'special://profile/Database'):
		try:
			path = Path(xbmcvfs.translatePath(special_path), db_name)
			key = str(path).lower()
			if key not in seen:
				seen.add(key)
				candidates.append(path)
		except Exception as e:
			logger('clear kodi thumbnails db candidate skipped', '%s | %s' % (special_path, e))
	return candidates


def _kodi_major_version():
	try: return int(str(xbmc.getInfoLabel('System.BuildVersion'))[:2])
	except: return 21


def _textures_database_label(dbfiles=None):
	try:
		if dbfiles:
			for dbfile in dbfiles:
				if dbfile: return Path(dbfile).name
		return str(kodi_utils.get_texture_database_path()).replace('\\', '/').rsplit('/', 1)[-1]
	except:
		return 'Textures14.db' if _kodi_major_version() >= 22 else 'Textures13.db'


# Idem pour special://temp : Kodi peut encore utiliser les fichiers presents.
def clear_kodi_temp_cache():
    logger('clear kodi temp', 'blocked unsafe live purge')
    xbmcgui.Dialog().ok('alkoFlix',
        'Pour nettoyer le dossier temporaire de Kodi, quittez Kodi normalement '
        'avant de supprimer des fichiers temporaires.\n\n'
        'alkoFlix ne touche pas aux fichiers temporaires en cours d\'utilisation.')
    return False


def _obsolete_thumbnail_days(days):
	try: days = int(str(days or '').strip())
	except: days = 15
	return days if days > 0 else 15


def _obsolete_thumbnail_cutoff(days):
	current_date = datetime.date(datetime.utcnow())
	return (current_date - timedelta(days=_obsolete_thumbnail_days(days))).strftime('%Y-%m-%d %H:%M:%S')


def _texture_db_for_obsolete_cleanup():
	for dbfile in _textures_database_candidates():
		try:
			if dbfile.exists(): return dbfile
		except: pass
	try: return Path(xbmcvfs.translatePath(kodi_utils.get_texture_database_path()))
	except: return Path(xbmcvfs.translatePath('special://database'), 'Textures14.db' if _kodi_major_version() >= 22 else 'Textures13.db')


# Les suppressions passent par Kodi, pas par des ecritures directes dans
# Textures13.db. Contrairement au premier essai A15, il n'y a PAS de plafond
# par execution : le nettoyage manuel et automatique parcourent TOUS les
# identifiants admissibles presentes au debut du nettoyage.
# La condition de date est celle de l'ancien nettoyeur (au moins une taille
# dont lastusetime est anterieur au seuil choisi).
# On interroge la base par petits groupes pour ne pas charger tous les IDs
# en memoire et pour interroger Kodi entre les suppressions.
def _obsolete_texture_ids(dbfile, back_date, limit, after_id=0, last_id=None):
    dbcon = None
    try:
        dbcon = database.connect(dbfile.resolve().as_uri() + '?mode=ro', uri=True, timeout=1.0)
        if last_id is None:
            last_id = dbcon.execute('SELECT MAX(idtexture) FROM sizes').fetchone()[0] or 0
        rows = dbcon.execute('''SELECT DISTINCT idtexture FROM sizes
                                WHERE lastusetime < ? AND idtexture > ? AND idtexture <= ?
                                ORDER BY idtexture LIMIT ?''',
                             (back_date, after_id, last_id, limit)).fetchall()
        return [int(row[0]) for row in rows if row and row[0] is not None]
    finally:
        if dbcon is not None: dbcon.close()


def _obsolete_texture_snapshot(dbfile, back_date):
    dbcon = None
    try:
        dbcon = database.connect(dbfile.resolve().as_uri() + '?mode=ro', uri=True, timeout=1.0)
        row = dbcon.execute('''SELECT COUNT(DISTINCT idtexture), MAX(idtexture)
                               FROM sizes WHERE lastusetime < ?''', (back_date,)).fetchone()
        return int(row[0] or 0), int(row[1] or 0)
    finally:
        if dbcon is not None: dbcon.close()


def _kodi_remove_texture(texture_id):
    payload = json.dumps({'jsonrpc': '2.0', 'method': 'Textures.RemoveTexture',
                          'params': {'textureid': int(texture_id)}, 'id': 1})
    response = json.loads(xbmc.executeJSONRPC(payload))
    return str(response.get('result', '')).upper() == 'OK' and 'error' not in response


def _is_playing():
    try: return bool(xbmc.Player().isPlaying())
    except Exception: return False


def clean_obsolete_thumbnails(days=15, silent=True, progress=False):
    days = _obsolete_thumbnail_days(days)
    if _is_playing():
        logger('obsolete thumbnails cleanup', 'deferred: playback is active')
        if not silent: notification('Nettoyage reporte : une lecture est en cours.', 3500)
        return None if silent else 0
    dbfile = _texture_db_for_obsolete_cleanup()
    if not dbfile.exists():
        if not silent: notification(ls(32575))
        return 0
    progress_dialog = None
    removed = 0
    last_processed = 0
    batch_size = 96  # Taille de lecture uniquement, pas une limite de suppressions.
    try:
        back_date = _obsolete_thumbnail_cutoff(days)
        total, upper_id = _obsolete_texture_snapshot(dbfile, back_date)
        if not total:
            logger('obsolete thumbnails cleanup', 'nothing to clean | days=%s' % days)
            if not silent: notification(ls(33190))
            return 0
        if progress:
            progress_dialog = xbmcgui.DialogProgress()
            progress_dialog.create(ls(33191), '')
        while last_processed < upper_id:
            if _is_playing():
                logger('obsolete thumbnails cleanup',
                       'interrupted by playback | days=%s | deleted=%s' % (days, removed))
                if not silent: notification('Nettoyage interrompu : lecture en cours.', 3500)
                return None if silent else removed
            if progress_dialog and progress_dialog.iscanceled():
                logger('obsolete thumbnails cleanup', 'cancelled | deleted=%s' % removed)
                return removed
            ids = _obsolete_texture_ids(dbfile, back_date, batch_size,
                                         after_id=last_processed, last_id=upper_id)
            if not ids: break
            for texture_id in ids:
                # Kodi peut commencer une lecture a tout moment, meme une fois
                # le nettoyage lance. Aucun appel de suppression dans ce cas.
                if _is_playing():
                    logger('obsolete thumbnails cleanup',
                           'interrupted by playback | days=%s | deleted=%s' % (days, removed))
                    if not silent: notification('Nettoyage interrompu : lecture en cours.', 3500)
                    return None if silent else removed
                if progress_dialog and progress_dialog.iscanceled():
                    logger('obsolete thumbnails cleanup', 'cancelled | deleted=%s' % removed)
                    return removed
                if not _kodi_remove_texture(texture_id):
                    logger('obsolete thumbnails cleanup',
                           'Kodi JSON-RPC rejected texture removal; aborting | id=%s' % texture_id)
                    if not silent: notification('Nettoyage incomplet : Kodi a refuse une suppression.', 4000)
                    return None if silent else removed
                removed += 1
                last_processed = texture_id
                if progress_dialog and (removed % 20 == 0 or removed == total):
                    progress_dialog.update(min(100, int(removed * 100 / total)),
                                           '%s / %s' % (removed, total))
            # Permet aux autres taches Kodi de progresser entre deux groupes.
            xbmc.sleep(20)
        logger('obsolete thumbnails cleanup done',
               'days=%s | deleted=%s | eligible_at_start=%s | via=Kodi_JSON_RPC | complete=true' %
               (days, removed, total))
        if not silent: notification('Miniatures obsoletes retirees : %s' % removed, 3000)
        return removed
    except Exception as exc:
        logger('obsolete thumbnails cleanup failed', '%s: %s' % (type(exc).__name__, exc))
        if not silent: notification('Nettoyage des miniatures impossible pour le moment.', 4000)
        return None if silent else removed
    finally:
        if progress_dialog:
            try: progress_dialog.close()
            except Exception: pass


def thumb_cleaner():
	minimum_uses = 30
	days = xbmcgui.Dialog().numeric(0 , ls(33188), defaultt=str(minimum_uses))
	if not days: return notification(ls(33189))
	return clean_obsolete_thumbnails(days=days, silent=False, progress=True)
