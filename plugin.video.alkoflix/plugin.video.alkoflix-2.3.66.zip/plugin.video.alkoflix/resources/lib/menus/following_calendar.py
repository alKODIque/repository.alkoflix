# -*- coding: utf-8 -*-
"""Calendrier des séries suivies, sur sept jours glissants.

Les calendriers de suivi délèguent le rendu à TVShows. Ceux des comptes
Trakt et MDbList regroupent les résultats du moteur Episodes par date locale.
"""

from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import date, datetime, timedelta
from hashlib import sha256

from modules import kodi_utils, settings
from modules.utils import CALENDAR_DAY_OFFSETS

DAYS = CALENDAR_DAY_OFFSETS
RELATIVE_DAY_LABELS = {-1: 32848, 0: 32849, 1: 32850}
WEEKDAY_LABELS = (33282, 33283, 33284, 33285, 33286, 33287, 33288)
SCHEDULE_CACHE_HOURS = 3
DETAIL_CACHE_HOURS = 4
SEASON_CACHE_HOURS = 8
FAILURE_CACHE_MINUTES = 15
REQUEST_WORKERS = 4


def calendar_dates(today=None):
    """Jour du périphérique Kodi, non jour UTC / horaire serveur."""
    today = today or datetime.now().astimezone().date()
    return {offset: (today + timedelta(days=offset)).isoformat() for offset in DAYS}


def calendar_day_label(offset, air_date, widget=False):
    if widget:
        return calendar_widget_label(offset)
    relative_label = RELATIVE_DAY_LABELS.get(offset)
    weekday = kodi_utils.local_string(WEEKDAY_LABELS[date.fromisoformat(air_date).weekday()])
    if relative_label is None:
        return weekday
    return '%s (%s)' % (kodi_utils.local_string(relative_label), weekday)


def calendar_widget_label(offset):
    if offset == -2: return kodi_utils.local_string(33289)
    if offset in RELATIVE_DAY_LABELS: return kodi_utils.local_string(RELATIVE_DAY_LABELS[offset])
    return kodi_utils.local_string(33291 if offset < 0 else 33290) % abs(offset)


def in_calendar_widget(params):
    return (params.get('calendar_widget') == 'true' or kodi_utils.in_calendar_widget_picker()
            or kodi_utils.external_browse())


def _valid_tv_id(value):
    value = str(value or '').strip()
    return value if value.isdigit() and int(value) > 0 else ''


def followed_tv_ids(provider):
    """Réunit historique, reprises et Watchlist du fournisseur effectivement choisi.

    Local = watched.db, Trakt = trakt.db, MDbList = mdblist.db. Une série
    sauvegardée dans une Watchlist est incluse même sans épisode déjà visionné.
    """
    from caches import watched_cache as wc
    ids = set()
    dbcon = None
    try:
        dbcon = wc._database_connect(wc.get_database(provider))
        dbcur = dbcon.cursor()
        for query in (
            "SELECT DISTINCT media_id FROM watched_status WHERE db_type IN ('episode','tvshow')",
            "SELECT DISTINCT media_id FROM progress WHERE db_type IN ('episode','tvshow')",
        ):
            try:
                for (media_id,) in dbcur.execute(query).fetchall():
                    tv_id = _valid_tv_id(media_id)
                    if tv_id: ids.add(tv_id)
            except Exception:
                # Les anciennes installations peuvent ne pas encore posséder
                # une des tables; l'autre source et la Watchlist restent valables.
                continue
    except Exception as e:
        kodi_utils.logger('calendrier suivi DB', '%s: %s' % (type(e).__name__, e))
    finally:
        try:
            if dbcon: dbcon.close()
        except Exception: pass
    try:
        rows, _ = wc.get_active_watchlist_items('tvshow', 1, 'None', paginate=False, watched_indicators=provider)
        for row in rows or []:
            tv_id = _valid_tv_id((row or {}).get('media_id'))
            if tv_id: ids.add(tv_id)
    except Exception as e:
        kodi_utils.logger('calendrier suivi Watchlist', '%s: %s' % (type(e).__name__, e))
    try:
        ids.difference_update(str(i) for i in (wc.get_dropped_tvshow_ids(provider) or []))
    except Exception: pass
    return ids


def _episode_dates(details, target_dates, season_getter=None):
    """Utilise les dates des épisodes (pas la date de première diffusion TV).

    next/last donnent une vérification peu coûteuse; quand l'une de ces dates
    touche la fenêtre, la saison correspondante permet d'identifier plusieurs
    épisodes distincts diffusés dans la période, y compris si next/last ont
    été réactualisés entretemps.
    """
    if not isinstance(details, dict): return set()
    target_dates = set(target_dates)
    matched, seasons = set(), set()
    for key in ('last_episode_to_air', 'next_episode_to_air'):
        episode = details.get(key) or {}
        if not isinstance(episode, dict): continue
        air_date = str(episode.get('air_date') or '')[:10]
        if air_date in target_dates:
            matched.add(air_date)
            try: seasons.add(int(episode.get('season_number')))
            except (TypeError, ValueError): pass
    # Pas de saison à interroger si la série ne diffuse pas dans notre fenêtre.
    if seasons and season_getter:
        for season in sorted(seasons):
            season_details = season_getter(season)
            if not isinstance(season_details, dict): continue
            for episode in season_details.get('episodes') or []:
                if isinstance(episode, dict):
                    air_date = str(episode.get('air_date') or '')[:10]
                    if air_date in target_dates: matched.add(air_date)
    return matched


def _cached_tmdb_payload(kind, tmdb_id, season=None):
    """Cache persistant partagé entre les jours et les menus/widgets.

    N'utilise pas tvshow_details() : cet appel récupère aussi crédits et images,
    alors que seuls les repères de diffusion sont nécessaires ici.
    """
    from caches.main_cache import MainCache
    from indexers import tmdb_api
    from indexers.tmdb_api import get_tmdb
    key = 'followed_series_calendar_v2_%s_%s%s' % (
        kind, tmdb_id, ('_%s' % season) if season is not None else '')
    cache = MainCache()
    try:
        value = cache.get(key)
        if value is not None: return value
    finally:
        try: cache.dbcon.close()
        except Exception: pass
    from indexers.tmdb_api import base_url
    from urllib.parse import quote
    # Seule l'API configurée par l'utilisateur est employée.
    api_key = settings.tmdb_api_key()
    path = 'tv/%s' % quote(str(tmdb_id), safe='')
    if kind == 'season': path += '/season/%s' % int(season)
    url = '%s/%s?api_key=%s&language=en-US' % (base_url, path, quote(str(api_key), safe=''))
    value = get_tmdb(url, errors=False)
    valid = isinstance(value, dict) and (value.get('id') or (kind == 'season' and isinstance(value.get('episodes'), list)))
    if valid:
        value = ({'name': value.get('name') or value.get('original_name') or '',
                  'last_episode_to_air': value.get('last_episode_to_air'),
                  'next_episode_to_air': value.get('next_episode_to_air'),
                  'seasons': [{'season_number': item.get('season_number'), 'air_date': item.get('air_date')}
                              for item in (value.get('seasons') or []) if isinstance(item, dict)]}
                 if kind == 'show' else {'episodes': [
                     {'air_date': episode.get('air_date'), 'episode_number': episode.get('episode_number')}
                     for episode in (value.get('episodes') or []) if isinstance(episode, dict)]})
        expiry = timedelta(hours=SEASON_CACHE_HOURS if kind == 'season' else DETAIL_CACHE_HOURS)
    else:
        # Sur une erreur réseau, ne surtout pas inventer une date de diffusion.
        value = {'_unavailable': True}
        expiry = timedelta(minutes=FAILURE_CACHE_MINUTES)
    cache = MainCache()
    try: cache.set(key, value, expiration=expiry)
    finally:
        try: cache.dbcon.close()
        except Exception: pass
    return value


def _show_airings(tmdb_id, target_dates):
    details = _cached_tmdb_payload('show', tmdb_id)
    if details.get('_unavailable'): return tmdb_id, None, ''
    dates = _episode_dates(
        details, target_dates,
        lambda season: _cached_tmdb_payload('season', tmdb_id, season))
    return tmdb_id, dates, details.get('name') or ''


def _schedule_index(ids, dates, provider):
    """Construit l’index des diffusions pour toute la période en une passe.

    Les bornes écartent les anciens index sur trois jours. La liste exacte des
    suivis permet de prendre en compte une modification de Watchlist/progression.
    """
    from caches.main_cache import MainCache
    ids = sorted(set(filter(None, (_valid_tv_id(i) for i in ids))), key=int)
    target_days = set(dates.values())
    cache_key = 'followed_series_calendar_v1_days_%s_%s_%s_%s' % (
        provider, min(target_days), max(target_days), sha256(','.join(ids).encode('ascii')).hexdigest())
    cache = MainCache()
    try:
        found = cache.get(cache_key)
        if isinstance(found, dict): return found
    finally:
        try: cache.dbcon.close()
        except Exception: pass
    results = {value: [] for value in dates.values()}
    had_errors = False
    if ids:
        with ThreadPoolExecutor(max_workers=REQUEST_WORKERS) as pool:
            tasks = [pool.submit(_show_airings, tv_id, target_days) for tv_id in ids]
            for future in as_completed(tasks):
                try:
                    tv_id, airing_dates, name = future.result()
                    if airing_dates is None:
                        had_errors = True
                        continue
                    for air_date in airing_dates:
                        results[air_date].append((tv_id, name))
                except Exception as e:
                    had_errors = True
                    kodi_utils.logger('calendrier suivi TMDb', '%s: %s' % (type(e).__name__, e))
    # Ne pas geler un résultat partiel si des requêtes TMDb ont échoué.
    for date_key in results:
        results[date_key].sort(key=lambda i: ((i[1] or '').casefold(), int(i[0])))
    index = {'days': results, 'partial': had_errors}
    if not had_errors:
        cache = MainCache()
        try: cache.set(cache_key, index, expiration=timedelta(hours=SCHEDULE_CACHE_HOURS))
        finally:
            try: cache.dbcon.close()
            except Exception: pass
    return index


def _filter_context(ids, progress_group='', catalogue_section=''):
    """Même séparation de catalogue que tous les menus Vos suivis de lecture."""
    from caches import watched_cache as wc
    ids = list(ids)
    allowed = wc._progress_catalogue_ids('tvshow', catalogue_section)
    if allowed is not None: ids = [i for i in ids if i in allowed]
    if not ids: return ids
    from modules import parental_control
    filter_group = progress_group not in ('', 'all', 'global', 'combined')
    filter_parental = parental_control.applies_to_action('following_calendar', 'tvshow')
    if not (filter_group or filter_parental): return ids
    from indexers import metadata
    from modules.utils import get_datetime
    meta_user_info = settings.metadata_user_info()
    current_date = get_datetime()
    filtered = []
    for tv_id in ids:
        try:
            meta = metadata.tvshow_meta('tmdb_id', tv_id, meta_user_info, current_date)
            if not meta or meta.get('blank_entry'): continue
            if filter_group and not wc._progress_matches_context('tvshow', meta, progress_group): continue
            if filter_parental and not parental_control.meta_allowed(meta, 'following_calendar', 'tvshow'): continue
            filtered.append(tv_id)
        except Exception: continue
    return filtered


def _calendar_provider(params):
    try:
        return int(params.get('watched_indicators', ''))
    except (ValueError, TypeError):
        try: return int(settings.watched_indicators())
        except (ValueError, TypeError): return 0


def _calendar_schedule(params, dates):
    provider = _calendar_provider(params)
    if provider not in (0, 1, 2): provider = 0
    ids = followed_tv_ids(provider)
    return provider, ids, _schedule_index(ids, dates, provider)


def _filter_calendar_scope(ids, params):
    return _filter_context(ids, str(params.get('progress_group') or '').lower(),
                           str(params.get('progress_catalogue_section') or ''))


def _notify_partial_schedule(index):
    if index['partial']:
        kodi_utils.notification('Calendrier : certaines dates TMDb sont temporairement indisponibles', time=3500)


def visible_calendar_days(params):
    dates = calendar_dates()
    _, _, index = _calendar_schedule(params, dates)
    days = index['days']
    # Filtrer chaque série une seule fois, même si elle diffuse plusieurs jours.
    ids = dict.fromkeys(tv_id for rows in days.values() for tv_id, _ in rows)
    allowed = set(_filter_calendar_scope(ids, params))
    _notify_partial_schedule(index)
    available = {day for day, rows in days.items() if any(tv_id in allowed for tv_id, _ in rows)}
    return calendar_folder_days(dates, available)


def calendar_folder_days(dates, available=None):
    # Les widgets exposent tous les jours, même sans diffusion. Ne jamais
    # transmettre un libellé None à une liste Kodi (Omega/Piers).
    if available is None:
        return [(offset, calendar_widget_label(offset)) for offset in dates]
    return [(offset, calendar_day_label(offset, day)) for offset, day in dates.items() if day in available]


def add_calendar_day_folders(navigator, context, days, prefix=''):
    for offset, label in days:
        params = dict(context, day_offset=str(offset), name=calendar_widget_label(offset))
        navigator._add_item(params, 'calendar.png', prefix, display_name=label if label is not None else '')
    navigator._end_directory(menu_kind='calendar' if days else '')


def _page(items, page_no, enabled, limit):
    items = list(items)
    if not enabled: return items, 1
    limit = max(1, int(limit))
    total_pages = max(1, (len(items) + limit - 1) // limit)
    start = (max(1, page_no) - 1) * limit
    return items[start:start + limit], total_pages


def _publish_calendar_page(ku, handle, params, items):
    try: page_no = max(1, int(params.get('new_page', '1')))
    except (TypeError, ValueError): page_no = 1
    shown, total_pages = _page(items, page_no, settings.paginate(), settings.page_limit())
    if shown: ku.add_items(handle, shown)
    if total_pages > page_no:
        new_params = {k: v for k, v in params.items() if k not in ('handle', 'fanart', 'iconImage')}
        new_params['new_page'] = str(page_no + 1)
        ku.add_dir(handle, new_params, ku.local_string(32799), ku.media_path('item_next.png'))
    return len(shown), page_no, total_pages


def _calendar_episode_rows(tmdb_id, air_date, window_dates):
    """Épisodes exacts d'une série suivie pour un jour, depuis le cache de saison.

    L'index du calendrier reste inchangé (IDs séries, cache stable) ; seul le
    rendu des jours -2 à 0 a besoin d'identifier les SxxEyy. Les saisons
    consultées pour construire l'index sont normalement déjà en cache.
    """
    details = _cached_tmdb_payload('show', tmdb_id)
    if details.get('_unavailable'): return []
    seasons = set()
    for key in ('last_episode_to_air', 'next_episode_to_air'):
        episode = details.get(key) or {}
        if not isinstance(episode, dict): continue
        if str(episode.get('air_date') or '')[:10] not in window_dates: continue
        try: seasons.add(int(episode['season_number']))
        except (KeyError, ValueError, TypeError): continue
    rows = []
    seen = set()
    for season in sorted(seasons):
        season_data = _cached_tmdb_payload('season', tmdb_id, season)
        if season_data.get('_unavailable'): continue
        for episode in season_data.get('episodes') or []:
            if not isinstance(episode, dict): continue
            if str(episode.get('air_date') or '')[:10] != air_date: continue
            try: episode_no = int(episode.get('episode_number'))
            except (ValueError, TypeError): continue
            if episode_no <= 0 or (season, episode_no) in seen: continue
            seen.add((season, episode_no))
            rows.append({'media_ids': {'tmdb': str(tmdb_id)},
                         'season': season, 'episode': episode_no,
                         'account_air_date': air_date})
    return rows


def _calendar_series_items(params, ids):
    from menus.tvshows import TVShows
    if not ids: return []
    worker = TVShows(dict(params, list=ids, action='following_calendar', ignore_menu_hide_watched='true'))
    return sorted(worker.worker(), key=lambda entry: (entry[1].getLabel() or '').casefold())


def render_calendar_day(params):
    """Épisodes de J-2 à J ; séries à partir de J+1, uniquement pour les suivis."""
    from modules import kodi_utils as ku
    handle = int(params['handle'])
    try: offset = int(params.get('day_offset', 0))
    except (ValueError, TypeError): offset = 0
    if offset not in DAYS: offset = 0
    dates = calendar_dates()
    selected_date = dates[offset]
    recent_day = offset in (-2, -1, 0)
    ku.logger('calendrier suivis', 'phase=début | jour=%s | format=%s' % (
        selected_date, 'episodes' if recent_day else 'series'))
    provider, ids, index = _calendar_schedule(params, dates)
    day_ids = _filter_calendar_scope([tv_id for tv_id, _ in index['days'].get(selected_date, [])], params)
    build_params = dict(params)
    build_params.update({'action': 'following_calendar', 'watched_indicators': str(provider),
                         'ignore_menu_hide_watched': 'true'})
    if recent_day:
        from menus.episodes import Episodes
        episode_rows = []
        for tmdb_id in day_ids:
            episode_rows.extend(_calendar_episode_rows(tmdb_id, selected_date, set(dates.values())))
        # Conserver un ordre stable pour les widgets et la pagination.
        episode_rows.sort(key=lambda row: (int(row['media_ids']['tmdb']), row['season'], row['episode']))
        for index_no, row in enumerate(episode_rows, 1): row['sort'] = index_no
        build_params['list'] = episode_rows
        worker = Episodes(build_params)
        worker.list_type = 'trakt_calendar'
        items = worker.worker() if episode_rows else []
        if ku.current_skin_id() == 'skin.arctic.fuse.3':
            # Éviter que le panneau AF3 double le numéro déjà dans le titre.
            for _, item, _ in items:
                info = item.getVideoInfoTag(offscreen=True)
                info.setSeason(-1)
                info.setEpisode(-1)
        content_type, sort_type, view_type = 'episodes', 'unsorted', 'view.episodes_lists'
        candidates = len(episode_rows)
    else:
        items = _calendar_series_items(build_params, day_ids)
        content_type, sort_type, view_type = 'tvshows', 'tvshows', 'view.tvshows'
        candidates = len(day_ids)
    shown_count, page_no, total_pages = _publish_calendar_page(ku, handle, params, items)
    ku.set_category(handle, calendar_day_label(offset, selected_date, widget=in_calendar_widget(params)))
    ku.set_sort_method(handle, sort_type)
    ku.set_content(handle, content_type)
    ku.end_directory(handle, False)  # Pas de mise en cache Kodi à travers minuit.
    if ku.current_skin_id() != 'skin.arctic.fuse.3':
        ku.set_view_mode(view_type, content_type)
    ku.logger('calendrier suivis', 'fournisseur=%s | jour=%s | candidats=%s | médias=%s | page=%s/%s | partiel=%s' % (
        provider, selected_date, candidates, shown_count, page_no, total_pages, index['partial']))
    _notify_partial_schedule(index)


def _provider_air_date(value):
    """Convertit un horodatage du fournisseur en date locale Kodi."""
    value = str(value or '').strip()
    try:
        if len(value) == 10: return date.fromisoformat(value).isoformat()
        return datetime.fromisoformat(value.replace('Z', '+00:00')).astimezone().date().isoformat()
    except ValueError:
        return ''


def _provider_calendar_source(mode):
    from indexers.mdblist_api import mdbl_get_my_calendar
    from indexers.trakt_api import trakt_anime_calendar, trakt_get_my_calendar, trakt_my_anime_calendar
    if mode == 'build_mdbl_calendar': return mdbl_get_my_calendar
    if mode == 'build_my_anime_calendar': return trakt_my_anime_calendar
    if mode == 'build_anime_calendar': return trakt_anime_calendar
    return lambda today: trakt_get_my_calendar(False, today)


def _add_provider_calendar_folders(params, days, widget, category):
    from menus.navigator import Navigator
    navigator = Navigator(dict(params, name=category))
    context = {key: value for key, value in params.items()
               if key in ('mode', 'watched_indicators', 'calendar_group', 'catalogue_section', 'fav_type', 'catalogue_id', 'catalog_id')}
    if widget:
        context['calendar_widget'] = 'true'
    add_calendar_day_folders(navigator, context, days)


def render_provider_calendar(params, handle, category, menu=None):
    """Affiche des dossiers de jours, ou les épisodes du seul jour sélectionné."""
    today = menu.current_date if menu else datetime.now().astimezone().date()
    dates = calendar_dates(today)
    requested = params.get('day_offset')
    day_selected = requested not in (None, '')
    widget = in_calendar_widget(params)
    if not day_selected and widget:
        return _add_provider_calendar_folders(params, calendar_folder_days(dates), True, category)

    target = None
    offset = 0
    if day_selected:
        try: offset = int(requested)
        except (TypeError, ValueError): pass
        target = dates.get(offset)

    mode = params['mode']
    public = mode == 'navigator.catalogue_calendar'
    if public and not day_selected:
        from menus.catalogue_calendar import available_days
        available = available_days(params, dates.values())
        return _add_provider_calendar_folders(params, calendar_folder_days(dates, available), False, category)

    if public and target and params.get('catalogue_section'):
        from menus.catalogue_calendar import catalogue_day_items
        series = offset > 0
        try:
            items = catalogue_day_items(params, target, series)
        except Exception as exc:
            kodi_utils.logger('calendrier alkoPaste', '%s | %s' % (target, type(exc).__name__))
            items = []
        label = calendar_day_label(offset, target, widget=widget)
        return _finish_provider_day(handle, params, label, items, series)

    allowed_dates = {target} if day_selected else set(dates.values())
    if menu is None:
        from menus.episodes import Episodes
        menu = Episodes(params)
    menu.list_type = 'trakt_calendar'
    episodes = []
    try:
        if not day_selected or target:
            if public:
                from menus.catalogue_calendar import catalogue_episodes
                episodes = catalogue_episodes(params, target)
            else:
                episodes = _provider_calendar_source(mode)(today) or []
    except Exception as exc:
        kodi_utils.logger('calendrier compte', '%s | %s' % (mode, type(exc).__name__))
        episodes = []
    menu.list = []
    for episode in episodes:
        air_date = _provider_air_date(episode.get('first_aired'))
        if air_date and air_date not in allowed_dates: continue
        menu.list.append(dict(episode, account_air_date=air_date))
    menu.list.sort(key=lambda row: row.get('sort_title', ''))
    items = menu.worker() if menu.list else []

    if not day_selected:
        available = {item.getProperty('alkoflix_first_aired') for _, item, _ in items}
        return _add_provider_calendar_folders(params, calendar_folder_days(dates, available), False, category)

    results = [entry for entry in items if entry[1].getProperty('alkoflix_first_aired') == target]
    label = calendar_day_label(offset, target, widget=widget) if target else category
    _finish_provider_day(handle, params, label, results)


def _finish_provider_day(handle, params, label, results, series=False):
    arctic_fuse = kodi_utils.current_skin_id() == 'skin.arctic.fuse.3'
    if arctic_fuse and not series:
        # AF3 affiche déjà le numéro d'épisode dans le titre.
        for _, item, _ in results:
            info = item.getVideoInfoTag(offscreen=True)
            info.setSeason(-1)
            info.setEpisode(-1)
    _publish_calendar_page(kodi_utils, handle, params, results)
    kodi_utils.set_category(handle, label)
    kodi_utils.set_sort_method(handle, 'unsorted')
    content = 'tvshows' if series else 'episodes'
    if series:
        kodi_utils.set_content(handle, content)
    else:
        kodi_utils.set_menu_content(handle, default_content=content)
    kodi_utils.end_directory(handle, False)
    if not arctic_fuse:
        kodi_utils.set_view_mode('view.tvshows' if series else 'view.episodes_lists', content)
