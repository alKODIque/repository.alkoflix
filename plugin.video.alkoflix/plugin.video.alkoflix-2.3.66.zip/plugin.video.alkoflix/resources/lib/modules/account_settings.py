"""État local des comptes gérés par les actions de connexion d’alkoFlix."""

import os
import sqlite3
from contextlib import closing
from pathlib import Path


ACCOUNT_SETTINGS = frozenset((
    'ad.token', 'ad.account_id',
    'rd.token', 'rd.refresh', 'rd.client_id', 'rd.secret', 'rd.username',
    'tb.token', 'tb.account_id',
    'trakt.token', 'trakt.refresh', 'trakt.expires', 'trakt_user', 'trakt_indicators_active',
    'mdblist.token', 'mdblist.auth_type', 'mdblist.access_token', 'mdblist.refresh_token',
    'mdblist.expires', 'mdblist.client_id', 'mdblist_user', 'mdbl_indicators_active',
    'tmdb.token', 'tmdb.account_id', 'tmdb.username', 'tmdb.session_id', 'tmdb.session_account_id',
    'alkopastes.api_key_user', 'alkopastes.api_mode',
))


def _connect(profile_directory):
    directory = Path(profile_directory)
    directory.mkdir(parents=True, exist_ok=True)
    path = directory / 'account_settings.db'
    os.close(os.open(path, os.O_CREAT | os.O_WRONLY, 0o600))
    return sqlite3.connect(path, timeout=10)


def _ensure_table(connection):
    connection.execute('CREATE TABLE IF NOT EXISTS account_settings (id TEXT PRIMARY KEY, value TEXT NOT NULL)')


def read(profile_directory, legacy_settings=None):
    """Importe les comptes existants sans réactiver une connexion explicitement effacée."""
    with closing(_connect(profile_directory)) as connection, connection:
        _ensure_table(connection)
        saved = dict(connection.execute('SELECT id, value FROM account_settings'))
        if legacy_settings:
            missing = (ACCOUNT_SETTINGS & legacy_settings.keys()) - saved.keys()
            if missing:
                connection.executemany(
                    'INSERT OR IGNORE INTO account_settings (id, value) VALUES (?, ?)',
                    [(key, legacy_settings[key]) for key in missing],
                )
                saved = dict(connection.execute('SELECT id, value FROM account_settings'))
        return saved


def write(profile_directory, key, value):
    # Une valeur vide est enregistrée aussi : elle représente une déconnexion explicite.
    with closing(_connect(profile_directory)) as connection, connection:
        _ensure_table(connection)
        connection.execute('PRAGMA secure_delete = ON')
        connection.execute(
            'INSERT INTO account_settings (id, value) VALUES (?, ?) '
            'ON CONFLICT(id) DO UPDATE SET value = excluded.value WHERE value != excluded.value',
            (key, value),
        )
