Icônes alkoFlix - Coal 1.0.0

Ce pack est activé automatiquement par alkoFlix 2.1.27 ou plus récent lorsqu’il est installé.
Aucune copie manuelle dans plugin.video.alkoflix n’est nécessaire.

Installation du pack  -> icônes Coal
Désinstallation du pack -> icônes alkoFlix d’origine

Les fichiers non prévus pour recevoir le fond Coal sont inclus sans modification dans le miroir media afin de garantir un repli visuel complet.
